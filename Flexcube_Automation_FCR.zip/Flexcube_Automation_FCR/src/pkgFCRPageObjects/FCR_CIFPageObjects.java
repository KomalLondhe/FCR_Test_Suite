                package pkgFCRPageObjects;

import java.util.HashMap;
import java.util.Map;

import utility.WebDr;

public class FCR_CIFPageObjects {
                public static void Customer_Addition_8053(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("CustomerIC", "ID|NationalID|fraTxn/showdata");
        My_Page_Objects.put("Category", "ID|CustomerType");
        My_Page_Objects.put("Language", "ID|Language");
        My_Page_Objects.put("ShortName", "ID|ShortName");
        My_Page_Objects.put("FullName", "ID|FullNameCust");
        My_Page_Objects.put("Salutation", "ID|Prefix");
        My_Page_Objects.put("FirstName", "ID|FirstName|fraTxn/showdata");
        My_Page_Objects.put("MiddleName", "ID|MiddleName|fraTxn/showdata");
        My_Page_Objects.put("LastName", "ID|LastName|fraTxn/showdata");
        My_Page_Objects.put("AddressLine1", "ID|Addr1");
        My_Page_Objects.put("AddressLine2", "ID|Addr2");
        My_Page_Objects.put("AddressLine3", "ID|Addr3");
        My_Page_Objects.put("City", "ID|City");
        My_Page_Objects.put("State", "ID|StateProv");
        My_Page_Objects.put("Country", "ID|Country");
        My_Page_Objects.put("Nationality", "ID|Nationality");
        My_Page_Objects.put("ResidentCountry", "ID|Residence");
        My_Page_Objects.put("Zipcode", "ID|Zip");
        My_Page_Objects.put("Fax", "ID|ctlMailFax");
        My_Page_Objects.put("DateOfBirth", "ID|BirthDate");
        My_Page_Objects.put("Phone1", "ID|PhoneCntry");
        My_Page_Objects.put("Phone2", "ID|PhoneArea");
        My_Page_Objects.put("Phone3", "ID|Phone");
        My_Page_Objects.put("OfficePhone1", "ID|OffPhoneCntry");
        My_Page_Objects.put("OfficePhone2", "ID|OffPhoneArea");
        My_Page_Objects.put("OfficePhone3", "ID|OffPhone");
        My_Page_Objects.put("OfficePhone4", "ID|OffPhoneExt");
        My_Page_Objects.put("CustEducation", "ID|Education");
        My_Page_Objects.put("MobileNo", "ID|Mobile");
        My_Page_Objects.put("Email", "ID|Email");
        My_Page_Objects.put("Mail", "ID|ctlMailTelex");
        My_Page_Objects.put("Gender", "ID|Sex");
        My_Page_Objects.put("Designation", "ID|ctlDesignation");
        My_Page_Objects.put("IncomeCategory", "ID|cmbIncomeCategory");
        My_Page_Objects.put("MaritalStatus", "ID|MaritalStatus");
        My_Page_Objects.put("Business", "ID|PicklistBus");
        My_Page_Objects.put("Business_kenya", "ID|Business");
        My_Page_Objects.put("Profession", "ID|Profession|fraTxn/showdata");
        My_Page_Objects.put("AMLRating", "ID|flgAml|fraTxn/showdata");
        My_Page_Objects.put("PEP", "ID|flgPep");
        My_Page_Objects.put("InternationalTxn", "ID|flgInternatTran");
        My_Page_Objects.put("IssuingAuth", "ID|issueAuth");
        My_Page_Objects.put("Issuingbranch", "ID|brnIssue");
        My_Page_Objects.put("IssuingDate", "ID|datIssue");
        My_Page_Objects.put("CIVDate", "ID|datCiv");
        My_Page_Objects.put("Staff_flag", "ID|FlgStaff|fraTxn/showdata");
        My_Page_Objects.put("Employee_ID", "ID|EmployeeId|fraTxn/showdata");
        My_Page_Objects.put("BirthPlace", "ID|birthPlace");
        My_Page_Objects.put("ValidateCustomer", "ID|btnValdCust");
        My_Page_Objects.put("8053_OK", "ID|btnOk|fraTxn/showdata");
        My_Page_Objects.put("Kenya_OK", "ID|btnOk|fraTxn/showdata");
      
        
        WebDr.page_Objects = My_Page_Objects;
        
                 }
                
                public static void Customer_Inquiry_CIM09(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("InquiryBtn", "XPATH|//input[@value='i']|fraTxn/showdata");
        My_Page_Objects.put("SearchCriteria", "ID|cmbSearchCriteria");
        My_Page_Objects.put("SearchString", "ID|ctlCustInfo");
        My_Page_Objects.put("CustomerID", "ID|lblID|fraTxn/showdata");
        My_Page_Objects.put("Close_CIM09", "XPATH|//input[@id='ctlClose']|fraTxn/showdata");
        WebDr.page_Objects = My_Page_Objects;
        
                 }
                public static void Customer_Activation() {
                Map<String, String> My_Page_Objects = new HashMap<String, String>();
    My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
    My_Page_Objects.put("SearchCriteria_CIM33", "ID|CbSeleCriteria|fraTxn/showdata");
    My_Page_Objects.put("CustomerID_CIM33", "ID|ctlCustID");
    My_Page_Objects.put("Post_CIM33", "XPATH|//input[@id='ctlPost']|fraTxn/showdata");
    My_Page_Objects.put("Action", "ID|CbAction|fraTxn/showdata");
    My_Page_Objects.put("SearchCriteria_CIM34", "ID|CbSeleCriteria|fraTxn/showdata");
    My_Page_Objects.put("CustomerID_CIM34", "ID|ctlCustID");
    My_Page_Objects.put("CIM34_OK", "ID|ctlOK");
    
    
    WebDr.page_Objects = My_Page_Objects;
    
 }
                
                public static void Customer_Search_1000(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("SearchBy", "ID|SearchCrit|fraTxn/showdata");
        My_Page_Objects.put("SearchString1", "ID|SearchStr|fraTxn/showdata");
        My_Page_Objects.put("CustIDRow","XPATH|//tr[@class='TGridNormal']/td[1]|fraTxn/showdata");
        My_Page_Objects.put("OK_1000", "ID|btnOk");
        My_Page_Objects.put("CustomerID", "NAME|CustID|Base/showdata");
        My_Page_Objects.put("FullName", "NAME|CustName|Base/showdata");
//        My_Page_Objects.put("CustomerIC", "XPATH|//td[contains(text(),'National ID')]|Base/showdata");
        My_Page_Objects.put("CustomerIC", "XPATH|//b[contains(text(),'National')]|Base/showdata");
        My_Page_Objects.put("Customer_Type", "XPATH|//b[contains(text(),'Category')]");
        My_Page_Objects.put("HomeBranch", "XPATH|//b[contains(text(),'Home Branch')]");
        WebDr.page_Objects = My_Page_Objects;
        
                 }
                
                
                public static void Customer_Modify_CIM09(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("ModifyBtn", "XPATH|//input[@value='m']|fraTxn/showdata");
        My_Page_Objects.put("SearchCriteria", "ID|cmbSearchCriteria");
        My_Page_Objects.put("SearchString", "ID|ctlCustInfo");
        My_Page_Objects.put("Clear_CIM09", "ID|ctlClear");
//       My_Page_Objects.put("CustomerMIS", "XPATH|//a[contains(text(),'Customer MIS Info')]fraTxn/showdata");
//       My_Page_Objects.put("CompositeMIS", "XPATH|//a[contains(text(),'Composite MIS Info')]");
//        My_Page_Objects.put("CustomerMIS", "LINKTEXT|Customer MIS Info"); //a[@id='Tab6Anchor']/child::label
//        My_Page_Objects.put("CustomerMIS", "LINKTEXT|Composite MIS Info");
       My_Page_Objects.put("CustomerMIS", "XPATH|//a/label[contains(text(),'Customer MIS Info')]|fraTxn/showdata");
       My_Page_Objects.put("CompositeMIS", "XPATH|//a/label[contains(text(),'Composite MIS Info')]");
       /* My_Page_Objects.put("CustomerMIS", "LINKTEXT|Customer MIS Info|fraTxn/showdata");
        My_Page_Objects.put("CompositeMIS", "LINKTEXT|Composite MIS Info");
       */ 
       My_Page_Objects.put("BIC", "ID|ctlMisCodeCustomer_1");
       My_Page_Objects.put("MarketSegment", "ID|ctlMisCodeCustomer_2");
       My_Page_Objects.put("Residence", "ID|ctlMisCodeCustomer_3");
       My_Page_Objects.put("CompanyCode", "ID|ctlMisCodeCustomer_4");
      // My_Page_Objects.put("CPB", "ID|ctlMisCodeCustomer_5");
       My_Page_Objects.put("ReferStream", "ID|ctlMisCodeComposite_1"); 
       My_Page_Objects.put("ProfitCost", "ID|ctlMisCodeComposite_2"); 
       My_Page_Objects.put("TradingPartner", "ID|ctlMisCodeComposite_3"); 
       My_Page_Objects.put("SalesCode", "ID|ctlMisCodeComposite_4"); 
       My_Page_Objects.put("CIM09_OK", "ID|ctlOK");
      // My_Page_Objects.put("PEP", "XPATH|//table[@id='UDF']/tbody/tr[5]/td[3]/select[@id='UDFValue']|fraPop/showdata");
       My_Page_Objects.put("PEP", "XPATH|//table[@id='UDF']/tbody[2]/tr[6]/td[3]/child::select|fraPop/showdata");
       My_Page_Objects.put("KYCDate", "XPATH|//table[@id='UDF']/tbody[2]/tr[8]/td[3]/child::input|fraPop/showdata");
       My_Page_Objects.put("KYCIndicator", "XPATH|//table[@id='UDF']/tbody[2]/tr[10]/td[3]/child::select|fraPop/showdata");
       My_Page_Objects.put("AddressVerification", "XPATH|//table[@id='UDF']/tbody[2]/tr[11]/td[3]/child::select|fraPop/showdata");
       My_Page_Objects.put("AddressVerifier", "XPATH|//table[@id='UDF']/tbody[2]/tr[12]/td[3]/child::input|fraPop/showdata");
      // My_Page_Objects.put("KYCindicator", "XPATH|//select[@id='UDFValue']/child::option|fraPop/showdata");
       My_Page_Objects.put("Validate","ID|btnValidate");
       My_Page_Objects.put("BackButton","ID|Back");
       My_Page_Objects.put("IndividualCustomerInfo", "XPATH|//a[@id='Tab3Anchor']/child::label|fraTxn/showdata");
       My_Page_Objects.put("Designation", "ID|ctlDesignation");
       My_Page_Objects.put("BasicInformation", "XPATH|//a[@id='Tab0Anchor']/child::label|fraTxn/showdata");
       My_Page_Objects.put("EmployeeID", "ID|ctlEmployeeId");
        My_Page_Objects.put("CIM09_OK", "ID|ctlOK");
        My_Page_Objects.put("AuthorizeBtn", "XPATH|//input[@value='z']|fraTxn/showdata");
        My_Page_Objects.put("CIM09Authorize_OK", "ID|ctlOK|fraTxn/showdata");
        
       
        WebDr.page_Objects = My_Page_Objects;
        
                 }
                
                public static void Customer_Modify_CIM09_BBK(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("ModifyBtn", "XPATH|//input[@value='m']|fraTxn/showdata");
        My_Page_Objects.put("SearchCriteria", "ID|cmbSearchCriteria");
        My_Page_Objects.put("SearchString", "ID|ctlCustInfo");
        My_Page_Objects.put("Clear_CIM09", "ID|ctlClear");
        My_Page_Objects.put("CustomerMIS", "XPATH|//a/label[contains(text(),'Customer MIS Info')]|fraTxn/showdata");
        My_Page_Objects.put("CompositeMIS", "XPATH|//a/label[contains(text(),'Composite MIS Info')]");
        My_Page_Objects.put("BIC", "ID|ctlMisCodeCustomer_1");
        My_Page_Objects.put("MarketSegment", "ID|ctlMisCodeCustomer_2");
        My_Page_Objects.put("Residence", "ID|ctlMisCodeCustomer_3");
        My_Page_Objects.put("CompanyCode", "ID|ctlMisCodeCustomer_4");
        My_Page_Objects.put("WorkplaceRanking", "ID|ctlMisCodeCustomer_5");
        My_Page_Objects.put("CountryResidence", "ID|ctlMisCodeCustomer_6");
        My_Page_Objects.put("CustomerExp", "ID|ctlMisCodeCustomer_7");
        My_Page_Objects.put("BawEmployerCode", "ID|ctlMisCodeCustomer_8");
        My_Page_Objects.put("ESDCode", "ID|ctlMisCodeCustomer_9");
        My_Page_Objects.put("BorrowingHistory1", "ID|ctlMisCodeCustomer_10");
       // My_Page_Objects.put("CPB", "ID|ctlMisCodeCustomer_5");
        My_Page_Objects.put("ReferStream", "ID|ctlMisCodeComposite_1"); 
        My_Page_Objects.put("ProfitCost", "ID|ctlMisCodeComposite_2"); 
        My_Page_Objects.put("TradingPartner", "ID|ctlMisCodeComposite_3"); 
        My_Page_Objects.put("SalesCode", "ID|ctlMisCodeComposite_4");
        My_Page_Objects.put("CPF", "ID|ctlMisCodeComposite_5");
        My_Page_Objects.put("AgricValue", "ID|ctlMisCodeComposite_6");
        My_Page_Objects.put("BorrowingHistory2", "ID|ctlMisCodeComposite_7");
        My_Page_Objects.put("IndividualCustomerInfo", "XPATH|//a/label[contains(text(),'Individual Customer Info')]|fraTxn/showdata");
        My_Page_Objects.put("SourceofFunds", "ID|ctlSrcFunds");
        My_Page_Objects.put("IncomeCategory", "XPATH|//select[@id='cmbIncomeCategory']");
        My_Page_Objects.put("PlaceofBirth", "ID|ctlPlaceBrth");
        My_Page_Objects.put("BasicInformation", "XPATH|//a/label[contains(text(),'Basic Information')]|fraTxn/showdata");
        My_Page_Objects.put("IncomeTaxNum", "ID|ctlIncomeTaxNo");
        My_Page_Objects.put("CIM09_OK", "ID|ctlOK");
     
        My_Page_Objects.put("PEP", "XPATH|//table[@id='UDF']/tbody[2]/tr[7]/td[3]/child::select|fraPop/showdata");
        My_Page_Objects.put("KYCDate", "XPATH|//table[@id='UDF']/tbody[2]/tr[2]/td[3]/child::input|fraPop/showdata");
        My_Page_Objects.put("KYCIndicator", "XPATH|//table[@id='UDF']/tbody[2]/tr[1]/td[3]/child::select|fraPop/showdata");
        My_Page_Objects.put("AddressVerification", "XPATH|//table[@id='UDF']/tbody[2]/tr[3]/td[3]/child::select|fraPop/showdata");
        My_Page_Objects.put("AddressVerifier", "XPATH|//table[@id='UDF']/tbody[2]/tr[4]/td[3]/child::input|fraPop/showdata");
        My_Page_Objects.put("NetMonthSalary", "XPATH|//table[@id='UDF']/tbody[2]/tr[5]/td[3]/child::input|fraPop/showdata");
        My_Page_Objects.put("OtherIncome", "XPATH|//table[@id='UDF']/tbody[2]/tr[6]/td[3]/child::input|fraPop/showdata");
        My_Page_Objects.put("RiskAssessment", "XPATH|//table[@id='UDF']/tbody[2]/tr[8]/td[3]/child::select|fraPop/showdata");
        My_Page_Objects.put("ParentCompany", "XPATH|//table[@id='UDF']/tbody[2]/tr[11]/td[3]/child::select|fraPop/showdata");
        My_Page_Objects.put("CountryofRegistration", "XPATH|//table[@id='UDF']/tbody[2]/tr[12]/td[3]/child::select|fraPop/showdata");
        My_Page_Objects.put("ComplexStructure", "XPATH|//table[@id='UDF']/tbody[2]/tr[21]/td[3]/child::select|fraPop/showdata");
        
        
       // My_Page_Objects.put("KYCindicator", "XPATH|//select[@id='UDFValue']/child::option|fraPop/showdata");
        My_Page_Objects.put("Validate","ID|btnValidate");
        My_Page_Objects.put("BackButton","ID|Back");
        My_Page_Objects.put("IndividualCustomerInfo", "XPATH|//a[@id='Tab3Anchor']/child::label|fraTxn/showdata");
        My_Page_Objects.put("Designation", "ID|ctlDesignation");
        My_Page_Objects.put("BasicInformation", "XPATH|//a[@id='Tab0Anchor']/child::label|fraTxn/showdata");
        My_Page_Objects.put("EmployeeID", "ID|ctlEmployeeId");
         My_Page_Objects.put("CIM09_OK", "ID|ctlOK");
         My_Page_Objects.put("AuthorizeBtn", "XPATH|//input[@value='z']|fraTxn/showdata");
         My_Page_Objects.put("CIM09Authorize_OK", "ID|ctlOK|fraTxn/showdata");
        
        WebDr.page_Objects = My_Page_Objects;

                }

public static void Bill_Payment_by_Cash_1025(){
   Map<String, String> My_Page_Objects = new HashMap<String, String>();
   My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
   My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
   My_Page_Objects.put("CompanyID", "ID|IssuerCode|fraTxn/showdata");
   My_Page_Objects.put("BillNumber", "ID|DocNo");
   My_Page_Objects.put("ConsumerNo", "ID|ConsumerNo");
   My_Page_Objects.put("AccountNo", "ID|AccountNo");
   My_Page_Objects.put("BillCcy", "ID|ACY_Code");
   My_Page_Objects.put("TxnCcy", "ID|TCY_Code");
   My_Page_Objects.put("BillAmount", "ID|ACY_Amount");
   My_Page_Objects.put("BillRemitName", "ID|BillRemitName");
   My_Page_Objects.put("BillRemitID", "ID|BillRemitID");
   My_Page_Objects.put("BillAmountAccount", "ID|TCY_Amount");
   My_Page_Objects.put("Fee", "ID|fldCpbCharge");
   My_Page_Objects.put("ReferenceNo1", "ID|BillRefNo1");
   My_Page_Objects.put("ReferenceNo2", "ID|BillRefNo2");
   My_Page_Objects.put("UserReference", "ID|User_Ref_No");
   My_Page_Objects.put("RemitterName", "ID|BillRemitName|fraTxn/showdata");
   My_Page_Objects.put("RemitterID", "ID|BillRemitID");
   My_Page_Objects.put("UserNarrative", "ID|UsrNarrative");
   My_Page_Objects.put("MandatoryUDF1", "XPATH|//table[@id='UDF']/tbody[2]/tr[1]/td[3]/child::input|fraPop/showdata");
   My_Page_Objects.put("MandatoryUDF2", "XPATH|//table[@id='UDF']/tbody[2]/tr[2]/td[3]/child::input|fraPop/showdata");
   My_Page_Objects.put("Denomination", "XPATH|//input[@value='UPDATEDENOMINATION']/parent::td/following-sibling::td[2]/input|fraPop/showdata");
   My_Page_Objects.put("Validate","ID|btnValidate|fraPop/showdata" );
   My_Page_Objects.put("Back","ID|Back|fraPop/showdata" );
   My_Page_Objects.put("D_OK", "ID|btnOk");
   
   My_Page_Objects.put("Sign","XPATH|//input[@id='PhotoImage' and @value='1']|fraPop/showdata" );
   My_Page_Objects.put("SignOk","ID|btnOkImage");
   My_Page_Objects.put("SignZoom","XPATH|//input[@name='ZoomIN']");
   My_Page_Objects.put("SignVerified","ID|btnSign|fraPop/showdata");
   My_Page_Objects.put("SignCancel","ID|btnCancel");

   
  // My_Page_Objects.put("Count", "XPATH|(//input[@value='10 shilling coin']/parent::td/following-sibling::td[2]/input|fraPop/showdata");
//   My_Page_Objects.put("Count", "XPATH|//input[@value='10 shilling coin']//following-sibling::td[2]//input[@id='UserCount']|fraPop/showdata");
    My_Page_Objects.put("OK_1025", "ID|btnOk|fraTxn/showdata");
    My_Page_Objects.put("StatusBar","ID|StatusBar|bottom/");
                WebDr.page_Objects = My_Page_Objects;
   
}


                public static void Customer_Relation_CI141(){
                
                    Map<String, String> My_Page_Objects = new HashMap<String, String>();
                    My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
                    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
                    My_Page_Objects.put("AddBtn", "XPATH|//input[@value='a']|fraTxn/showdata");
                    My_Page_Objects.put("SearchCriteria", "ID|cmbSearchCriteria|fraTxn/showdata");
                    My_Page_Objects.put("SearchString", "ID|ctlCustInfo");
                    My_Page_Objects.put("InputBy", "ID|InputBy");
                    My_Page_Objects.put("SearchCriteria1", "ID|cmbSearchCriteria1|fraTxn/showdata");
                    My_Page_Objects.put("SearchString1", "ID|ctlCustInfo1");
                    My_Page_Objects.put("Picklist1", "ID|ctlPickListrelcod1|fraTxn/showdata");
                    My_Page_Objects.put("Picklist2", "ID|ctlPickListrelcod2|fraTxn/showdata");
                    My_Page_Objects.put("Relation", "ID|txtrelcode");
                    My_Page_Objects.put("InvRelation", "ID|txtinvrelcode");
                    My_Page_Objects.put("ShareHold", "ID|ctlShareHold");
                    My_Page_Objects.put("OK_CI141", "ID|ctlOK|fraTxn/showdata");
                   
                    My_Page_Objects.put("Modify_CI141", "XPATH|//input[@value='m']|fraTxn/showdata");
        My_Page_Objects.put("Inversion_Relation_Code", "ID|txtinvrelcode|fraTxn/showdata"); 
        My_Page_Objects.put("Share_Holding_Percent", "ID|ctlShareHold|fraTxn/showdata");
        My_Page_Objects.put("CLOSE_CI141", "ID|ctlClose|fraTxn/showdata"); 
        My_Page_Objects.put("Delete_CI141", "XPATH|//input[@value='d']|fraTxn/showdata");
                WebDr.page_Objects = My_Page_Objects;
    
                }
                
                public static void Cust_Sign_Link_7102(){
                                
                    Map<String, String> My_Page_Objects = new HashMap<String, String>();
                    
                    My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
                    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
                    My_Page_Objects.put("ImageType","ID|ImageType|fraTxn/showdata");
                    My_Page_Objects.put("CustomerID","ID|CustID");
                    My_Page_Objects.put("SelectionCriteria","ID|SelCriteria");
                    My_Page_Objects.put("OK_7102","ID|btnOkImage|fraTxn/showdata");
                    My_Page_Objects.put("CLOSE_7102", "ID|ctlClose|fraTxn/showdata");
                    My_Page_Objects.put("SignZoom","XPATH|//input[@name='ZoomIN']");
                    My_Page_Objects.put("Browse","XPATH|//input[@id='Browse1']");
                    My_Page_Objects.put("Image_OK", "XPATH|//input[@value='Ok']");
                    WebDr.page_Objects = My_Page_Objects;
                    
                }

                public static void Customer_MemoMaintenance_CIM13() {
                                // TODO Auto-generated method stub
                                Map<String, String> My_Page_Objects = new HashMap<String, String>();
                    My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
                    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
                    My_Page_Objects.put("MemoAdd", "XPATH|//input[@name='ctlMntToolBar' and @value='a']|fraTxn/showdata");
                    My_Page_Objects.put("MemoDelete", "XPATH|//input[@name='ctlMntToolBar' and @value='d']|fraTxn/showdata");
                    My_Page_Objects.put("MemoAuth", "XPATH|//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");
                    My_Page_Objects.put("MemoModify", "XPATH|//input[@name='ctlMntToolBar' and @value='m']|fraTxn/showdata");
                    My_Page_Objects.put("SearchCriteria","ID|cmbSearchCriteria");
                    My_Page_Objects.put("CustomerSearchString","ID|ctlCustInfo|fraTxn/showdata");
                    My_Page_Objects.put("LabelCustID","XPATH|//td/input[@id='lblID']|fraTxn/showdata");
                    My_Page_Objects.put("MemoReason","XPATH|//input[@id='ctlCodReason']|fraTxn/showdata");
                    My_Page_Objects.put("MemoTextArea","XPATH|//textarea[@id='ctlMemoText']|fraTxn/showdata");
                    My_Page_Objects.put("Fullname","XPATH|//input[@id='lblFullName']|fraTxn/showdata");
                    My_Page_Objects.put("MemoSeverity","XPATH|//input[@id='cmbSeverity']|fraTxn/showdata");
                    My_Page_Objects.put("MemoText","XPATH|//input[@id='ctlMemoText']|fraTxn/showdata");
                    My_Page_Objects.put("OK_CIM13","ID|ctlOK|fraTxn/showdata");
                    My_Page_Objects.put("Clear_CIM13","ID|ctlClear|fraTxn/showdata");
                    WebDr.page_Objects = My_Page_Objects;
                }

                public static void Bill_Payment_by_Cheque_6575() {
                                // TODO Auto-generated method stub
                                Map<String, String> My_Page_Objects = new HashMap<String, String>();
                                   My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
                                   My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
                                   My_Page_Objects.put("CompanyID", "ID|IssuerCode|fraTxn/showdata");
                                  My_Page_Objects.put("BillNumber", "ID|DocNo");
                                   My_Page_Objects.put("ConsumerNo", "ID|ConsumerNo");
                                   My_Page_Objects.put("AccountNo", "ID|AccountNo");
                                   My_Page_Objects.put("BillCcy", "ID|ACY_Code");
                                   My_Page_Objects.put("TxnCcy", "ID|TCY_Code");
                                   My_Page_Objects.put("BillAmount", "ID|ACY_Amount");
                                   My_Page_Objects.put("BillAmountAccount", "ID|TCY_Amount");
                                   My_Page_Objects.put("Fee", "ID|fldCpbCharge");
                                   My_Page_Objects.put("ReferenceNo1", "ID|BillRefNo1");
                                   My_Page_Objects.put("ReferenceNo2", "ID|BillRefNo2");
                                   My_Page_Objects.put("UserReference", "ID|User_Ref_No");
                                   My_Page_Objects.put("ClearingType", "ID|ChqClgType|fraPop/showdata");
                                   My_Page_Objects.put("ChqNo", "ID|ChqNo");
                                   My_Page_Objects.put("ChqLiteral", "ID|ChqLiteral");
                                   My_Page_Objects.put("ChqDate", "ID|ChqDate");
                                   My_Page_Objects.put("ChqRoutingNo", "ID|ChqRoutingNo");
                                   My_Page_Objects.put("DraweeAcct", "ID|DraweeAcct");
                                   My_Page_Objects.put("Commision", "ID|Commision");
                                   My_Page_Objects.put("D_OK", "ID|btnOk");
                                   My_Page_Objects.put("OK_6575", "ID|btnOk|fraTxn/showdata");
                                   WebDr.page_Objects = My_Page_Objects;
                }
                
                public static void Customer_Type_MNT_CIM08() {
                                Map<String, String> My_Page_Objects = new HashMap<String, String>();
                                   My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
                                   My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
                                   My_Page_Objects.put("ModifyBtn", "XPATH|//input[@value='m']|fraTxn/showdata");
                                   My_Page_Objects.put("MemoAdd", "XPATH|.//input[@name='ctlMntToolBar' and @value='a']|fraTxn/showdata");
                                   My_Page_Objects.put("CustTypeCode", "ID|ctlCustTypeCod|fraTxn/showdata");
                                   My_Page_Objects.put("CustTypeName", "ID|ctlCustTypeName");
                                   My_Page_Objects.put("CorporateFlag", "ID|ctlCbCorp");
                                   My_Page_Objects.put("IdentificationCriteria", "ID|ctlICTypes");
                                   My_Page_Objects.put("ICValidationCheckBox", "ID|ctlIcValReq");
                                   My_Page_Objects.put("ExternalValidationCheckBox", "ID|ctlExtValReq|fraTxn/showdata");
                                   My_Page_Objects.put("ExternalValidationDescription", "ID|ctlExtValDesc|fraTxn/showdata");
                                   My_Page_Objects.put("ExternalValidationURL", "ID|ctlExtValUrl");
                                   My_Page_Objects.put("TaxCode1", "ID|ctlPicklistCodTds");
                                   My_Page_Objects.put("TaxCode2", "ID|ctlPicklistCodTds_2|fraTxn/showdata");
                                   My_Page_Objects.put("OK_CIM08","ID|ctlOK|fraTxn/showdata");
                                   WebDr.page_Objects = My_Page_Objects; 
                                   
                                   
                                   
                }
                
                public static void Customer_Memo_CIM13() {
                                Map<String, String> My_Page_Objects = new HashMap<String, String>();
                                  My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
                                   My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
                                   My_Page_Objects.put("AddBtn", "XPATH|//input[@value='a']|fraTxn/showdata");
                                   My_Page_Objects.put("ModifyBtn", "XPATH|//input[@value='m']|fraTxn/showdata");
                                   My_Page_Objects.put("AuthorizeBtn", "XPATH|//input[@value='z']|fraTxn/showdata");
                                   My_Page_Objects.put("SearchCriteria", "ID|cmbSearchCriteria|fraTxn/showdata");
                                   My_Page_Objects.put("SearchString", "ID|ctlCustInfo|fraTxn/showdata");
                                   My_Page_Objects.put("MemoReason", "ID|ctlCodReasonInq");
                                   My_Page_Objects.put("Severity", "ID|cmbSeverity");
                                   My_Page_Objects.put("MemoText", "ID|ctlMemoText");
                                  
                                   My_Page_Objects.put("OK_CIM13","ID|ctlOK|fraTxn/showdata");
                                
                                 
                                 WebDr.page_Objects = My_Page_Objects; 
                }
}
        
       