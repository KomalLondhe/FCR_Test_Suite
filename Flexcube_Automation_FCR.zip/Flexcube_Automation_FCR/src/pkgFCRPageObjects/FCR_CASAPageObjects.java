package pkgFCRPageObjects;

import java.util.HashMap;
import java.util.Map;

import pkgFCRResuableModule.Clearing;
import utility.WebDr;

public class FCR_CASAPageObjects {

	public static void CASAAcctOpening_8051(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("BranchName","ID|AccountBrn|fraTxn/showdata" );
        My_Page_Objects.put("ProductName","ID|ProductCode" );
        My_Page_Objects.put("AccountTitle","ID|AcctTitle" );
        My_Page_Objects.put("SerialNo","ID|SerialNo" );
        My_Page_Objects.put("CustomerIC1","ID|NationalID1" );
        My_Page_Objects.put("CustomerIC2","ID|NationalID2" );
        My_Page_Objects.put("CustomerIC3","ID|NationalID3" );
        My_Page_Objects.put("Category1","ID|CustomerType1|fraTxn/showdata" );
        My_Page_Objects.put("Category2","ID|CustomerType2" );
        My_Page_Objects.put("Category3","ID|CustomerType3" );
        My_Page_Objects.put("Relation1","ID|CustomerAcctRel1|fraTxn/showdata" );
        My_Page_Objects.put("Relation2","ID|CustomerAcctRel2" );
        My_Page_Objects.put("Relation3","ID|CustomerAcctRel3" );
        My_Page_Objects.put("OfficerID","ID|OfficerID" );
        My_Page_Objects.put("TaxCode","ID|TaxCode" );
        My_Page_Objects.put("TaxCode2","ID|TaxCode_2" );
        My_Page_Objects.put("ChequeBookRequest","ID|FlgChBkReq" );
        My_Page_Objects.put("InterestWaiver","ID|FlgIntWav" );
        My_Page_Objects.put("NoOfLeaves","ID|NoOfChqLeaves" );
        My_Page_Objects.put("RestrictedAcct","ID|Restricted" );
        My_Page_Objects.put("DepositTerm","ID|RdDepTerm" );
        My_Page_Objects.put("MinorAcctStatus","ID|RdMinorAcct" );
        My_Page_Objects.put("CreditIntVar","ID|RdCrIntVar" );
        My_Page_Objects.put("DebitIntVar","ID|RdDrIntVar" );
        My_Page_Objects.put("InstallmentAmt","ID|RdInstAmt" );
        My_Page_Objects.put("Validate","ID|btnValdCust" );
        My_Page_Objects.put("Ok","ID|btnOk|fraTxn/showdata" );
	    My_Page_Objects.put("SystemDate","XPATH|//input[@id='PostDate']|fraMenu/left");
        My_Page_Objects.put("UDFDate","XPATH|//input[@id='UDFValue'][1]|fraPop/showdata" );
        My_Page_Objects.put("UDFValidate","XPATH|//input[@id='btnValidate']");
        My_Page_Objects.put("UDFBack","XPATH|//input[@id='Back']");
        My_Page_Objects.put("CustPick","ID|CustSearch1|");
        My_Page_Objects.put("SelectSearchCriteria", "ID|SearchCrit|fraPop/showdata");
        My_Page_Objects.put("SearchValue", "ID|SearchStr");
        My_Page_Objects.put("SelectRow", "XPATH|//tr[@class='TGridNormal']");
		WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void CashDeposit_1401(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("AccountNo","ID|AccountNo|fraTxn/showdata" );
        My_Page_Objects.put("TxnCurrency","ID|TCY_Code");
        My_Page_Objects.put("TxnAmount","ID|TCY_Amount" );
        My_Page_Objects.put("DepositorID","ID|TaxPayerID");
        My_Page_Objects.put("DepositorName","ID|TaxPayerName");
        My_Page_Objects.put("UserRefNo","ID|User_Ref_No|fraTxn/showdata" );
        My_Page_Objects.put("Ok","ID|btnOk|fraTxn/showdata" );
        My_Page_Objects.put("Sign","XPATH|.//input[@id='PhotoImage' and @value='1']|fraPop/showdata" );
       // My_Page_Objects.put("Sign","ID|PhotoImage|fraPop/showdata" );
        My_Page_Objects.put("SignOk","ID|btnOkImage");
        My_Page_Objects.put("SignZoom","XPATH|//input[@name='ZoomIN']");
        My_Page_Objects.put("SignVerified","ID|btnSign|fraPop/showdata");
        My_Page_Objects.put("SignCancel","ID|btnCancel");
        My_Page_Objects.put("StatusBar","ID|StatusBar|bottom/");
        My_Page_Objects.put("Denomination", "XPATH|//input[@value='UPDATEDENOMINATION']/parent::td/following-sibling::td[2]/input|fraPop/showdata");
        My_Page_Objects.put("D_Ok","ID|btnOk|fraPop/showdata" );
        My_Page_Objects.put("Validate","ID|btnValidate|fraPop/showdata" );
        My_Page_Objects.put("Back","ID|Back|fraPop/showdata" );
        //UDFs
        My_Page_Objects.put("MandatoryUDF1", "XPATH|//table[@id='UDF']/tbody[2]/tr[3]/td[3]/child::input|fraPop/showdata");
        My_Page_Objects.put("MandatoryUDF2", "XPATH|//table[@id='UDF']/tbody[2]/tr[4]/td[3]/child::input|fraPop/showdata");
        My_Page_Objects.put("MandatoryUDF3", "XPATH|//table[@id='UDF']/tbody[2]/tr[5]/td[3]/child::input|fraPop/showdata");
        
        WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void FundsTransferRequest_1006(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("FromAcctNo","ID|AccountNo|fraTxn/showdata" );
        My_Page_Objects.put("ToAcctNo","ID|ToAccountNo" );
        My_Page_Objects.put("FromAmount","ID|ACY_Amount" );
        My_Page_Objects.put("UserRefNo","ID|User_Ref_No" );
        My_Page_Objects.put("DepositorID","ID|TaxPayerID" );
        My_Page_Objects.put("DepositorName","ID|TaxPayerName" );
        My_Page_Objects.put("Sign","XPATH|.//input[@id='PhotoImage' and @value='1']|fraPop/showdata" );
        // My_Page_Objects.put("Sign","ID|PhotoImage|fraPop/showdata" );
         My_Page_Objects.put("SignOk","ID|btnOkImage");
         My_Page_Objects.put("SignZoom","XPATH|//input[@name='ZoomIN']");
         My_Page_Objects.put("SignVerified","ID|btnSign|fraPop/showdata");
         My_Page_Objects.put("SignCancel","ID|btnCancel");
         My_Page_Objects.put("StatusBar","ID|StatusBar|bottom/");
        My_Page_Objects.put("Ok","ID|btnOk" );

        
		WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void CashWithdrawal_1001(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("AccountNo","ID|AccountNo|fraTxn/showdata" );
        My_Page_Objects.put("TxnCurrency","ID|TCY_Code" );
        My_Page_Objects.put("Retail","ID|ACLCY_Rate" );
        My_Page_Objects.put("Amount","ID|TCY_Amount" );
        My_Page_Objects.put("Fee","ID|fldCpbCharge" );

        My_Page_Objects.put("Narrative","ID|Narrative" );
        My_Page_Objects.put("UserRefNo","ID|User_Ref_No" );
        My_Page_Objects.put("Sign","XPATH|.//input[@id='PhotoImage' and @value='1']|fraPop/showdata");
        My_Page_Objects.put("SignOk","ID|btnOkImage|fraPop/showdata" );
        My_Page_Objects.put("SignZoom","XPATH|//input[@name='ZoomIN']");
        My_Page_Objects.put("SignVerified","ID|btnSign|fraPop/showdata" );
        My_Page_Objects.put("SignCancel","ID|btnCancel|fraPop/showdata");
        My_Page_Objects.put("Denomination", "XPATH|//input[@value='UPDATEDENOMINATION']/parent::td/following-sibling::td[2]/input|fraPop/showdata");
        My_Page_Objects.put("D_Ok","ID|btnOk|fraPop/showdata" );
        My_Page_Objects.put("StatusBar","ID|StatusBar|bottom/");
        My_Page_Objects.put("Ok","ID|btnOk|fraTxn/showdata" );

		WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void AcctClosingBalInfo_CH001(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        
		WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void CustomerSearch_1000(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("SearchBy","ID|SearchCrit|fraTxn/showdata" );
        My_Page_Objects.put("SearchString","ID|SearchStr");
        My_Page_Objects.put("CustIDRow","XPATH|//tr[@class='TGridNormal']/td[1]|fraTxn/showdata");
        My_Page_Objects.put("OK_1000", "ID|btnOk");
        My_Page_Objects.put("CustomerID", "NAME|CustID|Base/showdata");
        WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void Account_Closing_CH001(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("AccountNo","ID|CtlChAcctNo|fraTxn/showdata");
        My_Page_Objects.put("ClosingReason","ID|ctlcodreason1"); 
        My_Page_Objects.put("OK_CH001", "ID|ctlOK");
        My_Page_Objects.put("CLOSE_CH001", "ID|ctlClose|fraTxn/showdata");
        My_Page_Objects.put("CLEAR_CH001", "ID|ctlClear|fraTxn/showdata");
        My_Page_Objects.put("AddBtn", "XPATH|//input[@value='a']|fraTxn/showdata");
        My_Page_Objects.put("AuthorizeBtn", "XPATH|//input[@value='z']|fraTxn/showdata");
        
        
        WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void Account_Open_Today_CH021() {
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
	        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	        My_Page_Objects.put("AccountNo","XPATH|//input[@id='CtlChAcctNo']|fraTxn/showdata");
	        My_Page_Objects.put("AccountInfo", "XPATH|//a[@id='Tab3Anchor']/child::label|fraTxn/showdata");
	        My_Page_Objects.put("AccountStatus","XPATH|//select[@name='CodAcctStat']|fraTxn/showdata");
	        WebDr.page_Objects = My_Page_Objects;
	        
	}
	
	public static void CashWithdrawalInvalid_1001(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("AccountNo","ID|AccountNo|fraTxn/showdata" );
        My_Page_Objects.put("TxnCurrency","ID|TCY_Code" );
        My_Page_Objects.put("Retail","ID|ACLCY_Rate" );
        My_Page_Objects.put("Amount","ID|TCY_Amount" );
        My_Page_Objects.put("Fee","ID|fldCpbCharge" );
        My_Page_Objects.put("Narrative","ID|Narrative" );
        My_Page_Objects.put("UserRefNo","ID|User_Ref_No" );
        My_Page_Objects.put("Sign","XPATH|.//input[@id='PhotoImage' and @value='1']|fraPop/showdata");
        My_Page_Objects.put("SignOk","ID|btnOkImage|fraPop/showdata" );
        My_Page_Objects.put("SignZoom","XPATH|//input[@name='ZoomIN']");
        My_Page_Objects.put("SignVerified","ID|btnSign|fraPop/showdata");
        My_Page_Objects.put("SignCancel","ID|btnCancel|fraPop/showdata");
        My_Page_Objects.put("Denomination", "XPATH|//input[@value='UPDATEDENOMINATION']/parent::td/following-sibling::td[2]/input|fraPop/showdata");
        My_Page_Objects.put("D_Ok","ID|btnOk|fraPop/showdata" );

        My_Page_Objects.put("Ok","ID|btnOk|fraTxn/showdata" );

		WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void ProductMasterMaintenance_CHM01(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	     My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	     My_Page_Objects.put("ProductCodePickList","ID|ctlProdCodePick|fraTxn/showdata" );
	     My_Page_Objects.put("ProductCode","ID|ctlmskProdCode|fraTxn/showdata" );
	     My_Page_Objects.put("CHM01_Clear", "ID|ctlClear|fraTxn/showdata");
	    // My_Page_Objects.put("FacilitiesTab","ID|lblSSTab1|fraTxn/showdata" );
	    // My_Page_Objects.put("ChequeBoxFlag","ID|ctlFlgChqBk" );
	     
	     WebDr.page_Objects = My_Page_Objects;
	}
	
	
	public static void CASAInterestRateTiersMaintenance_CHM02(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	     My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	     
	     My_Page_Objects.put("PlanCodePickList","ID|ctlPlanPickList|fraTxn/showdata" );
	     My_Page_Objects.put("PlanCode","ID|ctlmskPlanCode|fraTxn/showdata" );
	     My_Page_Objects.put("Modify", "XPATH|//input[@name='ctlMntToolBar' and @value='m']|fraTxn/showdata");
         My_Page_Objects.put("CLOSE_CHM02", "ID|ctlClose|fraTxn/showdata");

	     WebDr.page_Objects = My_Page_Objects;
	}
	

	public static void CASA_Account_Status_CHM21(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	     My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	     My_Page_Objects.put("AcctNo", "ID|CtlChAcctNo|fraTxn/showdata");
	     My_Page_Objects.put("CurrentAccStatus", "ID|ctlCurrentAcctStat");
	     My_Page_Objects.put("StatusChoice", "ID|cmbChoice");
	     My_Page_Objects.put("StatusReason", "ID|ctlcodreason");
	     My_Page_Objects.put("OK_CHM21", "ID|ctlOK");
	     	
	     WebDr.page_Objects = My_Page_Objects;
	}
	public static void CASA_CH021_Authorize(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	     My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	     My_Page_Objects.put("AuthorizeBtn", "XPATH|//input[@value='z']|fraTxn/showdata");
	     My_Page_Objects.put("AcctNo", "ID|CtlChAcctNo|fraTxn/showdata");
	     My_Page_Objects.put("OK_CH021", "ID|ctlOK|fraTxn/showdata");
	     WebDr.page_Objects = My_Page_Objects;
	}

	public static void CASSViewAccountStatement_CH031() {
		// TODO Auto-generated method stub
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	     My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	     My_Page_Objects.put("SystemDate","XPATH|//input[@id='PostDate']|fraMenu/left");
	     My_Page_Objects.put("AccountNo", "ID|CtlCodAcctNo|fraTxn/showdata");
	     My_Page_Objects.put("RadioTransaction", "ID|optTrnPrd|fraTxn/showdata");
	     My_Page_Objects.put("StartDate", "ID|ctlStartDate|fraTxn/showdata");
	     My_Page_Objects.put("EndDate", "ID|ctlStartDate_ctlCal");
	     My_Page_Objects.put("Inquire", "ID|cmdInquire");
	     My_Page_Objects.put("Txn_Table_Date", "XPATH|//table[@id='MSFlexGrid1']//td[contains(text(),'"+(WebDr.getValue("Txn_Date"))+"')]|fraTxn/showdata");
	     My_Page_Objects.put("Txn_Table_Instruction1", "XPATH|//table[@id='MSFlexGrid1']//td[contains(text(),'"+(WebDr.getValue("Txn_Instruction1"))+"')]|fraTxn/showdata");
	     My_Page_Objects.put("Txn_Table_Instruction2", "XPATH|//table[@id='MSFlexGrid1']//td[contains(text(),'"+(WebDr.getValue("Txn_Instruction2"))+"')]|fraTxn/showdata");
	     My_Page_Objects.put("Txn_Table_Instruction3", "XPATH|//table[@id='MSFlexGrid1']//td[contains(text(),'"+(WebDr.getValue("Txn_Instruction3"))+"')]|fraTxn/showdata");
	     My_Page_Objects.put("ModifiedAccount", "XPATH|//table[@id='MSFlexGrid1']//td[contains(text(),'"+(WebDr.getValue("ModifiedAccount"))+"')]|fraTxn/showdata");
	     My_Page_Objects.put("CANCEL_CH031", "ID|ctlClose|fraTxn/showdata");
	     WebDr.page_Objects = My_Page_Objects;
	}

	public static void CASAModifyCustomerShortName_7101() {
		// TODO Auto-generated method stub
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	     My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	     My_Page_Objects.put("ChangeType", "ID|ChangeType|fraTxn/showdata");
	     My_Page_Objects.put("CustomerIC", "ID|NationalID");
	     My_Page_Objects.put("CustomerType", "ID|CustomerType");
	     My_Page_Objects.put("NewShortName", "ID|NewShortName");
	     My_Page_Objects.put("OK", "XPATH|//input[@name='btnOk']");
	     WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void Cust_SignPhoto_Delink_7103() {
		// TODO Auto-generated method stub
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		    
	    My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	    My_Page_Objects.put("ImageType","ID|ImageType|fraTxn/showdata");
	    My_Page_Objects.put("CustomerID","ID|CustID");
	    My_Page_Objects.put("SelectionCriteria","ID|SelCriteria");
	    My_Page_Objects.put("OK_7102","ID|btnOkImage|fraTxn/showdata");
	    My_Page_Objects.put("Image_OK", "XPATH|//input[@value='Ok']");
	    WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void CASA_Invalid_Standing_Instruction() {
		// TODO Auto-generated method stub
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		    
	    My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	    My_Page_Objects.put("AddBtn", "XPATH|//input[@value='a']|fraTxn/showdata");
	    My_Page_Objects.put("AccountNo", "ID|CtlChAcctNo|fraTxn/showdata");
	    //This facility is not supported
	    WebDr.page_Objects = My_Page_Objects;
	   
	}
	
	public static void CASA_SweepIN_CHM39() {
		// TODO Auto-generated method stub
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		    
	    My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	    My_Page_Objects.put("AddBtn", "XPATH|//input[@value='a']|fraTxn/showdata");
	    My_Page_Objects.put("ModifyBtn", "XPATH|//input[@value='m']|fraTxn/showdata");
	    My_Page_Objects.put("AccountNo", "ID|CtlChAcctNo|fraTxn/showdata");
	    My_Page_Objects.put("InstructionNumber", "ID|ctlInstructionNo|fraTxn/showdata");    
	    My_Page_Objects.put("SweepInAccountNo", "ID|CtlSwpinAcctNo");
	    My_Page_Objects.put("CHM39_OK", "ID|ctlOK");
	    My_Page_Objects.put("CHM39_Close", "ID|ctlClose|fraTxn/showdata");
	    My_Page_Objects.put("CHM39_Clear", "ID|ctlClear|fraTxn/showdata");
	    My_Page_Objects.put("AuthorizeBtn", "XPATH|//input[@value='z']|fraTxn/showdata");
	    My_Page_Objects.put("Instr_No", "ID|ctlInstructionNo");
	    WebDr.page_Objects = My_Page_Objects;
	   
	}
	
	public static void Reversal_6006() {
		// TODO Auto-generated method stub
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 
		    My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		    My_Page_Objects.put("AccountNo", "ID|AccountNo|fraTxn/showdata");
		    My_Page_Objects.put("FromSequenceNum", "ID|FromSeqNo");
		    My_Page_Objects.put("ToSequenceNum", "ID|ToSeqNo");
		    My_Page_Objects.put("ToTransactionTime", "ID|ToTxnTime");
		    My_Page_Objects.put("FromTransactionTime", "ID|FromTxnTime");
		    My_Page_Objects.put("FromAmount", "ID|FromAmount");
		    My_Page_Objects.put("ToAmount", "ID|ToAmount");
		    My_Page_Objects.put("Mnemonic", "ID|Literal|fraTxn/showdata");
		    My_Page_Objects.put("GET_Btn", "ID|Fetch|fraTxn/showdata");
		    My_Page_Objects.put("Reversal_Btn", "ID|Reversal|fraPop/showdata"); 
		    My_Page_Objects.put("State", "XPATH|//tr[@class='TGridNormal']/td[6]|fraTxn/showdata"); 
		    
		    
		    
		 WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void ReportCategory_Request(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 
		    My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		   // My_Page_Objects.put("Report_type", "ID|radio1|fraTxn/showdata");
		    My_Page_Objects.put("Report_type", "XPATH|//input[@id='radio1' and contains(text(),'"+(WebDr.getValue("Report_type"))+"']|fraTxn/showdata");
		   
		    My_Page_Objects.put("Category", "XPATH|//table[@id='TabTbl']//td[contains(text(),'"+(WebDr.getValue("CategoryName"))+"')]|fraTxn/showdata");
		    My_Page_Objects.put("Report_Group", "XPATH|//table[@id='SideTbl'][1]//td[contains(text(),'"+(WebDr.getValue("ReportGroup"))+"')]|fraTxn/showdata");
		   
		    My_Page_Objects.put("Report_ID", "XPATH|//tr[@id='CH220']/td[contains(text(),'"+(WebDr.getValue("ReportID"))+"')]");
		    
		    
		    WebDr.page_Objects = My_Page_Objects;
		    
		
	}
	
	public static void ReportCategory_Request_7778(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 
		    My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		   // My_Page_Objects.put("Report_type", "ID|radio1|fraTxn/showdata");
		    My_Page_Objects.put("View_btn", "ID|btnView|fraTxn/showdata");
		    
		    
		    WebDr.page_Objects = My_Page_Objects;
		    
		
	}
	
	
	

	public static void ReportCategory_Request_CH220(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		    My_Page_Objects.put("SystemDate","XPATH|//input[@id='PostDate']|fraMenu/left");
		    My_Page_Objects.put("AccountNo", "XPATH|//input[@id='Param' and @rownum='1']|fraTxn/showdata");
		    My_Page_Objects.put("FromDate", "XPATH|//input[@id='Param' and @rownum='2']|fraTxn/showdata");
		    My_Page_Objects.put("ToDate", "XPATH|//input[@id='Param' and @rownum='3']");
		    My_Page_Objects.put("WaiveSC", "XPATH|//input[@id='Param' and @rownum='4']");
		    My_Page_Objects.put("ValueDate", "XPATH|//input[@id='Param' and @rownum='5']");
		    My_Page_Objects.put("ValueDate", "XPATH|//input[@id='Param' and @rownum='5']");
		    My_Page_Objects.put("Generate_btn", "ID|btnGenerate|fraTxn/showdata");
		    My_Page_Objects.put("LoggedInUser", "XPATH|//select[@id='UserID']|fraTxn/showdata");
		    My_Page_Objects.put("View_btn", "ID|btnView|fraTxn/showdata");
		    
		 
		 WebDr.page_Objects = My_Page_Objects;
		    
			
		}
	
	public static void ReportCategory_Request_GL008(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 	My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		    My_Page_Objects.put("SystemDate","XPATH|//input[@id='PostDate']|fraMenu/left");
		    My_Page_Objects.put("GLAccountNo", "XPATH|//input[@id='Param' and @rownum='1']|fraTxn/showdata");
		    My_Page_Objects.put("BranchCode", "XPATH|//input[@id='Param' and @rownum='2']|fraTxn/showdata");
		    My_Page_Objects.put("FromDate", "XPATH|//input[@id='Param' and @rownum='3']");
		    My_Page_Objects.put("ToDate", "XPATH|//input[@id='Param' and @rownum='4']");
		    My_Page_Objects.put("Generate_btn", "ID|btnGenerate|fraTxn/showdata");

		    WebDr.page_Objects = My_Page_Objects;
		    
			
	}
	public static void CASAModifyCustomerID_CIM39() {
		// TODO Auto-generated method stub
	
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	     My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	     My_Page_Objects.put("ModifyBtn", "XPATH|//input[@value='m']|fraTxn/showdata");
	     My_Page_Objects.put("AuthorizeBtn", "XPATH|//input[@value='z']|fraTxn/showdata");
	     My_Page_Objects.put("SearchCriteria", "ID|cmbSearchCriteria|fraTxn/showdata");
	     My_Page_Objects.put("CustInfo", "ID|ctlCustInfo|fraTxn/showdata");
	     My_Page_Objects.put("NewSearchCriteria1", "ID|cmbSearchCriteria1");
	     My_Page_Objects.put("NewCustInfo1", "ID|ctlCustInfo1");
	     My_Page_Objects.put("OK", "XPATH|//input[@id='cmdOk']|fraTxn/showdata");
	     My_Page_Objects.put("OK_CIM39", "XPATH|//input[@id='cmdCommit']");
		WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void BalanceInquiry_7002(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		 My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		 My_Page_Objects.put("AccountNumber", "XPATH|//input[@id='AccountNo']|fraTxn/showdata");
		 My_Page_Objects.put("Available_Balance", "ID|Available|fraTxn/showdata");
		 My_Page_Objects.put("CANCEL_7002", "XPATH|//input[@id='btnCancel']");
		 WebDr.page_Objects = My_Page_Objects;
	}

	public static void CASA_Modify_AccountAddress_CHM36() {
		// TODO Auto-generated method stub
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		 My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		 My_Page_Objects.put("ModifyBtn", "XPATH|//input[@value='m']|fraTxn/showdata");
		 My_Page_Objects.put("AuthorizeBtn", "XPATH|//input[@value='z']|fraTxn/showdata");
		 My_Page_Objects.put("AccountNumber", "XPATH|//input[@id='CtlChAcctNo']");
		 My_Page_Objects.put("SerialNumber", "XPATH|//input[@id='tbSerialno']");
		 My_Page_Objects.put("Address1", "XPATH|//input[@id='tbAcctAdrsTxt1']");
		 My_Page_Objects.put("Address2", "XPATH|//input[@id='tbAcctAdrsTxt2']");
		 My_Page_Objects.put("Address3", "XPATH|//input[@id='tbAcctAdrsTxt3']");
		 My_Page_Objects.put("OK", "XPATH|//input[@id='ctlOK']");
		 WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void CASA_StandingInstruction_CHM31() {
		// TODO Auto-generated method stub
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		 My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		 My_Page_Objects.put("SystemDate","XPATH|//input[@id='PostDate']|fraMenu/left");
		  My_Page_Objects.put("AddBtn", "XPATH|//input[@value='a']|fraTxn/showdata");
		    My_Page_Objects.put("AccountNo", "ID|CtlChAcctNo|fraTxn/showdata");
		    My_Page_Objects.put("InstructionNumber", "ID|ctlInstrNo|fraTxn/showdata");
		    My_Page_Objects.put("InstructionType", "ID|cmbInstrType|fraTxn/showdata");
		    My_Page_Objects.put("PriorityNo", "ID|ctlPriority|fraTxn/showdata");
		    My_Page_Objects.put("ForceDebit", "ID|ctlForceDebit|fraTxn/showdata");
		    My_Page_Objects.put("Freqeuncy", "ID|ctlFrequency|fraTxn/showdata");
		    My_Page_Objects.put("Amount", "ID|ctlAmount|fraTxn/showdata");
		     My_Page_Objects.put("BenefAccountNo", "ID|CtlBenefAcctNo|fraTxn/showdata");
		     My_Page_Objects.put("StartDate", "ID|ctlStartDate|fraTxn/showdata");
		     My_Page_Objects.put("EndDate", "ID|ctlEndDate|fraTxn/showdata");
		     My_Page_Objects.put("NextDate", "ID|ctlNextDate|fraTxn/showdata");
		     My_Page_Objects.put("Retries", "ID|ctlNoOfRetries|fraTxn/showdata");
		     My_Page_Objects.put("Narrative", "ID|ctlNarrative");  
		    My_Page_Objects.put("CHM31_OK", "ID|ctlOK");
		    My_Page_Objects.put("CHM31_Close", "ID|ctlClose|fraTxn/showdata");
		    My_Page_Objects.put("ModifyBtn", "XPATH|//input[@value='m']|fraTxn/showdata");
		    My_Page_Objects.put("AuthorizeBtn", "XPATH|//input[@value='z']|fraTxn/showdata");
		    My_Page_Objects.put("Instr_No", "ID|ctlInstrNo");
		 WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void CASA_GLCreditCASADebit_1460(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("GLCurrency", "XPATH|//select[@id='ACY_Code']|fraTxn/showdata");
        My_Page_Objects.put("GLAccountNo", "XPATH|//input[@id='GlAccountNo']|fraTxn/showdata");
        My_Page_Objects.put("TxnAmount", "XPATH|//input[@id='TCY_Amount']");
        My_Page_Objects.put("RefNumber", "XPATH|//input[@id='DocNo']");
        My_Page_Objects.put("UserRefNumber", "XPATH|//input[@id='User_Ref_No']");
        My_Page_Objects.put("OKButton", "XPATH|//input[@id='btnOk']|fraTxn/showdata");
        My_Page_Objects.put("Denomination", "XPATH|//input[@value='UPDATEDENOMINATION']/parent::td/following-sibling::td[2]/input|fraPop/showdata");
        My_Page_Objects.put("OKDenomButton", "XPATH|//input[@id='btnOk']|fraPop/showdata");
        
        
        WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void CASA_GLDebitCASACredit_1060(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("GLCurrency", "XPATH|//select[@id='ACY_Code']|fraTxn/showdata");
        My_Page_Objects.put("GLAccountNo", "XPATH|//input[@id='GlAccountNo']|fraTxn/showdata");
        My_Page_Objects.put("TxnAmount", "XPATH|//input[@id='TCY_Amount']");
        My_Page_Objects.put("RefNumber", "XPATH|//input[@id='DocNo']");
        My_Page_Objects.put("UserRefNumber", "XPATH|//input[@id='User_Ref_No']");
        My_Page_Objects.put("OKButton", "XPATH|//input[@id='btnOk']|fraTxn/showdata");
        My_Page_Objects.put("Denomination", "XPATH|//input[@value='UPDATEDENOMINATION']/parent::td/following-sibling::td[2]/input|fraPop/showdata");
        My_Page_Objects.put("OKDenomButton", "XPATH|//input[@id='btnOk']|fraPop/showdata");
        
        
        WebDr.page_Objects = My_Page_Objects;
	}

	public static void BranchStatus_Inquiry_BAM95() {
		// TODO Auto-generated method stub
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	     My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	     My_Page_Objects.put("BranchCode", "XPATH|//select[@id='ctlCodCcBrn']|fraTxn/showdata");
	     My_Page_Objects.put("BranchStatus", "XPATH|//select[@id='cboBranchStatus']");
	     My_Page_Objects.put("Close", "ID|ctlClose");
	     My_Page_Objects.put("OK", "ID|ctlOK");
	     WebDr.page_Objects = My_Page_Objects;
	}

	public static void CASA_Chequebook_Issue_CHM37() {
		// TODO Auto-generated method stub
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	     My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	     My_Page_Objects.put("CHKBKAdd", "XPATH|.//input[@name='ctlMntToolBar' and @value='a']|fraTxn/showdata");
	     My_Page_Objects.put("CHKBKModify", "XPATH|.//input[@name='ctlMntToolBar' and @value='m']|fraTxn/showdata");   
	     My_Page_Objects.put("CHKBKAuthorize", "XPATH|.//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");   
	     My_Page_Objects.put("AccountNo", "ID|CtlChAcctNo");
	     My_Page_Objects.put("CHKBKSerial", "ID|tbChqBkSrNo");
	     My_Page_Objects.put("CHKBKType", "XPATH|//select[@id='ctlChqBkTyp']");
	     My_Page_Objects.put("CHKBKDeliveryBranch", "ID|cmbChqDelBr");   
	     My_Page_Objects.put("CHKBKleaves", "ID|ctlChqLeaves");
	     My_Page_Objects.put("ChequeType", "XPATH|//select[@id='cmbChqSubTyp']");
	     My_Page_Objects.put("HandOff", "ID|chkFlgPrn");
	     My_Page_Objects.put("Requested", "ID|optRequested");
	     My_Page_Objects.put("Issued", "ID|optIssued");
	     My_Page_Objects.put("Delivered", "ID|optDelivered");
	     My_Page_Objects.put("WaiveSCYes", "ID|optWaiveSCYes");
	     My_Page_Objects.put("WaiveSCNo", "ID|optWaiveSCNo");
	     My_Page_Objects.put("Close", "ID|ctlClose");
	     My_Page_Objects.put("OK", "ID|ctlOK");
	     WebDr.page_Objects = My_Page_Objects;
	}

	public static void CASA_SingleAccountTransfer_BA995() {
		// TODO Auto-generated method stub
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	     My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	     My_Page_Objects.put("RecordAdd", "XPATH|//input[@name='ctlMntToolBar' and @value='a']|fraTxn/showdata");
	     My_Page_Objects.put("RecordAuth", "XPATH|//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");
	     My_Page_Objects.put("AccountNo", "ID|CtlCodAcctNo");
	     My_Page_Objects.put("Branch","XPATH|//select[@id='ctlcodccbrn']|fraTxn/showdata");
	     My_Page_Objects.put("TransferBranch","XPATH|//select[@id='ctlXfercodccbrn']|fraTxn/showdata");
	     My_Page_Objects.put("OK", "ID|ctlOK");
	     WebDr.page_Objects = My_Page_Objects;
	}

	public static void CASA_HoldAccountFund_Add_1055() {
		// TODO Auto-generated method stub
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	     My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	     My_Page_Objects.put("AccountNo", "ID|AccountNo|fraTxn/showdata");
	     My_Page_Objects.put("Amount", "ID|TCY_Amount");
	     My_Page_Objects.put("EarmarkType","XPATH|//select[@id='EarmarkType']");
	     My_Page_Objects.put("EarmarkReason","XPATH|//select[@id='ReasonCode']");
	     My_Page_Objects.put("ExpiryDate", "ID|ExpiryDate");
	     My_Page_Objects.put("OK", "ID|btnOk|fraTxn/showdata");
	     My_Page_Objects.put("StatusBar","ID|StatusBar|bottom/");
	     WebDr.page_Objects = My_Page_Objects;
	}

	public static void CASA_HoldAccountFund_Delete_CHM33() {
		// TODO Auto-generated method stub
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	     My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	     My_Page_Objects.put("RecordDelete", "XPATH|//input[@name='ctlMntToolBar' and @value='d']|fraTxn/showdata");
	     My_Page_Objects.put("RecordAuth", "XPATH|//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");
	     My_Page_Objects.put("AccountNo", "ID|CtlChAcctNo");
	     My_Page_Objects.put("PickList", "ID|ctlPickList");
	     My_Page_Objects.put("OK", "ID|ctlOK|fraTxn/showdata");
	     WebDr.page_Objects = My_Page_Objects;
	}

	public static void CASA_SweepOutMaintenance_Add_CHM32() {
		// TODO Auto-generated method stub
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		    My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		    My_Page_Objects.put("SystemDate","XPATH|//input[@id='PostDate']|fraMenu/left");
		    My_Page_Objects.put("RecordAdd", "XPATH|//input[@name='ctlMntToolBar' and @value='a']|fraTxn/showdata");
		    My_Page_Objects.put("RecordAuth", "XPATH|//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");
		    My_Page_Objects.put("SweepOutToCASA", "ID|optChAcct");
		    My_Page_Objects.put("SweepOutToTD", "ID|optTdAcct");
		    My_Page_Objects.put("TDDetails","XPATH|//a[@id='Tab1Anchor']");
		    My_Page_Objects.put("AcctVar", "ID|tbAcctvar");
		    My_Page_Objects.put("CompFreq", "ID|CtlCompFreq");
		    My_Page_Objects.put("PayOutFreq", "ID|ctlPayOutFreq");
		    My_Page_Objects.put("BaseAmtTierRate", "ID|cmbBaseAmtTierRate");
		    My_Page_Objects.put("Months", "ID|tbMonths");
		    My_Page_Objects.put("Days", "ID|tbDays");
		    My_Page_Objects.put("TdSweepinStatus", "ID|ctlTdSweepinStatus");
		    My_Page_Objects.put("BeneficiaryDetails","XPATH|//a[@id='Tab0Anchor']");
		    My_Page_Objects.put("AccountNo", "ID|CtlChAcctNo1");
		    My_Page_Objects.put("ProdTD", "ID|ctlCodProdTD");
		    My_Page_Objects.put("ExecutionTypeEOD", "ID|optExeTypeEod|fraTxn/showdata");
		    My_Page_Objects.put("ExecutionTypeBOD", "ID|optExeTypeBod|fraTxn/showdata");
		    My_Page_Objects.put("Picklist", "ID|ctlPickList1");
		    My_Page_Objects.put("Frequency", "ID|Frequency1");
		    My_Page_Objects.put("EndDate", "ID|ctlDate2|fraTxn/showdata");
		    My_Page_Objects.put("NextDate", "ID|ctlDate3|fraTxn/showdata");
		    My_Page_Objects.put("CASASweepOutAccount", "ID|CtlChAcctNo2");
		    My_Page_Objects.put("MinBal", "ID|ctlMinBalRet|fraTxn/showdata");
		    My_Page_Objects.put("MaxAmtSweepOut", "ID|ctlMaxAmtSwpOut");
		    My_Page_Objects.put("MinAmtSweepOut", "ID|ctlEcoAmtSwpOut");
		    My_Page_Objects.put("Narrative", "ID|tbNarrative");
		    My_Page_Objects.put("OK", "ID|ctlOK|fraTxn/showdata");
		    My_Page_Objects.put("Close", "ID|ctlClose|fraTxn/showdata");

            My_Page_Objects.put("Modify", "XPATH|//input[@name='ctlMntToolBar' and @value='m']|fraTxn/showdata");
            My_Page_Objects.put("Instruction_No", "ID|tbInstNo");
            My_Page_Objects.put("Delete", "XPATH|//input[@name='ctlMntToolBar' and @value='d']|fraTxn/showdata");
            WebDr.page_Objects = My_Page_Objects;
	}
	public static void CASA_SweepOutMaintenance_Modify_CHM32() {
		// TODO Auto-generated method stub
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		    My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		    My_Page_Objects.put("Modify", "XPATH|//input[@name='ctlMntToolBar' and @value='m']|fraTxn/showdata");
		    My_Page_Objects.put("AccountNo", "ID|CtlChAcctNo1");
		    My_Page_Objects.put("Instruction_No", "ID|tbInstNo");
		    My_Page_Objects.put("RecordAdd", "XPATH|//input[@name='ctlMntToolBar' and @value='a']|fraTxn/showdata");
		    My_Page_Objects.put("RecordAuth", "XPATH|//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");
		    My_Page_Objects.put("SweepOutToCASA", "ID|optChAcct");
		    My_Page_Objects.put("SweepOutToTD", "ID|optTdAcct");
		    My_Page_Objects.put("TDDetails","XPATH|//a[@id='Tab1Anchor']");
		    My_Page_Objects.put("AcctVar", "ID|tbAcctvar");
		    My_Page_Objects.put("CompFreq", "ID|CtlCompFreq");
		    My_Page_Objects.put("PayOutFreq", "ID|ctlPayOutFreq");
		    My_Page_Objects.put("BaseAmtTierRate", "ID|cmbBaseAmtTierRate");
		    My_Page_Objects.put("Months", "ID|tbMonths");
		    My_Page_Objects.put("Days", "ID|tbDays");
		    My_Page_Objects.put("TdSweepinStatus", "ID|ctlTdSweepinStatus");
		    My_Page_Objects.put("BeneficiaryDetails","XPATH|//a[@id='Tab0Anchor']");
		    My_Page_Objects.put("AccountNo", "ID|CtlChAcctNo1");
		    My_Page_Objects.put("ProdTD", "ID|ctlCodProdTD");
		    My_Page_Objects.put("ExecutionTypeEOD", "ID|optExeTypeEod|fraTxn/showdata");
		    My_Page_Objects.put("ExecutionTypeBOD", "ID|optExeTypeBod|fraTxn/showdata");
		    My_Page_Objects.put("Picklist", "ID|ctlPickList1");
		    My_Page_Objects.put("Frequency", "ID|Frequency1");
		    My_Page_Objects.put("StartDate", "ID|ctlDate1");
		    My_Page_Objects.put("EndDate", "ID|ctlDate2");
		    My_Page_Objects.put("NextDate", "ID|ctlDate3");
		    My_Page_Objects.put("CASASweepOutAccount", "ID|CtlChAcctNo2");
		    My_Page_Objects.put("MinBal", "ID|ctlMinBalRet");
		    My_Page_Objects.put("MaxAmtSweepOut", "ID|ctlMaxAmtSwpOut");
		    My_Page_Objects.put("MinAmtSweepOut", "ID|ctlEcoAmtSwpOut");
		    My_Page_Objects.put("Narrative", "ID|tbNarrative");
		    My_Page_Objects.put("OK", "ID|ctlOK|fraTxn/showdata");
		    My_Page_Objects.put("Close", "ID|ctlClose|fraTxn/showdata");
		    
		    
		  WebDr.page_Objects = My_Page_Objects;
}




	public static void CASA_Misc_Customer_Debit(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		    My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		    My_Page_Objects.put("SystemDate","XPATH|//input[@id='PostDate']|fraMenu/left");
		    My_Page_Objects.put("AccountNo", "ID|AccountNo|fraTxn/showdata");
		    My_Page_Objects.put("Txn_Ccy", "ID|TCY_Code");
		    My_Page_Objects.put("GlAccountNo", "XPATH|//input[@id='GlAccountNo']|fraTxn/showdata");
		    My_Page_Objects.put("Amount", "ID|ACY_Amount");
		    My_Page_Objects.put("ReferenceNo", "ID|DocNo");
		    My_Page_Objects.put("UserReferenceNo", "ID|User_Ref_No");
		    My_Page_Objects.put("btn_OK_1008", "ID|btnOk|fraTxn/showdata");
		    My_Page_Objects.put("GlAccountNo1", "ID|CtlCodGlAcct|fraTxn/showdata");
		    My_Page_Objects.put("Branch", "ID|CtlCodCCBrn|fraTxn/showdata");
		    My_Page_Objects.put("Currency", "ID|ctlCodeCurrency");
		    My_Page_Objects.put("Transactions_type", "ID|CboInqTyp");
		    My_Page_Objects.put("FromDate", "ID|CtlDateFrom");
		    My_Page_Objects.put("ToDate", "ID|CtlDateTo");
		    My_Page_Objects.put("Inquire_GLM04", "ID|CmdInqTrMv|fraTxn/showdata");
		    My_Page_Objects.put("Transaction", "XPATH|//table[@id='GridTranMov']//td[contains(text(),'"+WebDr.getValue("AccountNo")+":Miscellaneous Customer')]|fraTxn/showdata");
		    My_Page_Objects.put("Sign","XPATH|.//input[@id='PhotoImage' and @value='1']|fraPop/showdata");
	        My_Page_Objects.put("SignOk","ID|btnOkImage|fraPop/showdata" );
	        My_Page_Objects.put("SignZoom","XPATH|//input[@name='ZoomIN']");
	        My_Page_Objects.put("SignVerified","ID|btnSign|fraPop/showdata" );
	        My_Page_Objects.put("SignCancel","ID|btnCancel|fraPop/showdata");
		    WebDr.page_Objects = My_Page_Objects;
		    
	}
	
	public static void CASA_Interest_Rate_Add_CHM02(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		 My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		 My_Page_Objects.put("SystemDate","XPATH|//input[@id='PostDate']|fraMenu/left");
		 My_Page_Objects.put("RecordAdd", "XPATH|//input[@name='ctlMntToolBar' and @value='a']|fraTxn/showdata");
		 My_Page_Objects.put("RecordAuth", "XPATH|//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");
		 My_Page_Objects.put("RecordModify", "XPATH|//input[@name='ctlMntToolBar' and @value='m']|fraTxn/showdata");
		 My_Page_Objects.put("Plan_code", "ID|ctlmskPlanCode");
		 My_Page_Objects.put("PlanSelect", "ID|ctlPlanPickList");
		 My_Page_Objects.put("Effective_date", "ID|ctlDate_0");
		 My_Page_Objects.put("Plan_Description", "ID|ctlPlanDesc");
		 My_Page_Objects.put("Credit_Type", "ID|optIntCrd");
		 My_Page_Objects.put("Debit_Type", "ID|optIntDebit");
		 My_Page_Objects.put("Overline_Type", "ID|optIntOverline");
		 My_Page_Objects.put("TOD_Type", "ID|optIntTOD");
		 My_Page_Objects.put("AddRate", "ID|cmdAddGridRow");
		 My_Page_Objects.put("OK_CHM02", "ID|ctlOK|fraTxn/showdata");
		 My_Page_Objects.put("Max_Balance", "XPATH|//table[@id='grdInstTiers']/tbody/tr/td[@class='TGridURL'][2]");
		 My_Page_Objects.put("Index_code", "XPATH|//table[@id='grdInstTiers']/tbody/tr/td[@class='TGridURL'][3]");
		 My_Page_Objects.put("Int_Variance", "XPATH|//table[@id='grdInstTiers']/tbody/tr/td[@class='TGridURL'][5]|fraTxn/showdata");
		 
		 WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void SweepIn_SweepOut_Priority_Maintenance_CHM40(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		 My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		 My_Page_Objects.put("Modify", "XPATH|//input[@name='ctlMntToolBar' and @value='m']|fraTxn/showdata");
		 My_Page_Objects.put("Add", "XPATH|//input[@name='ctlMntToolBar' and @value='a']|fraTxn/showdata");
		 My_Page_Objects.put("Account_No", "ID|CtlChAcctNo");
		 My_Page_Objects.put("OK_CHM40", "ID|ctlOK");
		 My_Page_Objects.put("CLOSE_CHM40", "ID|ctlClose|fraTxn/showdata");
		 My_Page_Objects.put("Priority_Number", "XPATH|//table[@id='grdSwpDetls']/tbody/tr[1]/td[6]|fraTxn/showdata");
		 WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void Account_Master_Maintenance_CH021(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		 My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		 My_Page_Objects.put("Account_No", "ID|CtlChAcctNo|fraTxn/showdata");
		 My_Page_Objects.put("BalanceInfo", "XPATH|//a/label[contains(text(),'Balance Info.')]|fraTxn/showdata");
		 My_Page_Objects.put("Overdraft", "XPATH|//a/label[contains(text(),'Overdraft/Overline')]|fraTxn/showdata");
		 My_Page_Objects.put("InterestTiers", "XPATH|//a/label[contains(text(),'Interest Tiers Info.')]|fraTxn/showdata");
		 My_Page_Objects.put("Available_Balance", "ID|tbAvailableBal|fraTxn/showdata");
		 My_Page_Objects.put("Last_Debit_Amt", "ID|tbLastAmt_0|fraTxn/showdata");
		 My_Page_Objects.put("Last_Credit_Amt", "ID|tbLastAmt_1|fraTxn/showdata");
		 My_Page_Objects.put("Clear_CH021", "ID|ctlClear|fraTxn/showdata");
		 
		 
		 
		 WebDr.page_Objects = My_Page_Objects;

	}

	public static void Sweep_In_Maintenance_CHM39(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		 My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		 My_Page_Objects.put("Account_No", "ID|CtlChAcctNo|fraTxn/showdata");
		 My_Page_Objects.put("PickList", "ID|ctlPickList|fraTxn/showdata");
		 My_Page_Objects.put("Instruction_Number", "ID|ctlInstructionNo|fraTxn/showdata");
		 My_Page_Objects.put("SweepIn_Account_Number", "ID|CtlSwpinAcctNo|fraTxn/showdata");
		 WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void Invalid_CHQBK_CHM37(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		 My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		  My_Page_Objects.put("RecordAdd", "XPATH|//input[@name='ctlMntToolBar' and @value='a']|fraTxn/showdata");
		 My_Page_Objects.put("Account_No", "ID|CtlChAcctNo|fraTxn/showdata");
		 WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void Transaction_Definition_TC001(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		 My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		 My_Page_Objects.put("ModifyBtn", "XPATH|//input[@name='ctlMntToolBar' and @value='m']|fraTxn/showdata");
		 My_Page_Objects.put("BranchCode", "ID|ctlBranchCod|fraTxn/showdata");
		 My_Page_Objects.put("TransactionMnem", "ID|ctlTranMnem|fraTxn/showdata");
		 My_Page_Objects.put("DualControl", "ID|ctlDualCntrl|fraTxn/showdata");
		 My_Page_Objects.put("OK_TC001", "ID|ctlOK|fraTxn/showdata");
		 My_Page_Objects.put("CLOSE_TC001", "ID|ctlClose|fraTxn/showdata");
		 WebDr.page_Objects = My_Page_Objects;
	}
	public static void ATM_inquiry_ATM01(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("BankCode", "ID|ctlBankCode|fraTxn/left");
        
         My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("ModifyBtn", "XPATH|//input[@name='ctlMntToolBar' and @value='m']|fraTxn/showdata");
        My_Page_Objects.put("BranchCode", "ID|ctlBranchCod|fraTxn/showdata");
        My_Page_Objects.put("TransactionMnem", "ID|ctlTranMnem|fraTxn/showdata");
        My_Page_Objects.put("DualControl", "ID|ctlDualCntrl|fraTxn/showdata");
        My_Page_Objects.put("OK_TC001", "ID|ctlOK|fraTxn/showdata");
        My_Page_Objects.put("CLOSE_TC001", "ID|ctlClose|fraTxn/showdata");
        WebDr.page_Objects = My_Page_Objects;
 }

	
}
