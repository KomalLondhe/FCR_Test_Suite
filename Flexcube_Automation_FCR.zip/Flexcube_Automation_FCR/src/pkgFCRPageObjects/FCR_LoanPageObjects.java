package pkgFCRPageObjects;

import java.util.HashMap;
import java.util.Map;

import utility.WebDr;

public class FCR_LoanPageObjects {

	public static void Launch(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("CertError","ID|overridelink" );
        My_Page_Objects.put("Retail","ID|RETAIL" );
		WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void Login_page()
    {
           Map<String, String> My_Page_Objects = new HashMap<String, String>();
           My_Page_Objects.put("Retail","ID|RETAIL" );
           My_Page_Objects.put("UserID","XPATH|//input[@name='fldUserID']|showdata" );
           My_Page_Objects.put("Password","XPATH|//input[@name='fldUserPass']" );
           My_Page_Objects.put("LoginButton","XPATH|//img[@id='LoginImage']" );
           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
           My_Page_Objects.put("TellerBatch","XPATH|//table[@class='TableGrid']|fraTxn/showdata");
           My_Page_Objects.put("Screen_OK", "XPATH|//input[@name='btnOk']|fraTxn/showdata");
           My_Page_Objects.put("PostingDate", "XPATH|//input[@name='BatchDate']|fraTxn/showdata");
           WebDr.page_Objects = My_Page_Objects;
           
    }      
           
    public static void LN057_page()
    {
           Map<String, String> My_Page_Objects = new HashMap<String, String>();
           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
           My_Page_Objects.put("LNM057Add", "XPATH|//input[@name='ctlMntToolBar' and @value='a']|fraTxn/showdata");
           My_Page_Objects.put("LNM057Auth", "XPATH|//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");
           My_Page_Objects.put("LNM057Cancel", "XPATH|//input[@name='ctlMntToolBar' and @value='k']|fraTxn/showdata");
           My_Page_Objects.put("CustPicklist", "XPATH|//input[@id='ctlCustAmdInfoPick']");
           My_Page_Objects.put("Clear", "XPATH|//input[@id='ctlClear']|fraTxn/showdata");
           My_Page_Objects.put("CustomerSearchCriteria","NAME|cmbSearchCriteria|fraTxn/showdata" );
           My_Page_Objects.put("CustomerInfo","ID|ctlCustInfo" );
           My_Page_Objects.put("BRANCH","NAME|ctlcodccbrn|fraTxn/showdata" );
           My_Page_Objects.put("CustomerRelation","NAME|ctlCustRel" );
           My_Page_Objects.put("Product","NAME|ctlCodProd" );
           My_Page_Objects.put("LoanPurpose","NAME|ctlLnPurpose" );
           My_Page_Objects.put("LoanTerm","NAME|ctlLnTerm" );
           My_Page_Objects.put("AssetValue","NAME|ctlAssetVal" );
           My_Page_Objects.put("Contribution","NAME|ctlContribution" );
           My_Page_Objects.put("RepayMode","NAME|ctlRepayMode" );
           My_Page_Objects.put("InterestVariance","NAME|ctlIntVar" );
           My_Page_Objects.put("Clear","ID|ctlClear|fraTxn/showdata" );
           My_Page_Objects.put("LN057Screen_OK", "ID|ctlOK|fraTxn/showdata");
           WebDr.page_Objects = My_Page_Objects;

    }
    
public static void LN323_page()
    {
           Map<String, String> My_Page_Objects = new HashMap<String, String>();
           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
           My_Page_Objects.put("AccountNO","ID|ctlLnAcctNo|fraTxn/showdata" );
           //My_Page_Objects.put("Document_Check","XPATH|.//table[@id='grdDocDetails']//tr["+i+"]//td[@class='TGridURL']|fraTxn/showdata" );
           My_Page_Objects.put("LN323Screen_OK", "XPATH|//input[@id='ctlOK']");
           WebDr.page_Objects = My_Page_Objects;                 
    }

    public static void LNM31_page()
    {
           Map<String, String> My_Page_Objects = new HashMap<String, String>();
           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
           My_Page_Objects.put("LNM31MntTool", "XPATH|//input[@name='ctlMntToolBar' and @value='a']|fraTxn/showdata");
           My_Page_Objects.put("LoanAccountNO","ID|ctlLnAcctNo" );
           My_Page_Objects.put("ArrearType","NAME|ctlArrearTyp"); 
           My_Page_Objects.put("CASAAccountNO","ID|ctlChAcctNo" );
           My_Page_Objects.put("LNM31Screen_OK", "XPATH|//input[@id='ctlOK']|fraTxn/showdata");
           My_Page_Objects.put("LNM31AuthMntTool", "XPATH|//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");
           My_Page_Objects.put("AuthLoanAccountNO","ID|ctlLnAcctNo|fraTxn/showdata" );
           My_Page_Objects.put("PickList","ID|ctlPickList");
           My_Page_Objects.put("CustName","ID|tbNamCustShrt|fraTxn/showdata");
           My_Page_Objects.put("LNM31Screen_Authorize_OK", "XPATH|//input[@id='ctlOK']|fraTxn/showdata");
           My_Page_Objects.put("LNM31_Close", "XPATH|//input[@id='ctlClose']|fraTxn/showdata");
           WebDr.page_Objects = My_Page_Objects;
    }
           
public static void LOGOUT_page()
    {
           Map<String, String> My_Page_Objects = new HashMap<String, String>(); 
           //My_Page_Objects.put("LOGOUT","LINKTEXT|Logout|UpperFrame" );
           My_Page_Objects.put("LOGOUT","ID|tbLogOut|UpperFrame" );
           My_Page_Objects.put("UserID","XPATH|//input[@name='fldUserID']|showdata" );
           WebDr.page_Objects = My_Page_Objects;

    }
    
    
    public static void SuperLogin_page()
    {
           Map<String, String> My_Page_Objects = new HashMap<String, String>();
           My_Page_Objects.put("SuperUserID","XPATH|.//input[@name='fldUserID']|showdata" );
           My_Page_Objects.put("SuperPassword","XPATH|.//input[@name='fldUserPass']|showdata" );
           My_Page_Objects.put("SuperLoginButton","XPATH|.//img[@id='LoginImage']|showdata" );
           WebDr.page_Objects = My_Page_Objects;

    }



    public static void LNM31_Authorize_page()
    {
           Map<String, String> My_Page_Objects = new HashMap<String, String>();
           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
           My_Page_Objects.put("LNM31AuthMntTool", "XPATH|.//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");
           My_Page_Objects.put("LoanAccountNO","ID|ctlLnAcctNo|fraTxn/showdata" );
           My_Page_Objects.put("PickList","ID|ctlPickList']|fraTxn/showdata" );
           My_Page_Objects.put("LNM31Screen_Authorize_OK", "XPATH|.//input[@name='ctlOK']|fraTxn/showdata");
           WebDr.page_Objects = My_Page_Objects;

    }
    
    public static void LN521_page()
    {
           Map<String, String> My_Page_Objects = new HashMap<String, String>();
           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
           My_Page_Objects.put("LoanAccountNO","ID|CtlLnAcctNo|fraTxn/showdata" );
           My_Page_Objects.put("Disbursement","ID|cmdDisb|fraTxn/showdata" );
           My_Page_Objects.put("DisbursementMode","NAME|ctlDisbMode|fraTxn/showdata" );
           My_Page_Objects.put("DisbursementAmount","ID|ctlDisbAmt|fraTxn/showdata" );
           My_Page_Objects.put("DisbursementReason","NAME|ctlCodReasonDisb|fraTxn/showdata" );
           My_Page_Objects.put("DisbursementReasonDescription","ID|ctlReasonDescDisb|fraTxn/showdata" );
           My_Page_Objects.put("DeductionDetails","ID|cmdDeductDtls|fraTxn/showdata" );
           My_Page_Objects.put("DeductionOK","ID|cmdDednOk|fraTxn/showdata" );
           My_Page_Objects.put("ComputeSchedule","ID|cmdComputeSched|fraTxn/showdata" );
           My_Page_Objects.put("ValidateSchedule","ID|cmdValSchedule|fraTxn/showdata" );
           My_Page_Objects.put("GenerateSchedule","ID|cmdGenSched|fraTxn/showdata" );
           My_Page_Objects.put("LN521Screen_OK","ID|ctlOK|fraTxn/showdata" );
           My_Page_Objects.put("AccountNumber","ID|ToAccountNo|fraTxn/showdata" );
           My_Page_Objects.put("UserRefNumber","ID|User_Ref_No|fraTxn/showdata" );
           My_Page_Objects.put("1413Screen_OK","ID|btnOk|fraTxn/showdata" );  
           My_Page_Objects.put("LoanAuth", "XPATH|//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");
           
           WebDr.page_Objects = My_Page_Objects;
 
    }
    
    public static void LN1413_page()
    {
           Map<String, String> My_Page_Objects = new HashMap<String, String>();
           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
           My_Page_Objects.put("LoanAccountNO","ID|AccountNo|fraTxn/showdata" );
           My_Page_Objects.put("DisbursementMode","ID|DisbursementMod" );
           My_Page_Objects.put("1413Screen_OK","ID|btnOk" );
           My_Page_Objects.put("AccountNumber","ID|ToAccountNo|fraTxn/showdata" );
           My_Page_Objects.put("UserRefNumber","ID|User_Ref_No|fraTxn/showdata" );
           My_Page_Objects.put("DisbursementAMT","ID|ACY_Amount" );
           My_Page_Objects.put("1413Screen_OK","ID|btnOk|fraTxn/showdata" );    
           WebDr.page_Objects = My_Page_Objects;
    }
    
    public static void LN7026_page()
    {
           Map<String, String> My_Page_Objects = new HashMap<String, String>();
           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
           My_Page_Objects.put("LoanAccountNO","ID|AccountNo|fraTxn/showdata" );
           My_Page_Objects.put("LoanBalanceAmt","ID|AmtAvailBal" );
           My_Page_Objects.put("OutstandingBalanceAmt","ID|AmtTotOutstanding" );
           My_Page_Objects.put("UnclearAmt","ID|AmtUnclear" );
           My_Page_Objects.put("PrincipalAmt","ID|AmtPrincBalance" );
           My_Page_Objects.put("7026Screen_Cancel","ID|btnCancel" );    
           WebDr.page_Objects = My_Page_Objects;
    }
    
    public static void LNM10_page()
    {
           Map<String, String> My_Page_Objects = new HashMap<String, String>();
           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
           My_Page_Objects.put("LoanAccountNO","ID|CtlLnAcctNo|fraTxn/showdata");
           My_Page_Objects.put("LoanAccountInqRadio","ID|optInterestDetails");
           My_Page_Objects.put("Transactions","ID|Tab0Anchor");
           My_Page_Objects.put("TxnDetails","ID|Tab1Anchor");
           My_Page_Objects.put("InterestDetails","ID|Tab2Anchor");
           My_Page_Objects.put("AccountDetails","ID|Tab3Anchor");
           My_Page_Objects.put("ArrearTotals","ID|Tab4Anchor");
           My_Page_Objects.put("ArrearTxns","ID|Tab6Anchor");
           My_Page_Objects.put("MinAmountTxns","ID|Tab7Anchor");
           My_Page_Objects.put("LoanApplNumber", "ID|ctlApplnNo");
           My_Page_Objects.put("Close","ID|ctlClose");    
           WebDr.page_Objects = My_Page_Objects;
    }
    
    public static void LoanInstallmentInquiry_1065()
    {
           Map<String, String> My_Page_Objects = new HashMap<String, String>();
           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
           My_Page_Objects.put("LoanAccountNO","ID|AccountNo|fraTxn/showdata");
           My_Page_Objects.put("InstallMode","ID|InstallMode");
           My_Page_Objects.put("OK", "ID|btnOk");  
           My_Page_Objects.put("AmtDue","ID|AmtForInst");
           My_Page_Objects.put("AmtBal","ID|AmtPrincBalance");
           My_Page_Objects.put("InstArrears","ID|AmtArrInst");
           My_Page_Objects.put("Cancel", "ID|btnCancel");  
           WebDr.page_Objects = My_Page_Objects;
    }
    
    public static void LoanFullPaymentInquiry_1067()
    {
           Map<String, String> My_Page_Objects = new HashMap<String, String>();
           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
           My_Page_Objects.put("LoanAccountNO","ID|AccountNo|fraTxn/showdata");
           My_Page_Objects.put("PenaltyMethod","ID|PenaltyMethod");
           My_Page_Objects.put("SettleMode", "ID|SettleMode");
           My_Page_Objects.put("ACY_Amount","ID|ACY_Amount");
           My_Page_Objects.put("OK", "ID|btnOk");  
           My_Page_Objects.put("Cancel", "ID|btnCancel");  
           WebDr.page_Objects = My_Page_Objects;
    }

	public static void LoanAccountRates_LNM83() {
		// TODO Auto-generated method stub
			Map<String, String> My_Page_Objects = new HashMap<String, String>();
	        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	        My_Page_Objects.put("LNM83Inquiry", "XPATH|.//input[@name='ctlMntToolBar' and @value='i']|fraTxn/showdata");
	        My_Page_Objects.put("LoanAccountNO","ID|ctlCodAcctNo");
	        My_Page_Objects.put("RatePlan","ID|ctlDatEffIntIndexPickList");
	        My_Page_Objects.put("Details", "XPATH|//a/label[contains(text(),'Details')]|fraTxn/showdata");
	        My_Page_Objects.put("RateRevision", "XPATH|//a/label[contains(text(),'Rate Revision')]");
	        My_Page_Objects.put("Close", "ID|ctlClose");  
	        WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void LoanAccountAttributes_LNM35() {
		// TODO Auto-generated method stub
			Map<String, String> My_Page_Objects = new HashMap<String, String>();
	        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	        My_Page_Objects.put("LoanInquiry", "XPATH|//input[@name='ctlMntToolBar' and @value='i']|fraTxn/showdata");
	        My_Page_Objects.put("LoanAccountNO","ID|CtlLnAcctNo");
	        My_Page_Objects.put("LoanCustName","ID|ctlCustName");
	        My_Page_Objects.put("LoanAttributes","XPATH|//a/label[contains(text(),'Attributes')]");
	        My_Page_Objects.put("DateMgr","ID|ctlDatMigration");
	        My_Page_Objects.put("Close", "ID|ctlClose");  
	        WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void LoanProductMaster_LNM11() {
		// TODO Auto-generated method stub
			Map<String, String> My_Page_Objects = new HashMap<String, String>();
	        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	        My_Page_Objects.put("LoanInquiry", "XPATH|//input[@name='ctlMntToolBar' and @value='i']|fraTxn/showdata");
	        My_Page_Objects.put("LoanProd","ID|txtCodProd");
	        My_Page_Objects.put("LoanProdName","ID|txtProdName");
	        My_Page_Objects.put("Close", "ID|ctlClose");  
	        WebDr.page_Objects = My_Page_Objects;
	}

	public static void LOANProductRatePlanInquiry_LN060() {
		// TODO Auto-generated method stub
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		My_Page_Objects.put("LoanInquiry", "XPATH|//input[@name='ctlMntToolBar' and @value='i']|fraTxn/showdata");
		My_Page_Objects.put("LoanAdd", "XPATH|//input[@name='ctlMntToolBar' and @value='a']|fraTxn/showdata");
		My_Page_Objects.put("LoanModify", "XPATH|//input[@name='ctlMntToolBar' and @value='m']|fraTxn/showdata");
		My_Page_Objects.put("LoanAuth", "XPATH|//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");
		My_Page_Objects.put("Clear","ID|ctlClear");
		My_Page_Objects.put("LoanRateID","ID|ctlRateId");
		My_Page_Objects.put("PickListRateID","ID|ctlPlanNamePickList");
		My_Page_Objects.put("LoanPlanName","ID|txtPlanName|fraTxn/showdata");
		My_Page_Objects.put("EffectiveDate","ID|ctlDatEffective|fraTxn/showdata");
		My_Page_Objects.put("NewEffectiveDate","ID|ctlNewDatEffective|fraTxn/showdata");
		My_Page_Objects.put("LoanRateType","ID|ctlRateType");
		My_Page_Objects.put("SlabDefinition","ID|ctlSlabDefnType");
		My_Page_Objects.put("RateDefinition","ID|ctlDefnType");
		My_Page_Objects.put("DetailsTab","ID|cmdShowDetails");
		My_Page_Objects.put("OK", "ID|ctlOK|fraTxn/showdata");
		My_Page_Objects.put("Close", "ID|ctlClose|fraTxn/showdata");  
		WebDr.page_Objects = My_Page_Objects;
	}
	public static void LOANPGlBalanceInquiryGLM04() {
        // TODO Auto-generated method stub
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("GlAccountNo","ID|CtlCodGlAcct");
        My_Page_Objects.put("BranchName","ID|CtlCodCCBrn");
        My_Page_Objects.put("Currency","ID|ctlCodeCurrency");
        My_Page_Objects.put("InquiryType","ID|CboInqTyp");
        My_Page_Objects.put("ToDate","ID|CtlDateTo");
        My_Page_Objects.put("OK", "ID|ctlOK|fraTxn/showdata");
        WebDr.page_Objects = My_Page_Objects;
 }
  
}
