package utility;

import java.util.concurrent.TimeoutException;

import org.openqa.selenium.JavascriptExecutor;

import testCases.Driver;

public class FCRListner extends Driver implements Runnable  {

	public void run(){
		while(! Driver.driver.getTitle().isEmpty()){
			try {
				alertListner();
			} catch (TimeoutException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			docReadyListner();
		}
	}

	public void alertListner() throws TimeoutException{
		if(WebDr.isAlertPresent()){
			String alertText=Driver.driver.switchTo().alert().getText();
			Driver.driver.switchTo().alert().accept();
		}else{
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}		
	}
	
	public void docReadyListner(){
		WebDr.readyState= ((JavascriptExecutor) driver)
				.executeScript("return document.readyState").toString()
				.equals("complete");
	}
}


