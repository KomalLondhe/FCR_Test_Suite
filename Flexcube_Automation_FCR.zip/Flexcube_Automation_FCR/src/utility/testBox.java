package utility;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class testBox implements ActionListener {
 JTextArea text;
 public static void main (String[] args) {
 testBox gui = new testBox();
 gui.go();
 }
 public void go() {
 JFrame frame = new JFrame("");
 JPanel panel = new JPanel();
 JTextField textField = new JTextField();
 String userText=textField.getText();
 
 text = new JTextArea(20,20);
 text.setLineWrap(true);

 JScrollPane scroller = new JScrollPane(text);
 scroller.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
 scroller.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
 
 panel.add(scroller);
 
 frame.getContentPane().add(BorderLayout.CENTER, panel);
 frame.getContentPane().add(BorderLayout.SOUTH, textField);

 frame.setSize(275,400);
 frame.setVisible(true);
 frame.setLocation(1170, 460);
 }
 public void actionPerformed(ActionEvent ev) {
 text.append("button clicked \n ");
 }
}