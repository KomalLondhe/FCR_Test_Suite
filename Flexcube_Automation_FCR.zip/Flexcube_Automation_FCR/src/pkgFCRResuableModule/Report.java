	package pkgFCRResuableModule;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import testCases.Driver;
import utility.Constant;
import utility.HtmlReporter;
import utility.WebDr;

public class Report extends Driver {

			public static void ReportCategory_Request() throws Exception {
				pkgFCRPageObjects.FCR_ReportPageObjects.ReportCategory_Request();				
				WebDr.fastPath(WebDr.getValue("FastPath"));
				WebDr.waitForPageLoaded();
				
				WebDr.click("Report_type", "Click on Report Type button");
				WebDr.clickwithmouse("Category", "Click on category");
				WebDr.clickwithmouse("Report_Group", "Click on Report Group");
				WebDr.click("Report_ID", "Click on Report ID");
				
			}
			private static void verifyReportWindow() throws Exception {
				// TODO Auto-generated method stub
				try{
				WebDr.fastPath(WebDr.getValue("FastPathViewReport"));
				pkgFCRPageObjects.FCR_ReportPageObjects.ReportCategory_Request_7778();
				WebDr.waitForPageLoaded();
				WebDr.isElementExist("View_btn", "Check for View button");				
				WebElement wbDocs = Driver.driver.findElement(By.xpath("//table[@class='TableGrid']/tbody"));
				List obCellDatatr = wbDocs.findElements(By.tagName("tr"));
				int introws = obCellDatatr.size();
				String strReportID = null;
				System.out.println("-------------------row count" + introws);
				for(int i=2;i<=introws;i++){
					WebDr.waitForPageLoaded();
					WebElement objCheck = Driver.driver.findElement(By.xpath("//table[@class='TableGrid']//tr["+i+"]/td[4]/input"));
					strReportID = Driver.driver.findElement(By.xpath("//table[@class='TableGrid']//tr["+i+"]/td[1]/input")).getAttribute("value");
					Actions builder = new Actions(driver);
					if (objCheck.isEnabled() && (strReportID.contains(WebDr.getValue("ReportID")))) {
						try{
							builder.click(objCheck).build().perform();
						}catch(Exception e){
								e.printStackTrace();
						}
						WebDr.waitForPageLoaded();
						WebDr.clickwithmouse("View_btn", "Click on View Button");
						if (WebDr.alertClickWithText("pending")==false){
							i=i-1;
							introws = introws - 1;
							HtmlReporter.WriteStep("Check whether the user is able to generate " +WebDr.getValue("ReportID")+ " in for a transaction or not.",
									"User should be able to generate " +WebDr.getValue("ReportID")+ " for a transaction successfully. ",
									"Report Generation Successful. " , true);
						}
						else{
							HtmlReporter.WriteStep("Check whether the user is able to generate " +WebDr.getValue("ReportID")+  " in for a transaction or not.",
								"User should be able to generate " +WebDr.getValue("ReportID")+ " for a transaction successfully. ",
								"Report Generation Successful. " , true);
							
						}
						
						WebDr.fastPath(WebDr.getValue("FastPathViewReport"));
						pkgFCRPageObjects.FCR_ReportPageObjects.ReportCategory_Request_7778();
						WebDr.waitForPageLoaded();
						WebDr.isElementExist("View_btn", "Check for View button");
					}
				}
				}catch(Exception error){
					error.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to generate " +WebDr.getValue("ReportID")+  " in  for a transaction or not.",
							"User should be able to generate " +WebDr.getValue("ReportID")+ " for a transaction successfully. ",
							"Report Generation Unsuccessful. " + error.getMessage(), false);
				}
			}
			
			public static void ReportCategory_Request_CH220() throws Exception {
				try
				{
				Report.ReportCategory_Request();
				pkgFCRPageObjects.FCR_ReportPageObjects.ReportCategory_Request_CH220();
				WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
				
				String sysdate = WebDr.getTextBoxValue("SystemDate", "System date is fetched and displayed");		
				WebDr.setText("FromDate", WebDr.ChangeDatebyDays(WebDr.getValue("Duration")) , "Enter From Date");
				WebDr.setText("ToDate", sysdate , "Enter To Date");
				WebDr.setText("WaiveSC", WebDr.getValue("WaiveSC") , "Enter Waived SC value");
				WebDr.setText("ValueDate", WebDr.getValue("ValueDate")  , "Enter Value Date");
				WebDr.clickwithmouse("Generate_btn", "Click on Generate button");
				WebDr.alertAccept();
				Report.verifyReportWindow();
				
				}
				
				catch (Exception error){
					error.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to generate " +WebDr.getValue("ReportID")+   " in for a transaction or not.",
							"User should be able to generate " +WebDr.getValue("ReportID")+ " for a transaction successfully. ",
							"Report Generation Unsuccessful. " + error.getMessage(), false);
					
				}
			}
			
		

			
			public static void ReportCategory_Request_GL008() throws Exception {
				try{
				Report.ReportCategory_Request();
				pkgFCRPageObjects.FCR_ReportPageObjects.ReportCategory_Request_GL008();
				WebDr.setText("GLAccountNo", WebDr.getValue("GLAccountNo"), "Enter GL Account Number");
				WebDr.setText("BranchCode", WebDr.getValue("BranchCode"), "Enter Branch Code");
				String sysdate = WebDr.getTextBoxValue("SystemDate", "System date is fetched and displayed");		
				WebDr.setText("FromDate", WebDr.ChangeDatebyStaticDays(-360) , "Enter From Date");
				WebDr.setText("ToDate", sysdate , "Enter To Date");
				WebDr.clickwithmouse("Generate_btn", "Click on Generate button");
				WebDr.alertAccept();
				Report.verifyReportWindow();
				
				}
				
				catch (Exception error){
					error.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to generate" +WebDr.getValue("ReportID")+   " in for a transaction or not.",
							"User should be able to generate " +WebDr.getValue("ReportID")+ " for a transaction successfully. ",
							"Report Generation Unsuccessful. " + error.getMessage(), false);
					
				}
			}
			
			public static void ReportCategory_Request_CH112() throws Exception {
				try{
				Report.ReportCategory_Request();
				pkgFCRPageObjects.FCR_ReportPageObjects.ReportCategory_Request_CH112();
				WebDr.rClearUpdateTextField("Process_date", WebDr.ChangeDatebyStaticDays(-30), "Update Process date field");
				WebDr.clickwithmouse("View_btn", "Click on View button");
				
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded_Long(240);
				WebDr.SwitchToLatestWindow();
				String newWindowURL =  driver.getPageSource();
				System.out.println(newWindowURL);
				if (newWindowURL.contains("CH112"))
				{
				HtmlReporter.WriteStep("Check whether the user is able to generate " +WebDr.getValue("ReportID")+ " in  for a transaction or not.",
						"User should be able to generate  " +WebDr.getValue("ReportID")+ "  for a transaction successfully. ",
						"Report Generation Successful. " , true);
				}
				else{
					HtmlReporter.WriteStep("Check whether the user is able to generate" + WebDr.getValue("ReportID") +   " in for a transaction or not.",
							"User should be able to generate " +WebDr.getValue("ReportID")+ " for a transaction successfully. ",
							"Report Generation Unsuccessful. " , false);	
				}
				WebDr.CloseWindowWithNumber(3);
				}
				
				catch (Exception error){
					error.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to generate" +WebDr.getValue("ReportID")+   "in for a transaction or not.",
							"User should be able to generate " +WebDr.getValue("ReportID")+ " for a transaction successfully. ",
							"Report Generation Unsuccessful. " + error.getMessage(), false);
					WebDr.CloseWindowWithNumber(3);
				}
				
			}
			
			
			public static void ReportCategory_Request_CH790() throws Exception {
				try{
				Report.ReportCategory_Request();
				pkgFCRPageObjects.FCR_ReportPageObjects.ReportCategory_Request_CH112();
				WebDr.rClearUpdateTextField("Process_date", WebDr.ChangeDatebyStaticDays(-30), "Update Process date field");
				WebDr.clickwithmouse("View_btn", "Click on View button");
				
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded_Long(240);
				WebDr.SwitchToLatestWindow();
				String newWindowURL =  driver.getPageSource();
				System.out.println(newWindowURL);
				if (newWindowURL.contains("CH790"))
				{
				HtmlReporter.WriteStep("Check whether the user is able to generate " +WebDr.getValue("ReportID")+ " in  for a transaction or not.",
						"User should be able to generate  " +WebDr.getValue("ReportID")+ "  for a transaction successfully. ",
						"Report Generation Successful. " , true);
				}
				else{
					HtmlReporter.WriteStep("Check whether the user is able to generate" + WebDr.getValue("ReportID") +   " in for a transaction or not.",
							"User should be able to generate " +WebDr.getValue("ReportID")+ " for a transaction successfully. ",
							"Report Generation Unsuccessful. " , false);	
				}
				WebDr.CloseWindowWithNumber(3);
				}
				
				catch (Exception error){
					error.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to generate" +WebDr.getValue("ReportID")+   "in for a transaction or not.",
							"User should be able to generate " +WebDr.getValue("ReportID")+ " for a transaction successfully. ",
							"Report Generation Unsuccessful. " + error.getMessage(), false);
					WebDr.CloseWindowWithNumber(3);
				}
			}
			
			
			public static void ReportCategory_Request_CH102() throws Exception {
				try{
				Report.ReportCategory_Request();
				pkgFCRPageObjects.FCR_ReportPageObjects.ReportCategory_Request_CH112();
				
				
				WebDr.rClearUpdateTextField("Process_date", WebDr.ChangeDatebyStaticDays(-30), "Update Process date field");
				WebDr.clickwithmouse("View_btn", "Click on View button");
				
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded_Long(240);
				WebDr.SwitchToLatestWindow();
				String newWindowURL =  driver.getPageSource();
				System.out.println(newWindowURL);
				if (newWindowURL.contains("CH102"))
				{
				HtmlReporter.WriteStep("Check whether the user is able to generate " +WebDr.getValue("ReportID")+ " in  for a transaction or not.",
						"User should be able to generate  " +WebDr.getValue("ReportID")+ "  for a transaction successfully. ",
						"Report Generation Successful. " , true);
				}
				else{
					HtmlReporter.WriteStep("Check whether the user is able to generate" + WebDr.getValue("ReportID") +   " in for a transaction or not.",
							"User should be able to generate " +WebDr.getValue("ReportID")+ " for a transaction successfully. ",
							"Report Generation Unsuccessful. " , false);	
				}
				WebDr.CloseWindowWithNumber(3);
				}
				
				catch (Exception error){
					error.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to generate" +WebDr.getValue("ReportID")+   "in for a transaction or not.",
							"User should be able to generate " +WebDr.getValue("ReportID")+ " for a transaction successfully. ",
							"Report Generation Unsuccessful. " + error.getMessage(), false);
					WebDr.CloseWindowWithNumber(3);
				}
			}
			
			
			public static void ReportCategory_Request_TD102() throws Exception {
				try{
				Report.ReportCategory_Request();
				pkgFCRPageObjects.FCR_ReportPageObjects.ReportCategory_Request_CH112();
				WebDr.rClearUpdateTextField("Process_date",  WebDr.ChangeDatebyDays(WebDr.getValue("Duration")), "Update Process date field");
				WebDr.clickwithmouse("View_btn", "Click on View button");
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded_Long(240);
				WebDr.SwitchToLatestWindow();
				String newWindowURL =  driver.getPageSource();
		
				System.out.println(newWindowURL);
				if (newWindowURL.contains("TD102"))
				{
				HtmlReporter.WriteStep("Check whether the user is able to generate " +WebDr.getValue("ReportID")+ " in  for a transaction or not.",
						"User should be able to generate  " +WebDr.getValue("ReportID")+ "  for a transaction successfully. ",
						"Report Generation Successful. " , true);
				}
				else{
					HtmlReporter.WriteStep("Check whether the user is able to generate" + WebDr.getValue("ReportID") +   " in for a transaction or not.",
							"User should be able to generate " +WebDr.getValue("ReportID")+ " for a transaction successfully. ",
							"Report Generation Unsuccessful. " , false);	
				}
				WebDr.CloseWindowWithNumber(3);
				}
				
				catch (Exception error){
					error.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to generate" +WebDr.getValue("ReportID")+   "in for a transaction or not.",
							"User should be able to generate " +WebDr.getValue("ReportID")+ " for a transaction successfully. ",
							"Report Generation Unsuccessful. " + error.getMessage(), false);
					WebDr.CloseWindowWithNumber(3);
				}
			}
}
			
