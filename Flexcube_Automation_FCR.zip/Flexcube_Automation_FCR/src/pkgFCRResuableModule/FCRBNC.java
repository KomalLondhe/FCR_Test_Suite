package pkgFCRResuableModule;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import testCases.Driver;
import utility.Constant;
import utility.FCRDBConnection;
import utility.HtmlReporter;
import utility.WebDr;

public class FCRBNC extends Driver {
	public static boolean blnBNCFailedStep;
	public static String strBNCFailedDesc;
	public static boolean blnFCRBNCMntRadio;
	public static int intFCRBNCMntRadio;

	public static void BNCValidation_Fastpath() throws Exception {
		String strFastpathCount = WebDr.getValue("FastpathCount");
		int intFPCount = Integer.parseInt(strFastpathCount);
		String strFP = "FastPath";
		String strFetchFP = "";
		String strScreen = "";
		String strFPNumber = "";
		boolean blnFPOpen;

		try {

			pkgFCRPageObjects.FCR_BNC.BNCNavigateFastpath();

			for (int cnt = 1; cnt <= intFPCount; cnt++) {
				strFetchFP = WebDr.getValue(strFP + Integer.toString(cnt));
				strScreen = strFetchFP.split("-")[0];
				strFPNumber = strFetchFP.split("-")[1];
				blnFPOpen = false;
				blnBNCFailedStep = false;
				intFCRBNCMntRadio = 0;
				strBNCFailedDesc = "";
				System.out.println("navigating to fastpath-------------------------------------" + strFPNumber);
				blnFPOpen = WebDr.fastPath_BNC(strFPNumber);
				WebDr.waitForPageLoaded();

				try {

					if (blnFPOpen == false) {
						blnBNCFailedStep = true;
						HtmlReporter.WriteStep("FCR BNC TC---Verify fastpath screen " + strFetchFP,
								"User should be able to access " + strFetchFP,
								strFetchFP + " screen could not opened due to error message", false);
						// WebDr.clickElementImageSikuli_BNC("NoSuperOKButton.PNG",
						// 1, "Click on error message");
						System.out.println(strFetchFP + " screen could not opened due to error message");
					} else {
						String strAppFP = WebDr.getText_BNC("Caption");
						System.out.println(strFPNumber + "Expected Fastpath screen---------------" + strScreen);
						System.out.println(strFPNumber + "Fastpath---------------" + strAppFP);
						
						if (strAppFP.toLowerCase().equals(strScreen.toLowerCase())) {
							blnBNCFailedStep = false;
							HtmlReporter.WriteStep("FCR BNC TC---Verify fastpath screen " + strFetchFP,
									"User should be able to access " + strFetchFP,
									strFetchFP + " screen opened successfully", true);
							
							// To verify absa logo is present or not
							//WebDr.waitForPageLoaded();
							//WebDr.clickElementImageSikuli("AbsaLogo.PNG", 10, "CLick on absa logo");

						}

						else {
							blnBNCFailedStep = true;
							FCRBNC.strBNCFailedDesc = "";
							HtmlReporter.WriteStep("FCR BNC TC---Verify fastpath screen " + strFetchFP,
									"User should be able to access " + strFetchFP,
									strFetchFP + " screen could not opned successfully", false);
						}
					}

					// takes screenshots for MntToolbar operations like
					// Add\Modify\Delete if it is present on the screen
					WebDr.GetMntToolbarRadioScreens();

				} catch (Exception e) {
					blnBNCFailedStep = true;
					System.out.println(
							"unable to navigate to fastpath====================================>" + strFPNumber);
					e.printStackTrace();
				}
			}

		} catch (Exception e1) {
			HtmlReporter.WriteStep("Verify fastpath screen " + strFetchFP,
					"User should be able to access " + strFetchFP, strFetchFP + " screen is not opened successfully",
					false);
			e1.printStackTrace();
		}

	}

	public static void CASAAcctOpening_8051() throws Exception, Exception {
		String strUDFDate = "";
		try {
			pkgFCRPageObjects.FCR_CASAPageObjects.CASAAcctOpening_8051();

			WebDr.fastPath(WebDr.getValue("FastPath"));
			strUDFDate = WebDr.getTextBoxValue("SystemDate", "System date is fetched and displayed");
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("BranchName", WebDr.getValue("BranchName"), "Select Branch Name");
			WebDr.selectDropValueByVisibleText("ProductName", WebDr.getValue("ProductName"), "Select Product Name");
			WebDr.setText("AccountTitle", WebDr.getValue("AcctTitle"), "Enter Account Title");
			if (WebDr.strFCRCountry.equals("NBC") || WebDr.strFCRCountry.equals("BBK")) {
				WebDr.click("CustPick", "Click on Validate");
				WebDr.selectDropValueByVisibleText("SelectSearchCriteria", "Customer ID", "Select search criteria");
				WebDr.rTab();
				WebDr.setText("SearchValue", WebDr.getValue("CustomerID"), "Enter search value");
				WebDr.rTab();
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.rDown();
				WebDr.rEnter();
				WebDr.SwitchToLatestWindow();
				// WebDr.click("SelectRow", "Click on record");
				WebDr.waitForPageLoaded();
				// Thread.sleep(8000);
			} else
				WebDr.setText("CustomerIC1", WebDr.getValue("CustomerIC1"), "Enter Customer IC");

			WebDr.SwitchToLatestWindow();
			if (!((WebDr.strFCRCountry.equals("NBC") || (WebDr.strFCRCountry.equals("BBK"))))) {
				WebDr.selectDropValueByVisibleText("Category1", WebDr.getValue("Category1"), "Selct Category");
			}
			WebDr.setText("Relation1", WebDr.getValue("Relations"), "Enter Relation");
			WebDr.selectDropValueByVisibleText("OfficerID", WebDr.getValue("OfficerID"), "Select Officer ID");
			if (!(WebDr.strFCRCountry.equals("NBC"))) {
				WebDr.setText("NoOfLeaves", WebDr.getValue("NoOfLeaves"), "Enter No Of Leaves");
			}
			WebDr.clickwithmouse("Validate", "Click on Validate");
			// WebDr.rEnter();
			// WebDr.alertAccept();
			WebDr.alertHandlingForErrors("Existing", "Check for alert message");
			WebDr.waitForPageLoaded();
			// WebDr.rEnter();
			WebDr.clickwithmouse("AccountTitle", "Click Account Title");
			// WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("Ok", "Click on OK");

			if (WebDr.strFCRCountry.equals("NBC")) {
				WebDr.authWithComment();
			} else if (WebDr.strFCRCountry.equals("BBK")) {
				WebDr.alertClickWithText("UDF");
				WebDr.waitForPageLoaded();
				WebDr.setText("UDFDate", strUDFDate, "Account open date");
				WebDr.clickwithmouse("UDFValidate", "Click on validate");
				WebDr.waitForPageLoaded();
				WebDr.clickwithmouse("UDFBack", "Click on Back");
				WebDr.clickwithmouse("Ok", "Click on OK");
			}

			WebDr.getAccountNo();
			WebDr.AccountNo = WebDr.getAccountNo();
			WebDr.alertAccept();
			WebDr.waitForPageLoaded();
			if (!(WebDr.AccountNo.toString().length() == 0)) {
				HtmlReporter.WriteStep("Verify opening of CASA account",
						"User should be able to create a " + WebDr.getValue("ProductName") + "  CASA Account.",
						"CASA Account Creation Successful. CASA Account No - " + WebDr.AccountNo, true);
			} else {
				HtmlReporter.WriteStep("Verify opening of CASA account", "User should be able to create CASA Account.",
						"CASA Account Creation Unsuccessful. CASA Account No - ", false);

			}

		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Verify opening of CASA account", "User should be able to create CASA Account. ",
					"CASA Account creation unsuccessful: " + e.toString(), false);
		}
	}

	public static void CashDeposit_1401() throws Exception {
		try {

			// Enter_Details
			pkgFCRPageObjects.FCR_CASAPageObjects.CashDeposit_1401();
			WebDr.fastPath(WebDr.getValue("FastPath"));

			if (WebDr.AlertHandleForUnknownErrors())
				throw new Exception();

			WebDr.waitForPageLoaded();
			WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
			WebDr.rTab();
			WebDr.waitForPageLoaded();

			if (WebDr.strFCRCountry.equals("NBC")) {
				WebDr.selectDropValueByVisibleText("TxnCurrency", WebDr.getValue("TxnCurrency"), "Select Txn Currency");
			}

			WebDr.setText("TxnAmount", WebDr.getValue("TxnAmount"), "Enter Tax Amount");
			WebDr.click("TxnAmount", "Click in TxnAmount field");
			WebDr.rTab();

			WebDr.AlertHandleOfflineChargeErrors();

			if (WebDr.strFCRCountry.equals("NBC")) {
				WebDr.setText("DepositorID", WebDr.getValue("DepositorID"), "Enter Depositor ID");
				WebDr.rTab();
				WebDr.setText("DepositorName", WebDr.getValue("DepositorName"), "Enter Depositor Name");
				WebDr.rTab();
			}

			WebDr.setText("UserRefNo", WebDr.getValue("UserRef"), "Enter User Ref");
			WebDr.rTab();
			WebDr.rTab();
			WebDr.clickwithmouse("Ok", "Clik on OK");

			if (WebDr.strFCRCountry.equals("UG") || WebDr.strFCRCountry.equals("NBC"))
				WebDr.alertAccept();

			if (WebDr.strFCRCountry.equals("UGChanged")) {
				// SignatureVerfication
				WebDr.waitForPageLoaded();
				WebDr.click("Sign", "Click on Sign");
				WebDr.click("SignOk", "Click on OK");
				WebDr.waitForPageLoaded();
				WebDr.waitForNumberOfWindowsToEqual(3);
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				WebDr.clickactivatewithmouse("SignZoom", "Click on signature window");
				WebDr.CloseWindowWithTitle("Signature");
				WebDr.SwitchToLatestWindow();
				WebDr.click("FastPath", "Click in the textfield");

				WebDr.click("SignVerified", "Click on Signature Verified");
				WebDr.click("SignCancel", "Click on Cancel");

				// 1401ScreenReturn
				WebDr.waitForPageLoaded();
				WebDr.click("AccountNo", "Click on Account No");
				WebDr.click("Ok", "Click on OK");
				WebDr.alertAccept();
			}

			// Denomination
			WebDr.waitForPageLoaded();
			WebDr.DenominationEntry("Enter Denomination");

			// WebDr.setText ("Count", "2", "");
			// WebDr.setText("Denomination", WebDr.getValue("Denomination"),
			// "Enter Denomination");
			if (!WebDr.strFCRCountry.equals("BBK")) {
				WebDr.click("D_Ok", "Click on OK button");
			}
			// 1401ScreenReturn
			WebDr.waitForPageLoaded();
			try {
				WebDr.click("AccountNo", "Click on Account No");
				WebDr.clickwithmouse("Ok", "Click on OK");
				// WebDr.alertAccept();
			} catch (Exception e) {
				System.out.println("Inside");
				Thread.sleep(5000);
				e.printStackTrace();
				WebDr.alertAccept();
			}

			if (WebDr.strFCRCountry.equals("UG")) {
				WebDr.alertClickWithText("Suntec");
				WebDr.alertClickWithText("kool");
				// AuthWithComments
				WebDr.authWithComment();

				if (WebDr.alertClickWithText("kool")) {
					WebDr.authWithComment();
				}
			}

			if (WebDr.strFCRCountry.equals("UG") || WebDr.strFCRCountry.equals("NBC")) {
				if (WebDr.alertClickWithText("Transaction sequence number is"))
					HtmlReporter.WriteStep(
							"Check whether teller is able to fund a CASA account using physical cash  from 1401 screen.",
							"User should be able to deposit funds successfully. ", "Funds Transfer Successful. ", true);
				else {
					HtmlReporter.WriteStep(
							"Check whether teller is able to fund a CASA account using physical cash  from 1401 screen.",
							"User should be able to deposit funds successfully. ", "Funds Transfer Unsuccessful. ",
							false);
				}
			} else if (WebDr.strFCRCountry.equals("BBK")) {
				if (WebDr.VerifyStatusBarText("StatusBar", 10, "Transaction sequence number is",
						"Verify transaction status"))
					HtmlReporter.WriteStep(
							"Check whether teller is able to fund a CASA account using physical cash  from 1401 screen.",
							"User should be able to deposit funds successfully. ", "Funds Transfer Successful. ", true);
				else {
					HtmlReporter.WriteStep(
							"Check whether teller is able to fund a CASA account using physical cash  from 1401 screen.",
							"User should be able to deposit funds successfully. ", "Funds Transfer Unsuccessful. ",
							false);
				}

				WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
			}

		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Check whether teller is able to fund a CASA using physical cash  from 1401 screen.",
					"User should be able to deposit funds successfully. ",
					"Funds Transfer Unsuccessful. " + e.getMessage(), false);

		}
	}

	public static void BNC_HelpMenu() throws Exception {
		try {

			pkgFCRPageObjects.FCR_BNC.BNCNavigateFastpath();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoad();
			Actions builder = new Actions(driver);
			driver.switchTo().frame("UpperFrame");
			WebElement elmn = driver.findElement(By.id("tbHelp"));
			builder.moveToElement(elmn).build().perform();
			driver.switchTo().defaultContent();
			WebElement subelemnt = driver.findElement(By.id("HL001"));
			builder.click(subelemnt);
			// builder.click(elmn).build().perform();

			/*
			 * WebDr.actionClass("Help"); WebDr.click("Help",
			 * "Click on HelpMenu"); WebDr.actionClass("Oracle_Help");
			 * WebDr.click("Oracle_Help", "Click on Help Link");
			 */

			HtmlReporter.WriteStep("Verify fastpath screen ", "User should be able to access HelpMenu",
					" User is able to access help menu,", true);
		} catch (Exception e1) {
			e1.printStackTrace();
			HtmlReporter.WriteStep("Verify fastpath screen ", "User should be able to access HelpMenu",
					" User is not able to access help menu,", false);

		}

	}
	
	

	
}
