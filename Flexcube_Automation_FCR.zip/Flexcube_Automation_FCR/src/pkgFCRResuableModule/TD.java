package pkgFCRResuableModule;

import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import testCases.Driver;
import utility.FCRDBConnection;
import utility.HtmlReporter;
import utility.WebDr;

public class TD extends Driver {

	public static void TimeDepositAccountOpening_8054() throws Exception {

		try {
			pkgFCRPageObjects.FCR_TDPageObjects.TD8054_page();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			//WebDr.swtichOnTellerWindow("FastPath");
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("BranchName", WebDr.getValue("BranchName"), "Select Branch Name");
			WebDr.selectDropValueByVisibleText("ProductName", WebDr.getValue("ProductName"), "Select Product Name");
			// WebDr.setText("AccountTitle", WebDr.getValue("Test TD Account"),
			// "Enter Account Title");
			WebDr.setText("AccountTitle", WebDr.timestampValue, "Enter Account Title");
			WebDr.rTab();
			
			WebDr.rTab();
			WebDr.clickwithmouse("CustomerSearch", "Click on the Customer Search button");
			WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"),
					"Select Customer IC");
			WebDr.waitForPageLoaded();
			WebDr.setText("SearchString", WebDr.getValue("SearchString"), "Enter Search String");
			WebDr.rTab();
			WebDr.waitForPageLoaded();	
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.SwitchToLatestWindow();
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("CustomerRelations", WebDr.getValue("CustomerRelations"),
					"Select Customer Relations");
			WebDr.selectDropValueByVisibleText("MinorAccountStatus", WebDr.getValue("MinorAccountStatus"),
					"Select Minor Account Status");
			WebDr.clickwithmouse("ValidateCustomer", "Click on the Validate Customer button");
			WebDr.waitForPageLoaded();
			if ((WebDr.strFCRCountry.equals("BBK"))) {
				WebDr.blnNavigatFPScreen = true;
				WebDr.alertClickWithText("Existing");
			}
			if (!(WebDr.strFCRCountry.equals("BBK"))) {
				WebDr.alertClickWithText("Existing");
			}
			WebDr.clickwithmouse("OKButton", "Click on the OK Button");
			WebDr.authWithComment();
			// WebDr.alertClickWithText("GetTcyRate function of ctlRate
			// failed.");

			WebDr.TDAccountNo = WebDr.getTDAccountNo();
			WebDr.alertAccept();
			Thread.sleep(3000);
			//String query= "Select cod_acct_no from td_acct_mast where cod_acct_title = '"+WebDr.timestampValue+"'";
			// WebDr.alertAcceptAndContinue();
			// WebDr.alertAccept();
			if (!((WebDr.strFCRCountry.equals("BBK")))) {
				try {
					WebDr.clickAlwaysImageSikuli("OKDialog.PNG", 5, "Click to continue");
					WebDr.clickAlwaysImageSikuli("OKDialog.PNG", 5, "Click to continue");
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			
			WebDr.waitForPageLoaded();
			// String strAppTDNumber =
			// WebDr.getTextBoxValue("AccountNumber","Get Term Deposit Account
			// Number");
			if (WebDr.TDAccountNo != "")
				HtmlReporter.WriteStep("Check for Time Deposit Account Opening",
						"User should be able to open Time Deposit account using 8054",
						"User opened Time Deposit account successfully using 8054 -" + WebDr.TDAccountNo, true);
			else
				HtmlReporter.WriteStep("Check for Time Deposit Account Opening",
						"User should be able to open Time Deposit account using 8054",
						"User could not open Time Deposit account successfully using 8054 - " + WebDr.TDAccountNo,
						false);
			/*
			 * if (strAppTDNumber.equals(WebDr.TDAccountNo))
			 * HtmlReporter.WriteStep("Check for Time Deposit Account Opening",
			 * "User should be able to open Time Deposit account using 8054",
			 * "User opened Time Deposit account successfully using 8054 -"
			 * +WebDr.TDAccountNo,true); else
			 * HtmlReporter.WriteStep("Check for Time Deposit Account Opening",
			 * "User should be able to open Time Deposit account using 8054",
			 * "User could not open Time Deposit account successfully using 8054 - "
			 * +WebDr.TDAccountNo,false); WebDr.click("Close",
			 * "Click on Close");
			 */
			
			//FCRDBConnection.DBValidation_FetchValue(query);
		} catch (Exception exc) {
			exc.printStackTrace();
			HtmlReporter.WriteStep("Check for Time Deposit Account Opening",
					"User should be able to open Time Deposit account using 8054", exc.getMessage(), false);
		}

	}

	public static void TimeDepositPayin_1356() throws Exception {
		try {
			pkgFCRPageObjects.FCR_TDPageObjects.TD1356_page();
			if (blnNavigatFPScreen) {
				if (WebDr.fastPathWithAlert(WebDr.getValue("FastPath"), "Open TTV Batch")) {
					// WebDr.waitForPageLoaded();
					// if (WebDr.SwitchToLatestAlertCheck("Open TTV Batch")){
					WebDr.openTTVbatch("96");
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.setText("AccountNumber", WebDr.TDAccountNo, "Enter TD Account Number");
					WebDr.rTab();

				} else {
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.setText("AccountNumber", WebDr.TDAccountNo, "Enter TD Account Number");
					WebDr.rTab();
				}
			}
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("AddButton", "Click on the Add Button");
			WebDr.waitElementImageSikuli("TDPayinRecord.PNG", 60, "Wait for TDPayin Record");
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.rEnter();
			if (!WebDr.getValue("PayinMode").equals("Transfer to CASA")) {
				WebDr.r.keyPress(KeyEvent.VK_C);
				WebDr.r.keyRelease(KeyEvent.VK_C);
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				// Thread.sleep(15000);
				WebDr.waitElementImageSikuli("TDPayinCashRecord.PNG", 120, "Wait for TDPayin Record");
			}

			if (WebDr.strFCRCountry.equals("UG"))
				WebDr.rTab();

			if (WebDr.getValue("PayinMode").equals("Transfer to CASA")) {
				WebDr.rTab();
			}
			// Thread.sleep(5000);

			WebDr.rTab();
			WebDr.rEnter();
			// WebDr.keyboard("50000");
			System.out.println(WebDr.getValue("TDAmount"));
			WebDr.keyboard(WebDr.getValue("TDAmount"));
			Thread.sleep(5000);
			WebDr.rTab();
			WebDr.waitForPageLoaded();

			/*if (WebDr.strFCRCountry.equals("NBC")) {
				WebDr.rTab();
				WebDr.rTab();
				WebDr.rEnter();
				WebDr.waitForPageLoaded();
				WebDr.waitForElement("SaveCashDetails");
				WebDr.click("SaveCashDetails", "Click on save button");
				WebDr.waitForPageLoaded();
				
			}*/
			
			
			if (WebDr.getValue("PayinMode").equals("Transfer to CASA")) {
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rEnter();
				WebDr.waitForPageLoaded();
				WebDr.setText("CASAAccountNo", WebDr.getValue("CASANumber"), "Enter CASA Account No");
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.waitForElement("SaveCashDetails");
				WebDr.waitForPageLoaded();
				WebDr.click("SaveCashDetails", "Click on save button");
			}

			WebDr.clickwithmouse("PayinButton", "Click on the Payin Button");
			Thread.sleep(5000);
			WebDr.selectDropValueByVisibleText("PayoutFrequency", WebDr.getValue("PayoutFrequency"),
					"Select Payout Frequency");
			WebDr.selectDropValueByVisibleText("CompoundingFrequency", WebDr.getValue("CompoundingFrequency"),
					"Select Compounding Frequency");
			WebDr.selectDropValueByVisibleText("BaseRate", WebDr.getValue("BaseRate"), "Select Base Rate");

			// if (WebDr.strFCRCountry.equals("UG") ||
			// WebDr.strFCRCountry.equals("BBK")){
			WebDr.setText("TermMonths", WebDr.getValue("TermMonths"), "Select Term Months ");
			WebDr.rTab();
			WebDr.alertClickWithText("holiday");
			WebDr.setText("TermDays", WebDr.getValue("TermDays"), "Select Term Days ");
			WebDr.rTab();
			WebDr.alertClickWithText("holiday");

			WebDr.rClearUpdateTextField("DepositVariance", WebDr.getValue("DepositVariance"), "Enter Deposit Variance");
			Thread.sleep(5000);
			WebDr.rTab();
			WebDr.clickwithmouse("SaveButton", "Click on the Save Button ");
			WebDr.clickwithmouse("OKButton", "Click on the OK Button ");

			// WebDr.authWithComment();

			WebDr.authWithCommentOnlyOnce();

			// WebDr.alertAccept();
			// if (WebDr.clickAlwaysImageSikuli("SignImageSuccessOK.PNG", 20,
			// "Click on deposit number")){
			// if (WebDr.alertHandlingForErrors("Deposit Number", "Verify alert
			// message")){
			if (WebDr.clickAlwaysImageSikuli("OKDialog.PNG", 5, "Click on Deposit Number")) {
				HtmlReporter.WriteStep("Check for Time Deposit Payin-" + WebDr.getValue("PayinMode"),
						"User should be able to Payin using 1356",
						"User is able to Payin using 1356 - " + WebDr.TDAccountNo, true);
			} else {
				HtmlReporter.WriteStep("Check for Time Deposit Payin-" + WebDr.getValue("PayinMode"),
						"User should be able to Payin using 1356",
						"User is not able to Payin using 1356 - " + WebDr.TDAccountNo, false);
			}
			blnNavigatFPScreen = true;
			WebDr.SwitchToLatestWindow();
		} catch (Exception exc) {
			exc.printStackTrace();
			HtmlReporter.WriteStep("Check for Time Deposit Payin", "User should be able to Payin using 1356",
					exc.getMessage(), false);
		}
	}

	public static void TimeDepositBalanceInquiry_7020() throws Exception {
        String strEnterCustID;
        try {
               pkgFCRPageObjects.FCR_TDPageObjects.TD7020_page();
               WebDr.fastPath(WebDr.getValue("FastPath"));
               WebDr.waitForPageLoaded();
               /*if (!WebDr.CustID.isEmpty()) {
                     strEnterCustID = WebDr.CustID;
               } else {
                     strEnterCustID = WebDr.getValue("CustomerID");
               }*/

               ///WebDr.setText("AccountNumber", WebDr.TDAccountNo, "Enter TD Account Number");
               // WebDr.setText("AccountNumber", "strEnterCustID", "Enter TD
               // Account Number");
               WebDr.setText("AccountNumber", WebDr.getValue("AccountNumber"),"Enter account number");
               // "Enter TD Account Number");
               WebDr.rTab();
               WebDr.rEnter();
               WebDr.SwitchToLatestWindow();
               WebDr.waitForPageLoaded();
               WebDr.rTab();
               WebDr.rTab();
               WebDr.rEnter();
               WebDr.SwitchToLatestWindow();
               WebDr.waitForPageLoaded();
               WebDr.click("OKButton", "Click on the OK Button");

               if (WebDr.strFCRCountry.equals("UG") || WebDr.strFCRCountry.equals("NBC")) {
                     if (WebDr.isAlertPresent())
                            WebDr.alertAccept();
                     WebDr.authWithComment();
               }
               //if (!WebDr.TDAccountNo.isEmpty()) 
                     HtmlReporter.WriteStep("Check for Time Deposit Balance Inquiry",
                                   "User should be able to Inquire the Balance using 7020",
                                   "User is able to Inquire the Balance using 7020 - " + WebDr.TDAccountNo, true);
        
               
        } catch (Exception exc) {
               HtmlReporter.WriteStep("Check for Time Deposit Balance Inquiry",
                            "User should be able to Inquire the Balance using 7020", exc.getMessage(), false);
        }
 }

	public static void TimeDepositAccountMaster_TD020() throws Exception {
		try {
			pkgFCRPageObjects.FCR_TDPageObjects.TD020_page();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			//WebDr.setText("AccountNumber", WebDr.TDAccountNo, "Enter TD Account Number");
			WebDr.setText("AccountNumber", WebDr.getValue("AccountNumber"),"Enter TD Account Number");
			WebDr.rTab();
			WebDr.rTab();
			Thread.sleep(5000);
			WebDr.clickwithmouse("CloseButton", "Click on the Close Button");

			WebDr.alertAccept();
				HtmlReporter.WriteStep("Check for Time Deposit Account Master",
						"User should be able to check the account details using TD020",
						"User is able to check the account details using TD020 - ", true);
			

		} catch (Exception exc) {
			HtmlReporter.WriteStep("Check for Time Deposit Account Master",
					"User should be able to check the account details using TD020", exc.getMessage(), false);
		}
	}

	public static void TimeDepositDepositMaster_TD021() throws Exception {
		try {
			pkgFCRPageObjects.FCR_TDPageObjects.TD021_page();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			//WebDr.setText("AccountNumber", WebDr.TDAccountNo, "Enter TD Account Number");
			WebDr.setText("AccountNumber", WebDr.getValue("AccountNumber"),"Enter TD Account Number");
			WebDr.rTab();
			WebDr.rTab();
			WebDr.clickwithmouse("PickDepNoButton", "Click on the Org Deposit No Button");
			WebDr.SwitchToLatestWindow();
			WebDr.rTab();
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.rTab();
			WebDr.rTab();
			WebDr.SwitchToLatestWindow();
			WebDr.clickwithmouse("CloseButton", "Click on the Close Button");

			WebDr.alertAccept();
			
				HtmlReporter.WriteStep("Check for Time Deposit Deposit Master",
						"User should be able to check the Deposit details using TD021",
						"User is able to check the Deposit details using TD021 - ", true);
			

		} catch (Exception exc) {
			HtmlReporter.WriteStep("Check for Time Deposit Deposit Master",
					"User should be able to check the Deposit details using TD021", exc.getMessage(), false);
		}
	}

	public static void TD_Redemption_1358() throws Exception {
		String strTDAccount = "";
		try {
			pkgFCRPageObjects.FCR_TDPageObjects.TD1358_page();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();

			if (WebDr.TDAccountNo.isEmpty()) {
				strTDAccount = WebDr.getValue("AccountNumber");
			} else
				strTDAccount = WebDr.TDAccountNo;

			WebDr.setText("AccountNumber", strTDAccount, "Enter TD Account Number");
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("DepPickList", "Click on the Deposit Pick List");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.doubleclickwithmouse("RedeemMode", "Click on Deposit Status");
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.r.keyPress(KeyEvent.VK_F);
			WebDr.r.keyRelease(KeyEvent.VK_F);
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("FastPath", "Click on FastPath");
			WebDr.clickwithmouse("ValidateButton", "Click on the Validate Button");
			WebDr.waitForPageLoaded();
		} catch (Exception exc) {
			exc.printStackTrace();
			HtmlReporter.WriteStep("Check if the TD can be premature redeemed using 1358 option",
					"User should be able to validate if the TD can be premature redeemed using 1358 option",
					exc.getMessage(), false);
		}

		switch (WebDr.getValue("TDOperation")) {
		case "Redeem":
			try {
				WebDr.clickwithmouse("FastPath", "Click on FastPath");
				WebDr.clickwithmouse("PayoutButton", "Click on the Payout Button");
				WebDr.clickwithmouse("AddButton", "Click on the Payout Button");
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rEnter();
				WebDr.waitForPageLoaded();
				WebDr.r.keyPress(KeyEvent.VK_C);
				WebDr.r.keyRelease(KeyEvent.VK_C);
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.clickwithmouse("OKButton", "Click on the OK Button");
				WebDr.authWithComment();
				WebDr.alertAccept();
				WebDr.clickAlwaysImageSikuli("CancelButton.png", 5, "Click on the Cancel Button");

				HtmlReporter.WriteStep("Check if the TD can be premature redeemed using 1358 option",
						"User should be able to check if the TD can be premature redeemed using 1358 option",
						"User is able to check if the TD can be premature redeemed using 1358 option - " + strTDAccount,
						true);

			} catch (Exception exc) {
				exc.printStackTrace();
				HtmlReporter.WriteStep("Check if the TD can be premature redeemed using 1358 option",
						"User should be able to check if the TD can be premature redeemed using 1358 option",
						exc.getMessage(), false);
			}
			break;
		case "RedeemMultiplePayoutMode":
			try {
				WebDr.clickwithmouse("FastPath", "Click on FastPath");
				WebDr.click("PayoutButton", "Click on the Payout Button");
				WebDr.waitForPageLoaded();

				// add first payout
				WebDr.click("AddButton", "Click on the Payout Button");
				String strPayoutAmt = WebDr.getTextBoxValue("TotalPayoutAmt", "Total Payout Amt");
				double payout1 = (Double.parseDouble(strPayoutAmt.replace(",", "")));
				double dividefactor = 10;
				payout1 = payout1 / dividefactor;
				int intpayout = (int) Math.round(payout1);
				String strPayout1 = Integer.toString(intpayout);
				// String strPayout = Double.toString(payout1);
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rEnter();
				WebDr.waitForPageLoaded();
				WebDr.r.keyPress(KeyEvent.VK_C);
				WebDr.r.keyRelease(KeyEvent.VK_C);
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.rEnter();
				WebDr.keyboard(strPayout1);
				WebDr.rTab();
				// add second payout
				WebDr.clickwithmouse("AddButton", "Click on the Payout Button");
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rEnter();
				WebDr.waitForPageLoaded();
				WebDr.r.keyPress(KeyEvent.VK_T);
				WebDr.r.keyRelease(KeyEvent.VK_T);
				WebDr.r.keyPress(KeyEvent.VK_T);
				WebDr.r.keyRelease(KeyEvent.VK_T);
				WebDr.r.keyPress(KeyEvent.VK_T);
				WebDr.r.keyRelease(KeyEvent.VK_T);
				WebDr.r.keyPress(KeyEvent.VK_T);
				WebDr.r.keyRelease(KeyEvent.VK_T);
				// WebDr.keyboard("Transfer to GL");
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.rTab();
				WebDr.rTab();
				WebDr.rEnter();
				WebDr.setText("RedeemGLAccount", WebDr.getValue("RedeemGLAccount"), "Account number to redeem TD");
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				// WebDr.rEnter();
				// WebDr.SelectTopAcct();
				WebDr.clickwithmouse("SaveRedeemAccount", "Click on Save");

				WebDr.clickwithmouse("FastPath", "Clik in fastpath");
				WebDr.clickwithmouse("OKButton", "Click on the OK Button");
				WebDr.authWithComment();

				if (WebDr.alertHandlingForErrors("Record added", "Verify alert message"))
					HtmlReporter.WriteStep(
							"Check if the TD premature amount can be paid out by multiple modes, check the calculations for interest and tax amount",
							"System should allow the user to premature redeem the TD via multiple payout modes using 1358 option",
							"User is able to prematurely redeem the TD via multiple payout modes using 1358 option - "
									+ strTDAccount,
							true);
				else
					HtmlReporter.WriteStep(
							"Check if the TD premature amount can be paid out by multiple modes, check the calculations for interest and tax amount",
							"System should allow the user to premature redeem the TD via multiple payout modes using 1358 option",
							"User is not able to prematurely redeem the TD via multiple payout modes using 1358 option - "
									+ strTDAccount,
							false);

				WebDr.clickAlwaysImageSikuli("CancelButton.png", 5, "Click on the Cancel Button");

			} catch (Exception exc) {
				exc.printStackTrace();
				HtmlReporter.WriteStep(
						"Check if the TD premature amount can be paid out by multiple modes, check the calculations for interest and tax amount",
						"System should allow the user to premature redeem the TD via multiple payout modes using 1358 option",
						exc.getMessage(), false);
			}
			break;

		case "RedeemError":
			try {
				if (WebDr.SwitchToLatestAlertCheck("lien marked"))
					HtmlReporter.WriteStep("Check if the user should not be allowed redeem the TD for Lien amount",
							"System should give error to the user for the Redmption  using 1358 option",
							"User is not able to redeem the TD for which lien is marked using 1358 option - "
									+ strTDAccount,
							true);
				else
					throw new Exception();
			} catch (Exception exc) {
				exc.printStackTrace();
				HtmlReporter.WriteStep("Check if the user should not be allowed redeem the TD for Lien amount",
						"System should give error to the user for the Redmption  using 1358 option",
						"User is able to redeem the TD for which lien is marked using 1358 option -" + strTDAccount
								+ exc.getMessage(),
						false);
			}
			break;
		}
	}

	public static void TD_Multiple_Payout_TD039() throws Exception {
		try {
			pkgFCRPageObjects.FCR_TDPageObjects.TD039_page();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			// WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("TDAddRadioButton", "Click on the Add Radio Button");

			if (WebDr.TDAccountNo.isEmpty()) {
				WebDr.TDAccountNo = WebDr.getValue("AccountNumber");
				WebDr.setText("AccountNumber", WebDr.getValue("AccountNumber"), "Enter TD Account Number");
			} else
				WebDr.setText("AccountNumber", WebDr.TDAccountNo, "Enter TD Account Number");

			// WebDr.setText("AccountNumber", WebDr.getValue("AccountNumber"),
			// "Enter TD Account Number");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.setText("PayoutType", WebDr.getValue("PayoutType"), "Enter TD Payout Type");
			WebDr.clickwithmouse("DepositNoPickList", "Click on the Deposit Number Pick List");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.setText("PrematurePayoutDate", WebDr.getValue("PrematurePayoutDate"), "Enter Premature Payout Date");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.setText("PrematurePayoutMode", WebDr.getValue("PrematurePayoutMode"), "Enter Premature Payout Mode");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.rShiftTab();
			WebDr.waitForPageLoaded();
			WebDr.rShiftTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("RenewalProductCodePickList", "Click on the Renewal Product Code Pick List");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.setText("Variance", WebDr.getValue("Variance"), "Enter the Variance");
			WebDr.setText("RenewalTermMonths", WebDr.getValue("RenewalTermMonths"), "Enter the Renewal Term Months");
			WebDr.setText("RenewalTermDays", WebDr.getValue("RenewalTermDays"), "Enter the Renewal Term Days");
			WebDr.setText("PayoutFrequency", WebDr.getValue("PayoutFrequency"), "Enter the Payout Frequency");
			WebDr.setText("CompoundingFrequency", WebDr.getValue("CompoundingFrequency"),
					"Enter the Compounding Frequency");
			WebDr.setText("BaseRate", WebDr.getValue("BaseRate"), "Enter the Base Rate");
			WebDr.clickwithmouse("SaveButton", "Click on the Save Button");
			WebDr.clickwithmouse("OKButton", "Click on the OK Button");
			WebDr.alertHandlingForErrors("Click Ok to Continue",
					"Click on the Record Added... Authorization Pending Tab");
			LOAN.logout();
			LOAN.superLogin();
			WebDr.waitForPageLoaded();
			pkgFCRPageObjects.FCR_TDPageObjects.TD039_page();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("TDAuthorizeRadioButton", "Click on the Authorize Radio Button");
			WebDr.setText("AccountNumber", WebDr.getValue("AccountNumber"), "Enter TD Account Number");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("OKButton", "Click on the OK Button");
			WebDr.alertHandlingForErrors("Click Ok to Continue", "Click on the Record Authorized Tab");
			LOAN.logout();
			LOAN.login();
			HtmlReporter.WriteStep(
					"Check if the Multiple Payout instructions can be maintained for the Term deposit account",
					"User should be able to check if the Multiple Payout instructions can be maintained for the Term deposit account",
					"User is able to check if the Multiple Payout instructions can be maintained for the Term deposit account - "
							+ WebDr.TDAccountNo,
					true);

		} catch (Exception exc) {
			exc.printStackTrace();
			HtmlReporter.WriteStep(
					"Check if the Multiple Payout instructions can be maintained for the Term deposit account",
					"User should be able to check if the Multiple Payout instructions can be maintained for the Term deposit account",
					exc.getMessage(), false);
		}
	}

	public static void TD_Lien_Master_Maintenance_TDM24() throws Exception {
		pkgFCRPageObjects.FCR_TDPageObjects.TDM24_page();
		WebDr.fastPath(WebDr.getValue("FastPath"));
		switch (WebDr.getValue("TDOperation")) {
		case "Add":
			try {
				WebDr.waitForPageLoaded();
				WebDr.clickwithmouse("TDAddRadioButton", "Click on the Add Radio Button");
				if (WebDr.TDAccountNo.isEmpty()) {
					WebDr.TDAccountNo = WebDr.getValue("AccountNumber");
					WebDr.setText("AccountNumber", WebDr.getValue("AccountNumber"), "Enter TD Account Number");
				} else
					WebDr.setText("AccountNumber", WebDr.TDAccountNo, "Enter TD Account Number");
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.clickwithmouse("DepositNoPickList", "Click on the Deposit Number Pick List");
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rEnter();
				WebDr.waitForPageLoaded();
				WebDr.rClearUpdateTextField("LienAmount", WebDr.getValue("LienAmount"), "Enter Lien Amount");
				WebDr.rTab();
				WebDr.rClearUpdateTextField("LienDescription", WebDr.getValue("LienDescription"),
						"Enter Lien Description");
				WebDr.rTab();
				WebDr.selectDropValueByVisibleText("ReasonForLien", WebDr.getValue("ReasonForLien"),
						"Enter Reason For Lien");
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.clickwithmouse("OKButton", "Click on the OK Button");
				if (WebDr.strFCRCountry.equals("BBK")) {
					WebDr.SwitchToLatestAlertCheck("Record Modified");
					LOAN.logout();
					LOAN.superLogin();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.clickwithmouse("TDAuthorizeBtn", "Click on the Authorize Radio Button");
					if (WebDr.TDAccountNo.isEmpty()) {
						WebDr.TDAccountNo = WebDr.getValue("AccountNumber");
						WebDr.setText("AccountNumber", WebDr.getValue("AccountNumber"), "Enter TD Account Number");
					} else
						WebDr.setText("AccountNumber", WebDr.TDAccountNo, "Enter TD Account Number");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("DepositNoPickList", "Click on the Deposit Number Pick List");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.rEnter();
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("OKButton", "Click on the OK Button");
					if (WebDr.SwitchToLatestAlertCheck("Record Authorized"))
						HtmlReporter.WriteStep(
								"Check if the Manual Lien can be marked on Term Deposit using TDM24 option",
								"User should be able to check if the Manual Lien can be marked on Term Deposit using TDM24 option",
								"User is able to check if the Manual Lien can be marked on Term Deposit using TDM24 option - "
										+ WebDr.TDAccountNo,
								true);
					else {
						HtmlReporter.WriteStep(
								"Check if the Manual Lien can be marked on Term Deposit using TDM24 option",
								"User should be able to check if the Manual Lien can be marked on Term Deposit using TDM24 option",
								"User is not able to check if the Manual Lien can be marked on Term Deposit using TDM24 option - "
										+ WebDr.TDAccountNo,
								false);
					}
					LOAN.logout();
					LOAN.superLogin();
				} else {
					WebDr.authOnlyCreds();
					if (WebDr.strFCRCountry.equals("NBC")) {
						if (WebDr.SwitchToLatestAlertCheck("Record Authorized"))
							HtmlReporter.WriteStep(
									"Check if the Manual Lien can be marked on Term Deposit using TDM24 option",
									"User should be able to check if the Manual Lien can be marked on Term Deposit using TDM24 option",
									"User is able to check if the Manual Lien can be marked on Term Deposit using TDM24 option - "
											+ WebDr.TDAccountNo,
									true);
						else {
							HtmlReporter.WriteStep(
									"Check if the Manual Lien can be marked on Term Deposit using TDM24 option",
									"User should be able to check if the Manual Lien can be marked on Term Deposit using TDM24 option",
									"User is not able to check if the Manual Lien can be marked on Term Deposit using TDM24 option - "
											+ WebDr.TDAccountNo,
									false);
						}
					} else {
						if (WebDr.SwitchToLatestAlertCheck("Click Ok to Continue"))
							HtmlReporter.WriteStep(
									"Check if the Manual Lien can be marked on Term Deposit using TDM24 option",
									"User should be able to check if the Manual Lien can be marked on Term Deposit using TDM24 option",
									"User is able to check if the Manual Lien can be marked on Term Deposit using TDM24 option - "
											+ WebDr.TDAccountNo,
									true);
						else
							HtmlReporter.WriteStep(
									"Check if the Manual Lien can be marked on Term Deposit using TDM24 option",
									"User should be able to check if the Manual Lien can be marked on Term Deposit using TDM24 option",
									"User is not able to check if the Manual Lien can be marked on Term Deposit using TDM24 option - "
											+ WebDr.TDAccountNo,
									false);
					}
				}
			} catch (Exception exc) {
				exc.printStackTrace();
				HtmlReporter.WriteStep("Check if the Manual Lien can be marked on Term Deposit using TDM24 option",
						"User should be able to check if the Manual Lien can be marked on Term Deposit using TDM24 option",
						exc.getMessage(), false);
			}
			break;

		case "Remove":
			try {
				WebDr.waitForPageLoaded();
				WebDr.clickwithmouse("TDDeleteRadioButton", "Click on the Delete Radio Button");
				if (WebDr.TDAccountNo.isEmpty()) {
					WebDr.setText("AccountNumber", WebDr.getValue("AccountNumber"), "Enter TD Account Number");
					WebDr.TDAccountNo = WebDr.getValue("AccountNumber");
				} else
					WebDr.setText("AccountNumber", WebDr.TDAccountNo, "Enter TD Account Number");
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.clickwithmouse("DepositNoPickList", "Click on the Deposit Number Pick List");
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rEnter();
				WebDr.waitForPageLoaded();
				WebDr.clickwithmouse("OKButton", "Click on the OK Button");
				WebDr.waitForPageLoaded();
				WebDr.authOnlyCreds();
				if (WebDr.SwitchToLatestAlertCheck("Click Ok to Continue"))
					HtmlReporter.WriteStep(
							"Check if the Manual Lien can be marked on Term Deposit can be removed using TDM24 option",
							"User should be able to remove Manual Lien can be marked on Term Deposit using TDM24 option",
							"User is able to remove the Manual Lien can be marked on Term Deposit using TDM24 option - "
									+ WebDr.TDAccountNo,
							true);
				else
					HtmlReporter.WriteStep(
							"Check if the Manual Lien can be marked on Term Deposit can be removed using TDM24 option",
							"User should be able to remove Manual Lien can be marked on Term Deposit using TDM24 option",
							"User is not able to remove the Manual Lien can be marked on Term Deposit using TDM24 option - "
									+ WebDr.TDAccountNo,
							false);
			} catch (Exception exc) {
				exc.printStackTrace();
				HtmlReporter.WriteStep(
						"Check if the Manual Lien can be marked on Term Deposit can be removed using TDM24 option",
						"User should be able to check if the Manual Lien can be marked on Term Deposit using TDM24 option",
						exc.getMessage(), false);
			}
			break;

		}
	}

	public static void TD028_Block_TD() throws Exception {
        try {
               pkgFCRPageObjects.FCR_TDPageObjects.TD028_Block_TD();
               WebDr.fastPath(WebDr.getValue("FastPath"));
               WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter TD Account Number");
               WebDr.rTab();
               WebDr.waitForPageLoaded();
               
               if (!(WebDr.IsCheckboxSelected("BlockedChqBox", "Check whether checkbox is selected or not"))) {
                     WebDr.clickwithmouse("BlockedChqBox", "Click on  the checkbox");
                     WebDr.selectDropValueByVisibleText("BlockReason", WebDr.getValue("BlockReason"), "Select Block Reason");
                     WebDr.waitForPageLoaded();
                     WebDr.clickwithmouse("OKButton", "Click on OK");
                     WebDr.authOnlyCreds();
                     WebDr.waitForPageLoaded();
                     HtmlReporter.WriteStep("Check if the user is able to Block the TD Account using TD028 option",
                                          "User should be able to block the TD account using the TD028 option",
                                          "User is able to block acccount successfully", true);
                            
                     

               } else {
                     HtmlReporter.WriteStep("Check if the user is able to Block the TD Account using TD028 option",
                                   "User should be able to block the TD account using the TD028 option",
                                   "User is  unable to block TD account as it is already blocked", false);
               }

        } catch (Exception exc) {
               exc.printStackTrace();
               HtmlReporter.WriteStep("Check if the user is able to Block the TD Account using TD028 option",
                            "User should be able to block the TD account using the TD028 option", exc.getMessage(), false);
        }
 }

 public static void TD028_UnBlock_TD() throws Exception {
        try {
               pkgFCRPageObjects.FCR_TDPageObjects.TD028_Block_TD();
               WebDr.fastPath(WebDr.getValue("FastPath"));
               WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter TD Account Number");
               WebDr.rTab();

               WebDr.waitForPageLoaded();
               if (WebDr.IsCheckboxSelected("BlockedChqBox", "Check whether checkbox is selected or not")) {
                     WebDr.clickwithmouse("BlockedChqBox", "Click on  the checkbox");
                     // WebDr.selectDropValueByVisibleText("BlockReason",
                     // WebDr.getValue("BlockReason"), "Select Block Reason");
                     WebDr.clickwithmouse("OKButton", "Click on OK");
                     WebDr.authOnlyCreds();
                     WebDr.waitForPageLoaded();
                     HtmlReporter.WriteStep("Check if the user is able to Unblock the TD Account using TD028 option",
                                          "User should be able to unblock the TD account using the TD028 option",
                                          "User is able to unblock acccount successfully", true);
                            
                     
               } else {
                     HtmlReporter.WriteStep("Check if the user is able to unblock the TD Account using TD028 option",
                                   "User should be able to unblock the TD account using the TD028 option",
                                   "User is  unable to unblock TD account as it is already unblocked", false);
                     WebDr.alertAccept();
               }

        } catch (Exception exc) {
               exc.printStackTrace();
               HtmlReporter.WriteStep("Check if the user is able to unBlock the TD Account using TD028 option",
                            "User should be able to unblock the TD account using the TD028 option", exc.getMessage(), false);
        }
 }






public static void TD_AuditTrailInquiry_TD031() throws Exception {
        try {
               pkgFCRPageObjects.FCR_TDPageObjects.TD_AuditTrailInquiry_TD031();
               WebDr.fastPath(WebDr.getValue("FastPath"));
               WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter TD Account Number");
               WebDr.rTab();
               WebDr.selectDropValueByVisibleText("Action", WebDr.getValue("Action"), "Select Action");
               WebDr.rTab();
               if (!(WebDr.getValue("ValueDateFrom") == null)) {
                     WebDr.rClearUpdateTextField("ValueDateFrom", WebDr.getValue("ValueDateFrom"), "Enter ValueDateFrom");
                     WebDr.rTab();
               }
               if (!(WebDr.getValue("ValueDateTo").equals("NA"))) {
                     WebDr.rClearUpdateTextField("ValueDateTo", WebDr.getValue("ValueDateTo"), "Enter ValueDateTo");
                     WebDr.rTab();
               }
               WebDr.clickwithmouse("Inquire", "Click on OK");
               WebDr.waitForPageLoaded();
               WebElement wbDocs = Driver.driver.findElement(By.xpath("//table[@id='grdAudTran']/tbody"));
               List obCellDatatr = wbDocs.findElements(By.tagName("tr"));
               int introws = obCellDatatr.size();
               if (introws > 1)
                     HtmlReporter.WriteStep("Check if the TD inquiry can be done in TD031 - TD Audit Trail",
                                   "User should be able to check the Accouting entries passed in the TD account like interest accrual, compounding and payout using TD031 option",
                                   "User is able to check the Accouting entries passed in the TD account like interest accrual, compounding and payout using TD031 option for account no "
                                                 + WebDr.getValue("AccountNo"),
                                   true);
               else
                     HtmlReporter.WriteStep("Check if the TD inquiry can be done in TD031 - TD Audit Trail",
                                   "User should be able to check the Accouting entries passed in the TD account like interest accrual, compounding and payout using TD031 option",
                                   "User is not able to check the Accouting entries passed in the TD account like interest accrual, compounding and payout using TD031 option for account no "
                                                 + WebDr.getValue("AccountNo"),
                                   false);
        } catch (Exception exc) {
               exc.printStackTrace();
               HtmlReporter.WriteStep("Check if the TD inquiry can be done in TD031 - TD Audit Trail",
                            "User should be able to check the Accouting entries passed in the TD account like interest accrual, compounding and payout using TD031 option for account no "
                                          + WebDr.getValue("AccountNo"),
                            exc.getMessage(), false);
        }
 }

 public static void TD_AccountLedger_Inquire_TD037() throws Exception {
        try {
               pkgFCRPageObjects.FCR_TDPageObjects.TD_AccountLedger_Inquire_TD037();
               WebDr.fastPath(WebDr.getValue("FastPath"));
               WebDr.waitForPageLoaded();
               WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter TD Account Number");
               WebDr.rTab();
               if (WebDr.SelectCheckbox("AllDeposits", "Checkbox status"))
                     WebDr.rTab();
               if (!(WebDr.getValue("ValueDateFrom") == null)) {
                     WebDr.rClearUpdateTextField("ValueDateFrom", WebDr.getValue("ValueDateFrom"), "Enter ValueDateFrom");
                     WebDr.rTab();
               }
               if (!(WebDr.getValue("ValueDateTo").equals("NA"))) {
                     WebDr.rClearUpdateTextField("ValueDateTo", WebDr.getValue("ValueDateTo"), "Enter ValueDateTo");
                     WebDr.rTab();
               }
               WebDr.clickwithmouse("Inquire", "Click on OK");
               WebDr.waitForPageLoaded();
               WebElement wbDocs = Driver.driver.findElement(By.xpath("//table[@id='grdAcctTran']/tbody"));
               List obCellDatatr = wbDocs.findElements(By.tagName("tr"));
               int introws = obCellDatatr.size();
               if (introws > 1)
                     HtmlReporter.WriteStep("Check if the TD inquiry can be done in TD037 - TD Account Ledger Inquiry",
                                   "User should be able to check TD ledger entries passed using TD037 option, this would be replicating TD_NoBook",
                                   "User is able to check TD ledger entries passed using TD037 option, this would be replicating TD_NoBook for account no "
                                                 + WebDr.getValue("AccountNo"),
                                   true);
               else
                     HtmlReporter.WriteStep("Check if the TD inquiry can be done in TD037 - TD Account Ledger Inquiry",
                                   "User should be able to check TD ledger entries passed using TD037 option, this would be replicating TD_NoBook",
                                   "User is not able to check TD ledger entries passed using TD037 option, this would be replicating TD_NoBook for account no "
                                                 + WebDr.getValue("AccountNo"),
                                   false);
        } catch (Exception exc) {
               exc.printStackTrace();
               HtmlReporter.WriteStep("Check if the TD inquiry can be done in TD037 - TD Account Ledger Inquiry",
                            "User should be able to check TD ledger entries passed using TD037 option, this would be replicating TD_NoBook"
                                          + WebDr.getValue("AccountNo"),
                            exc.getMessage(), false);
        }
 }

 public static void TD_AccountTDS_Inquire_TDS11() throws Exception {
        try {
               pkgFCRPageObjects.FCR_TDPageObjects.TD_AccountTDS_Inquire_TDS11();
               WebDr.fastPath(WebDr.getValue("FastPath"));
               WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"),
                            "Enter Search Criteria");
               WebDr.rTab();
               WebDr.setText("SearchString", WebDr.getValue("SearchString"), "Enter Search String");
               WebDr.rTab();

               WebDr.SwitchToLatestWindow();
               WebDr.SelectTopAcct();
               WebDr.SwitchToLatestWindow();

               WebDr.clickwithmouse("Inquire", "Click on the Inquire Button");

               WebDr.waitForPageLoaded();
               WebElement wbDocs = WebDr.getElement("CustTable");
               List obCellDatatr = wbDocs.findElements(By.tagName("tr"));
               int introws = obCellDatatr.size();
               if (introws < 1)
                     throw new Exception();

               WebDr.doubleclickwithmouse("CustTableCell", "Click on the CustTable record");
               WebDr.waitForPageLoaded();

               WebDr.waitForPageLoaded();
               wbDocs = WebDr.getElement("CustTable");
               obCellDatatr = wbDocs.findElements(By.tagName("tr"));
               introws = obCellDatatr.size();
               if (introws < 1)
                     throw new Exception();

               HtmlReporter.WriteStep(
                            "Check if this option allowes user to inquire Accountwise and branchwise TDS details",
                            "User should be allowed to inquire accountwise and branchwise TDS details",
                            "User is allowed to inquire accountwise and branchwise TDS details", true);

        } catch (Exception exc) {
               exc.printStackTrace();
               HtmlReporter.WriteStep(
                            "Check if this option allowes user to inquire Accountwise and branchwise TDS details",
                            "User should be allowed to inquire accountwise and branchwise TDS details",
                            "User is not allowed to inquire accountwise and branchwise TDS details", false);
        }
 }


	public static void TD_Product_Master_Modify_TDM01() throws Exception {
		boolean chk1, chk2, chk3;
		try {
			pkgFCRPageObjects.FCR_TDPageObjects.TDM01_page();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();

			WebDr.clickwithmouse("TDModifyRadioButton", "Click on the Modify Radio Button");
			WebDr.alertAccept();

			WebDr.waitForElement("ProdCode");
			WebDr.setText("ProdCode", WebDr.getValue("ProdCode"), "Enter TD Prod Code");
			WebDr.rTab();
			WebDr.waitForPageLoaded();

			chk1 = WebDr.isElementDisabled("ProdCode", "Check Prod Code");

			WebDr.click("OnMaturity", "Click on link OnMaturity");
			WebDr.waitForPageLoaded();
			chk2 = WebDr.enabled("ForcedTerm", true, "Check Forced Term");
			chk3 = WebDr.enabled("AutoTerm", true, "Check Auto Term");

			if (chk1) {
				HtmlReporter.WriteStep(
						"Check whether the user is able to modify the product code or not after navigating to FP TDM01",
						"User should not be able to modify the product code in TDM01.",
						"User is not be able to modify the product code in TDM01.", true);
			} else {
				HtmlReporter.WriteStep(
						"Check whether the user is able to modify the product code or not after navigating to FP TDM01",
						"User should not be able to modify the product code in TDM01.",
						"User is able to modify the product code in TDM01.", false);
			}

			if (chk2 && chk3) {
				HtmlReporter.WriteStep(
						"Check whether the user is able to modify the term or not after navigating to FP TDM01",
						"User should be able to modify the term in TDM01.", "User is able to modify the term in TDM01.",
						true);
			} else {
				HtmlReporter.WriteStep(
						"Check whether the user is able to modify the term or not after navigating to FP TDM01",
						"User should be able to modify the term in TDM01.",
						"User is not able to modify the term in TDM01.", false);
			}

		} catch (Exception e) {
			HtmlReporter.WriteStep(
					"Check whether the user is able to modify the term or not after navigating to FP TDM01",
					"User should be able to modify the term in TDM01.",
					"Error occured during  modification of the product code in TDM01." + e.getMessage(), false);
		}

	}

	public static void TD_Product_Master_ModifyAuthorize_TDM01() throws Exception {
		boolean chk1, chk2, chk3;
		String forcedterm, autoterm;
		try {
			pkgFCRPageObjects.FCR_TDPageObjects.TDM01_page();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();

			WebDr.clickwithmouse("TDModifyRadioButton", "Click on the Modify Radio Button");
			WebDr.alertAccept();

			WebDr.waitForElement("ProdCode");
			WebDr.setText("ProdCode", WebDr.getValue("ProdCode"), "Enter TD Prod Code");
			WebDr.rTab();
			WebDr.waitForPageLoaded();

			chk1 = WebDr.isElementDisabled("ProdCode", "Check Prod Code");

			WebDr.click("OnMaturity", "Click on link OnMaturity");
			WebDr.waitForPageLoaded();
			chk2 = WebDr.enabled("ForcedTerm", true, "Check Forced Term");
			chk3 = WebDr.enabled("AutoTerm", true, "Check Auto Term");

			if ((!chk2) || (!chk3))
				throw new Exception();

			forcedterm = WebDr.getValue("ForcedTerm");
			autoterm = WebDr.getValue("AutoTerm");
			if (forcedterm.equals(WebDr.getTextBoxValue("ForcedTerm", "Get ForcedTerm")))
				forcedterm = String.valueOf(Integer.parseInt(forcedterm) - 1);

			if (autoterm.equals(WebDr.getTextBoxValue("AutoTerm", "Get AutoTerm")))
				autoterm = String.valueOf(Integer.parseInt(autoterm) - 1);

			WebDr.rClearUpdateTextField("ForcedTerm", forcedterm, "Modify ForcedTerm");
			WebDr.rClearUpdateTextField("AutoTerm", autoterm, "Modify AutoTerm");

			if (chk1) {
				HtmlReporter.WriteStep(
						"Check whether the user is able to modify and authorize the product code or not after navigating to FP TDM01",
						"User should not be able to modify and authorize the product code in TDM01.",
						"User is not be able to modify the product code in TDM01.", true);
			} else {
				HtmlReporter.WriteStep(
						"Check whether the user is able to modify and authorize the product code or not after navigating to FP TDM01",
						"User should not be able to modify and authorize the product code in TDM01.",
						"User is able to modify the product code in TDM01.", false);
			}

		} catch (Exception e) {
			HtmlReporter.WriteStep(
					"Check whether the user is able to modify and authorize the term or not after navigating to FP TDM01",
					"User should not be able to modify and authorize the product code in TDM01.",
					"Erro occured during  modification of the product code in TDM01." + e.getMessage(), false);
		}

	}

	public static void TD_ProductRate_Inquire_TD060() throws Exception {
		try {
			pkgFCRPageObjects.FCR_TDPageObjects.TD_ProductRate_Inquire_TD060();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.clickwithmouse("TDInquireRadioButton", "Click on the Inquire Radio Button");
			WebDr.setText("ProdCode", WebDr.getValue("ProdCode"), "Enter ProdCode");
			WebDr.rTab();
			WebDr.waitForPageLoaded();

			String prodname = WebDr.getTextBoxValue("ProdName", "Get TD ProdName");
			if (prodname.isEmpty())
				throw new Exception();

			WebDr.clickwithmouse("Close", "Click on the Close Button");
			WebDr.waitForPageLoaded();
			HtmlReporter.WriteStep("Check whether the valid user is able to navigate FP TD060 or not.",
					"Valid user should be able to navigate FP TD060", "Valid user is able to navigate FP TD060", true);

		} catch (Exception exc) {
			exc.printStackTrace();
			HtmlReporter.WriteStep("Check whether the valid user is able to navigate FP TD060 or not",
					"Valid user should be able to navigate FP TD060", "Valid user is not able to navigate FP TD060",
					false);
		}
	}

	public static void TD_ProductRate_Modify_TD060() throws Exception {
        try {
               pkgFCRPageObjects.FCR_TDPageObjects.TD_ProductRate_Inquire_TD060();
               WebDr.fastPath(WebDr.getValue("FastPath"));
               WebDr.clickwithmouse("TDModifyRadioButton", "Click on the Inquire Radio Button");
               WebDr.alertAccept();
               WebDr.setText("ProdCode", WebDr.getValue("ProdCode"), "Enter ProdCode");
               
               WebDr.rTab();
               
               WebDr.waitForPageLoaded();

               //String prodname = WebDr.getTextBoxValue("ProdName", "Get TD ProdName");
               WebElement elmn= driver.findElement(By.id("txtIncrementalAmt"));
               
               if (elmn.isEnabled())
               {
               
               HtmlReporter.WriteStep("Check whether the valid user is able to modify FP TD060 or not.",
                            "Valid user should not be able to navigate FP TD060", "Valid user is able to navigate FP TD060", false);
               }else
               {
                     HtmlReporter.WriteStep("Check whether the valid user is able to modify FP TD060 or not.",
                                   "Valid user should not be able to navigate FP TD060", "Valid user is not able to navigate FP TD060", true);
               }

        } catch (Exception exc) {
               exc.printStackTrace();
               HtmlReporter.WriteStep("Check whether the valid user is able to navigate FP TD060 or not",
                            "Valid user should be able to navigate FP TD060", "Valid user is not able to navigate FP TD060",
                            false);
        }
 }

	
}
