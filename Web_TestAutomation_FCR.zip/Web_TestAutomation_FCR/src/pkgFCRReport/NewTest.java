package pkgFCRReport;

import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;

import testCases.Driver;

import org.testng.annotations.BeforeTest;
import org.junit.AfterClass;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;

import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;

import pkgFCRPageObjects.FCR_BNC;
import pkgFCRResuableModule.CIF;
import pkgFCRResuableModule.Clearing;
import pkgFCRResuableModule.FCRBNC;
import pkgFCRResuableModule.GEFU;
import pkgFCRResuableModule.CASA;
import pkgFCRResuableModule.LOAN;
import pkgFCRResuableModule.Master;
import pkgFCRResuableModule.Remittance;
import pkgFCRResuableModule.Report;
import pkgFCRResuableModule.TD;
import utility.FCRDBConnection;
import utility.WebDr;

public class NewTest extends Driver {
	static ExtentTest test;
	static ExtentReports report;
	
 
public static void executeTC(WebDriver driver, String str_tc)
					throws Exception {
				// System.out.println("TestFlowBIR.java- executeTC Invoked");
			
				switch (str_tc) {
				case "Login":
					Login(driver);
					break;
				case "MultipleLogin":
					multipleLogout(driver);
					break;
				case "multipleLogout":
					multipleLogout(driver);
					break;
				case "FCR_BNC":
					TC_FCR_BNC(driver);
					break;
				case "TC_CS_05":
					TC_CS_05(driver);
					break;
				case "LogoutWithClose":
					LogoutWithClose(driver);
					break;
				}
				
				//case "FCRDbconnection":
					//TC_FCRDbconnection(
	 // pkgFCRResuableModule.LOAN.login();
	 // pkgFCRResuableModule.CIF.Customer_Search_1000();
  }

  private static void LogoutWithClose(WebDriver driver) throws Exception {
	// TODO Auto-generated method stub
	  LOAN.logoutwithclose();
	
}

private static void TC_CS_05(WebDriver driver) throws Exception {
	// TODO Auto-generated method stub
	CASA.CustomerSearch_1000();
	
}

private static void multipleLogout(WebDriver driver) {
	// TODO Auto-generated method stub
	
}

private static void TC_FCR_BNC(WebDriver driver) {
	// TODO Auto-generated method stub
	
}
@Test
private static void Login(WebDriver driver) throws Exception {
	LOAN.launch();
	LOAN.login();
	// TODO Auto-generated method stub
	
}

@BeforeSuite
  public static void StartTest()
  {
                  report = new ExtentReports("C:\\TestData\\Htmlreport\\ExtentReportResults.html");
                  test = report.startTest("SanityPack");
                  
  }
  @AfterSuite
  public static void EndTest()
  {
                  report.endTest(test);
                  report.flush();
  }
 
  @BeforeTest
  public void beforeTest() throws Exception {
	  testCases.Driver.mainDriver();
	  
  }

  @AfterTest
  public void afterTest() throws Exception {
	  //pkgFCRResuableModule.LOAN.logout();
  }

}
