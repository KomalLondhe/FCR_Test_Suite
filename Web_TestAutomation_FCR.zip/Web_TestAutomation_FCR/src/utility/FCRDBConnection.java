package utility;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.apache.poi.hssf.record.formula.functions.Char;

import testCases.Driver;

public class FCRDBConnection  extends Driver{
	static Connection con_fcr = null;
	static String data = null;
	static String DBData = null;
	//static String DBDataBatch = null;
	static Statement stmt_fcr = null;
	
	public static void openconnection(String DBServiceName, String DBUsername, String DBPassword) throws Exception {
		try {
			DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con_fcr = DriverManager.getConnection(
					"jdbc:oracle:thin:@//jhbdcr00266n01.corp.dsarena.com:2521/" + DBServiceName, DBUsername, DBPassword);
			System.out.println("FCR Database Connection Successful");
			HtmlReporter.WriteStep("User is able to connect Database", "Database connection should be successful",
					"FCR Database Connection Successful", true);
		} catch (SQLException e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("User is able to connect Database", "Database connection should be successful",
					"FCR Database Connection UnSuccessful", false);
		}

	}

	public static String getValuefromDB(String query) throws Exception {
		try{
		stmt_fcr = con_fcr.createStatement();
		ResultSet rs = stmt_fcr.executeQuery(query);
		while (rs.next()) {
			data = rs.getString(1);
		
			System.out.println("Value received from Database :   " + data);
			HtmlReporter.WriteStep("Verify user is able to fetch data from database",
					"Value fetched from database =" + data, "Database validation successful", true);
		}
		}
		catch (SQLException e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Verify user is able to fetch data from database",
					"Value fetched from database =" + data, "Database validation not successful", false);
		}
		return data;
	}

	public static boolean verifyValueFromDB(String query, String ExpectedResult) throws Exception {
		try
		{
		stmt_fcr = con_fcr.createStatement();
		ResultSet rs = stmt_fcr.executeQuery(query);
		while (rs.next()) {
			data = rs.getString(1);
			//System.out.println("Bank Name :   " + data);		
		}
		}
		catch (SQLException e) {
			e.printStackTrace();
			
		}
		if (data.equals(ExpectedResult)) {

			HtmlReporter.WriteStep("Verify user is able to fetch data from database",
					"Value verified from database =" + data, "Database validation successful", true);
			return true;
		} else {
			HtmlReporter.WriteStep("Verify user is able to fetch data from database",
					"Value verified from database =" + data, "Database validation successful", false);
			return false;
		}
	}

	public static void closeConnection() {
		try {
			// con_xlrt.close();
			con_fcr.close();
			// con_bem.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public static String DBValidation_FetchValue(String Query) throws Exception
	{
		try
		{
			FCRDBConnection.openconnection(WebDr.DBServiceName, WebDr.DBUsername, WebDr.DBPassword);
			DBData = FCRDBConnection.getValuefromDB(Query);
			FCRDBConnection.closeConnection();
			
		}
		catch (SQLException e) {
			e.printStackTrace();	
		}
		return DBData;
		
	}
	public static String DB_ConnectivityVerification(String Query) throws Exception
	{
		try
		{
			FCRDBConnection.openconnection(WebDr.DBServiceName, WebDr.DBUsername, WebDr.DBPassword);
			DBData = FCRDBConnection.getValuefromDB(Query);
			System.err.println("DB data : ********************" +DBData);
			FCRDBConnection.closeConnection();
			
			if (DBData!=null) {

				HtmlReporter.WriteStep("Verify user is able to retrieve data from database and check for database connectivity",
						"User should be able to retrieve data from database and check for database connectivity", "Value from Database retrieved successfully, Database connection successful", true);
				
			} else if(DBData==null){
				HtmlReporter.WriteStep("Verify user is able to retrieve data from database and check for database connectivity",
						"User should be able to retrieve data from database and check for database connectivity", "Value from Database not retrieved successfully, Database connection successful", true);
				
			}
			else
			{
				HtmlReporter.WriteStep("Verify user is able to check for database connectivity",
						"User should be able to  check for database connectivity", "Database connection not successful", false);
			}
		}	
		catch (SQLException e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Verify user is able to connect to database successfully",
					"User should be able to connect to database successfully", "Database connection not successful", false);
		}
		return DBData;
		
		
	}
	public static boolean DBValidation_VerifyValue() throws Exception
	{
		try
		{
			FCRDBConnection.openconnection(WebDr.DBServiceName, WebDr.DBUsername, WebDr.DBPassword);
			FCRDBConnection.verifyValueFromDB(DBData,WebDr.getValue("ExpectedValue"));
			FCRDBConnection.closeConnection();
		}
		catch (SQLException e) {
			e.printStackTrace();
			
		}
		return true;	
	}
	
	
	public static String QueryValueExecutor(String ExcelQuery, String Value, String AppendQuery) throws Exception
	{
		try
		{
			FCRDBConnection.openconnection(WebDr.DBServiceName, WebDr.DBUsername, WebDr.DBPassword);
			String FinalQuery = ExcelQuery.concat(Value).concat(AppendQuery);
			DBData = FCRDBConnection.getValuefromDB(FinalQuery);
			FCRDBConnection.closeConnection();
		}
		catch (SQLException e) {
			e.printStackTrace();	
		}
		return DBData;
		
	}

	public static void BatchRun_Status(String Query) throws Exception
	{
		try
		{
			String batchdata = null;
			FCRDBConnection.openconnection(WebDr.DBServiceName, WebDr.DBUsername, WebDr.DBPassword);
			stmt_fcr = con_fcr.createStatement();
			ResultSet rs = stmt_fcr.executeQuery(Query);
			while (rs.next()) {
				batchdata = rs.getString(1);
				System.out.println("Value received from Database :   " + batchdata);
				HtmlReporter.WriteStep("Verify user is able to fetch data from database",
						"Value fetched from database =" + batchdata, "Database validation successful", true);
			}
			//DBDataBatch = FCRDBConnection.getValuefromDB(Query);
			System.err.println("DB data : ********************" +batchdata);
			FCRDBConnection.closeConnection();
			
			if (batchdata==null) {
				HtmlReporter.WriteStep("Verify user is able to check for Batch run status",
						"User should be able to  check for Batch run status", "No batch run in progress", true);
				
			} 
			else if (batchdata=="R")
			{
				HtmlReporter.WriteStep("Verify user is able to check for Batch run status",
						"User should be able to  check for Batch run status", "Batch run in progress", false);
			}
			else
			{
				HtmlReporter.WriteStep("Verify user is able to check for Batch run status",
						"User should be able to  check for Batch run status", "Batch run in progress", false);
			}
			
		}	
		catch (SQLException e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Verify user is able to check for Batch run status",
					"User should be able to  check for Batch run status", "Batch run in progress", false);
		}
		//return DBDataBatch;
		
		
	}
}