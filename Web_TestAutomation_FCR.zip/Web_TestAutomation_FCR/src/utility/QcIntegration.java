package utility;

public class QcIntegration {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/*// TODO Auto-generated method stub
		 ALMServiceWrapper wrapper = new ALMServiceWrapper(
                 "http://localhost:8081/qcbin");*/
	}

}
