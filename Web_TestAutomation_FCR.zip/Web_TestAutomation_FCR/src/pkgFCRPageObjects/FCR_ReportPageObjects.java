package pkgFCRPageObjects;

import java.util.HashMap;
import java.util.Map;

import utility.WebDr;

public class FCR_ReportPageObjects {

	
	
	public static void ReportCategory_Request(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 
		    My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		    My_Page_Objects.put("Report_type", "XPATH|(//input[@id='radio1'])[position()="+ (WebDr.getValue("Report_type")) +"]|fraTxn/showdata");		   
		    My_Page_Objects.put("Category", "XPATH|//table[@id='TabTbl']//td[contains(text(),'"+(WebDr.getValue("CategoryName"))+"')]|fraTxn/showdata");
		    My_Page_Objects.put("Report_Group", "XPATH|//table[@id='SideTbl'][1]//td[contains(text(),'"+(WebDr.getValue("ReportGroup"))+"')]|fraTxn/showdata");
		   
		    My_Page_Objects.put("Report_ID", "XPATH|//tr[@id='"+(WebDr.getValue("ReportID_row"))+"']/td[contains(text(),'"+(WebDr.getValue("ReportID"))+"')]");
		    
		    
		    WebDr.page_Objects = My_Page_Objects;
		    
		
	}
	
	public static void ReportCategory_Request_7778(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 
		    My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		   // My_Page_Objects.put("Report_type", "ID|radio1|fraTxn/showdata");
		    My_Page_Objects.put("View_btn", "ID|btnView|fraTxn/showdata");
		    WebDr.page_Objects = My_Page_Objects;
	}
	
	
	

	public static void ReportCategory_Request_CH220(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		    My_Page_Objects.put("SystemDate","XPATH|//input[@id='PostDate']|fraMenu/left");
		    My_Page_Objects.put("AccountNo", "XPATH|//input[@id='Param' and @rownum='1']|fraTxn/showdata");
		    My_Page_Objects.put("FromDate", "XPATH|//input[@id='Param' and @rownum='2']|fraTxn/showdata");
		    My_Page_Objects.put("ToDate", "XPATH|//input[@id='Param' and @rownum='3']");
		    My_Page_Objects.put("WaiveSC", "XPATH|//input[@id='Param' and @rownum='4']");
		    My_Page_Objects.put("ValueDate", "XPATH|//input[@id='Param' and @rownum='5']");
		    My_Page_Objects.put("ValueDate", "XPATH|//input[@id='Param' and @rownum='5']");
		    My_Page_Objects.put("Generate_btn", "ID|btnGenerate|fraTxn/showdata");
		    My_Page_Objects.put("LoggedInUser", "XPATH|//select[@id='UserID']|fraTxn/showdata");
		    My_Page_Objects.put("View_btn", "ID|btnView|fraTxn/showdata");
		    
		 
		 WebDr.page_Objects = My_Page_Objects;
		    
			
		}
	
	public static void ReportCategory_Request_GL008(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 	My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		    My_Page_Objects.put("SystemDate","XPATH|//input[@id='PostDate']|fraMenu/left");
		    if (WebDr.strFCRCountry.equals("BBK")){
		    	 My_Page_Objects.put("BranchCode", "XPATH|//input[@id='Param' and @rownum='1']|fraTxn/showdata");
				 My_Page_Objects.put("GLAccountNo", "XPATH|//input[@id='Param' and @rownum='2']|fraTxn/showdata");
		    }
		    else{
		    My_Page_Objects.put("GLAccountNo", "XPATH|//input[@id='Param' and @rownum='1']|fraTxn/showdata");
		    My_Page_Objects.put("BranchCode", "XPATH|//input[@id='Param' and @rownum='2']|fraTxn/showdata");
		    }
		    My_Page_Objects.put("FromDate", "XPATH|//input[@id='Param' and @rownum='3']|fraTxn/showdata");
		    My_Page_Objects.put("ToDate", "XPATH|//input[@id='Param' and @rownum='4']|fraTxn/showdata");
		    My_Page_Objects.put("Generate_btn", "ID|btnGenerate|fraTxn/showdata");

		    WebDr.page_Objects = My_Page_Objects;
		    
			
	}
	
	public static void ReportCategory_Request_CH112(){
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 	My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		    My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		    My_Page_Objects.put("SystemDate","XPATH|//input[@id='PostDate']|fraMenu/left");
		    My_Page_Objects.put("Process_date","XPATH|//input[@id='btRepDt']|fraTxn/showdata");
		    
		    My_Page_Objects.put("View_btn", "ID|btnView|fraTxn/showdata");
		    

		    WebDr.page_Objects = My_Page_Objects;
		    
			
	}
	
	
}
