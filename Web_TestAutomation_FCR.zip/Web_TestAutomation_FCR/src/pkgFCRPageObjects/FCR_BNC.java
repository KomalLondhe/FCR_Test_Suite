package pkgFCRPageObjects;

import java.util.HashMap;
import java.util.Map;

import pkgFCRResuableModule.Clearing;
import utility.WebDr;

public class FCR_BNC {

	public static void BNCNavigateFastpath(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("Close","ID|ctlClose|fraTxn/showdata" );
        My_Page_Objects.put("Caption","ID|formCaption|fraTxn/showdata" );
        My_Page_Objects.put("RadioAdd", "XPATH|//input[@name='ctlMntToolBar' and @value='a']|fraTxn/showdata");
        My_Page_Objects.put("RadioModify", "XPATH|//input[@name='ctlMntToolBar' and @value='m']|fraTxn/showdata");
        My_Page_Objects.put("RadioDelete", "XPATH|//input[@name='ctlMntToolBar' and @value='d']|fraTxn/showdata");
        My_Page_Objects.put("RadioCancel", "XPATH|//input[@name='ctlMntToolBar' and @value='k']|fraTxn/showdata");
        My_Page_Objects.put("RadioAmend", "XPATH|//input[@name='ctlMntToolBar' and @value='n']|fraTxn/showdata");
        My_Page_Objects.put("RadioAuthorize", "XPATH|//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");
        My_Page_Objects.put("RadioEnquiry", "XPATH|//input[@name='ctlMntToolBar' and @value='i']|fraTxn/showdata");
        
        
        My_Page_Objects.put("Help","ID|tbHelp|UpperFrame" );
        //My_Page_Objects.put("Oracle_Help","XPATH|//div[@id='tbFCR_tbHelp']//span[@id='HL001' and @class='TopicMenuActive_HTC']|showdata" );
        //My_Page_Objects.put("Oracle_Help","XPATH|//span[@id='HL001' and @class='TopicMenuActive_HTC']|showdata" );
        My_Page_Objects.put("Oracle_Help","ID|HL001|showdata" );
        
//        My_Page_Objects.put("ProductName","ID|ProductCode" );
//        My_Page_Objects.put("AccountTitle","ID|AcctTitle" );
//        My_Page_Objects.put("SerialNo","ID|SerialNo" );
      /*  My_Page_Objects.put("CustomerIC1","ID|NationalID1" );
        My_Page_Objects.put("CustomerIC2","ID|NationalID2" );
        My_Page_Objects.put("CustomerIC3","ID|NationalID3" );
        My_Page_Objects.put("Category1","ID|CustomerType1|fraTxn/showdata" );
        My_Page_Objects.put("Category2","ID|CustomerType2" );
        My_Page_Objects.put("Category3","ID|CustomerType3" );
        My_Page_Objects.put("Relation1","ID|CustomerAcctRel1|fraTxn/showdata" );
        My_Page_Objects.put("Relation2","ID|CustomerAcctRel2" );
        My_Page_Objects.put("Relation3","ID|CustomerAcctRel3" );
        My_Page_Objects.put("OfficerID","ID|OfficerID" );
        My_Page_Objects.put("TaxCode","ID|TaxCode" );
        My_Page_Objects.put("TaxCode2","ID|TaxCode_2" );
        My_Page_Objects.put("ChequeBookRequest","ID|FlgChBkReq" );
        My_Page_Objects.put("InterestWaiver","ID|FlgIntWav" );
        My_Page_Objects.put("NoOfLeaves","ID|NoOfChqLeaves" );
        My_Page_Objects.put("RestrictedAcct","ID|Restricted" );
        My_Page_Objects.put("DepositTerm","ID|RdDepTerm" );
        My_Page_Objects.put("MinorAcctStatus","ID|RdMinorAcct" );
        My_Page_Objects.put("CreditIntVar","ID|RdCrIntVar" );
        My_Page_Objects.put("DebitIntVar","ID|RdDrIntVar" );
        My_Page_Objects.put("InstallmentAmt","ID|RdInstAmt" );
        My_Page_Objects.put("Validate","ID|btnValdCust" );
        My_Page_Objects.put("Ok","ID|btnOk|fraTxn/showdata" );
	    My_Page_Objects.put("SystemDate","XPATH|//input[@id='PostDate']|fraMenu/left");
        My_Page_Objects.put("UDFDate","XPATH|//input[@id='UDFValue'][1]|fraPop/showdata" );
        My_Page_Objects.put("UDFValidate","XPATH|//input[@id='btnValidate']");
        My_Page_Objects.put("UDFBack","XPATH|//input[@id='Back']");
        My_Page_Objects.put("CustPick","ID|CustSearch1|");
        My_Page_Objects.put("SelectSearchCriteria", "ID|SearchCrit|fraPop/showdata");
        My_Page_Objects.put("SearchValue", "ID|SearchStr");
        My_Page_Objects.put("SelectRow", "XPATH|//tr[@class='TGridNormal']");				*/
		WebDr.page_Objects = My_Page_Objects;
	}
	
/*	public static void CashDeposit_1401(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("AccountNo","ID|AccountNo|fraTxn/showdata" );
        My_Page_Objects.put("TxnCurrency","ID|TCY_Code");
        My_Page_Objects.put("TxnAmount","ID|TCY_Amount" );
        My_Page_Objects.put("DepositorID","ID|TaxPayerID");
        My_Page_Objects.put("DepositorName","ID|TaxPayerName");
        My_Page_Objects.put("UserRefNo","ID|User_Ref_No|fraTxn/showdata" );
        My_Page_Objects.put("Ok","ID|btnOk|fraTxn/showdata" );
        My_Page_Objects.put("Sign","XPATH|.//input[@id='PhotoImage' and @value='1']|fraPop/showdata" );
       // My_Page_Objects.put("Sign","ID|PhotoImage|fraPop/showdata" );
        My_Page_Objects.put("SignOk","ID|btnOkImage");
        My_Page_Objects.put("SignZoom","XPATH|//input[@name='ZoomIN']");
        My_Page_Objects.put("SignVerified","ID|btnSign|fraPop/showdata");
        My_Page_Objects.put("SignCancel","ID|btnCancel");
        My_Page_Objects.put("StatusBar","ID|StatusBar|bottom/");
        My_Page_Objects.put("Denomination", "XPATH|//input[@value='UPDATEDENOMINATION']/parent::td/following-sibling::td[2]/input|fraPop/showdata");
        My_Page_Objects.put("D_Ok","ID|btnOk|fraPop/showdata" );
        
        
        WebDr.page_Objects = My_Page_Objects;
	}*/
	
}
