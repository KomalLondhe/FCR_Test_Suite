package pkgFCRPageObjects;

import java.util.HashMap;
import java.util.Map;

import pkgFCRResuableModule.Clearing;
import utility.WebDr;

public class FCR_ClearingPageObjects {
	public static void InwardClearing_5521(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("Action", "XPATH|//select[@id='Action']|fraTxn/showdata");
        My_Page_Objects.put("Batch_number", "ID|BatchNum");
        My_Page_Objects.put("Batch_Status", "ID|BatchStat");
        My_Page_Objects.put("EndPoint", "ID|EndPoint");
        My_Page_Objects.put("Currency", "ID|TCY_Code");
        My_Page_Objects.put("Cheque_Count", "ID|ChqCnt");
        My_Page_Objects.put("Clearing_Type", "ID|ICType");
        My_Page_Objects.put("OK_5521", "ID|btnOk");
        My_Page_Objects.put("Save_5521", "ID|btnSave|fraTxn/showdata");
        My_Page_Objects.put("AccountNo", "XPATH|//input[@id='AccountNo']|fraTxn/showdata");
        My_Page_Objects.put("Cheque_Routing_No", "XPATH|//input[@id='ChqRoutingNo']");
        My_Page_Objects.put("Cheque_No", "XPATH|//input[@id='ChequeNo']");
        My_Page_Objects.put("Amount", "XPATH|//input[@id='TCY_Amount']");
        My_Page_Objects.put("PayeeName", "XPATH|//input[@id='PayeeName']");
        My_Page_Objects.put("Payee_RoutingNo", "XPATH|//input[@id='Payee_RoutingNo']");
        My_Page_Objects.put("Validate_btn_5521", "XPATH|//input[@id='btnValidate']|fraTxn/showdata");
        My_Page_Objects.put("Authorize_btn", "XPATH|//input[@id='btnAuth']|fraTxn/showdata");
  
        
        WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void Auth_InwardClearing_ST032(){
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	       My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	       My_Page_Objects.put("Details_Tab", "XPATH|//a/label[contains(text(),'Details of Batches')]|fraTxn/showdata");
	       My_Page_Objects.put("Batch_Click", "XPATH|//table[@id='GridAuthBat']//td[contains(text(),'"+WebDr.BatchNo+"')]|fraTxn/showdata");
	      // My_Page_Objects.put("Batch_Click", "XPATH|//table[@id='GridAuthBat']//td[contains(text(),'35285')]|fraTxn/showdata");
	       My_Page_Objects.put("Authorize_btn_ST032", "ID|CmdAuthorize|fraTxn/showdata");
	       
	       My_Page_Objects.put("Previous_btn_ST032", "ID|CmdPrev");
	       My_Page_Objects.put("Next_btn_ST032", "ID|CmdNext");
	       My_Page_Objects.put("EndPoint", "ID|ctlCodEndPoint|fraTxn/showdata");
	       My_Page_Objects.put("Clearing_Type", "ID|ctlictype|fraTxn/showdata");
	       My_Page_Objects.put("OK_ST033", "ID|ctlOK|fraTxn/showdata");
	       
	       
	       
		 WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void ClearingViewDebitEntry_CH031(){
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	     My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	     My_Page_Objects.put("SystemDate","XPATH|//input[@id='PostDate']|fraMenu/left");
	     My_Page_Objects.put("AccountNo", "ID|CtlCodAcctNo|fraTxn/showdata");
	     My_Page_Objects.put("RadioTransaction", "ID|optTrnPrd");
	     My_Page_Objects.put("StartDate", "ID|ctlStartDate|fraTxn/showdata");
	     My_Page_Objects.put("EndDate", "ID|ctlEndDate|fraTxn/showdata");
	     My_Page_Objects.put("Inquire", "ID|cmdInquire|fraTxn/showdata");
	     My_Page_Objects.put("ChequeNo", "XPATH|//table[@id='MSFlexGrid1']//td[contains(text(),'"+Clearing.ChequeNo+"')]|fraTxn/showdata");

		 WebDr.page_Objects = My_Page_Objects;
			
	}
	
	public static void Clearing_RejectedCheque_ST034(){
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	     My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	     My_Page_Objects.put("BatchNo","ID|ctlKeyBatchNo|fraTxn/showdata");
	     My_Page_Objects.put("OK_ST034","ID|ctlOK|fraTxn/showdata");
	     My_Page_Objects.put("FailChequeNo", "XPATH|//table[@id='GridScanRej']//td[contains(text(),'"+Clearing.FailedChequeNo+"')]|fraTxn/showdata");
	     My_Page_Objects.put("RejectReason", "ID|ctlRej|fraTxn/showdata");
	     
		 WebDr.page_Objects = My_Page_Objects;
			
	}
	
	public static void Clearing_PassedCheque_ST035(){
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	     My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	     My_Page_Objects.put("BatchNo","ID|ctlKeyBatchNo|fraTxn/showdata");
	     My_Page_Objects.put("OK_ST034","ID|ctlOK|fraTxn/showdata");
	     My_Page_Objects.put("PassChequeNo", "XPATH|//table[@id='GridScanPass']//td[contains(text(),'"+Clearing.PassedChequeNo+"')]|fraTxn/showdata");
		 WebDr.page_Objects = My_Page_Objects;
			
	}
	
	public static void Inquire_Failed_Instrument_ST034(){
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	     My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	     My_Page_Objects.put("BatchNo","ID|ctlKeyBatchNo|fraTxn/showdata");
	     My_Page_Objects.put("OK_ST034","ID|ctlOK|fraTxn/showdata");
	     My_Page_Objects.put("FailChequeNo", "XPATH|//table[@id='GridScanRej']//td[contains(text(),'"+Clearing.ChequeNo+"')]|fraTxn/showdata");
	     My_Page_Objects.put("RejectReason", "ID|ctlRej|fraTxn/showdata");
	     
		 WebDr.page_Objects = My_Page_Objects;
			
	}
	
	public static void OutwardClearing_5506(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("Action", "XPATH|//select[@id='Action']|fraTxn/showdata");
        My_Page_Objects.put("Batch_number", "ID|BatchNum");
        My_Page_Objects.put("Batch_Status", "ID|BatchStat");
        My_Page_Objects.put("DepositBranch", "ID|CodBranch");
        My_Page_Objects.put("Currency", "ID|TCY_Code");
        My_Page_Objects.put("Cheque_Count", "ID|ChqCnt");
        //My_Page_Objects.put("Clearing_Type", "ID|ICType");
        //My_Page_Objects.put("DrawerAccountNo1", "XPATH|//table[@id='TblOutBatDtls']/td/input[@id='DrawerAcct'][1]|fraTxn/showdata");
        //My_Page_Objects.put("DrawerAccountNo2", "XPATH|//table[@id='TblOutBatDtls']/tr/td/input[@id='DrawerAcct'][2]|fraTxn/showdata");
        My_Page_Objects.put("DrawerAccountNo1", "XPATH|(//input[@id='DrawerAcct'])[1]|fraTxn/showdata");
        My_Page_Objects.put("DrawerAccountNo2", "XPATH|(//input[@id='DrawerAcct'])[2]|fraTxn/showdata");
        My_Page_Objects.put("OK_5506", "ID|btnOk");
        My_Page_Objects.put("Save_5506", "ID|btnSave|fraTxn/showdata");
        My_Page_Objects.put("AccountNo", "XPATH|//input[@id='AccountNo']|fraTxn/showdata");
        My_Page_Objects.put("Cheque_Routing_No", "XPATH|//input[@id='ChqRoutingNo']");
        My_Page_Objects.put("Cheque_No", "XPATH|//input[@id='ChequeNo']");
        My_Page_Objects.put("Amount", "XPATH|//input[@id='TCY_Amount']");
        My_Page_Objects.put("PayeeName", "XPATH|//input[@id='PayeeName']");
        My_Page_Objects.put("Payee_RoutingNo", "XPATH|//input[@id='Payee_RoutingNo']");
        My_Page_Objects.put("Validate_btn_5506", "XPATH|//input[@id='btnValidate']|fraTxn/showdata");
        My_Page_Objects.put("Authorize_btn", "XPATH|//input[@id='btnAuth']|fraTxn/showdata");
  
        
        WebDr.page_Objects = My_Page_Objects;
	}
	
	public static void OutwardClearing_ST023(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("Clearinghouse", "ID|ctlCodEndPoint|fraTxn/showdata");
	      My_Page_Objects.put("Clearing_Type", "ID|ctlCodOcClgType|fraTxn/showdata");
	      My_Page_Objects.put("OK_ST023", "ID|ctlOK");
        WebDr.page_Objects = My_Page_Objects;
        
     	}
	
	public static void Inward_Clearing_AccountingEntries(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("SystemDate","XPATH|//input[@id='PostDate']|fraMenu/left");
        My_Page_Objects.put("GL_Acct", "ID|CtlCodGlAcct|fraTxn/showdata");
        My_Page_Objects.put("GL_Branch", "ID|CtlCodCCBrn|fraTxn/showdata");
        My_Page_Objects.put("GL_Currency", "ID|ctlCodeCurrency");
        My_Page_Objects.put("Inquiry_type", "ID|CboInqTyp");
        My_Page_Objects.put("From_Date", "ID|CtlDateFrom|fraTxn/showdata");
        My_Page_Objects.put("To_Date", "ID|CtlDateTo|fraTxn/showdata");
        My_Page_Objects.put("Inquire_GLM04", "ID|CmdInqTrMv|fraTxn/showdata");
         My_Page_Objects.put("GL_Entry", "XPATH|//table[@id='GridTranMov']//td[contains(text(),'"+Clearing.AccountNo+"')]|fraTxn/showdata");
        WebDr.page_Objects = My_Page_Objects;
        
     	}
	
	public static void  ValueDate_Clearing_ST001() {
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		 My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	        My_Page_Objects.put("SystemDate","XPATH|//input[@id='PostDate']|fraMenu/left");
	        My_Page_Objects.put("EndPoint", "ID|ctlCodEndPoint|fraTxn/showdata");
	        My_Page_Objects.put("Clearing_Type", "ID|ctlCodOcClgType|fraTxn/showdata");
	        My_Page_Objects.put("Clearing_Date", "ID|ctlDate");
	        My_Page_Objects.put("OK_ST001", "ID|ctlOK");
		WebDr.page_Objects = My_Page_Objects;
	}
}
