package pkgFCRPageObjects;

import java.util.HashMap;
import java.util.Map;

import utility.WebDr;

public class FCR_GEFUPageObjects {

	public static void GEFU_FileUpload_BA452(){
        Map<String, String> My_Page_Obejcts = new HashMap<String, String>();
        My_Page_Obejcts.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Obejcts.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Obejcts.put("ExtSysCodePickList", "XPATH|//input[@id='ctlextsyscodePick']|fraTxn/showdata");
        My_Page_Obejcts.put("FileTypePickList", "XPATH|//input[@id='ctlfiletypePick']");
        My_Page_Obejcts.put("InputFileName", "XPATH|//input[@id='txtinputfilename']");
        My_Page_Obejcts.put("Narration", "XPATH|//input[@id='txtNarration']");
        My_Page_Obejcts.put("OKButton", "XPATH|//input[@id='ctlOK']|fraTxn/showdata");
        
        
        WebDr.page_Objects = My_Page_Obejcts;
	}
	
	public static void GEFU_FileUploadInquiry_BAM96(){ 
        Map<String, String> My_Page_Obejcts = new HashMap<String, String>();
        My_Page_Obejcts.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Obejcts.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Obejcts.put("ExtSysCodePickList", "XPATH|//input[@id='picklistsyscode']|fraTxn/showdata");
        My_Page_Obejcts.put("FileTypePickList", "XPATH|//input[@id='picklistfiletype']");
        My_Page_Obejcts.put("OKButton", "XPATH|//input[@id='ctlOK']|fraTxn/showdata");
        My_Page_Obejcts.put("GEFUUploadedFile", "XPATH|//table[@id='grdFileList']//td[contains(text(),'Upload_GEFU_02072018_4.txt')]|fraTxn/showdata");
        My_Page_Obejcts.put("GetResponseButton", "XPATH|//input[@id='btnGetResp']|fraTxn/showdata");
        My_Page_Obejcts.put("UserID", "XPATH|//input[@id='txtTellerID']");
        My_Page_Obejcts.put("UploadDate", "XPATH|//input[@id='ctlUploadDate']");
        My_Page_Obejcts.put("ProcessDate", "XPATH|//input[@id='ctlProcessDate']");
        My_Page_Obejcts.put("BranchCode", "ID|ctlBranch|fraTxn/showdata");
        My_Page_Obejcts.put("StartDate", "XPATH|//table[@id='grdFileList']//td[contains(text(),'20/09/2018 11:53:55')]|fraTxn/showdata");
        My_Page_Obejcts.put("EndDate", "XPATH|//table[@id='grdFileList']//td[contains(text(),'20/09/2018 11:53:55')]|fraTxn/showdata");
        My_Page_Obejcts.put("Status", "XPATH|//table[@id='grdFileList']/tbody/tr[1]/td[12]|fraTxn/showdata");
        My_Page_Obejcts.put("Record", "XPATH|//table[@id='grdFileList']/tbody/tr[1]/td[7]|fraTxn/showdata");
        //My_Page_Obejcts.put("RecordDetails", "XPATH|//input[@id='field_data']|fraTxn/showdata");
        My_Page_Obejcts.put("RecordStatus", "XPATH|//table[@id='grdFileDetails']/tbody/tr[1]/td[3]|fraTxn/showdata");
        My_Page_Obejcts.put("RecordDetails", "XPATH|//table[@id='grdRecDetails']/tbody/tr[2]/td[2]|fraTxn/showdata");
         
        WebDr.page_Objects = My_Page_Obejcts;
	}
	
	public static void GEFU_StatementInquiry_CH031(){
        Map<String, String> My_Page_Obejcts = new HashMap<String, String>();
        My_Page_Obejcts.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Obejcts.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Obejcts.put("AccountNumber", "XPATH|//input[@id='CtlCodAcctNo']|fraTxn/showdata");
        
        
        WebDr.page_Objects = My_Page_Obejcts;
	}
	
	
	
}
