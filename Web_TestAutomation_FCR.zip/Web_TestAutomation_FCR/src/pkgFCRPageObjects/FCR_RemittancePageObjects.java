package pkgFCRPageObjects;

import java.util.HashMap;
import java.util.Map;

import utility.WebDr;

public class FCR_RemittancePageObjects {
		
	
	public static void Remittance_DDSaleAgainstCash_8305(){
        Map<String, String> My_Page_Obejcts = new HashMap<String, String>();
        My_Page_Obejcts.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Obejcts.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Obejcts.put("BankCode", "XPATH|//select[@id='IssuerCode1']|fraTxn/showdata");
        My_Page_Obejcts.put("PayableBranchPickList", "XPATH|//input[@id='PicklistPayBr']|fraTxn/showdata");
        My_Page_Obejcts.put("ChqCcyPickList", "ID|PicklistCcy|fraTxn/showdata");
        My_Page_Obejcts.put("TxnCcy", "XPATH|//select[@id='TCY_Code']|fraTxn/showdata");
        My_Page_Obejcts.put("ChequeAmount", "XPATH|//input[@id='ACY_Amount']");
        My_Page_Obejcts.put("MICRNumber", "XPATH|//input[@id='InstrNo']");
        My_Page_Obejcts.put("BeneficiaryName", "XPATH|//input[@id='NamBenef']");
        My_Page_Obejcts.put("PassportICNo", "XPATH|//input[@id='NationalID']");
        My_Page_Obejcts.put("BenfAddr1", "XPATH|//input[@id='Addr1']");
        My_Page_Obejcts.put("BenfAddr2", "XPATH|//input[@id='Addr2']");
        My_Page_Obejcts.put("UserRefNo", "XPATH|//input[@id='User_Ref_No']");
        My_Page_Obejcts.put("OKButton", "XPATH|//input[@id='btnOk']|fraTxn/showdata");
        My_Page_Obejcts.put("UDFWalkInCustName", "XPATH|//input[@id='UDFValue']|fraPop/showdata");
        My_Page_Obejcts.put("ValidateButton", "XPATH|//input[@id='btnValidate']|fraPop/showdata");
        My_Page_Obejcts.put("BackButton", "XPATH|//input[@id='Back']|fraPop/showdata");
        My_Page_Obejcts.put("Denomination", "XPATH|//input[@value='UPDATEDENOMINATION']/parent::td/following-sibling::td[2]/input|fraPop/showdata");
        My_Page_Obejcts.put("OKDenomButton", "XPATH|//input[@id='btnOk']|fraPop/showdata");
        WebDr.page_Objects = My_Page_Obejcts;
	}
	
	public static void Remittance_DDSaleAgainstGL_8306(){
        Map<String, String> My_Page_Obejcts = new HashMap<String, String>();
        My_Page_Obejcts.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Obejcts.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Obejcts.put("BankCode", "XPATH|//select[@id='IssuerCode1']|fraTxn/showdata");
        My_Page_Obejcts.put("PayableBranchPickList", "XPATH|//input[@id='PicklistPayBr']|fraTxn/showdata");
        My_Page_Obejcts.put("GLCurrency", "XPATH|//select[@id='ACY_Code']");
        My_Page_Obejcts.put("ChqCcyPickList", "XPATH|//input[@id='PicklistCcy']");
        My_Page_Obejcts.put("GLAcctNumPickList", "XPATH|//input[@id='PicklistGl']");
        My_Page_Obejcts.put("GLAccountNumber", "XPATH|//input[@id='GlAccountNo']|fraTxn/showdata");
        My_Page_Obejcts.put("ChequeAmount", "XPATH|//input[@id='TCY_Amount']");
        My_Page_Obejcts.put("MICRNumber", "XPATH|//input[@id='InstrNo']");
        My_Page_Obejcts.put("RoutingNumber", "XPATH|//input[@id='InstRoutingNo']");
        My_Page_Obejcts.put("BeneficiaryName", "XPATH|//input[@id='NamBenef']");
        My_Page_Obejcts.put("PassportICNo", "XPATH|//input[@id='NationalID']");
        My_Page_Obejcts.put("BenfAddr1", "XPATH|//input[@id='Addr1']");
        My_Page_Obejcts.put("BenfAddr2", "XPATH|//input[@id='Addr2']");
        My_Page_Obejcts.put("UserRefNo", "XPATH|//input[@id='User_Ref_No']");
        My_Page_Obejcts.put("OKButton", "XPATH|//input[@id='btnOk']|fraTxn/showdata");
        My_Page_Obejcts.put("UDFWalkInCustName", "XPATH|//table[@id='UDF']/tbody[2]/tr[1]/td[5]/child::input|fraPop/showdata");
        My_Page_Obejcts.put("Validate","ID|btnValidate");
        My_Page_Obejcts.put("BackButton","ID|Back");
        
        WebDr.page_Objects = My_Page_Obejcts;
	}
	
	public static void Remittance_BankersChequeSaleAgainstCash_8301(){
        Map<String, String> My_Page_Obejcts = new HashMap<String, String>();
        My_Page_Obejcts.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Obejcts.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Obejcts.put("BankCode", "XPATH|//select[@id='IssuerCode1']|fraTxn/showdata");
        My_Page_Obejcts.put("ChqCcyPickList", "XPATH|//input[@id='PicklistCcy']");
        My_Page_Obejcts.put("TxnCcy", "XPATH|//select[@id='TCY_Code']");
        My_Page_Obejcts.put("ChequeAmount", "XPATH|//input[@id='ACY_Amount']");
        My_Page_Obejcts.put("MICRNumber", "XPATH|//input[@id='InstrNo']");
        My_Page_Obejcts.put("BeneficiaryName", "XPATH|//input[@id='NamBenef']");
        My_Page_Obejcts.put("PassportICNo", "XPATH|//input[@id='NationalID']");
        My_Page_Obejcts.put("BenfAddr1", "XPATH|//input[@id='Addr1']");
        My_Page_Obejcts.put("BenfAddr2", "XPATH|//input[@id='Addr2']");
        My_Page_Obejcts.put("UserRefNo", "XPATH|//input[@id='User_Ref_No']");
        My_Page_Obejcts.put("OKButton", "XPATH|//input[@id='btnOk']|fraTxn/showdata");
        My_Page_Obejcts.put("WalkinCustName", "XPATH|//input[@id='CustName']|fraTxn/showdata");
        My_Page_Obejcts.put("FastPath_GL","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Obejcts.put("GlAcctNo", "XPATH|//input[@id='GlAccountNo']");
        My_Page_Obejcts.put("GlCcy", "XPATH|//select[@id='ACY_Code']");
        My_Page_Obejcts.put("TxnCcy", "XPATH|//select[@id='TCY_Code']");
        My_Page_Obejcts.put("TxnAmount", "XPATH|//select[@id='TCY_Amount']");

        WebDr.page_Objects = My_Page_Obejcts;
	}
	
	public static void Remittance_DDLiquidationInquiryCash_8310(){
        Map<String, String> My_Page_Obejcts = new HashMap<String, String>();
        My_Page_Obejcts.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Obejcts.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Obejcts.put("LiquidationMode", "XPATH|//select[@id='LqdType']|fraTxn/showdata");
        My_Page_Obejcts.put("LiquidationType", "XPATH|//select[@id='LiquidationType']");
        My_Page_Obejcts.put("SerialNo", "XPATH|//input[@id='DocNo']");
        My_Page_Obejcts.put("OKButton", "XPATH|//input[@id='btnOk']|fraTxn/showdata");
        My_Page_Obejcts.put("TransactionCcy", "XPATH|//select[@id='TCY_Code']|fraTxn/showdata");
        My_Page_Obejcts.put("GLAccNo", "XPATH|//input[@name='GlAccountNo1']");  
        My_Page_Obejcts.put("UserRefNo", "XPATH|//input[@id='User_Ref_No']|fraTxn/showdata");
        My_Page_Obejcts.put("OKButton2", "XPATH|//input[@id='btnOk']|fraTxn/showdata");
        My_Page_Obejcts.put("Denomination", "XPATH|//input[@value='UPDATEDENOMINATION']/parent::td/following-sibling::td[2]/input|fraPop/showdata");
        My_Page_Obejcts.put("OKDenomButton", "XPATH|//input[@id='btnOk']|fraPop/showdata");
        My_Page_Obejcts.put("OKButton", "XPATH|//input[@id='btnOk']|fraTxn/showdata");
        
        WebDr.page_Objects = My_Page_Obejcts;
	}
	
	public static void Remittance_DDLiquidationInquiryCASA_8310(){
        Map<String, String> My_Page_Obejcts = new HashMap<String, String>();
        My_Page_Obejcts.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Obejcts.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Obejcts.put("LiquidationMode", "XPATH|//select[@id='LqdType']|fraTxn/showdata");
        My_Page_Obejcts.put("LiquidationType", "XPATH|//select[@id='LiquidationType']");
        My_Page_Obejcts.put("SerialNo", "XPATH|//input[@id='DocNo']");
        My_Page_Obejcts.put("OKButton", "XPATH|//input[@id='btnOk']|fraTxn/showdata");
        My_Page_Obejcts.put("AccountNo", "XPATH|//input[@id='AccountNo']|fraTxn/showdata");
        My_Page_Obejcts.put("UserRefNo", "XPATH|//input[@id='User_Ref_No']|fraTxn/showdata");
        My_Page_Obejcts.put("OKButton2", "XPATH|//input[@id='btnOk']|fraTxn/showdata");
        WebDr.page_Objects = My_Page_Obejcts;
	}
	
	public static void Remittance_BCLiquidationInquiryCash_8307(){
        Map<String, String> My_Page_Obejcts = new HashMap<String, String>();
        My_Page_Obejcts.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Obejcts.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Obejcts.put("LiquidationMode", "XPATH|//select[@id='LqdType']|fraTxn/showdata");
        My_Page_Obejcts.put("SerialNo", "XPATH|//input[@id='DocNo']");
        My_Page_Obejcts.put("LiquidationType", "XPATH|//select[@id='LiquidationType']");
        My_Page_Obejcts.put("OKButton", "XPATH|//input[@id='btnOk']");
        My_Page_Obejcts.put("UserRefNo", "XPATH|//input[@id='User_Ref_No']|fraTxn/showdata");
        My_Page_Obejcts.put("OKButton2", "XPATH|//input[@id='btnOk']|fraTxn/showdata");
        My_Page_Obejcts.put("Denomination", "XPATH|//input[@value='UPDATEDENOMINATION']/parent::td/following-sibling::td[2]/input|fraPop/showdata");
        My_Page_Obejcts.put("OKDenomButton", "XPATH|//input[@id='btnOk']|fraPop/showdata");
        My_Page_Obejcts.put("OKButton2", "XPATH|//input[@id='btnOk']|fraTxn/showdata");
        My_Page_Obejcts.put("GlAccNo", "XPATH|//input[@id='GlAccountNo1']|fraTxn/showdata");
        WebDr.page_Objects = My_Page_Obejcts;
	}
	
	public static void Remittance_BCLiquidationInquiryCASA_8307(){
        Map<String, String> My_Page_Obejcts = new HashMap<String, String>();
        My_Page_Obejcts.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Obejcts.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Obejcts.put("LiquidationMode", "XPATH|//select[@id='LqdType']|fraTxn/showdata");
        My_Page_Obejcts.put("SerialNo", "XPATH|//input[@id='DocNo']");
        My_Page_Obejcts.put("LiquidationType", "XPATH|//select[@id='LiquidationType']");
        My_Page_Obejcts.put("OKButton", "XPATH|//input[@id='btnOk']");
        My_Page_Obejcts.put("AccountNo", "XPATH|//input[@id='AccountNo']|fraTxn/showdata");
        My_Page_Obejcts.put("UserRefNo", "XPATH|//input[@id='User_Ref_No']|fraTxn/showdata");
        My_Page_Obejcts.put("OKButton2", "XPATH|//input[@id='btnOk']|fraTxn/showdata");
        
        
        WebDr.page_Objects = My_Page_Obejcts;
	}
	
	public static void Remittance_DDSaleAgainstAccount_1014(){
        Map<String, String> My_Page_Obejcts = new HashMap<String, String>();
        My_Page_Obejcts.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Obejcts.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Obejcts.put("BankCode", "XPATH|//select[@id='IssuerCode1']|fraTxn/showdata");
        My_Page_Obejcts.put("PayableBranchPickList", "XPATH|//input[@id='PicklistPayBr']|fraTxn/showdata");
        My_Page_Obejcts.put("AccountNumber", "XPATH|//input[@id='AccountNo']");
        My_Page_Obejcts.put("ChqCcyPickList", "XPATH|//input[@id='PicklistCcy']");
        My_Page_Obejcts.put("ChequeAmount", "XPATH|//input[@id='TCY_Amount']");
        My_Page_Obejcts.put("ChqNo", "ID|ChqNo|fraTxn/showdata");
        My_Page_Obejcts.put("MICRNumber", "XPATH|//input[@id='MicrNo']");
        My_Page_Obejcts.put("RoutingNumber", "XPATH|//input[@id='InstRoutingNo']");
        My_Page_Obejcts.put("BeneficiaryName", "XPATH|//input[@id='NamBenef']");
        My_Page_Obejcts.put("PassportICNo", "XPATH|//input[@id='NationalID']");
        My_Page_Obejcts.put("BenfAddr1", "XPATH|//input[@id='Addr1']");
        My_Page_Obejcts.put("BenfAddr2", "XPATH|//input[@id='Addr2']");
        My_Page_Obejcts.put("UserRefNo", "XPATH|//input[@id='User_Ref_No']");
        My_Page_Obejcts.put("OKButton", "XPATH|//input[@id='btnOk']|fraTxn/showdata");
        My_Page_Obejcts.put("UDFWalkInCustName", "XPATH|//table[@id='UDF']/tbody[2]/tr[1]/td[5]/child::input|fraPop/showdata");
        My_Page_Obejcts.put("Validate","ID|btnValidate");
        My_Page_Obejcts.put("BackButton","ID|Back");
        My_Page_Obejcts.put("Sign","XPATH|.//input[@id='PhotoImage' and @value='1']|fraPop/showdata");
        My_Page_Obejcts.put("SignOk","ID|btnOkImage|fraPop/showdata" );
        My_Page_Obejcts.put("SignZoom","XPATH|//input[@name='ZoomIN']");
        My_Page_Obejcts.put("SignVerified","ID|btnSign|fraPop/showdata" );
        My_Page_Obejcts.put("SignCancel","ID|btnCancel|fraPop/showdata");
        
        WebDr.page_Objects = My_Page_Obejcts;
       
	}
	
	public static void Remittance_BCSaleAgainstAccount_1010(){
        Map<String, String> My_Page_Obejcts = new HashMap<String, String>();
        My_Page_Obejcts.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Obejcts.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Obejcts.put("BankCode", "XPATH|//select[@id='IssuerCode1']|fraTxn/showdata");
        My_Page_Obejcts.put("AccountNumber", "XPATH|//input[@id='AccountNo']");
        My_Page_Obejcts.put("ChqCcyPickList", "XPATH|//input[@id='PicklistCcy']");
        My_Page_Obejcts.put("ChequeAmount", "XPATH|//input[@id='TCY_Amount']");
        My_Page_Obejcts.put("MICRNumber", "XPATH|//input[@id='MicrNo']");
        My_Page_Obejcts.put("BeneficiaryName", "XPATH|//input[@id='NamBenef']");
        My_Page_Obejcts.put("PassportICNo", "XPATH|//input[@id='NationalID']");
        My_Page_Obejcts.put("BenfAddr1", "XPATH|//input[@id='Addr1']");
        My_Page_Obejcts.put("BenfAddr2", "XPATH|//input[@id='Addr2']");
        My_Page_Obejcts.put("UserRefNo", "XPATH|//input[@id='User_Ref_No']");
        My_Page_Obejcts.put("OKButton", "XPATH|//input[@id='btnOk']|fraTxn/showdata");
        WebDr.page_Objects = My_Page_Obejcts;
	}
	
	public static void Remittance_DDDetailsMaint_BAM38(){
        Map<String, String> My_Page_Obejcts = new HashMap<String, String>();
        My_Page_Obejcts.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Obejcts.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Obejcts.put("AddButton", "XPATH|//input[@name='ctlMntToolBar' and @value='a']|fraTxn/showdata");
        My_Page_Obejcts.put("IssuerPickListCode", "XPATH|//input[@id='ctlPickListisscode']|fraTxn/showdata");
        My_Page_Obejcts.put("PayableBranch", "XPATH|//select[@id='ctlcodccbrn']");
        My_Page_Obejcts.put("AddressLine1", "XPATH|//input[@id='txtaddr1']");
        My_Page_Obejcts.put("AddressLine2", "XPATH|//input[@id='txtaddr2']");
        My_Page_Obejcts.put("City", "XPATH|//input[@id='txtcity']");
        My_Page_Obejcts.put("State", "XPATH|//input[@id='txtstate']");
        My_Page_Obejcts.put("ZIPCode", "XPATH|//input[@id='Txtzip']");
        My_Page_Obejcts.put("CountryPickList", "XPATH|//input[@id='ctlPickCntry']");
        My_Page_Obejcts.put("PayableAmount", "XPATH|//input[@id='ctlamtpayable']");
        My_Page_Obejcts.put("OKButton", "XPATH|//input[@id='ctlOK']");
        My_Page_Obejcts.put("AuthoriseButton", "XPATH|//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");
              
        //My_Page_Objects.put("LNM31AuthMntTool", "XPATH|//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");
                     
        WebDr.page_Objects = My_Page_Obejcts;
	}
	
	public static void Remittance_DD_Liquidation_Inquiry_CASA_8310(){
        Map<String, String> My_Page_Obejcts = new HashMap<String, String>();
        My_Page_Obejcts.put("AccountNo", "XPATH|//input[@id='AccountNo']|fraTxn/showdata");
        My_Page_Obejcts.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Obejcts.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
       My_Page_Obejcts.put("AddButton", "XPATH|//input[@name='ctlMntToolBar' and @value='a']|fraTxn/showdata");
        My_Page_Obejcts.put("IssuerPickListCode", "XPATH|//input[@id='ctlPickListisscode']|fraTxn/showdata");
        My_Page_Obejcts.put("PayableBranch", "XPATH|//select[@id='ctlcodccbrn']");
        My_Page_Obejcts.put("AddressLine1", "XPATH|//input[@id='txtaddr1']");
        My_Page_Obejcts.put("AddressLine2", "XPATH|//input[@id='txtaddr2']");
        My_Page_Obejcts.put("City", "XPATH|//input[@id='txtcity']");
        My_Page_Obejcts.put("State", "XPATH|//input[@id='txtstate']");
        My_Page_Obejcts.put("ZIPCode", "XPATH|//input[@id='Txtzip']");
        My_Page_Obejcts.put("CountryPickList", "XPATH|//input[@id='ctlPickCntry']");
        My_Page_Obejcts.put("PayableAmount", "XPATH|//input[@id='ctlamtpayable']");
        My_Page_Obejcts.put("OKButton", "XPATH|//input[@id='ctlOK']");
        My_Page_Obejcts.put("AuthoriseButton", "XPATH|//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");
              
        //My_Page_Objects.put("LNM31AuthMntTool", "XPATH|//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");
                     
        WebDr.page_Objects = My_Page_Obejcts;
	}

	public static void Remittance_CASA_Cheque_Withdrawal_1013() {
		 Map<String, String> My_Page_Obejcts = new HashMap<String, String>();
	        My_Page_Obejcts.put("AccountNo", "XPATH|//input[@id='AccountNo']|fraTxn/showdata");
	        My_Page_Obejcts.put("TxnAmt", "XPATH|//input[@id='TCY_Amount']|fraTxn/showdata");
	        My_Page_Obejcts.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	        My_Page_Obejcts.put("UserRefNo", "XPATH|//input[@id='User_Ref_No']");
	        My_Page_Obejcts.put("OKButton", "XPATH|//input[@id='ctlOK']");
	        My_Page_Obejcts.put("ChqNo", "XPATH|//input[@id='ChqNo']");
	        
	        
	       My_Page_Obejcts.put("AddButton", "XPATH|//input[@name='ctlMntToolBar' and @value='a']|fraTxn/showdata");
	        My_Page_Obejcts.put("IssuerPickListCode", "XPATH|//input[@id='ctlPickListisscode']|fraTxn/showdata");
	        My_Page_Obejcts.put("PayableBranch", "XPATH|//select[@id='ctlcodccbrn']");
	        My_Page_Obejcts.put("AddressLine1", "XPATH|//input[@id='txtaddr1']");
	        My_Page_Obejcts.put("AddressLine2", "XPATH|//input[@id='txtaddr2']");
	        My_Page_Obejcts.put("City", "XPATH|//input[@id='txtcity']");
	        My_Page_Obejcts.put("State", "XPATH|//input[@id='txtstate']");
	        My_Page_Obejcts.put("ZIPCode", "XPATH|//input[@id='Txtzip']");
	        My_Page_Obejcts.put("CountryPickList", "XPATH|//input[@id='ctlPickCntry']");
	        My_Page_Obejcts.put("PayableAmount", "XPATH|//input[@id='ctlamtpayable']");
	        My_Page_Obejcts.put("OKButton", "XPATH|//input[@id='ctlOK']");
	        My_Page_Obejcts.put("AuthoriseButton", "XPATH|//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");
	              
	        //My_Page_Objects.put("LNM31AuthMntTool", "XPATH|//input[@name='ctlMntToolBar' and @value='z']|fraTxn/showdata");
	                     
	        WebDr.page_Objects = My_Page_Obejcts;
		
	}
	
	
	
}
