package pkgFCRPageObjects;

import java.util.HashMap;
import java.util.Map;

import utility.WebDr;

public class FCR_TDPageObjects {
		
	 public static void TD8054_page()
	    {
	           Map<String, String> My_Page_Objects = new HashMap<String, String>();
	           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	           My_Page_Objects.put("BranchName","ID|AccountBrn|fraTxn/showdata");
	           My_Page_Objects.put("ProductName","ID|ProductCode");
	           My_Page_Objects.put("AccountTitle","ID|AcctTitle");
	           My_Page_Objects.put("CustomerSearch","ID|CustSearch1");
	           My_Page_Objects.put("SearchCriteria","ID|SearchCrit|fraPop/showdata");
	           My_Page_Objects.put("SearchString","ID|SearchStr|fraPop/showdata");
	           My_Page_Objects.put("CustomerRelations","ID|CustomerAcctRel1|fraTxn/showdata");
	           My_Page_Objects.put("MinorAccountStatus","ID|RdMinorAcct");
	           My_Page_Objects.put("ValidateCustomer","ID|btnValdCust");
	           My_Page_Objects.put("OKButton","XPATH|//input[@name='btnOk']");
	           My_Page_Objects.put("AccountNumber","XPATH|//input[@id='tdAcctNo']|fraTxn/showdata");
	           WebDr.page_Objects = My_Page_Objects;
	    }
	 
	 public static void TD1356_page()
	    {
	           Map<String, String> My_Page_Objects = new HashMap<String, String>();
	           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	           My_Page_Objects.put("VoucherNumber","ID|VoucherNo|fraTxn/showdata");
	           My_Page_Objects.put("VoucherSrNumber","ID|VoucherSrNo");
	           My_Page_Objects.put("OKButton_9021","XPATH|//input[@name='btnOk']");
	           My_Page_Objects.put("AccountNumber","XPATH|//input[@id='tdAcctNo']|fraTxn/showdata");
	           My_Page_Objects.put("AddButton","ID|ctlAdd|fraTxn/showdata");
	           My_Page_Objects.put("PayinButton","XPATH|//input[@id='ctlPayin']|fraTxn/showdata");
	           My_Page_Objects.put("CASAAccountNo","XPATH|//input[@id='CodAcctNo']|fraTxn/showdata");
	           My_Page_Objects.put("SaveCashDetails", "ID|ctlSaveXferAcct");
	           //My_Page_Objects.put("PayoutFreq","XPATH|//table[@class='BgMainTable']/tbody/tr[5]/td/div/div[@id='Tab1']/table[@class='TBody']/tbody/tr[2]/td[2]/child::select|fraTxn/showdata");
		       My_Page_Objects.put("PayoutFrequency","XPATH|//select[@id='PayoutFreq']|fraTxn/showdata");
	           My_Page_Objects.put("CompoundingFrequency","XPATH|//select[@id='CompFreq']");
	           My_Page_Objects.put("BaseRate","XPATH|//select[@id='BaseRate']");
	           My_Page_Objects.put("TermMonths","XPATH|//input[@id='TermM']");
	           My_Page_Objects.put("TermDays","XPATH|//input[@id='TermD']");
	      	   My_Page_Objects.put("DepositVariance","XPATH|//input[@id='AcctVariance']");
	      	   My_Page_Objects.put("SaveButton","XPATH|//input[@id='ctlSaveDepDtls']|fraTxn/showdata");
	      	   My_Page_Objects.put("OKButton","XPATH|//input[@id='ctlOK']");
	          // XPATH|//table[@id='UDF']/tbody[2]/tr[6]/td[3]/child::select|fraPop/showdata  
	           WebDr.page_Objects = My_Page_Objects;
	    }
	 
	 
	 public static void TD7020_page()
	    {
	           Map<String, String> My_Page_Objects = new HashMap<String, String>();
	           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	           My_Page_Objects.put("AccountNumber","XPATH|//input[@id='AccountNo']|fraTxn/showdata");
	           My_Page_Objects.put("OKButton","XPATH|//input[@id='btnOk']|fraTxn/showdata");
	           WebDr.page_Objects = My_Page_Objects;
	    }
	
	 
	 public static void TD020_page()
	    {
	           Map<String, String> My_Page_Objects = new HashMap<String, String>();
	           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	           My_Page_Objects.put("AccountNumber","XPATH|//input[@id='CtlTdAcctNo']|fraTxn/showdata");
	           My_Page_Objects.put("CloseButton","XPATH|//input[@id='ctlClose']|fraTxn/showdata");
	           WebDr.page_Objects = My_Page_Objects;
	    }
	
	 
	 public static void TD021_page()
	    {
	           Map<String, String> My_Page_Objects = new HashMap<String, String>();
	           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	           My_Page_Objects.put("AccountNumber","XPATH|//input[@id='CtlTdAcctNo']|fraTxn/showdata");
	           My_Page_Objects.put("PickDepNoButton","XPATH|//input[@id='ctlPickDepNo']");
	           My_Page_Objects.put("CloseButton","XPATH|//input[@id='ctlClose']|fraTxn/showdata");
	           WebDr.page_Objects = My_Page_Objects;
	    }
	 
	 public static void TD1358_page()
	    {
	           Map<String, String> My_Page_Objects = new HashMap<String, String>();
	           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	           My_Page_Objects.put("AccountNumber","XPATH|//input[@id='tdAcctNo']|fraTxn/showdata");
	           My_Page_Objects.put("DepPickList", "XPATH|//input[@id='DepNoPicklist']");
	           //My_Page_Objects.put("RedeemMode", "XPATH|//tr[@tabIndex='0']/td[text()='Open']");
	           My_Page_Objects.put("RedeemMode", "XPATH|//tr[@tabIndex='0']/td[4]");
	           My_Page_Objects.put("ValidateButton", "XPATH|//input[@id='ctlValidateDeposit']|fraTxn/showdata");
	           My_Page_Objects.put("PayoutButton", "XPATH|//input[@id='ctlPayoutDtls']|fraTxn/showdata");
	           My_Page_Objects.put("AddButton", "XPATH|//input[@id='ctlAdd']");
	           My_Page_Objects.put("TotalPayoutAmt", "XPATH|//input[@id='PayoutAmt']");
	           My_Page_Objects.put("RedeemGLAccount", "XPATH|//input[@id='GLAcctNo']");
	           My_Page_Objects.put("SaveRedeemAccount", "XPATH|//input[@id='ctlSaveXferAcct']");
	           My_Page_Objects.put("OKButton", "XPATH|//input[@id='ctlOK']|fraTxn/showdata");
	           WebDr.page_Objects = My_Page_Objects;
	    }
	 
	 public static void TD039_page()
	    {
	           Map<String, String> My_Page_Objects = new HashMap<String, String>();
	           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	           My_Page_Objects.put("TDAddRadioButton", "XPATH|//input[@name='ctlMntToolBar']|fraTxn/showdata");
	           My_Page_Objects.put("AccountNumber","XPATH|//input[@id='tdAcctNo']|fraTxn/showdata");
	           My_Page_Objects.put("PayoutType","XPATH|//select[@id='PayoutType']|fraTxn/showdata");
	           My_Page_Objects.put("DepositNoPickList","XPATH|//input[@id='DepositNoPicklist']");
	           My_Page_Objects.put("PrematurePayoutDate","XPATH|//input[@id='preMatPayoutDate']");
	           My_Page_Objects.put("PrematurePayoutMode","XPATH|//select[@id='preMatPayoutMode']");
	           My_Page_Objects.put("RenewalProductCodePickList","XPATH|//input[@id='RenProdCodProdPicklist']");
	           My_Page_Objects.put("Variance","XPATH|//input[@id='RenProdVariance']");
	           My_Page_Objects.put("RenewalTermMonths","XPATH|//input[@id='RenProdRenTermM']");
	           My_Page_Objects.put("RenewalTermDays","XPATH|//input[@id='RenProdRenTermD']");
	           My_Page_Objects.put("PayoutFrequency","XPATH|//select[@id='RenProdPayoutFreq']");
	           My_Page_Objects.put("CompoundingFrequency","XPATH|//select[@id='RenProdCompFreq']");
	           My_Page_Objects.put("BaseRate","XPATH|//select[@id='RenProdBaseRate']");
	           My_Page_Objects.put("SaveButton","XPATH|//input[@id='ctlSaveRenProd']");
	           My_Page_Objects.put("OKButton","XPATH|//input[@id='ctlOK']");
	           My_Page_Objects.put("TDAuthorizeRadioButton", "XPATH|.//input[@id='ctlMntToolBar' and @value='z']|fraTxn/showdata");
	           WebDr.page_Objects = My_Page_Objects;
	    }
	 
	 public static void TDM24_page()
	    {
	           Map<String, String> My_Page_Objects = new HashMap<String, String>();
	           My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
	           My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
	           My_Page_Objects.put("TDAddRadioButton", "XPATH|//input[@name='ctlMntToolBar']|fraTxn/showdata");
	           My_Page_Objects.put("TDAuthorizeBtn", "XPATH|//input[@value='z']|fraTxn/showdata");
	           My_Page_Objects.put("TDDeleteRadioButton", "XPATH|//input[@name='ctlMntToolBar' and @value='d']|fraTxn/showdata");
	           My_Page_Objects.put("AccountNumber","XPATH|//input[@id='CtlTdAcctNo']|fraTxn/showdata");
	           My_Page_Objects.put("DepositNoPickList","XPATH|//input[@id='ctlPickDepNo']");
	           My_Page_Objects.put("LienAmount","XPATH|//input[@id='ctlLienAmount']");
	           My_Page_Objects.put("LienDescription","XPATH|//input[@id='ctlTLienDesc']");
	           My_Page_Objects.put("ReasonForLien","XPATH|//select[@id='ctlcodreason']");
	           My_Page_Objects.put("OKButton","XPATH|//input[@id='ctlOK']");
	           WebDr.page_Objects = My_Page_Objects;
	    }
	 
	 public static void TD028_Block_TD()
	 {
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
         My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
         My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']"); 
         My_Page_Objects.put("AccountNo", "ID|ctlAcctNo|fraTxn/showdata");
         My_Page_Objects.put("BlockedChqBox", "ID|chkAcctBlocked");
         My_Page_Objects.put("BlockReason", "ID|ctlReasonCode");
         My_Page_Objects.put("OKButton","XPATH|//input[@id='ctlOK']|fraTxn/showdata");
         
         WebDr.page_Objects = My_Page_Objects;
		 
		 
	 }

	public static void TD_AuditTrailInquiry_TD031() {
		// TODO Auto-generated method stub
		 Map<String, String> My_Page_Objects = new HashMap<String, String>();
         My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
         My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']"); 
         My_Page_Objects.put("AccountNo", "ID|tbCodAcctNo|fraTxn/showdata");
         My_Page_Objects.put("Action", "ID|cboActionType");
         My_Page_Objects.put("ValueDateFrom", "ID|ctlValueDateFrom");
         My_Page_Objects.put("ValueDateTo", "ID|ctlValueDateTo");
         My_Page_Objects.put("Inquire","XPATH|//input[@value='Inquire']");
         WebDr.page_Objects = My_Page_Objects;
	}

	public static void TD_AccountLedger_Inquire_TD037() {
		// TODO Auto-generated method stub
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']"); 
        My_Page_Objects.put("AccountNo", "ID|tbCodAcctNo|fraTxn/showdata");
        My_Page_Objects.put("AllDeposits", "ID|chkAllDeposits");
        My_Page_Objects.put("ValueDateFrom", "ID|tbDatValStt");
        My_Page_Objects.put("ValueDateTo", "ID|tbDatValEnd");
        My_Page_Objects.put("Inquire","XPATH|//input[@value=' Inquire ']");
        WebDr.page_Objects = My_Page_Objects;
	}

	public static void TD_AccountTDS_Inquire_TDS11() {
		// TODO Auto-generated method stub
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']"); 
        My_Page_Objects.put("SearchCriteria", "ID|cmbSearchCriteria|fraTxn/showdata");
        My_Page_Objects.put("SearchString", "ID|ctlCustInfo");
        My_Page_Objects.put("Inquire", "ID|ctlInquire|fraTxn/showdata");
        My_Page_Objects.put("CustTable", "XPATH|//table[@id='fgdetails']/tbody");
        My_Page_Objects.put("CustTableCell", "XPATH|//table[@id='fgdetails']/tbody/tr[2]/td[1]");
        My_Page_Objects.put("AccTable", "XPATH|//table[@id='fgcustdet']/tbody");
        WebDr.page_Objects = My_Page_Objects;
	}

	public static void TDM01_page() {
		// TODO Auto-generated method stub
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']"); 
        My_Page_Objects.put("TDModifyRadioButton", "XPATH|//input[@name='ctlMntToolBar' and @value='m']|fraTxn/showdata");
        My_Page_Objects.put("ProdCode", "ID|mskCodProd");
        My_Page_Objects.put("OnMaturity", "XPATH|//label[text()='On Maturity']");
        My_Page_Objects.put("ForcedTerm", "ID|tbTermForcedRenewalMonths");
        My_Page_Objects.put("AutoTerm", "ID|tbTermAutoRenewalMonths");
        WebDr.page_Objects = My_Page_Objects;
		
	}

	public static void TD_ProductRate_Inquire_TD060() {
		// TODO Auto-generated method stub
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']"); 
        My_Page_Objects.put("TDInquireRadioButton", "XPATH|//input[@name='ctlMntToolBar' and @value='i']|fraTxn/showdata");
        My_Page_Objects.put("ProdCode", "ID|ctlText1");
        My_Page_Objects.put("ProdName", "ID|txtProdName|fraTxn/showdata");
        My_Page_Objects.put("Close", "ID|ctlClose");
        WebDr.page_Objects = My_Page_Objects;
		
	}
}
