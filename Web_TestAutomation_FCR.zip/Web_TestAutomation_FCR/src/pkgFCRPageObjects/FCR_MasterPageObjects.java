package pkgFCRPageObjects;

import java.util.HashMap;
import java.util.Map;
import utility.WebDr;

public class FCR_MasterPageObjects {

    public static void TAX_Code_Maintenance_BAM30(){
		Map<String, String> My_Page_Objects = new HashMap<String, String>();
		My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
		My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
		My_Page_Objects.put("ModifyBtn", "XPATH|//input[@value='m']|fraTxn/showdata");
		My_Page_Objects.put("TDSCode","ID|txtTDSCode|fraTxn/showdata" );
		My_Page_Objects.put("TDSDescription","ID|ctlTDSDesc" );
		My_Page_Objects.put("TDSExemptAmount","ID|ctlamtExemptAmt" );
		My_Page_Objects.put("TDSRate","ID|ctlamtTDSRate" );
		My_Page_Objects.put("OK","ID|ctlOK" );
		My_Page_Objects.put("Close","ID|ctlClose" );
		My_Page_Objects.put("AuthorizeBtn", "XPATH|//input[@value='z']|fraTxn/showdata");
        WebDr.page_Objects = My_Page_Objects;
    }

    public static void Company_Master_Maintenance_BAM81(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("ModifyBtn", "XPATH|//input[@value='m']|fraTxn/showdata");
        My_Page_Objects.put("CompanyCode","ID|ctlCodCompany|fraTxn/showdata" );    
        My_Page_Objects.put("CompanyName","ID|ctlCompanyName" );
        My_Page_Objects.put("CheckValidation","ID|ctlCheckDigitValidation" );       
        My_Page_Objects.put("OK","ID|ctlOK" );
        My_Page_Objects.put("Close","ID|ctlClose" );
        My_Page_Objects.put("AuthorizeBtn", "XPATH|//input[@value='z']|fraTxn/showdata");
        My_Page_Objects.put("InquireBtn", "XPATH|//input[@value='i']|fraTxn/showdata");
        WebDr.page_Objects = My_Page_Objects;
   }

    public static void Interest_Index_Rates_BAM13(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("ModifyBtn", "XPATH|//input[@value='m']|fraTxn/showdata");
        My_Page_Objects.put("AddBtn", "XPATH|//input[@value='a']|fraTxn/showdata");
        My_Page_Objects.put("IndexCode","ID|ctlIndexCode|fraTxn/showdata");
        My_Page_Objects.put("InterestRate","ID|ctlIntRate|fraTxn/showdata");
        My_Page_Objects.put("EffectiveDate","ID|ctlEffDate|fraTxn/showdata");
        My_Page_Objects.put("OK","ID|ctlOK|fraTxn/showdata" );
        My_Page_Objects.put("Close","ID|ctlClose|fraTxn/showdata" );
        My_Page_Objects.put("AuthorizeBtn", "XPATH|//input[@value='z']|fraTxn/showdata");
        My_Page_Objects.put("InquireBtn", "XPATH|//input[@value='i']|fraTxn/showdata");
		WebDr.page_Objects = My_Page_Objects;
	}
    
    public static void Bank_Master_Maintenance_BAM08(){
        Map<String, String> My_Page_Objects = new HashMap<String, String>();
        My_Page_Objects.put("FastPath","XPATH|//input[@name='CodeFastPath']|fraMenu/left");
        My_Page_Objects.put("FastPath_OK", "XPATH|//input[@name='button']");
        My_Page_Objects.put("ModifyBtn", "XPATH|//input[@value='m']|fraTxn/showdata");
        My_Page_Objects.put("AddBtn", "XPATH|//input[@value='a']|fraTxn/showdata");
        My_Page_Objects.put("BankCode","ID|tbBankcode|fraTxn/showdata");
        My_Page_Objects.put("OK","ID|ctlOK|fraTxn/showdata" );
        My_Page_Objects.put("Close","ID|ctlClose|fraTxn/showdata" );      
		WebDr.page_Objects = My_Page_Objects;
	}
    
    
}
