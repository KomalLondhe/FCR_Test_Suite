package testCases;

import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebDriver;

import pkgFCRPageObjects.FCR_BNC;
import pkgFCRResuableModule.CIF;
import pkgFCRResuableModule.Clearing;
import pkgFCRResuableModule.FCRBNC;
import pkgFCRResuableModule.GEFU;
import pkgFCRResuableModule.CASA;
import pkgFCRResuableModule.LOAN;
import pkgFCRResuableModule.Master;
import pkgFCRResuableModule.Remittance;
import pkgFCRResuableModule.Report;
import pkgFCRResuableModule.TD;
import utility.FCRDBConnection;
import utility.WebDr;


public class TestFlowFCR {
	public static void executeTC(WebDriver driver, String str_tc)
			throws Exception {
		// System.out.println("TestFlowBIR.java- executeTC Invoked");
	
		switch (str_tc) {
		case "Login":
			Login(driver);
			break;
		case "MultipleLogin":
			MultipleLogin(driver);
			break;
		case "multipleLogout":
			multipleLogout(driver);
			break;
		case "FCR_BNC":
			TC_FCR_BNC(driver);
			break;
		//case "FCRDbconnection":
			//TC_FCRDbconnection(driver);
			//break;
		case "TC_BNC_HelpMenu":
			TC_BNC_HelpMenu(driver);
			break;	
		case "TC_DB_Status":
			TC_DB_Status(driver);
			break;
		case "TC_BatchRun_Status":
			TC_BatchRun_Status(driver);
			break;
		case "TC_LN_01":
			TC_LN_01(driver);
			break;
		case "TC_LN_02":
			TC_LN_02(driver);
			break;
		case "TC_LN_03":
			TC_LN_03(driver);
			break;
		case "TC_LN_04":
			TC_LN_04(driver);
			break;
		case "TC_LN_05":
			TC_LN_05(driver);
			break;
		case "TC_LN_06":
			TC_LN_06(driver);
			break;
		case "TC_LN_07":
			TC_LN_07(driver);
			break;
		case "TC_LN_08":
			TC_LN_08(driver);
			break;
		case "TC_LN_09":
			TC_LN_09(driver);
			break;
		case "TC_LN_10":
			TC_LN_10(driver);
			break;
		case "TC_LN_11":
			TC_LN_11(driver);
			break;
		case "TC_LN_12":
			TC_LN_12(driver);
			break;
		case "TC_LN_13":
			TC_LN_13(driver);
			break;
		case "TC_LN_14":
			TC_LN_14(driver);
			break;
		case "TC_LN_15":
			TC_LN_15(driver);
			break;	
		case "TC_LN_16":
			TC_LN_16(driver);
			break;
		case "TC_CS_01":
			TC_CS_01(driver);
			break;
		case "TC_CS_02":
			TC_CS_02(driver);
			break;
		case "TC_CS_03":
			TC_CS_03(driver);
			break;
		case "TC_CS_04":
			TC_CS_04(driver);
			break;
		case "TC_CS_05":
			TC_CS_05(driver);
			break;
		case "TC_CS_06":
			TC_CS_06(driver);
			break;
		case "TC_CS_07":
			TC_CS_07(driver);
			break;
		case "TC_CS_08":
			TC_CS_08(driver);
			break;
		case "TC_CS_09":
			TC_CS_09(driver);
			break;
		case "TC_CS_10":
			TC_CS_10(driver);
			break;
		case "TC_CS_11":
			TC_CS_11(driver);
			break;
		case "TC_CS_12":
			TC_CS_12(driver);
			break;
		case "TC_CS_13":
			TC_CS_13(driver);
			break;
		case "TC_CS_14":
			TC_CS_14(driver);
			break;
		case "TC_CS_15":
			TC_CS_15(driver);
			break;
			
		case "TC_CS_16":
			TC_CS_16(driver);
			break;
		case "TC_CS_17":
			TC_CS_17(driver);
			break;
		case "TC_CS_18":
			TC_CS_18(driver);
			break;
		case "TC_CS_19":
			TC_CS_19(driver);
			break;
		
		case "TC_CS_20":
			TC_CS_20(driver);
			break;
		case "TC_CS_21":
			TC_CS_21(driver);
			break;
		case "TC_CS_23":
			TC_CS_23(driver);
			break;
		case "TC_CS_24":
			TC_CS_24(driver);
			break;
		case "TC_CS_25":
			TC_CS_25(driver);
			break;
		case "TC_CS_26":
			TC_CS_26(driver);
			break;
		case "TC_CS_27":
			TC_CS_27(driver);
			break;
		case "TC_CS_28":
			TC_CS_28(driver);
			break;
		case "TC_CS_29":
			TC_CS_29(driver);
			break;
		case "TC_CS_30":
			TC_CS_30(driver);
			break;
		case "TC_CS_31":
			TC_CS_31(driver);
			break;
		case "TC_CS_32":
			TC_CS_32(driver);
			break;
		case "TC_CS_33":
			TC_CS_33(driver);
			break;
		case "TC_CS_34":
			TC_CS_34(driver);
			break;
		case "TC_CS_35":
			TC_CS_35(driver);
			break;
		case "TC_CS_36":
            TC_CS_36(driver);
            break;
		case "TC_CS_37":
            TC_CS_37(driver);
            break;
		case "TC_CS_38":
            TC_CS_38(driver);
            break;
		case "TC_CS_39":
            TC_CS_39(driver);
            break;
		case "TC_CS_40":
            TC_CS_40(driver);
            break;
		case "TC_CS_41":
            TC_CS_41(driver);
            break;
		case "TC_CS_42":
            TC_CS_42(driver);
            break;
		case "TC_CS_43":
            TC_CS_43(driver);
            break;
		case "TC_CS_44":
            TC_CS_44(driver);
            break;
		case "TC_CS_45":
            TC_CS_45(driver);
            break;
		case "TC_CS_46":
            TC_CS_46(driver);
            break;
		case "TC_CS_47":
            TC_CS_47(driver);
            break;
		case "TC_CS_48":
            TC_CS_48(driver);
            break;
		case "TC_CS_49":
            TC_CS_49(driver);
            break;
		case "TC_CS_50":
            TC_CS_50(driver);
            break;
		case "TC_CS_51":
            TC_CS_51(driver);
            break;
		case "TC_CS_52":
            TC_CS_52(driver);
            break;
		case "TC_CS_53":
            TC_CS_53(driver);
            break;
		case "TC_CS_54":
            TC_CS_54(driver);
            break;
		case "TC_CS_55":
            TC_CS_55(driver);
            break;
		case "TC_CS_56":
            TC_CS_56(driver);
            break;
		case "TC_CS_57":
            TC_CS_57(driver);
            break;
		case "TC_CS_58":
            TC_CS_58(driver);
            break;
		case "TC_CS_59":
            TC_CS_59(driver);
            break;    
		case "LogoutWithClose":
			LogoutWithClose(driver);
			break;
			
		case "TC_CI_01":
			TC_CI_01(driver);
			break;
		case "TC_CI_02":
			TC_CI_02(driver);
			break;
		case "TC_CI_03":
			TC_CI_03(driver);
			break;
		case "TC_CI_04":
			TC_CI_04(driver);
			break;
		case "TC_CI_05":
			TC_CI_05(driver);
			break;
		case "TC_CI_06":
			TC_CI_06(driver);
			break;
		case "TC_CI_07":
			TC_CI_07(driver);
			break;
		case "TC_CI_08":
			TC_CI_08(driver);
			break;
			
		case "TC_CI_09":
			TC_CI_09(driver);
			break;
		case "TC_CI_10":
			TC_CI_10(driver);
			break;
		case "TC_CI_11":
			TC_CI_11(driver);
			break;
		case "TC_CI_12":
			TC_CI_12(driver);
			break;
		case "TC_CI_13":
			TC_CI_13(driver);
			break;
		case "TC_CI_14":
			TC_CI_14(driver);
			break;
		case "TC_CI_15":
			TC_CI_15(driver);
			break;
		case "TC_CI_16":
			TC_CI_16(driver);
			break;
		case "TC_CI_17":
			TC_CI_17(driver);
			break;
		case "TC_CI_18":
			TC_CI_18(driver);
			break;
		case "TC_CI_19":
			TC_CI_19(driver);
			break;
		case "TC_CI_20":
			TC_CI_20(driver);
			break;
		case "TC_CI_21":
			TC_CI_21(driver);
			break;	
		case "TC_CI_22":
			TC_CI_22(driver);
			break;
		case "TC_CI_23":
			TC_CI_23(driver);
			break;
		case "TC_CI_24":
			TC_CI_24(driver);
			break;
			
		case "TC_TD_01":
			TC_TD_01(driver);
			break;
			
		case "TC_TD_02":
			TC_TD_02(driver);
			break;
			
		case "TC_TD_03":
			TC_TD_03(driver);
			break;
			
		case "TC_TD_04":
			TC_TD_04(driver);
			break;
			
		case "TC_TD_05":
			TC_TD_05(driver);
			break;
			
		case "TC_TD_06":
			TC_TD_06(driver);
			break;
			
		case "TC_TD_07":
			TC_TD_07(driver);
			break;
			
		case "TC_TD_08":
			TC_TD_08(driver);
			break;
			
		case "TC_TD_09":
			TC_TD_09(driver);
			break;
			
		case "TC_TD_10":
			TC_TD_10(driver);
			break;
			
		case "TC_TD_11":
			TC_TD_11(driver);
			break;
		case "TC_TD_12":
			TC_TD_12(driver);
			break;
		case "TC_TD_13":
			TC_TD_13(driver);
			break;
		case "TC_TD_14":
			TC_TD_14(driver);
			break;
		case "TC_TD_15":
			TC_TD_15(driver);
			break;
		case "TC_TD_16":
			TC_TD_16(driver);
			break;
		case "TC_TD_17":
			TC_TD_17(driver);
			break;
		case "TC_TD_18":
			TC_TD_18(driver);
			break;
		case "TC_TD_19":
			TC_TD_19(driver);
			break;
		case "TC_RP_01":
			TC_RP_01(driver);
			break;
			
		case "TC_RP_02":
			TC_RP_02(driver);
			break;
			
		case "TC_RP_03":
			TC_RP_03(driver);
			break;
		
		
			case "TC_RP_04":
				TC_RP_04(driver);
				break;
				
			case "TC_RP_05":
				TC_RP_05(driver);
				break;
				
			case "TC_RP_06":
				TC_RP_06(driver);
				break;
				
			case "TC_RP_07":
				TC_RP_07(driver);
				break;
					
		
			case "TC_RM_01":
				TC_RM_01(driver);
				break;	
			case "TC_RM_02":
				TC_RM_02(driver);
				break;	
			case "TC_RM_03":
				TC_RM_03(driver);
				break;
			case "TC_RM_04":
				TC_RM_04(driver);
				break;
			case "TC_RM_05":
				TC_RM_05(driver);
				break;
			case "TC_RM_06":
				TC_RM_06(driver);
				break;
			case "TC_RM_07":
				TC_RM_07(driver);
				break;
			case "TC_RM_08":
				TC_RM_08(driver);
				break;
			case "TC_RM_09":
				TC_RM_09(driver);
				break;
			case "TC_RM_10":
				TC_RM_10(driver);
				break;
			case "TC_RM_11":
				TC_RM_11(driver);
				break;	
			case "TC_RM_12":
				TC_RM_12(driver);
				break;	
			case "TC_RM_13":
				TC_RM_13(driver);
				break;
			case "TC_RM_14":
				TC_RM_14(driver);
				break;
			case "TC_RM_15":
				TC_RM_15(driver);
				break;	
			case "TC_CR_01":
				TC_CR_01(driver);
				break;	
			case "TC_CR_02":
				TC_CR_02(driver);
				break;
			case "TC_CR_03":
				TC_CR_03(driver);
				break;
				
			case "TC_CR_04":
				TC_CR_04(driver);
				break;
				
			case "TC_CR_05":
				TC_CR_05(driver);
				break;
				
			case "TC_CR_06":
				TC_CR_06(driver);
				break;
				
			case "TC_CR_07":
				TC_CR_07(driver);
				break;
			case "TC_CR_08":
				TC_CR_08(driver);
				break;
			case "TC_CR_09":
				TC_CR_09(driver);
				break;

				
			case "TC_GEFU_01":
				TC_GEFU_01(driver);
				break;	
			case "TC_GEFU_02":
				TC_GEFU_02(driver);
				break;	
			case "TC_GEFU_03":
				TC_GEFU_03(driver);
				break;
			case "TC_GEFU_04":
				TC_GEFU_04(driver);
				break;
			case "TC_GEFU_05":
				TC_GEFU_05(driver);
				break;		
				
			case "TC_MS_01":
                TC_MS_01(driver);
                break;
			case "TC_MS_02":
                TC_MS_02(driver);
                break;
			case "TC_MS_03":
                TC_MS_03(driver);
                break;
			case "TC_MS_04":
                TC_MS_04(driver);
                break;
			case "TC_MS_05":
                TC_MS_05(driver);
                break;	
			}

}
	
	
	private static void TC_FCR_BNC(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		FCRBNC.BNCValidation_Fastpath();
	}
	
	//private static void TC_FCRDbconnection(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		//FCRDBConnection.connectFCRDB("Select cod_acct_no from ch_acct_mast");
	//}
	
	private static void TC_BNC_HelpMenu(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
          FCRBNC.BNC_HelpMenu();
	}
	
	private static void TC_DB_Status(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		FCRDBConnection.DB_ConnectivityVerification(WebDr.getValue("Query"));
	}
	private static void TC_BatchRun_Status(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		FCRDBConnection.BatchRun_Status(WebDr.getValue("BatchQuery"));
	}
	private static void Login(WebDriver driver) throws Exception {
		LOAN.launch();
		LOAN.login();
	}
	private static void MultipleLogin(WebDriver driver) throws Exception {
		LOAN.launch();
		LOAN.multipleLogin();
	}
	private static void multipleLogout(WebDriver driver) throws Exception {
		
		LOAN.multipleLogout();
	}
	
	private static void LogoutWithClose(WebDriver driver) throws Exception {
		LOAN.logoutwithclose();
//		WebDr.waitForPageLoaded();
//		Driver.driver.quit();
	}
	
	private static void TC_LN_01(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		
		LOAN.loanAccountCreation_LN057();
	}

	private static void TC_LN_02(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		LOAN.loanDocMaintenence_LN323();
	}

	private static void TC_LN_03(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		LOAN.loanPayInst_LNM31_Add();
	}
	
	private static void TC_LN_04(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		LOAN.loanAcctSchedule_LN521();
	}	
	private static void TC_LN_05(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		LOAN.loanDisburse_1413();
	}	
	private static void TC_LN_06(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		LOAN.loanBalanceEnq_7026();
	}
	private static void TC_LN_07(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		LOAN.loanAccountTransactions_LNM10();
	}
	private static void TC_LN_08(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		LOAN.LoanInstallmentInquiry_1065();
	}
	private static void TC_LN_09(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		LOAN.LoanFullPaymentInquiry_1067();
	}
	private static void TC_LN_10(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		LOAN.LoanAccountRates_LNM83();
	}
	
	private static void TC_LN_11(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		LOAN.loanFullAccountDetails_Inquiry_LNM10();
	}
	
	private static void TC_LN_12(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		LOAN.LoanAccountAttributes_Inquiry_LNM35();
	}
	
	private static void TC_LN_13(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		LOAN.LOAN_Product_Master_Inquiry_LNM11();
	}
	
	private static void TC_LN_14(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		LOAN.LOAN_Product_RatePlan_Inquiry_LN060();
	}
	private static void TC_LN_15(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		LOAN.LOAN_Product_RatePlan_Add_LN060();
	}
	private static void TC_LN_16(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		LOAN.LOAN_Product_RatePlan_Modify_LN060();
	}
	private static void TC_CS_01(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		CASA.CASAAcctOpening_8051();
	}
	
	private static void TC_CS_02(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CashDeposit_1401();
	}
	
	private static void TC_CS_03(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.FundsTransferRequest_1006();
	}
	
	private static void TC_CS_04(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		CASA.CashWithdrawal_1001();
	}
	
	private static void TC_CS_05(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CustomerSearch_1000();
	}
	
	private static void TC_CS_06(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.Account_Closing_CH001();
	}
	private static void TC_CS_07(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.Account_Open_Today_CH021();
	}
	private static void TC_CS_08(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CashWithdrawalInvalid_1001();
	}
	
	private static void TC_CS_09(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.ProductMasterMaintenance_CHM01();
	}
	
	private static void TC_CS_10(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASA_Account_Status_CHM21();
	
	}
	private static void TC_CS_11(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASAInterestRateTiersMaintenance_CHM02();
	}
	private static void TC_CS_12(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASSViewAccountStatement_CH031();
	}
	private static void TC_CS_13(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASAModifyCustomerShortName_7101();
	}
	private static void TC_CS_14(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.Cust_SignPhoto_Delink_7103();
	}
	private static void TC_CS_15(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASA_Invalid_Standing_Instruction();
	}
	
	private static void TC_CS_16(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASA_SweepIN_CHM39();
	}
	private static void TC_CS_17(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASA_Modify_Sign_Link_7111();
	}
	private static void TC_CS_18(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASA_ModifyCustomerID_CIM39();
	}
	
	private static void TC_CS_19(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASA_GL_Credit_CASA_Debit_1460();
	}
	
	private static void TC_CS_20(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CIF.Bill_Payment_by_Cash_1025();
		CASA.Reversal_6006();
	}
	
	
	private static void TC_CS_21(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.Balance_Inquiry_7002();
	}
	private static void TC_CS_23(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASA_Modify_AccountAddress_CHM36();
	}
	
	private static void TC_CS_24(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASA_StandingInstruction_CHM31();
	}
	
	private static void TC_CS_25(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASA_GL_Debit_CASA_Credit_1060();
	}
	
	private static void TC_CS_26(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASA_BranchStatus_Inquiry_BAM95();
	}
	private static void TC_CS_27(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASA_Chequebook_Issue_CHM37();
	}
	private static void TC_CS_28(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASA_SingleAccountTransfer_BA995();
	}
	private static void TC_CS_29(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASA_HoldAccountFund_Add_1055();
	}
	private static void TC_CS_30(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASA_HoldAccountFund_Delete_CHM33();
	}
	private static void TC_CS_31(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.FundsTransferRequest_1006();
		CASA.FundTransfer_Reversal_6006();
	}
	private static void TC_CS_32(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASA_SweepOutMaintenance_Add_CHM32();
	}
	private static void TC_CS_33(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASA_Misc_Customer_Debit_1008();
	}
	private static void TC_CS_34(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASA_SweepOutMaintenance_Add_CHM32();
	}
	private static void TC_CS_35(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CASA.CASA_Interest_Rate_CHM02();
	}
	private static void TC_CS_36(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.TD_Account_StatusChange_Fail_CHM21();
 }
 
	private static void TC_CS_37(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.LN_Account_StatusChange_Fail_CHM21();
 }
	private static void TC_CS_38(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.SweepIn_SweepOut_Priority_Maintenance_CHM40();
 }
	private static void TC_CS_39(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.Account_Master_Maintenance_CH021();
 }
	private static void TC_CS_40(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.Account_Master_Maintenance_CH021();
 }
	private static void TC_CS_41(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.Account_Master_Maintenance_CH021();
 }
	private static void TC_CS_42(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.Invalid_CHQBK_CHM37();
 }
	private static void TC_CS_43(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.CASAAcctOpening_8051();
 }
	private static void TC_CS_44(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.Verify_SweepIn_Execution();
 }
	private static void TC_CS_45(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.SweepOut_Maintainance_Modify_CHM32();
 }
	private static void TC_CS_46(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.SweepOut_Maintainance_Delete_CHM32();
 }
	private static void TC_CS_47(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.SweepIn_SweepOut_Priority_Set_CHM40();
 }
	private static void TC_CS_48(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.StartDate_EndDate_Validation_CHM31();
 }
	private static void TC_CS_49(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.CASA_StandingInstruction_Modify_CHM31();
 }
	private static void TC_CS_50(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.CASA_StandingInstruction_inquiry_CHM31();
 }
	private static void TC_CS_51(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.Transaction_Definition_TC001();
 }
	private static void TC_CS_52(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.CASAInterestRateTiersMaintenance_Modify_CHM02();
 }
	private static void TC_CS_53(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.SweepIn_Invalid_Beneficiery_Provider_Add_CHM39();
 }
	private static void TC_CS_54(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.SweepIn_Modified_Added_Excution_CHM39();
 }
	private static void TC_CS_55(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.SweepIn_Inquiry_CHM39();
 }
	private static void TC_CS_56(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.SweepOutMMaintainance__Date_Verify_CHM32();
 }
	private static void TC_CS_57(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.CASA_SweepOutMaintenance_ValidCASAAcct_CHM32();
 }
	private static void TC_CS_58(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.TD_LN_Products_NotViewed_8051();
 }
	private static void TC_CS_59(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CASA.TD_LN_Products_NotViewed_8051();
 }
	private static void TC_CI_01(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		CIF.Customer_Addition_8053();
	}
	private static void TC_CI_02(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		CIF.Customer_InquiryByCriteria_CIM09();
	}
	private static void TC_CI_03(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		CIF.Customer_InquiryByCriteria_CIM09();
	}
	private static void TC_CI_04(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		CIF.Customer_InquiryByCriteria_CIM09();
	}
	private static void TC_CI_05(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		CIF.Customer_Inquiry_CIM09();
	}
	private static void TC_CI_06(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		CIF.Customer_Search_1000();
	}
	
	private static void TC_CI_07(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		CIF.Customer_Modify_CIM09();
	}
	private static void TC_CI_08(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		CIF.Bill_Payment_by_Cash_1025();
	}
	private static void TC_CI_09(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		CIF.Customer_Relation_CI141();
	}
	private static void TC_CI_10(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CIF.CashDeposit_HighMemoCust_1401();
	}
	private static void TC_CI_11(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CIF.CashDeposit_LowMemoCust_1401();
	}
	
	private static void TC_CI_12(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CIF.Cust_Sign_Link_7102();
	}
	private static void TC_CI_13(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CIF.Customer_MemoMaintenance_CIM13();
	}
	private static void TC_CI_14(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CIF.Bill_Payment_Against_Account_1075();
	}
	private static void TC_CI_15(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CIF.Bill_Payment_by_Cheque_6575();
	}
	private static void TC_CI_16(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CIF.Customer_Search_1000();
	}
	private static void TC_CI_17(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CIF.Customer_Type_MNT_CIM08();
	}
	
	private static void TC_CI_18(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CIF.Customer_Type_Modify_CIM08();
		}
	private static void TC_CI_19(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		CIF.Customer_Type_Invalid_CIM08();
		}
	private static void TC_CI_20(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CIF.View_Signature_Image_7102();
 }

	private static void TC_CI_21(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CIF.Customer_Relation_Modify_CI141();
 }

	private static void TC_CI_22(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        CIF.Customer_Relation_Delete_CI141();
 }
	
	private static void TC_CI_23(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
		CIF.Customer_MemoMaintenance_CIM13();
 }

	private static void TC_CI_24(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
		CIF.Customer_MemoMaintenance_CIM13();
 }
	
	private static void TC_TD_01(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		TD.TimeDepositAccountOpening_8054();
	}
	
	private static void TC_TD_02(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		TD.TimeDepositPayin_1356();
	}
	
	private static void TC_TD_03(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		TD.TimeDepositBalanceInquiry_7020();
	}
	
	private static void TC_TD_04(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		TD.TimeDepositAccountMaster_TD020();
	}
	
	private static void TC_TD_05(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		TD.TimeDepositDepositMaster_TD021();
	}
	
	private static void TC_TD_06(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		TD.TD_Redemption_1358();
	}
	
	private static void TC_TD_07(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		TD.TD_Multiple_Payout_TD039();
	}
	
	private static void TC_TD_08(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		TD.TD_Lien_Master_Maintenance_TDM24();
	}
	
	private static void TC_TD_09(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		TD.TimeDepositPayin_1356();
	}
	
	private static void TC_TD_10(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		TD.TD_Lien_Master_Maintenance_TDM24();
	}
	
	private static void TC_TD_11(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		TD.TD_Redemption_1358();
	}
	
	private static void TC_TD_12(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		TD.TD028_Block_TD();
	}
	
	
	private static void TC_TD_13(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		TD.TD028_UnBlock_TD();
	}
	
	private static void TC_TD_14(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		TD.TD_AuditTrailInquiry_TD031();
	}
	
	private static void TC_TD_15(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		TD.TD_AccountLedger_Inquire_TD037();
	}
	
	private static void TC_TD_16(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		TD.TD_AccountTDS_Inquire_TDS11();
	}
	
	private static void TC_TD_17(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		TD.TD_Redemption_1358();
	}
	
	private static void TC_TD_18(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		TD.TD_Product_Master_Modify_TDM01();
	}
	
	private static void TC_TD_19(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		TD.TD_ProductRate_Inquire_TD060();
	}
	
	private static void TC_RP_01(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		Report.ReportCategory_Request_CH220();
	}
	
	private static void TC_RP_02(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		Report.ReportCategory_Request_CH220();
		
	}
	
	private static void TC_RP_03(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		Report.ReportCategory_Request_GL008();
	}
	
	private static void TC_RP_04(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		Report.ReportCategory_Request_CH112();
	}
	
	private static void TC_RP_05(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		Report.ReportCategory_Request_CH790();
	}
	
	private static void TC_RP_06(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		Report.ReportCategory_Request_CH102();
	}
	
	private static void TC_RP_07(WebDriver driver) throws Exception {
		// TODO Auto-generated method stub
		Report.ReportCategory_Request_TD102();
	}
	
	private static void TC_RM_01(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Remittance.Remittance_DD_Sale_Against_Cash_8305();
	}
	
	private static void TC_RM_02(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Remittance.Remittance_DD_Sale_Against_GL_8306();
	}
	
	private static void TC_RM_03(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Remittance.Remittance_Bankers_Cheque_Sale_Against_Cash_8301();
	}
	
	private static void TC_RM_04(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Remittance.Remittance_DD_Liquidation_Inquiry_Cash_8310();
	}
	
	private static void TC_RM_05(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Remittance.Remittance_DD_Liquidation_Inquiry_CASA_8310();
	}
	private static void TC_RM_06(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Remittance.Remittance_BC_Liquidation_Inquiry_Cash_8307();
	}
	
	private static void TC_RM_07(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Remittance.Remittance_BC_Liquidation_Inquiry_CASA_8307();
	}
	private static void TC_RM_08(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Remittance.Remittance_DD_Sale_Against_Account_1014();
	}
	private static void TC_RM_09(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Remittance.Remittance_BC_Sale_Against_Account_1010();
	}
	private static void TC_RM_10(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Remittance.Remittance_DD_Details_Maint_BAM38();
	}
	private static void TC_RM_11(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Remittance.Remittance_BC_Liquidation_Inquiry_GL_8307();
	}
	private static void TC_RM_12(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Remittance.Remittance_DD_Sale_Against_GL_8306();
	}
	private static void TC_RM_13(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Remittance.Remittance_DD_Sale_Against_GL_8306();
		Remittance.Remittance_DD_Liquidation_Inquiry_AgaintGL_8310();
	}
	private static void TC_RM_14(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Remittance.Remittance_BC_Sale_Against_GL_8302();
	}
	private static void TC_RM_15(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Remittance.CASA_Cheque_Withdrawal_1013();
	}
	private static void TC_CR_01(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Clearing.InwardClearing_5521();
	}
	
	private static void TC_CR_02(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Clearing.Auth_InwardClearing_ST032();
	}
	
	private static void TC_CR_03(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Clearing.ClearingViewDebitEntry_CH031();
	}
	
	
	private static void TC_CR_04(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Clearing.InwardClearing_PassFail_5521();
	}
	
	private static void TC_CR_05(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Clearing.Inquire_Failed_Instrument_ST034();
		}
	private static void TC_CR_06(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Clearing.OutwardClearing_5506();
		}
	
	private static void TC_CR_07(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Clearing.OutwardClearing_ST023();
		}
	
	private static void TC_CR_08(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Clearing.Inward_Clearing_AccountingEntries();
		}
	private static void TC_CR_09(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		Clearing.ValueDate_Clearing_ST001();
		}
	
	
	private static void TC_GEFU_01(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		GEFU.GEFU_File_Upload_BA452();
	}
	private static void TC_GEFU_02(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		GEFU.GEFU_File_Upload_Inquiry_BAM96();
	}
	private static void TC_GEFU_03(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		GEFU.GEFU_Statement_Inquiry_CH031();
	}
	private static void TC_GEFU_04(WebDriver driver) throws UnhandledAlertException, Exception {
		// TODO Auto-generated method stub
		GEFU.GEFU_StartDate_EndDate_BAM96();
	}
	
	private static void TC_GEFU_05(WebDriver driver) throws UnhandledAlertException, Exception {	
		GEFU.GEFU_File_Status_Inquiry_BAM96();
	}
	
	private static void TC_MS_01(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        Master.TAX_Code_Maintenance_BAM30();
	}
	private static void TC_MS_02(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        Master.Company_Master_Maintenance_BAM81();
	}
	private static void TC_MS_03(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        Master.Interest_Index_Rates_BAM13_Modify();
	}
	private static void TC_MS_04(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        Master.Interest_Index_Rates_BAM13_Add();
	}
	private static void TC_MS_05(WebDriver driver) throws Exception {
        // TODO Auto-generated method stub
        Master.Bank_Master_Maintenance_BAM08();
	}
	
}