package pkgFCRResuableModule;

import org.apache.poi.hssf.record.formula.functions.If;
import org.openqa.selenium.By;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.interactions.Keyboard;

//import com.thoughtworks.selenium.webdriven.commands.WaitForPageToLoad;

import testCases.Driver;
import utility.Constant;
import utility.HtmlReporter;
import utility.WebDr;


public class Master extends Driver{
    
    public static void TAX_Code_Maintenance_BAM30() throws Exception {
                    try{
                                    pkgFCRPageObjects.FCR_MasterPageObjects.TAX_Code_Maintenance_BAM30();
                                    WebDr.fastPath(WebDr.getValue("FastPath"));
                                    WebDr.waitForPageLoaded();
                                    WebDr.clickwithmouse("ModifyBtn", "Select Mode MODIFY");
                                    WebDr.waitForPageLoaded();
                                    WebDr.setText("TDSCode", WebDr.getValue("TDSCode"), "Enter TDS Code");
                                    WebDr.rTab();   
                                    WebDr.waitForPageLoaded();
                                    WebDr.setText("TDSDescription", WebDr.getValue("TDSDescription"), "Enter TDS Description");
                                    WebDr.rTab();
                                    WebDr.setText("TDSExemptAmount", WebDr.getValue("TDSExemptAmount"), "Enter TDS Exemption Amount");
                                    WebDr.rTab();
                                    WebDr.setText("TDSRate", WebDr.getValue("TDSRate"), "Enter TDS Rate");
                                    WebDr.clickwithmouse("OK", "Click on OK");
                                    if(WebDr.isAlertPresent())
                                                    WebDr.alertHandlingForErrors("Authorisation Pending", "Check for alert message");
                                    WebDr.click("Close","Click on the CLOSE button");
                                    LOAN.logout();
                                    WebDr.waitForPageLoaded();
                                    LOAN.superLogin();
                                    WebDr.waitForPageLoaded();
                                    pkgFCRPageObjects.FCR_MasterPageObjects.TAX_Code_Maintenance_BAM30();
                                    WebDr.fastPath(WebDr.getValue("FastPath"));
                                    WebDr.waitForPageLoaded();
                                    WebDr.clickwithmouse("AuthorizeBtn","Select Mode Authorize");
                                    WebDr.setText("TDSCode", WebDr.getValue("TDSCode"), "Enter TDS Code");
                                    WebDr.rTab();
                                    WebDr.waitForPageLoaded();
                                    WebDr.clickwithmouse("OK", "Click on OK");
                                    WebDr.waitForPageLoaded();
                                    if(WebDr.isAlertPresent())
                                    {
                                                    WebDr.alertHandlingForErrors("Record Authorized", "Verify alert message");
                                    }
                                    HtmlReporter.WriteStep("Check whether the user is able to navigate FP BAM30 and modify the TDS rate for a TDS code or not.",
                                                                    "The user should  be able to to navigate FP BAM30 and modify the TDS rate for a TDS code",
                                                                    "Navigation and Modification of TAX Code maintenance successful. ", true);
                                    WebDr.waitForPageLoaded();
                                    LOAN.logout();
                                    LOAN.login();
                    }catch(Exception errAuth){
                                    errAuth.printStackTrace();
                                    HtmlReporter.WriteStep("Check whether the user is able to navigate FP BAM30 and modify the TDS rate for a TDS code or not.",
                                                                    "The user should not be able to to navigate FP BAM30 and not modify the TDS rate for a TDS code",
                                                                    "Navigation and Modification of TAX Code maintenance unsuccessful. ", false);
                                    WebDr.waitForPageLoaded();
                                    LOAN.logout();
                                    LOAN.login();
                    }
                                                    
    }
    
    
    public static void Company_Master_Maintenance_BAM81() throws Exception {
        try{
               pkgFCRPageObjects.FCR_MasterPageObjects.Company_Master_Maintenance_BAM81();
               WebDr.fastPath(WebDr.getValue("FastPath"));
               WebDr.waitForPageLoaded();
               WebDr.clickwithmouse("ModifyBtn", "Select Mode MODIFY");
               WebDr.waitForPageLoaded();
               WebDr.setText("CompanyCode", WebDr.getValue("CompanyCode"), "Enter Company Code");
               WebDr.rTab(); 
               WebDr.waitForPageLoaded();
               WebDr.setText("CompanyName", WebDr.getValue("CompanyName"), "Enter Company Name");
               if (WebDr.strFCRCountry.equals("BBM"))
               {
            	   WebDr.waitForPageLoaded();
            	   WebDr.selectDropValueByVisibleText("CheckValidation", "No check digit validation", "Select Check Validation");
               }
               WebDr.clickwithmouse("OK", "Click on OK");
               if(WebDr.isAlertPresent())
                     WebDr.alertHandlingForErrors("Authorisation Pending", "Check for alert message");
               WebDr.click("Close","Click on the CLOSE button");
               LOAN.logout();
               WebDr.waitForPageLoaded();
               LOAN.superLogin();
               WebDr.waitForPageLoaded();
               pkgFCRPageObjects.FCR_MasterPageObjects.Company_Master_Maintenance_BAM81();
               WebDr.fastPath(WebDr.getValue("FastPath"));
               WebDr.waitForPageLoaded();
               WebDr.clickwithmouse("AuthorizeBtn","Select Mode Authorize");
               WebDr.setText("CompanyCode", WebDr.getValue("CompanyCode"), "Enter Company Code");
               WebDr.rTab();
               WebDr.waitForPageLoaded();
               WebDr.rEnter();
               WebDr.waitForPageLoaded();
               if(WebDr.isAlertPresent())
               {
                     WebDr.alertHandlingForErrors("Record Authorized", "Verify alert message");
               }
               HtmlReporter.WriteStep("Check whether the user is able to navigate FP BAM81 and modify the company name and check whether the user is able to view the modified company name in the statement inquiry or not.",
                            "The user should  be able to to navigate FP BAM81 and view the modified company name in the statement inquiry",
                            "Navigation and Modification of Company Master Maintenance successful. ", true);
               WebDr.waitForPageLoaded();
               LOAN.logout();
               LOAN.login();
               
        }catch(Exception errAuth){
               errAuth.printStackTrace();
               HtmlReporter.WriteStep("Check whether the user is able to navigate FP BAM81 and modify the company name and check whether the user is able to view the modified company name in the statement inquiry or not.",
                            "The user should not be able to to navigate FP BAM81 and not view the modified company name in the statement inquiry",
                            "Navigation and Modification of Company Master Maintenance unsuccessful. ", false);
               WebDr.waitForPageLoaded();
               LOAN.logout();
               LOAN.login();
        }
                     
 }
   
    public static void Interest_Index_Rates_BAM13_Modify() throws UnhandledAlertException,Exception {
		try{
			pkgFCRPageObjects.FCR_MasterPageObjects.Interest_Index_Rates_BAM13();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("ModifyBtn", "Select Mode MODIFY");
			WebDr.waitForPageLoaded();
			WebDr.setText("IndexCode", WebDr.getValue("IndexCode"), "Enter Index Code");
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.SwitchToLatestWindow();
			WebDr.rTab();
			WebDr.rTab();
			WebDr.rEnter();
			if(WebDr.isAlertPresent())
			{
				WebDr.SwitchToLatestAlertCheck("FCR2621 : Warning: Date is current date/earlier than current date");
				WebDr.alertAccept();
			}	
			WebDr.rTab();
			WebDr.setText("InterestRate", WebDr.getValue("InterestRate"), "Enter Interest Rate");
			WebDr.clickwithmouse("OK","Click on OK");
			if(WebDr.isAlertPresent())
				WebDr.alertHandlingForErrors("Authorisation Pending", "Check for alert message");
			WebDr.click("Close","Click on the CLOSE button");
			LOAN.logout();
			WebDr.waitForPageLoaded();
			LOAN.superLogin();
			WebDr.waitForPageLoaded();
			pkgFCRPageObjects.FCR_MasterPageObjects.Interest_Index_Rates_BAM13();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("AuthorizeBtn","Select Mode Authorize");
			WebDr.waitForPageLoaded();
			WebDr.setText("IndexCode", WebDr.getValue("IndexCode"), "Enter Index Code");
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.SwitchToLatestWindow();
			WebDr.rTab();
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("OK","Click on OK");
			if(WebDr.isAlertPresent())
			{
				WebDr.alertHandlingForErrors("Record Authorized", "Verify alert message");
				WebDr.alertAccept();
			}
			HtmlReporter.WriteStep("Check whether the user is able to navigate FP BAM13 and modify the interest rate and authorize the modified data or not.",
					"User should be able to navigate FP BAM13 and modify the interest rate and authorize the modified data",
					"Navigation and Modification of Interest Index Rate successful. ", true);
			WebDr.clickwithmouse("Close","Click on Close");
			WebDr.waitForPageLoaded();
			LOAN.logout();
			LOAN.login();
	}
		catch(Exception errAuth){
			errAuth.printStackTrace();
			HtmlReporter.WriteStep("Check whether the user is able to navigate FP BAM13 and modify the interest rate and authorize the modified data or not.",
					"User should be able to navigate FP BAM13 and modify the interest rate and authorize the modified data",
					"Navigation and Modification of Interest Index Rate unsuccessful. ", false);
			LOAN.logout();
			LOAN.login();
		}
	}

	public static void Interest_Index_Rates_BAM13_Add() throws UnhandledAlertException,Exception {
		try{
			pkgFCRPageObjects.FCR_MasterPageObjects.Interest_Index_Rates_BAM13();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("AddBtn", "Select Mode ADD");
			WebDr.waitForPageLoaded();
			WebDr.setText("IndexCode", WebDr.getValue("IndexCode"), "Enter Index Code");
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.SwitchToLatestWindow();
			WebDr.rTab();
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.setText("EffectiveDate", WebDr.getValue("EffectiveDate"), "Enter Effective Date");
			WebDr.rTab();
			if(WebDr.isAlertPresent())
			{
				WebDr.SwitchToLatestAlertCheck("FCR2621 : Warning: Date is current date/earlier than current date");
				WebDr.alertAccept();
				WebDr.rTab();
			}	
			WebDr.rTab();
			WebDr.setText("InterestRate", WebDr.getValue("InterestRate"), "Enter Interest Rate");
			WebDr.clickwithmouse("OK","Click on OK");
			if(WebDr.isAlertPresent())
				WebDr.alertHandlingForErrors("Authorisation Pending", "Check for alert message");
			WebDr.click("Close","Click on the CLOSE button");
			LOAN.logout();
			WebDr.waitForPageLoaded();
			LOAN.superLogin();
			WebDr.waitForPageLoaded();
			pkgFCRPageObjects.FCR_MasterPageObjects.Interest_Index_Rates_BAM13();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("AuthorizeBtn","Select Mode Authorize");
			WebDr.waitForPageLoaded();
			WebDr.setText("IndexCode", WebDr.getValue("IndexCode"), "Enter Index Code");
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.SwitchToLatestWindow();
			WebDr.rTab();
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("OK","Click on OK");
			if(WebDr.isAlertPresent())
			{
				WebDr.alertHandlingForErrors("Record Authorized", "Verify alert message");
				WebDr.alertAccept();
			}
			HtmlReporter.WriteStep("Check whether the user is able to navigate FP BAM13 and add interest rate and authorize the added data or not.",
					"User should be able to navigate FP BAM13 and add the interest rate and authorize the added data",
					"Navigation and Addition of Interest Index Rate successful. ", true);
			WebDr.clickwithmouse("Close","Click on Close");
			WebDr.waitForPageLoaded();
			LOAN.logout();
			LOAN.login();
	}
		catch(Exception errAuth){
			errAuth.printStackTrace();
			HtmlReporter.WriteStep("Check whether the user is able to navigate FP BAM13 and add interest rate and authorize the added data or not.",
					"User should be able to navigate FP BAM13 and add the interest rate and authorize the added data",
					"Navigation and Addition of Interest Index Rate unsuccessful. ", false);
			LOAN.logout();
			LOAN.login();
		}
	}
		
		public static void Bank_Master_Maintenance_BAM08() throws UnhandledAlertException,Exception {
			try{
				pkgFCRPageObjects.FCR_MasterPageObjects.Bank_Master_Maintenance_BAM08();
				WebDr.fastPath(WebDr.getValue("FastPath"));
				WebDr.waitForPageLoaded();
				WebDr.clickwithmouse("ModifyBtn", "Select Mode ADD");
				WebDr.waitForPageLoaded();
				WebDr.setText("BankCode", WebDr.getValue("BankCode"), "Enter Bank Code");
				WebDr.rTab();
				if(WebDr.isElementDisabled("BankCode", "Check if Element is disabled"))
				{
					HtmlReporter.WriteStep("Check whether the user is able to navigate and modify the Bank code in the screen BAM08 or not.",
							"User should not be able to modify the Bank Code in the Screen BAM08",
							"Modification of Bank Code in the Screen BAM08 unsuccessfull", true);
					WebDr.clickwithmouse("Close","Click on Close");
				}
				else
				{
					HtmlReporter.WriteStep("Check whether the user is able to navigate and modify the Bank code in the screen BAM08 or not.",
							"User should not be able to modify the Bank Code in the Screen BAM08",
							"Modification of Bank Code in the Screen BAM08 successfull", false);
					WebDr.clickwithmouse("Close","Click on Close");
				}

		}
			catch(Exception errAuth){
				errAuth.printStackTrace();
				HtmlReporter.WriteStep("Check whether the user is able to  navigate and modify the Bank code in the screen BAM08 or not.",
						"User should not be able to modify the Bank Code in the Screen BAM08",
						"Modification of Bank Code in the Screen BAM08 successfull", false);
				WebDr.clickwithmouse("Close","Click on Close");
			
			}
	}

    
}
