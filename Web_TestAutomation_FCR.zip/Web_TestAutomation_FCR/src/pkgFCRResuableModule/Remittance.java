package pkgFCRResuableModule;

import testCases.Driver;
import utility.HtmlReporter;
import utility.WebDr;

public class Remittance extends Driver {

	public static void Remittance_DD_Sale_Against_Cash_8305() throws Exception {
		try {
			pkgFCRPageObjects.FCR_RemittancePageObjects.Remittance_DDSaleAgainstCash_8305();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.setText("BankCode", WebDr.getValue("BankCode"), "Select Bank Code");
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("PayableBranchPickList", "Click on Payable Branch Pick List");
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.SwitchToLatestWindow();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();

			WebDr.waitForPageLoaded();
			WebDr.SwitchToLatestWindow();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.SwitchToLatestWindow();
			WebDr.selectDropValueByVisibleText("TxnCcy", WebDr.getValue("TransactionCurrency"),
					"Select Transaction Currency");

			if (WebDr.strFCRCountry.equals("BBK")) {
				WebDr.alertAccept();
				WebDr.waitForPageLoaded();
				WebDr.alertAccept();
				WebDr.waitForPageLoaded();
				WebDr.alertAccept();
				WebDr.waitForPageLoaded();
				WebDr.alertAccept();
				WebDr.waitForPageLoaded();
			}

			WebDr.setText("ChequeAmount", WebDr.getValue("ChequeAmount"), "Enter Cheque Amount");
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();

			WebDr.setText("MICRNumber", WebDr.getTimeStamp(), "Enter MICR Number");
			WebDr.setText("BeneficiaryName", WebDr.getValue("BeneficiaryName"), "Enter Beneficiary Name");
			WebDr.setText("PassportICNo", WebDr.getTimeStamp(), "Enter Passport / IC Number ");
			WebDr.setText("BenfAddr1", WebDr.getValue("BenfAddr1"), "Enter Beneficiary Address 1");
			WebDr.setText("BenfAddr2", WebDr.getValue("BenfAddr2"), "Enter Beneficiary Address 2");
			WebDr.setText("UserRefNo", WebDr.getTimeStamp(), "Enter User Reference No");
			WebDr.clickwithmouse("OKButton", "Click on the OK Button");

			// Mandatory UDF Details
			if (WebDr.strFCRCountry.equals("BBK")) {
				WebDr.alertAccept();
				WebDr.setText("UDFWalkInCustName", WebDr.getValue("UDFWalkInCustName"),
						"Enter UDF Walk-In Customer Name");
				WebDr.clickwithmouse("ValidateButton", "Click on the Validate Button");
				WebDr.clickwithmouse("BackButton", "Click on the Back Button");
				WebDr.clickwithmouse("OKButton", "Click on the OK Button");
				WebDr.alertClickWithText("here");
				WebDr.alertClickWithText("here");
			}

			if (!WebDr.strFCRCountry.equals("BBM")) {
				// Denomination
				WebDr.waitForPageLoaded();
				WebDr.alertClickWithText("Denomination");
				WebDr.DenominationEntry("Enter Denomination");
				WebDr.clickwithmouse("OKDenomButton", "Click on the Denomination OK Button");
				WebDr.clickwithmouse("OKButton", "Click on the OK Button");
			} else {

				WebDr.waitForPageLoaded();
				WebDr.DenominationEntry("Enter Denomination");
				// WebDr.clickwithmouse("OKDenomButton", "Click on the
				// Denomination OK Button");
				WebDr.click("OKDenomButton", "Click on the Denomination OK Button");
				WebDr.clickwithmouse("OKButton", "Click on the OK Button");
			}

			if (WebDr.strFCRCountry.equals("UG")) {
				WebDr.alertClickWithText("Transaction Sequence number is ");
				WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");

			} else {
				if (WebDr.strFCRCountry.equals("BBK")) {
					WebDr.alertClickWithText("here");
					WebDr.alertClickWithText("here");
					WebDr.authWithComment();
					WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
				}

				if (WebDr.strFCRCountry.equals("BBM")) {
					WebDr.authWithComment();
					WebDr.alertClickWithText("Transaction Sequence number is ");
					WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
					WebDr.alertAccept();

				}
			}

			WebDr.getSerialNo();
			WebDr.SerialNo = WebDr.getSerialNo();
			WebDr.alertAccept();

			if (!(WebDr.SerialNo.toString().length() == 0)) {
				HtmlReporter.WriteStep("Check if the user can issue DD against Cash using option 8305",
						"User should be able to issue DD against Cash using option 8305",
						"Transaction successful. Serial No - " + WebDr.SerialNo, true);
			} else {
				HtmlReporter.WriteStep("Check if the user can issue DD against Cash using option 8305",
						"User should be able to issue DD against Cash using option 8305", "Transaction unsuccessful: ",
						false);

			}

		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Check if the user can issue DD against Cash using option 8305",
					"User should be able to issue DD against Cash using option 8305",
					"Transaction unsuccessful: " + e.toString(), false);
		}

	}

	public static void Remittance_DD_Sale_Against_GL_8306() throws Exception {
		try {
			pkgFCRPageObjects.FCR_RemittancePageObjects.Remittance_DDSaleAgainstGL_8306();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("BankCode", WebDr.getValue("BankCode"), "Select Bank Code");
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("PayableBranchPickList", "Click on Payable Branch Pick List");
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("GLCurrency", WebDr.getValue("GLCurrency"), "Select GL Currency");

			if (WebDr.strFCRCountry.equals("BBK")) {
				if (WebDr.isAlertPresent()) {
					try {

						WebDr.alertAccept();
						WebDr.alertAccept();
						if (WebDr.isAlertPresent()) {
							WebDr.alertAccept();
							WebDr.alertAccept();
						}
					} catch (Exception eAlert) {
						System.out.println("Error window did not exist");
					}
				}
				WebDr.clickwithmouse("ChqCcyPickList", "Click on Cheque Currency Pick List");
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.rTab();
				WebDr.rEnter();
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();

				if (WebDr.strFCRCountry.equals("BBK")) {
					if (WebDr.isAlertPresent()) {
						try {

							WebDr.alertAccept();
							WebDr.alertAccept();
							if (WebDr.isAlertPresent()) {
								WebDr.alertAccept();
								WebDr.alertAccept();
							}
						} catch (Exception eAlert) {
							System.out.println("Error window did not exist");
						}
					}
					/*
					 * WebDr.alertAccept(); WebDr.waitForPageLoaded();
					 * WebDr.alertAccept(); WebDr.waitForPageLoaded();
					 * WebDr.alertAccept(); WebDr.waitForPageLoaded();
					 * WebDr.alertAccept(); WebDr.waitForPageLoaded();
					 */
				}

				/*
				 * WebDr.clickwithmouse("GLAcctNumPickList",
				 * "Click on GL Account Number Pick List"); WebDr.rTab();
				 * WebDr.waitForPageLoaded(); WebDr.rTab();
				 * WebDr.waitForPageLoaded(); WebDr.rEnter();
				 * WebDr.waitForPageLoaded();
				 */
				WebDr.setText("GLAccountNumber", WebDr.getValue("GLAccountNumber"), "Enter GL Account Number");
				WebDr.rTab();
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.setText("ChequeAmount", WebDr.getValue("ChequeAmount"), "Enter Cheque Amount");
				if (WebDr.strFCRCountry.equals("BBK")) {
					WebDr.alertClickWithText("Inventory Details not found ");
				}
				/*
				 * if (WebDr.strFCRCountry.equals("BBM")) { //
				 * WebDr.alertAccept(); WebDr.
				 * alertClickWithText("Service Charges are more than Transaction Amount"
				 * ); }
				 */
				WebDr.setText("MICRNumber", WebDr.getTimeStamp(), "Enter MICR Number");
				if ((WebDr.strFCRCountry.equals("NBC"))) {
					WebDr.setText("RoutingNumber", WebDr.getTimeStamp(), "Enter Routing Number ");
				}
				WebDr.setText("BeneficiaryName", WebDr.getValue("BeneficiaryName"), "Enter Beneficiary Name");
				WebDr.setText("PassportICNo", WebDr.getTimeStamp(), "Enter Passport / IC Number ");
				WebDr.setText("BenfAddr1", WebDr.getValue("BenfAddr1"), "Enter Beneficiary Address 1");
				WebDr.setText("BenfAddr2", WebDr.getValue("BenfAddr2"), "Enter Beneficiary Address 2");
				WebDr.setText("UserRefNo", WebDr.getTimeStamp(), "Enter User Reference No");
				WebDr.clickwithmouse("OKButton", "Click on the OK Button");

				// Mandatory UDF Details
				if (WebDr.strFCRCountry.equals("BBK")) {
					WebDr.alertAccept();

					WebDr.setText("UDFWalkInCustName", WebDr.getValue("UDFWalkInCustName"),
							"Enter UDF Walk-In Customer Name");
					WebDr.clickwithmouse("ValidateButton", "Click on the Validate Button");
					WebDr.clickwithmouse("BackButton", "Click on the Back Button");
					WebDr.clickwithmouse("OKButton", "Click on the OK Button");
					WebDr.alertClickWithText("here");
					WebDr.alertClickWithText("here");
					WebDr.authWithComment();
				}
			}
			WebDr.alertClickWithText("Transaction Sequence number is ");
			WebDr.rTab();
			WebDr.rEnter();
			if (WebDr.strFCRCountry.equals("NBC")) {
				WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
				// WebDr.waitForPageLoaded();
			}
			WebDr.SerialNo = WebDr.getSerialNo();
			WebDr.alertAccept();

			if (!(WebDr.SerialNo.toString().length() == 0)) {
				HtmlReporter.WriteStep("Check if the user can issue DD against GL using option 8306",
						"User should be able to issue DD against GL using option 8306",
						"Transaction successful. Serial No - " + WebDr.SerialNo, true);
			} else {
				HtmlReporter.WriteStep("Check if the user can issue DD against GL using option 8306",
						"User should be able to issue DD against GL using option 8306",
						"Transaction unsuccessful. Serial No - ", false);

			}

		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Check if the user can issue DD against GL using option 8306",
					"User should be able to issue DD against GL using option 8306",
					"Transaction unsuccessful: " + e.toString(), false);
		}

	}

	public static void Remittance_Bankers_Cheque_Sale_Against_Cash_8301() throws Exception {
		try {
			pkgFCRPageObjects.FCR_RemittancePageObjects.Remittance_BankersChequeSaleAgainstCash_8301();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.setText("BankCode", WebDr.getValue("BankCode"), "Select Bank Code");
			WebDr.clickwithmouse("ChqCcyPickList", "Click on Cheque Currency Pick List");
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("TxnCcy", WebDr.getValue("TransactionCurrency"),
					"Select Transaction Currency");
			if (WebDr.isAlertPresent()) {
				WebDr.alertAccept();
				WebDr.alertAccept();
				WebDr.alertAccept();
				WebDr.alertAccept();

			}
			WebDr.setText("ChequeAmount", WebDr.getValue("ChequeAmount"), "Enter Cheque Amount");
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			if (WebDr.isAlertPresent()) {
				WebDr.alertAccept();
				WebDr.alertAccept();
			}
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.setText("MICRNumber", WebDr.getTimeStamp(), "Enter MICR Number");
			if (!WebDr.strFCRCountry.equals("NBC")) {
				WebDr.setText("WalkinCustName", WebDr.getValue("WalkinCustName"), "Enter Walkin Customer Name");
			}
			WebDr.setText("BeneficiaryName", WebDr.getValue("BeneficiaryName"), "Enter Beneficiary Name");
			WebDr.setText("PassportICNo", WebDr.getTimeStamp(), "Enter Passport / IC Number ");
			WebDr.setText("BenfAddr1", WebDr.getValue("BenfAddr1"), "Enter Beneficiary Address 1");
			WebDr.setText("BenfAddr2", WebDr.getValue("BenfAddr2"), "Enter Beneficiary Address 2");
			WebDr.setText("UserRefNo", WebDr.getTimeStamp(), "Enter User Reference No");
			WebDr.clickwithmouse("OKButton", "Click on the OK Button");
			if (WebDr.strFCRCountry.equals("BBK")) {
				WebDr.alertClickWithText("here");
				WebDr.alertClickWithText("here");
				WebDr.waitForPageLoaded();
				WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
				WebDr.waitForPageLoaded();
				WebDr.alertAccept();
				HtmlReporter.WriteStep("Check if the user can issue BC against Cash using option 8301",
						"User should be able to issue BC against Cash using option 8301", "Transaction successful.",
						true);
			}

			else if (WebDr.strFCRCountry.equals("UG")) {
				WebDr.alertClickWithText("Transaction sequence number is");
				WebDr.waitForPageLoaded();
				WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
				WebDr.waitForPageLoaded();
				WebDr.alertClickWithText("Serial Number is");
				WebDr.waitForPageLoaded();
				HtmlReporter.WriteStep("Check if the user can issue BC against Cash using option 8301",
						"User should be able to issue BC against Cash using option 8301",
						"Transaction successful. Serial No - " + WebDr.SerialNo, true);

			} else {
				WebDr.alertClickWithText("Transaction Sequence number is ");
				WebDr.getSerialNo();
				WebDr.SerialNo = WebDr.getSerialNo();
				if (WebDr.strFCRCountry.equals("NBC")) {
					if (WebDr.isAlertPresent()) {
						WebDr.alertClickWithText("Serial Number is  ");
					}
					WebDr.waitForPageLoaded();
				}
				if (!(WebDr.SerialNo.toString().length() == 0)) {
					HtmlReporter.WriteStep("Check if the user can issue BC against Cash using option 8301",
							"User should be able to issue BC against Cash using option 8301",
							"Transaction successful. Serial No - " + WebDr.SerialNo, true);
				} else {
					HtmlReporter.WriteStep("Check if the user can issue BC against Cash using option 8301",
							"User should be able to issue BC against Cash using option 8301",
							"Transaction unsuccessful. Serial No - ", false);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Check if the user can issue BC against Cash using option 8301",
					"User should be able to issue BC against Cash using option 8301",
					"Transaction unsuccessful: " + e.toString(), false);
		}

	}

	public static void Remittance_DD_Liquidation_Inquiry_Cash_8310() throws Exception {
		try {
			pkgFCRPageObjects.FCR_RemittancePageObjects.Remittance_DDLiquidationInquiryCash_8310();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();

			WebDr.selectDropValueByVisibleText("LiquidationMode", WebDr.getValue("LiquidationMode"),
					"Select Liquidation Mode");
			WebDr.setText("SerialNo", WebDr.getValue("SerialNo"), "Enter Serial Number");
			WebDr.selectDropValueByVisibleText("LiquidationType", WebDr.getValue("LiquidationType"),
					"Select Liquidation Type");
			WebDr.clickwithmouse("OKButton", "Click on OK Button");

			WebDr.alertAccept();
			WebDr.selectDropValueByVisibleText("TransactionCcy", WebDr.getValue("TransactionCcy"),
					"Select Transaction Currency ");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			if (WebDr.strFCRCountry.equals("BBK")) {
				if (WebDr.isAlertPresent()) {
					try {

						WebDr.alertAccept();
						WebDr.alertAccept();
						if (WebDr.isAlertPresent()) {
							WebDr.alertAccept();
							WebDr.alertAccept();
						}
					} catch (Exception eAlert) {
						System.out.println("Error window did not exist");
					}
				}
			}
			WebDr.waitForPageLoaded();
			WebDr.setText("UserRefNo", WebDr.getTimeStamp(), "Select User Reference Number");

			WebDr.clickwithmouse("OKButton2", "Click on OK Button");
			WebDr.alertClickWithText("Denomination");
			WebDr.DenominationEntry("Enter Denomination");
			WebDr.clickwithmouse("OKDenomButton", "Click on OK Denom Button");
			WebDr.clickwithmouse("OKButton", "Click on OK Button");

			try {
				if (WebDr.strFCRCountry.equals("BBK")) {
					if (WebDr.VerifyStatusBarText("StatusBar", 10, "Transaction sequence number is",
							"Verify transaction status"))
						HtmlReporter.WriteStep(
								"Check whether teller is able to fund a CASA account using physical cash  from 1401 screen.",
								"User should be able to deposit funds successfully. ", "Funds Transfer Successful. ",
								true);
					else {
						HtmlReporter.WriteStep(
								"Check whether teller is able to fund a CASA account using physical cash  from 1401 screen.",
								"User should be able to deposit funds successfully. ", "Funds Transfer Unsuccessful. ",
								false);
					}
				} else {

					if (WebDr.alertClickWithText("Transaction sequence number is")) {
						HtmlReporter.WriteStep("Check if the DD can be liquidated against cash",
								"User should be able to Check if the DD can be liquidated against cash",
								"Transaction successful. ", true);
						WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
					} else
						HtmlReporter.WriteStep("Check if the DD can be liquidated against cash",
								"User should be able to Check if the DD can be liquidated against cash",
								"Transaction unsuccessful. ", false);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();

		} catch (Exception error) {
			error.printStackTrace();
			HtmlReporter.WriteStep("Check if the DD can be liquidated against cash",
					"User should be able to Check if the DD can be liquidated against cash",
					"Transaction unsuccessful. ", false);
		}
	}

	public static void Remittance_DD_Liquidation_Inquiry_CASA_8310() throws Exception {
		try {
			pkgFCRPageObjects.FCR_RemittancePageObjects.Remittance_DDLiquidationInquiryCASA_8310();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("LiquidationMode", WebDr.getValue("LiquidationMode"),
					"Select Liquidation Mode");
			WebDr.setText("SerialNo", WebDr.getValue("SerialNo"), "Enter Serial Number");
			WebDr.selectDropValueByVisibleText("LiquidationType", WebDr.getValue("LiquidationType"),
					"Select Liquidation Type");
			WebDr.clickwithmouse("OKButton", "Click on OK Button");
			WebDr.alertAccept();
			WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
			WebDr.rTab();
			WebDr.rTab();
			if (WebDr.strFCRCountry.equals("BBK")) {
				if (WebDr.isAlertPresent()) {
					try {

						WebDr.alertAccept();
						WebDr.alertAccept();
						if (WebDr.isAlertPresent()) {
							WebDr.alertAccept();
							WebDr.alertAccept();
						}
					} catch (Exception eAlert) {
						System.out.println("Error window did not exist");
					}
				}
			}
			WebDr.waitForPageLoaded();
			WebDr.setText("UserRefNo", WebDr.getTimeStamp(), "Enter User Reference Number");
			WebDr.clickwithmouse("OKButton2", "Click on OK Button");
			try {
				if (WebDr.strFCRCountry.equals("BBK")) {
					if (WebDr.VerifyStatusBarText("StatusBar", 10, "Transaction sequence number is",
							"Verify transaction status"))
						HtmlReporter.WriteStep(
								"Check whether teller is able to fund a CASA account using physical cash  from 1401 screen.",
								"User should be able to deposit funds successfully. ", "Funds Transfer Successful. ",
								true);
					else {
						HtmlReporter.WriteStep(
								"Check whether teller is able to fund a CASA account using physical cash  from 1401 screen.",
								"User should be able to deposit funds successfully. ", "Funds Transfer Unsuccessful. ",
								false);
					}
				} else {

					if (WebDr.alertClickWithText("Transaction sequence number is")) {
						HtmlReporter.WriteStep("Check if the DD can be liquidated against cash",
								"User should be able to Check if the DD can be liquidated against cash",
								"Transaction successful. ", true);
						WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
					} else
						HtmlReporter.WriteStep("Check if the DD can be liquidated against cash",
								"User should be able to Check if the DD can be liquidated against cash",
								"Transaction unsuccessful. ", false);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}

			WebDr.alertAccept();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();

		} catch (Exception error) {
			error.printStackTrace();
			HtmlReporter.WriteStep("Check if the DD can be liquidated against CASA",
					"User should be able to Check if the DD can be liquidated against CASA",
					"Transaction unsuccessful. ", false);
		}
	}

	public static void Remittance_BC_Liquidation_Inquiry_Cash_8307() throws Exception {
		try {
			pkgFCRPageObjects.FCR_RemittancePageObjects.Remittance_BCLiquidationInquiryCash_8307();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("LiquidationMode", WebDr.getValue("LiquidationMode"),
					"Select Liquidation Mode");
			WebDr.setText("SerialNo", WebDr.getValue("SerialNo"), "Enter Serial Number");
			WebDr.selectDropValueByVisibleText("LiquidationType", WebDr.getValue("LiquidationType"),
					"Select Liquidation Type");
			WebDr.clickwithmouse("OKButton", "Click on OK Button");
			WebDr.alertAccept();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.setText("UserRefNo", WebDr.getTimeStamp(), "Enter User Reference Number");
			WebDr.clickwithmouse("OKButton2", "Click on OK Button");

			if (WebDr.strFCRCountry.equals("UG") || WebDr.strFCRCountry.equals("BBK")) {
				WebDr.alertClickWithText("Denomination");
				WebDr.DenominationEntry("Enter Denomination");
				WebDr.clickwithmouse("OKDenomButton", "Click on OK Button");
				WebDr.clickwithmouse("OKButton2", "Click on OK Button");
				WebDr.authWithComment();
			}
			if (WebDr.strFCRCountry.equals("BBM")) {
				WebDr.alertAccept();
				WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
				WebDr.alertClickWithText("Transaction Sequence number is ");
				WebDr.getSerialNo_8302();
				WebDr.SerialNo = WebDr.getSerialNo_8302();
			}
			if (WebDr.strFCRCountry.equals("NBC")) {
				if (WebDr.isAlertPresent()) {
					WebDr.alertClickWithText("Cash more than maximum limit.");
					WebDr.alertClickWithText("Transaction sequence number is");
					WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
					HtmlReporter.WriteStep("Check if the BC can be liquidated against cash",
							"User should be able to Check if the BC can be liquidated against cash",
							"Transaction successful. ", true);
				} else {
					HtmlReporter.WriteStep("Check if the BC can be liquidated against cash",
							"User should be able to Check if the BC can be liquidated against cash",
							"Transaction unsuccessful. ", false);
				}
			} else if (WebDr.strFCRCountry.equals("BBK")) {
				WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
				WebDr.alertClickWithText("Serial Number is ");
				HtmlReporter.WriteStep("Check if the BC can be liquidated against cash",
						"User should be able to Check if the BC can be liquidated against cash",
						"Transaction successful. ", true);

			} else {
				if (WebDr.alertClickWithText("Transaction sequence number is"))
					HtmlReporter.WriteStep("Check if the BC can be liquidated against cash",
							"User should be able to Check if the BC can be liquidated against cash",
							"Transaction successful. ", true);
				else {
					HtmlReporter.WriteStep("Check if the BC can be liquidated against cash",
							"User should be able to Check if the BC can be liquidated against cash",
							"Transaction unsuccessful. ", false);
				}
			}

			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.alertAccept();

		} catch (Exception error) {
			error.printStackTrace();
			HtmlReporter.WriteStep("Check if the BC can be liquidated against cash",
					"User should be able to Check if the BC can be liquidated against cash",
					"Transaction unsuccessful. ", false);
		}
	}

	public static void Remittance_BC_Liquidation_Inquiry_CASA_8307() throws Exception {
		try {
			pkgFCRPageObjects.FCR_RemittancePageObjects.Remittance_BCLiquidationInquiryCASA_8307();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("LiquidationMode", WebDr.getValue("LiquidationMode"),
					"Select Liquidation Mode");
			WebDr.setText("SerialNo", WebDr.getValue("SerialNo"), "Enter Serial Number");
			WebDr.selectDropValueByVisibleText("LiquidationType", WebDr.getValue("LiquidationType"),
					"Select Liquidation Type");
			WebDr.clickwithmouse("OKButton", "Click on OK Button");
			WebDr.alertAccept();
			WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
			WebDr.setText("UserRefNo", WebDr.getTimeStamp(), "Enter User Reference Number");
			WebDr.clickwithmouse("OKButton2", "Click on OK Button");
			WebDr.alertClickWithText("Sybrin");

			try {

				if (WebDr.alertClickWithText("Transaction sequence number is"))
					HtmlReporter.WriteStep("Check if the BC can be liquidated against CASA",
							"User should be able to Check if the BC can be liquidated against CASA",
							"Transaction successful. ", true);
				else
					HtmlReporter.WriteStep("Check if the BC can be liquidated against CASA",
							"User should be able to Check if the BC can be liquidated against CASA",
							"Transaction unsuccessful. ", false);
			} catch (Exception e) {
				e.printStackTrace();
			}

			WebDr.alertAccept();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();

		} catch (Exception error) {
			error.printStackTrace();
			HtmlReporter.WriteStep("Check if the BC can be liquidated against CASA",
					"User should be able to Check if the BC can be liquidated against CASA",
					"Transaction unsuccessful. ", false);
		}
	}

	public static void Remittance_DD_Sale_Against_Account_1014() throws Exception {
		try {
			pkgFCRPageObjects.FCR_RemittancePageObjects.Remittance_DDSaleAgainstAccount_1014();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.setText("BankCode", WebDr.getValue("BankCode"), "Select Bank Code");
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("PayableBranchPickList", "Click on Payable Branch Pick List");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.setText("AccountNumber", WebDr.getValue("AccountNumber"), "Select Account Number");
			WebDr.clickwithmouse("ChqCcyPickList", "Click on Cheque Currency Pick List");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			if (WebDr.strFCRCountry.equals("BBK")) {
				if (WebDr.isAlertPresent()) {
					try {

						WebDr.alertAccept();
						WebDr.alertAccept();
						if (WebDr.isAlertPresent()) {
							WebDr.alertAccept();
							WebDr.alertAccept();
						}
					} catch (Exception eAlert) {
						System.out.println("Error window did not exist");
					}
				}
			}
			WebDr.setText("ChequeAmount", WebDr.getValue("ChequeAmount"), "Enter Cheque Amount");
			if (WebDr.strFCRCountry.equals("BBK")) {
				WebDr.alertClickWithText("Inventory Details not found ");
				WebDr.waitForPageLoaded();
			}
			WebDr.setText("MICRNumber", WebDr.getTimeStamp(), "Enter MICR Number");
			WebDr.setText("RoutingNumber", WebDr.getTimeStamp(), "Enter Routing Number ");
			WebDr.setText("BeneficiaryName", WebDr.getValue("BeneficiaryName"), "Enter Beneficiary Name");
			WebDr.setText("PassportICNo", WebDr.getTimeStamp(), "Enter Passport / IC Number ");
			WebDr.setText("BenfAddr1", WebDr.getValue("BenfAddr1"), "Enter Beneficiary Address 1");
			WebDr.setText("BenfAddr2", WebDr.getValue("BenfAddr2"), "Enter Beneficiary Address 2");
			WebDr.setText("UserRefNo", WebDr.getTimeStamp(), "Enter User Reference No");
			WebDr.clickwithmouse("OKButton", "Click on the OK Button");
			if (WebDr.strFCRCountry.equals("BBK")) {
				WebDr.alertAccept();
				// WebDr.alertAccept();
				WebDr.setText("UDFWalkInCustName", WebDr.getValue("UDFWalkInCustName"),
						"Enter UDF Walk-In Customer Name");
				WebDr.clickwithmouse("ValidateButton", "Click on the Validate Button");
				WebDr.clickwithmouse("BackButton", "Click on the Back Button");
				WebDr.clickwithmouse("OKButton", "Click on the OK Button");
				WebDr.alertAccept();
				WebDr.alertClickWithText(WebDr.getValue("AccountNo"));
				WebDr.waitForPageLoaded();
				WebDr.click("Sign", "Click on Sign");
				WebDr.waitForNumberOfWindowsToEqual(3);
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				WebDr.clickactivatewithmouse("SignZoom", "Click on signature window");
				WebDr.CloseWindowWithTitle("Signature");
				WebDr.SwitchToLatestWindow();
				WebDr.click("FastPath", "Click in the textfield");

				WebDr.click("SignVerified", "Click on Signature Verified");

				WebDr.clickwithmouse("OKButton", "Click on the OK Button");
				WebDr.authWithComment();
			}
			WebDr.alertClickWithText("Transaction Sequence number is ");
			WebDr.alertAccept();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();

			WebDr.getSerialNo();
			WebDr.SerialNo = WebDr.getSerialNo();

			if (!(WebDr.SerialNo.toString().length() == 0)) {
				HtmlReporter.WriteStep(
						"Check if the user can Verify whether DD against the customer�s CASA using 1014-� DD Sale Against Account screen can be issued",
						"User should be able to issue  DD against the customer�s CASA using 1014-� DD Sale Against Account screen",
						"Transaction successful. Serial No - " + WebDr.SerialNo, true);
			} else {
				HtmlReporter.WriteStep(
						"Check if the user can Verify whether DD against the customer�s CASA using 1014-� DD Sale Against Account screen can be issued",
						"User should be able to issue  DD against the customer�s CASA using 1014-� DD Sale Against Account screen",
						"Transaction unsuccessful. Serial No - ", false);

			}

		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep(
					"Check if the user can Verify whether DD against the customer�s CASA using 1014-� DD Sale Against Account screen can be issued",
					"User should be able to issue  DD against the customer�s CASA using 1014-� DD Sale Against Account screen",
					"Transaction unsuccessful: " + e.toString(), false);
		}

	}

	public static void Remittance_BC_Sale_Against_Account_1010() throws Exception {
		try {
			pkgFCRPageObjects.FCR_RemittancePageObjects.Remittance_BCSaleAgainstAccount_1010();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.setText("BankCode", WebDr.getValue("BankCode"), "Select Bank Code");
			WebDr.setText("AccountNumber", WebDr.getValue("AccountNumber"), "Select Account Number");
			WebDr.clickwithmouse("ChqCcyPickList", "Click on Cheque Currency Pick List");
			WebDr.alertAccept();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.setText("ChequeAmount", WebDr.getValue("ChequeAmount"), "Enter Cheque Amount");
			WebDr.setText("MICRNumber", WebDr.getTimeStamp(), "Enter MICR Number");
			WebDr.setText("BeneficiaryName", WebDr.getValue("BeneficiaryName"), "Enter Beneficiary Name");
			WebDr.setText("PassportICNo", WebDr.getTimeStamp(), "Enter Passport / IC Number ");
			WebDr.setText("BenfAddr1", WebDr.getValue("BenfAddr1"), "Enter Beneficiary Address 1");
			WebDr.setText("BenfAddr2", WebDr.getValue("BenfAddr2"), "Enter Beneficiary Address 2");
			WebDr.setText("UserRefNo", WebDr.getTimeStamp(), "Enter User Reference No");
			WebDr.clickwithmouse("OKButton", "Click on the OK Button");
			WebDr.authWithComment();

			WebDr.alertClickWithText("Transaction Sequence number is ");
			WebDr.alertAccept();
			WebDr.rTab();
			WebDr.waitForPageLoaded();

			WebDr.rEnter();

			WebDr.getSerialNo();
			WebDr.SerialNo = WebDr.getSerialNo();
			WebDr.alertAccept();

			if (!(WebDr.SerialNo.toString().length() == 0)) {
				HtmlReporter.WriteStep(
						"Check if the user can Verify whether Bankers Cheque against the customer�s CASA using 1010-� Bankers Cheque Sale Against Account screen can be issued",
						"User should be able to issue Bankers Cheque against the customer�s CASA using 1010-� Bankers Cheque Sale Against Account screen",
						"Transaction successful. Serial No - " + WebDr.SerialNo, true);
			} else {
				HtmlReporter.WriteStep(
						"Check if the user can Verify whether Bankers Cheque against the customer�s CASA using 1010-� Bankers Cheque Sale Against Account screen can be issued",
						"User should be able to issue Bankers Cheque against the customer�s CASA using 1010-� Bankers Cheque Sale Against Account screen",
						"Transaction unsuccessful.", false);

			}

		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep(
					"Check if the user can Verify whether Bankers Cheque against the customer�s CASA using 1010-� Bankers Cheque Sale Against Account screen can be issued",
					"User should be able to issue Bankers Cheque against the customer�s CASA using 1010-� Bankers Cheque Sale Against Account screen",
					"Transaction unsuccessful." + e.toString(), false);
		}

	}

	public static void Remittance_DD_Details_Maint_BAM38() throws Exception {

		try {
			pkgFCRPageObjects.FCR_RemittancePageObjects.Remittance_DDDetailsMaint_BAM38();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("AddButton", "Click on Add Radio Button");

			if (WebDr.strFCRCountry.equals("UG")) {
				WebDr.clickwithmouse("IssuerPickListCode", "Click on Issuer Code Pick List");
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rEnter();
				WebDr.waitForPageLoaded();
			}

			else if (WebDr.strFCRCountry.equals("NBC") || WebDr.strFCRCountry.equals("BBK")) {
				WebDr.clickwithmouse("IssuerPickListCode", "Click on Issuer Code Pick List");
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rDown();
				WebDr.waitForPageLoaded();
				WebDr.rEnter();
				WebDr.waitForPageLoaded();

			}

			WebDr.selectDropValueByVisibleText("PayableBranch", WebDr.getValue("PayableBranch"),
					"Select Payable Branch");
			WebDr.setText("AddressLine1", WebDr.getValue("AddressLine1"), "Enter Adrress in Line 1");
			WebDr.setText("AddressLine2", WebDr.getValue("AddressLine2"), "Enter Adrress in Line 2");
			WebDr.setText("City", WebDr.getValue("City"), "Enter City");
			WebDr.setText("State", WebDr.getValue("State"), "Enter State");
			WebDr.setText("ZIPCode", WebDr.getValue("ZIPCode"), "Enter ZIP Code");

			if (WebDr.strFCRCountry.equals("UG")) {
				WebDr.clickwithmouse("CountryPickList", "Click on Country Pick List");
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rEnter();
				WebDr.waitForPageLoaded();
			}

			else if (WebDr.strFCRCountry.equals("NBC") || WebDr.strFCRCountry.equals("BBK")) {
				WebDr.clickwithmouse("CountryPickList", "Click on Country Pick List");
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.rDown();
				WebDr.waitForPageLoaded();
				WebDr.rEnter();
				WebDr.waitForPageLoaded();
			}

			WebDr.rClearUpdateTextField("PayableAmount", WebDr.getValue("PayableAmount"), "Enter Payable Amount");
			WebDr.clickwithmouse("OKButton", "Click on OK Button");
			WebDr.alertHandlingForErrors("Record Added... Authorisation Pending.. ", "Check for alert message");

			LOAN.logout();
			WebDr.waitForPageLoaded();
			LOAN.superLogin();
			pkgFCRPageObjects.FCR_RemittancePageObjects.Remittance_DDDetailsMaint_BAM38();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("AuthoriseButton", "Click on Authorise Radio Button");
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("IssuerPickListCode", "Click on Issuer Code Pick List");
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("OKButton", "Click on OK Button");
			// WebDr.alertHandlingForErrors("Record Authorized .. Click Ok to
			// Continue", "Check for alert message");

			try {

				if (WebDr.alertClickWithText("Record Authorized .. Click Ok to Continue"))
					HtmlReporter.WriteStep(
							"Check if the user can issue DD on the Payable branch maintained in the BAM38",
							"User should be able to issue DD on the Payable branch maintained in the BAM38",
							"DD Issue successful. ", true);
				else
					HtmlReporter.WriteStep(
							"Check if the user can issue DD on the Payable branch maintained in the BAM38",
							"User should be able to issue DD on the Payable branch maintained in the BAM38",
							"DD Issue unsuccessful. ", false);
			} catch (Exception e) {
				e.printStackTrace();
			}

			LOAN.logout();
			LOAN.login();

		} catch (Exception error) {
			error.printStackTrace();
			HtmlReporter.WriteStep("Check if the user can issue DD on the Payable branch maintained in the BAM38",
					"User should be able to issue DD on the Payable branch maintained in the BAM38",
					"DD Issue unsuccessful. ", false);
		}

	}

	public static void Remittance_BC_Sale_Against_GL_8302() throws Exception {
		try {
			pkgFCRPageObjects.FCR_RemittancePageObjects.Remittance_BankersChequeSaleAgainstCash_8301();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			if (WebDr.strFCRCountry.equals("NBC")) {
				WebDr.selectDropValueByVisibleText("BankCode", WebDr.getValue("BankCode"), "Select Bank Code");
			} else {
				WebDr.setText("BankCode", WebDr.getValue("BankCode"), "Select Bank Code");
			}
			WebDr.selectDropValueByVisibleText("GlCcy", WebDr.getValue("GlCcy"), "Select GL Currency");
			if (WebDr.strFCRCountry.equals("BBK")) {
				try {
					while (WebDr.isAlertPresent()) {
						WebDr.alertAccept();
					}
				} catch (Exception eAlert) {
					System.out.println("Error window did not exist");
				}
			}
			if (WebDr.strFCRCountry.equals("UG")) {
				WebDr.click("ChqCcyPickList", "Select Cheque Currency");
				WebDr.rTab();
				WebDr.rTab();
				WebDr.rEnter();
				WebDr.waitForPageLoaded();
			} else {
				WebDr.selectDropValueByVisibleText("TxnCcy", WebDr.getValue("TxnCcy"), "Select GL Currency");
			}
			WebDr.setText("GlAcctNo", WebDr.getValue("GlAcctNo"), "Enter GL Account Number");
			WebDr.rTab();
			if (WebDr.isAlertPresent()) {
				WebDr.alertAccept();
			}
			WebDr.waitForPageLoaded();
			WebDr.setText("ChequeAmount", WebDr.getValue("ChequeAmount"), "Enter Cheque Amount");
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.setText("MICRNumber", WebDr.getTimeStamp(), "Enter MICR Number");
			WebDr.rTab();
			// WebDr.setText("WalkinCustName", WebDr.getValue("WalkinCustName"),
			// "Enter WalkIn Customer Name");
			WebDr.setText("BeneficiaryName", WebDr.getValue("BeneficiaryName"), "Enter Beneficiary Name");
			WebDr.setText("PassportICNo", WebDr.getTimeStamp(), "Enter Passport / IC Number ");
			WebDr.setText("BenfAddr1", WebDr.getValue("BenfAddr1"), "Enter Beneficiary Address 1");
			WebDr.setText("BenfAddr2", WebDr.getValue("BenfAddr2"), "Enter Beneficiary Address 2");
			WebDr.setText("UserRefNo", WebDr.getTimeStamp(), "Enter User Reference No");
			WebDr.clickwithmouse("OKButton", "Click on the OK Button");
			WebDr.waitForPageLoaded();
			if (WebDr.strFCRCountry.equals("UG")) {
				WebDr.authWithComment();
				WebDr.waitForPageLoaded();
				WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
				WebDr.alertClickWithText("Transaction Sequence number is ");
				WebDr.getSerialNo_8302();
				WebDr.SerialNo = WebDr.getSerialNo_8302();
			}
			if (WebDr.strFCRCountry.equals("NBC")) {
				WebDr.alertClickWithText("Transaction Sequence number is ");
				WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
				WebDr.getSerialNo_8302();
				WebDr.SerialNo = WebDr.getSerialNo_8302();
			} else {
				WebDr.alertClickWithText("here");
				WebDr.alertClickWithText("here");
				WebDr.authWithComment();
				WebDr.waitForPageLoaded();
				WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
				WebDr.alertClickWithText("Transaction Sequence number is ");
				WebDr.getSerialNo_8302();
				WebDr.SerialNo = WebDr.getSerialNo_8302();
			}

			if (!(WebDr.SerialNo.toString().length() == 0)) {
				HtmlReporter.WriteStep("Check if the user can issue BC against Cash using option 8301",
						"User should be able to issue BC against Cash using option 8301",
						"Transaction successful. Serial No - " + WebDr.SerialNo, true);
			} else {
				HtmlReporter.WriteStep("Check if the user can issue BC against Cash using option 8301",
						"User should be able to issue BC against Cash using option 8301",
						"Transaction unsuccessful. Serial No - ", false);

			}

		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Check if the user can issue BC against Cash using option 8301",
					"User should be able to issue BC against Cash using option 8301",
					"Transaction unsuccessful: " + e.toString(), false);
		}

	}

	public static void Remittance_BC_Liquidation_Inquiry_GL_8307() throws Exception {
		try {
			pkgFCRPageObjects.FCR_RemittancePageObjects.Remittance_BCLiquidationInquiryCash_8307();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("LiquidationMode", WebDr.getValue("LiquidationMode"),
					"Select Liquidation Mode");
			WebDr.setText("SerialNo", WebDr.getValue("SerialNo"), "Enter Serial Number");
			// WebDr.setText("SerialNo", WebDr.SerialNo, "Enter Serial Number");
			WebDr.selectDropValueByVisibleText("LiquidationType", WebDr.getValue("LiquidationType"),
					"Select Liquidation Type");
			WebDr.clickwithmouse("OKButton", "Click on OK Button");
			WebDr.alertAccept();
			WebDr.waitForPageLoaded();
			// WebDr.rTab();
			WebDr.clickwithmouse("GlAccNo", "Click on GL Account Tab");
			WebDr.waitForPageLoaded();
			WebDr.setText("GlAccNo", WebDr.getValue("GlAccNo"), "Enter GL Account Number");
			WebDr.rTab();
			WebDr.setText("UserRefNo", WebDr.getTimeStamp(), "Enter User Reference Number");
			WebDr.clickwithmouse("OKButton2", "Click on OK Button");
			// WebDr.alertAccept();
			if (!WebDr.strFCRCountry.equals("NBC")) {
				WebDr.authWithComment();
				WebDr.waitForPageLoaded();
				WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
			}
			if (WebDr.alertClickWithText("Transaction sequence number is"))
				HtmlReporter.WriteStep("Check if the BC can be liquidated against GL",
						"User should be able to Check if the BC can be liquidated against GL",
						"Transaction successful. ", true);
			else
				HtmlReporter.WriteStep("Check if the BC can be liquidated against GL",
						"User should be able to Check if the BC can be liquidated against GL",
						"Transaction unsuccessful. ", false);
		} catch (Exception error) {
			error.printStackTrace();
			HtmlReporter.WriteStep("Check if the BC can be liquidated against GL",
					"User should be able to Check if the BC can be liquidated against GL", "Transaction unsuccessful. ",
					false);
		}

	}

	public static void Remittance_DD_Liquidation_Inquiry_AgaintGL_8310() throws Exception {
		try {
			pkgFCRPageObjects.FCR_RemittancePageObjects.Remittance_DDLiquidationInquiryCash_8310();
			WebDr.fastPath(WebDr.getValue("FastPath_1"));
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("LiquidationMode", WebDr.getValue("LiquidationMode"),
					"Select Liquidation Mode");
			WebDr.setText("SerialNo", WebDr.SerialNo, "Enter Serial Number");
			WebDr.selectDropValueByVisibleText("LiquidationType", WebDr.getValue("LiquidationType"),
					"Select Liquidation Type");
			WebDr.clickwithmouse("OKButton", "Click on OK Button");
			WebDr.alertAccept();
			WebDr.waitForPageLoaded();
			WebDr.waitForPageLoaded();
			WebDr.setText("GLAccNo", WebDr.getValue("GLAccNo"), "Select User Reference Number");
			// WebDr.setText("GLAccNo", WebDr.getValue("390701030"), "Select
			// User Reference Number");
			WebDr.rTab();
			WebDr.setText("UserRefNo", WebDr.getTimeStamp(), "Select User Reference Number");
			WebDr.clickwithmouse("OKButton2", "Click on OK Button");
			if (WebDr.alertClickWithText("Transaction sequence number is")) {
				HtmlReporter.WriteStep("Check if the DD can be liquidated against GL using 8310 option",
						"User should be able to Check if the DD can be liquidated against GL",
						"Transaction successful. ", true);
			} else {
				HtmlReporter.WriteStep("Check if the DD can be liquidated against GL using 8310 option",
						"User should be able to Check if the DD can be liquidated against GL",
						"Transaction unsuccessful. ", false);
			}

		} catch (Exception error) {
			error.printStackTrace();
			HtmlReporter.WriteStep("Check if the DD can be liquidated against GL",
					"User should be able to Check if the DD can be liquidated against GL", "Transaction unsuccessful. ",
					false);

		}
	}

	public static void CASA_Cheque_Withdrawal_1013() throws Exception {
		try {
			pkgFCRPageObjects.FCR_RemittancePageObjects.Remittance_CASA_Cheque_Withdrawal_1013();
			WebDr.fastPath(WebDr.getValue("FastPath1"));
			WebDr.waitForPageLoaded();
			WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
			WebDr.rTab();
			WebDr.setText("TxnAmt", WebDr.getValue("TxnAmt"), "Enter TxnAmt");
			WebDr.rTab();
			WebDr.setText("UserRefNo", WebDr.getTimeStamp(), "Select User Reference Number");
			WebDr.clickwithmouse("OKButton", "Click on OK Button");
			WebDr.setText("ChqNo", WebDr.getValue("ChqNo"), "Select User Reference Number");
			WebDr.clickwithmouse("OKButton", "Click on OK Button");
			WebDr.clickwithmouse("OKButton", "Click on OK Button");
		
			if (WebDr.alertClickWithText("Transaction sequence number is")) {
				HtmlReporter.WriteStep("Check whether the user is able to perform a cheque withdrawal transaction successfully or not.",
						"User should be able to perform a cheque withdrawal transaction successfully.",
						"Transaction successful. ", true);
			} else { 
				HtmlReporter.WriteStep("Check whether the user is able to perform a cheque withdrawal transaction successfully or not.",
						"User should be able to perform a cheque withdrawal transaction successfully.",
						"Transaction unsuccessful. ", false);
			}

		} catch (Exception error) {
			error.printStackTrace();
			HtmlReporter.WriteStep("Check whether the user is able to perform a cheque withdrawal transaction successfully or not.",
					"User should be able to perform a cheque withdrawal transaction successfully.", "Transaction unsuccessful. ",
					false);

		}
		
	}
}
