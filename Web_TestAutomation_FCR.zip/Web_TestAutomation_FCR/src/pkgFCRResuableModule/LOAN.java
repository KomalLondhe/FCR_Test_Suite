
package pkgFCRResuableModule;

import java.awt.event.KeyEvent;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchWindowException;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;

//import com.thoughtworks.selenium.webdriven.commands.IsAlertPresent;

import testCases.Driver;
import utility.Constant;
import utility.HtmlReporter;
import utility.WebDr;

public class LOAN extends Driver {

	public static void launch() throws Exception {
		// Retail click_SwitchToNewWindow
		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.Launch();

			// WebDr.SwitchToLatestWindow();
			// WebDr.clickwithmouse("Retail", "Click On Retail"); // Use for
			// single login
			Driver.driver.navigate().to("javascript:document.getElementById('Retail').click()"); // For
																									// Multiple
																									// login
																									// method

			// WebDr.rEnter()

			// if (WebDr.strFCRCountry.equals("UG")){
			try {
				int timeout = 5;
				if (WebDr.strFCRCountry.equals("BBK")) {
					timeout = 38;
				}
				/*WebDr.clickAlwaysImageSikuli("ActiveXInstall.PNG", timeout, "Click to continue");
				WebDr.clickAlwaysImageSikuli("ActiveXInstall.PNG", timeout, "Click to continue");*/
				System.out.println("----------------------------------------------" + WebDr.strFCRCountry
						+ "-----Launching window------------------------------------------------");
			} catch (Exception e) {
				e.printStackTrace();
			}
			// }

			strFCRLaunchWindow = Driver.driver.getWindowHandle();
		} catch (Exception e) {

			// HtmlReporter.WriteStep("Launch FCR application", "User should be
			// able to launch FCR application", "User is not able to launch FCR
			// application.",false);
			System.out.println(
					"--------------------------------------------User is not able to launch FCR application--------------------------------------------------------------");
			e.printStackTrace();
		}
	}

	public static void login() throws Exception {
		// login
		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.Login_page();
			WebDr.SwitchToLatestWindow();

			// if (strFCRAppWindow.isEmpty()){
			// strFCRAppWindow = Driver.driver.getWindowHandle();
			// WebDr.CloseWindowWithTitle("Flexcube Default");
			// WebDr.SwitchToLatestWindow();
			// }

			WebDr.waitForPageLoaded();

			if (WebDr.isAlertPresent() && WebDr.strFCRCountry.equals("NBC")) {
				WebDr.alertHandlingForErrors("SessInvalid", "Handling alert with error Session Invalid");
			}

			//WebDr.waitForElementToBeAvailable("UserID", 120);
			// WebDr.waitForElement("Password");
			// Thread.sleep(6000);
			System.out.println("Current URL:" + driver.getCurrentUrl());
			strFCRTellerWindow = Driver.driver.getWindowHandle();
			WebDr.click("UserID", "Click on UserID");
			WebDr.setText("UserID", WebDr.getValue("Username"), "Enter User ID");
			WebDr.setText("Password", WebDr.getValue("Password"), "Enter Password");
			WebDr.clickwithmouse("LoginButton", "Click on the Login button");
			WebDr.waitForPageLoad();
			WebDr.waitForElementToBeAvailable("FastPath", 120);
			//Reopen Teller Batch
			WebDr.clickwithmouse("FastPath", "Click in FCR Fastpath field");
			HtmlReporter.WriteStep("Login to FCR application", "User should be able to login to FCR application",
					"User is logged in successfully using " + WebDr.getValue("Username"), true);
			// if ((WebDr.exists("FastPath", true, "Check FastPath text field"))
			// == true) {
			// HtmlReporter.WriteStep("Login to FCR application", "User should
			// be able to login to FCR application", "User is logged in
			// successfully using " + WebDr.getValue("Username"),true);
			// }
			// else
			// {
			// HtmlReporter.WriteStep("Login to FCR application", "User should
			// be able to login to FCR application", "User is not logged in
			// successfully using " + WebDr.getValue("Username"),false);
			// throw new Exception();
			// }
		} catch (Exception e) {
			try {
				if (WebDr.isAlertPresent()) {
					WebDr.getTextOnAlertPopup("Verify Error Message");
					WebDr.alertAccept();
				}
				Constant.blnFCRAppStatus = false;
				HtmlReporter.WriteStep("Login to FCR application", "User should be able to login in FCR application",
						"User is not able to login in FCR application and open batch.", false);
				LOAN.FCRExit();
				e.printStackTrace();
				return;
			} catch (Exception error1) {
				error1.printStackTrace();
				System.out.println("No such error alert");
			}
			e.printStackTrace();
			HtmlReporter.WriteStep("Login to FCR application", "User should be able to login in FCR application",
					"User is not able to login in FCR application and open batch.", false);
		}
		// ***************************************************************************************
		/*
		 * try{ System.out.println("enter 9001"); WebDr.fastPath("9001");
		 * System.out.println("entered 9001"); System.out.println("click ok");
		 * WebDr.waitForElement("Screen_OK"); WebDr.click("FastPath",
		 * "Click on FastPath field"); WebDr.clickwithmouse("Screen_OK",
		 * "Click OK button"); try{ if (WebDr.isAlertPresent()) {
		 * WebDr.alertHandlingForErrors("Batch is open already",
		 * "Open Teller Batch in FCR application-9001"); } else
		 * if((WebDr.exists("TellerBatch", true,
		 * "Check for opening teller batch")) == true) {
		 * WebDr.waitForElement("Screen_OK"); WebDr.click("FastPath",
		 * "Click on FastPath field"); WebDr.clickwithmouse("Screen_OK",
		 * "Click OK button"); } }catch(Exception noobj){
		 * noobj.printStackTrace();
		 * System.out.println("Teller batch is already opened"); } //
		 * System.out.println("clicked ok"); //
		 * System.out.println("before alert");
		 * //WebDr.alertHandlingForErrors("successful",
		 * "Open Teller Batch in FCR application-9001"); //
		 * System.out.println("after alert"); } catch (Exception ebatch) {
		 * ebatch.printStackTrace();
		 * HtmlReporter.WriteStep("Open Teller Batch in FCR application-9001",
		 * "User should be able to open teller batch in FCR application",
		 * "User is not able to open teller batch in FCR application and open batch."
		 * ,false); }
		 */
		// ********************************************************************************************
		try {
			
			WebDr.fastPath("9002");
			WebDr.click("FastPath", "Click on FastPath field");
			WebDr.click("Screen_OK", "Click OK button");
			/*if (WebDr.strFCRCountry.equals("NBC")) {
				WebDr.alertAccept();
			}*/
			if(WebDr.alertClickWithText("Teller batch not open for this posting date"))
			{
				WebDr.fastPath("9001");
				WebDr.click("FastPath", "Click on FastPath field");
				WebDr.click("Screen_OK", "Click OK button");
				WebDr.waitForPageLoaded();
				WebDr.click("Screen_OK", "Click OK button");
				WebDr.waitForPageLoaded();
				WebDr.fastPath("9002");
				WebDr.click("FastPath", "Click on FastPath field");
				WebDr.click("Screen_OK", "Click OK button");
			}
			if (WebDr.alertClickWithText("xml txn request")) {

			} else if (WebDr.isAlertPresent()) {
				throw new Exception();
			}
			HtmlReporter.WriteStep("Reopen Teller Batch in FCR application-9002",
					"User should be able to reopen teller batch in FCR application",
					"User is able to reopen teller batch in FCR application.", true);
		} catch (Exception ebatch2) {
			ebatch2.printStackTrace();
			HtmlReporter.WriteStep("Reopen Teller Batch in FCR application-9002",
					"User should be able to reopen teller batch in FCR application",
					"User is not able to reopen teller batch in FCR application.", false);
		}
	}

	public static void logout() throws Exception {
		// logout
		pkgFCRPageObjects.FCR_LoanPageObjects.LOGOUT_page();
		try {
			WebDr.click("LOGOUT", "Click on Logout link");
			if (WebDr.strFCRCountry.equals("BBK")) {
				WebDr.SwitchToLatestWindow();
				LOAN.launch();
			} else {
				WebDr.waitForPageLoaded();
				if (!WebDr.isElementExist("LOGOUT", "Check for Logout Link"))
					HtmlReporter.WriteStep("Logout from FCR application",
							"User should be able to logout from FCR application",
							"User is able to log out from FCR application.", true);
				else {
					// throw new Exception();
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Logout from FCR application", "User should be able to logout from FCR application",
					"User is not able to logout from FCR application.<br>" + e.toString(), false);
		}
	}

	public static void multipleLogin() throws Exception {
		LOAN.login();
		pkgFCRPageObjects.FCR_LoanPageObjects.Login_page();
		driver.switchTo().window(strFCRLaunchWindow);
		// WebDr.SwitchToWindow(strFCRLaunchWindow);
		// WebDr.rAltTab();
		System.out.println("Switch to default window");
		WebDr.waitForElementToBeAvailable("Retail", 120);
		LOAN.launch();
		LOAN.superLogin();
		System.out.println(strFCRLaunchWindow);
		System.out.println(strFCRSuperWindow);
		System.out.println(strFCRTellerWindow);

		// WebDr.swtichOnTellerWindow(fastpath);
		// WebDr.waitForPageLoaded();

	}

	public static void multipleLogout() throws Exception {
		// WebDr.swtichOnTellerWindow();
		// WebDr.SwitchToLatestWindow();
		if (WebDr.strFCRCountry.equals("BBK")) {
			driver.switchTo().window(strFCRTellerWindow);
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("FLEXWIN.bottom.Logout();");
			driver.switchTo().window(strFCRSuperWindow);
			js.executeScript("FLEXWIN.bottom.Logout();");
		} else {
			driver.switchTo().window(strFCRTellerWindow);
			LOAN.logoutwithJSCommand(false);

			driver.switchTo().window(strFCRSuperWindow);
			LOAN.logoutwithJSCommand(true);
		}
	}

	public static void logoutwithclose() throws Exception {
		// logout
		pkgFCRPageObjects.FCR_LoanPageObjects.LOGOUT_page();
		try {
			WebDr.click("LOGOUT", "Click on Logout link");
			if (WebDr.strFCRCountry.equals("BBK")) {
				WebDr.SwitchToLatestWindow();

				HtmlReporter.WriteStep("Logout from FCR application",
						"User should be able to logout from FCR application",
						"User is able to log out from FCR application.", true);
			} else {
				WebDr.waitForPageLoaded();

				if (!WebDr.isElementExist("LOGOUT", "Check for Logout Link"))
					HtmlReporter.WriteStep("Logout from FCR application",
							"User should be able to logout from FCR application",
							"User is able to log out from FCR application.", true);
				else
					throw new Exception();
			}

			driver.close();
		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Logout from FCR application", "User should be able to logout from FCR application",
					"User is not able to logout from FCR application.<br>" + e.toString(), false);
		}
	}

	public static void logoutwithJSCommand(boolean isCloseRequired) throws Exception {
		// logout
		pkgFCRPageObjects.FCR_LoanPageObjects.LOGOUT_page();
		try {

			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("FLEXWIN.bottom.Logout();");
			WebDr.waitForPageLoaded();
			// WebDr.click("LOGOUT", "Click on Logout link");
			WebDr.waitForPageLoaded();
			WebDr.waitForPageLoaded();
			if (WebDr.isElementExist("UserID", "Check for UserID field")) {
				HtmlReporter.WriteStep("Logout from FCR application",
						"User should be able to logout from FCR application",
						"User is able to log out from FCR application.", true);
				if (isCloseRequired == true)
					driver.close();
			} else {
				throw new Exception();
			}
		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Logout from FCR application", "User should be able to logout from FCR application",
					"User is not able to logout from FCR application.<br>" + e.toString(), false);
		}
	}

	public static void FCRExit() throws Exception {
		// logout
		pkgFCRPageObjects.FCR_LoanPageObjects.LOGOUT_page();
		try {
			WebDr.click("LOGOUT", "Click on Logout link");
		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Logout from FCR application", "User should be able to logout from FCR application",
					"User is not able to logout from FCR application.", false);
			Driver.driver.quit();
		}
		Driver.driver.quit();
	}

	public static void superLogin() throws Exception {
		// superlogin
		WebDr.SwitchToLatestWindow();
		pkgFCRPageObjects.FCR_LoanPageObjects.Login_page();
		try {
			WebDr.waitForPageLoaded();
			if (WebDr.strFCRCountry.equals("BBK")) {
				WebDr.waitForPageLoaded_Long(60);
			}
			// WebDr.SwitchToLatestWindow();
			strFCRSuperWindow = Driver.driver.getWindowHandle();
			// WebDr.SwitchToLatestWindow();
			WebDr.waitForElementToBeAvailable("UserID", 180);
			// Thread.sleep(6000);
			System.out.println("Current URL:" + driver.getCurrentUrl());
			WebDr.click("UserID", "Click on User ID");
			WebDr.setText("UserID", WebDr.getValue("S_Username"), "Enter User ID");
			WebDr.setText("Password", WebDr.getValue("S_Password"), "Enter Password");
			WebDr.click("LoginButton", "Click on the Login button");
			WebDr.waitForPageLoaded();
			HtmlReporter.WriteStep("Login to FCR application using supervisor's login",
					"User should be able to login to FCR application",
					"User is logged in successfully using " + WebDr.getValue("S_Username"), true);

		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Login to FCR application using supervisor's login",
					"User should be able to login in FCR application",
					"User is not able to login in FCR application using supervisor's login.", false);
		}
	}

	public static void loanAccountCreation_LN057() throws Exception {
		String strEnterCustID;
		if (!WebDr.CustID.isEmpty()) {
			strEnterCustID = WebDr.CustID;
		} else {
			strEnterCustID = WebDr.getValue("SearchString");
		}

		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.LN057_page();

			//WebDr.swtichOnTellerWindow(WebDr.getValue("FastPath"));
			 WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();

			if (!WebDr.strFCRCountry.equals("UG")) {
				WebDr.click("LNM057Add", "Select Add radio button");
				WebDr.waitForPageLoaded();
			}

			WebDr.selectDropValueByVisibleText("CustomerSearchCriteria", "Customer Id", "Enter Customer ID");
			WebDr.setText("CustomerInfo", strEnterCustID, "Enter Search String");
			WebDr.rTab();
			WebDr.SwitchToLatestWindow();
			WebDr.SelectTopAcct();
			WebDr.SwitchToLatestWindow();
			WebDr.selectDropValueByVisibleText("BRANCH", WebDr.getValue("BranchName"), "Select Branch Name");
			WebDr.selectDropValueByVisibleText("CustomerRelation", WebDr.getValue("CustRelation"),
					"Select Customer Relation");
			WebDr.selectDropValueByVisibleText("Product", WebDr.getValue("ProductCode"), "Select Product");
			WebDr.setText("LoanPurpose", WebDr.getValue("LoanPurpose"), "Enter Loan Purpose");
			WebDr.setText("LoanTerm", WebDr.getValue("LoanTerm"), "Enter Loan Term");
			WebDr.rClearUpdateTextField("AssetValue", WebDr.getValue("AssetValue"), "Enter Asset Value");
			WebDr.rClearUpdateTextField("Contribution", WebDr.getValue("Contribution"), "Enter Contribution");
			WebDr.selectDropValueByVisibleText("RepayMode", WebDr.getValue("RepaymentMode"), "Select Repay Mode");
			WebDr.rClearUpdateTextField("InterestVariance", WebDr.getValue("InterestVariance"),
					"Enter Interest Variance");
			WebDr.rEnter();
			WebDr.SwitchToLatestWindow();
			WebDr.rTab();
			WebDr.rTab();
			// WebDr.rDown();
			WebDr.rEnter();
			WebDr.SwitchToLatestWindow();
			WebDr.clickwithmouse("LN057Screen_OK", "Click on the OK button");

			if (WebDr.strFCRCountry.equals("UG")) {
				WebDr.authOnlyCreds();
				WebDr.waitForPageLoaded();
				WebDr.SwitchToLatestWindow();
				WebDr.AccountNo = WebDr.getAccountNo();
				WebDr.alertHandlingForErrors("Loan Account has been generated with", "Check for alert message");
				// WebDr.SwitchToWindow(strFCRAppWindow);
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				if (!WebDr.AccountNo.isEmpty()) {
					HtmlReporter.WriteStep("Check for Loan Direct Account Opening",
							"User should be able to open Loan account using LN057",
							"User opened Loan account successfully using LN057 -" + WebDr.AccountNo, true);
				} else {
					HtmlReporter.WriteStep("Check for Loan Direct Account Opening",
							"User should be able to open Loan account using LN057",
							"User could not open Loan account successfully using LN057 ", false);
					Constant.blnFCRAppStatus = false;
				}
				System.out.println(WebDr.AccountNo);
			} else if (WebDr.strFCRCountry.equals("NBC") || WebDr.strFCRCountry.equals("BBK")
					|| WebDr.strFCRCountry.equals("BBM")) {
				String strtext = WebDr.returnTextOnAlertPopup("Verify alert message");
				// if (! WebDr.alertHandlingForErrors("Authorisation Pending",
				// "Check for alert message")){
				if (strtext.contains("Unauthorized")) {
					// To Do
					WebDr.alertClickWithText("Unauthorized");
					WebDr.click("LNM057Cancel",
							"Select Cancel radio button to cancel existing unauthorized record and re-enter data again");
					WebDr.clickwithmouse("Clear", "Click on Clear");
					WebDr.waitForPageLoaded();
					WebDr.selectDropValueByVisibleText("CustomerSearchCriteria", "Customer Id", "Enter Customer ID");
					WebDr.setText("CustomerInfo", WebDr.getValue("SearchString"), "Enter Search String");
					WebDr.rTab();
					WebDr.SwitchToLatestWindow();
					WebDr.SelectTopAcct();
					WebDr.rTab();
					// WebDr.SwitchToWindow(strFCRAppWindow);
					WebDr.SwitchToLatestWindow();
					WebDr.clickwithmouse("LN057Screen_OK",
							"Click on the OK button to cancel existing loan account record");
					WebDr.alertAccept();
					WebDr.waitForPageLoaded();
					///////////////////////////////////////////////////////////////////////////////////////////////////
					WebDr.click("LNM057Add", "Select Add radio button");
					WebDr.waitForPageLoaded();
					WebDr.selectDropValueByVisibleText("CustomerSearchCriteria", "Customer Id", "Enter Customer ID");
					WebDr.setText("CustomerInfo", WebDr.getValue("SearchString"), "Enter Search String");
					WebDr.rTab();
					WebDr.SwitchToLatestWindow();
					WebDr.SelectTopAcct();
					WebDr.SwitchToLatestWindow();
					WebDr.selectDropValueByVisibleText("BRANCH", WebDr.getValue("BranchName"), "Select Branch Name");
					WebDr.selectDropValueByVisibleText("CustomerRelation", WebDr.getValue("CustRelation"),
							"Select Customer Relation");
					WebDr.selectDropValueByVisibleText("Product", WebDr.getValue("ProductCode"), "Select Product");
					WebDr.setText("LoanPurpose", WebDr.getValue("LoanPurpose"), "Enter Loan Purpose");
					WebDr.setText("LoanTerm", WebDr.getValue("LoanTerm"), "Enter Loan Term");
					WebDr.rClearUpdateTextField("AssetValue", WebDr.getValue("AssetValue"), "Enter Asset Value");
					WebDr.rClearUpdateTextField("Contribution", WebDr.getValue("Contribution"), "Enter Contribution");
					WebDr.selectDropValueByVisibleText("RepayMode", WebDr.getValue("RepaymentMode"),
							"Select Repay Mode");
					WebDr.rClearUpdateTextField("InterestVariance", WebDr.getValue("InterestVariance"),
							"Enter Interest Variance");
					WebDr.rEnter();
					WebDr.SwitchToLatestWindow();
					WebDr.rTab();
					WebDr.rTab();
					WebDr.rDown();
					WebDr.rEnter();
					WebDr.SwitchToLatestWindow();
					WebDr.clickwithmouse("LN057Screen_OK", "Click on the OK button");
					if (!WebDr.alertHandlingForErrors("Authorisation Pending", "Check for alert message"))
						throw new Exception();
					///////////////////////////////////////////////////////////////////////////////////////////////////
				} else if (strtext.contains("Authorisation Pending")) {
					if (WebDr.isAlertPresent())
						WebDr.alertAccept();
					System.out.println(
							"Record is pending for authorization..................................................................");
				} else {
					throw new Exception();
				}
				// }

				LOAN.logout();
				WebDr.waitForPageLoaded();
				LOAN.superLogin();
				WebDr.waitForPageLoaded();

				pkgFCRPageObjects.FCR_LoanPageObjects.LN057_page();
				WebDr.fastPath(WebDr.getValue("FastPath"));
				WebDr.waitForPageLoaded();
				WebDr.click("LNM057Auth", "Select Authorise radio button");
				WebDr.waitForPageLoaded();
				if (WebDr.strFCRCountry.equals("BBK")) {
					WebDr.clickwithmouse("Clear", "Click on Clear");
					WebDr.waitForPageLoaded();
				}

				if (WebDr.strFCRCountry.equals("NBC") || WebDr.strFCRCountry.equals("BBK")
						|| WebDr.strFCRCountry.equals("BBM")) {
					WebDr.selectDropValueByVisibleText("CustomerSearchCriteria", "Customer Id", "Enter Customer ID");
					WebDr.setText("CustomerInfo", WebDr.getValue("SearchString"), "Enter Search String");
					WebDr.rTab();
					WebDr.SwitchToLatestWindow();
					WebDr.SelectTopAcct();
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					// WebDr.SwitchToWindow(strFCRAppWindow);
					WebDr.SwitchToLatestWindow();
				}
				WebDr.click("FastPath", "Click in fastpath testfield");
				WebDr.clickwithmouse("LN057Screen_OK", "Click on the OK button");
				WebDr.waitForPageLoaded();
				// WebDr.SwitchToLatestAlertCheck("Record Authorized");
				WebDr.alertHandlingForErrors("Record Authorized", "Verify alert message");
				WebDr.AccountNo = WebDr.getAccountNo();
				WebDr.alertAccept();
				// WebDr.SwitchToWindow(strFCRAppWindow);
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				if (!WebDr.AccountNo.isEmpty()) {
					HtmlReporter.WriteStep("Check for Loan Direct Account Opening",
							"User should be able to open Loan account using LN057",
							"User opened Loan account successfully using LN057 -" + WebDr.AccountNo, true);
					WebDr.alertAccept();
					WebDr.waitForPageLoaded();
				} else {
					HtmlReporter.WriteStep("Check for Loan Direct Account Opening",
							"User should be able to open Loan account using LN057",
							"User could not open Loan account successfully using LN057 ", false);
					Constant.blnFCRAppStatus = false;
				}
				System.out.println(WebDr.AccountNo);
				LOAN.logout();
				WebDr.waitForPageLoaded();
				LOAN.login();
			}
		} catch (Exception exc) {
			HtmlReporter.WriteStep("Check for Loan Direct Account Opening",
					"User should be able to open Loan account using LN057", exc.getMessage(), false);
			exc.printStackTrace();
			LOAN.logout();
			WebDr.waitForPageLoaded();
			LOAN.login();
		}
	}

	public static void loanDocMaintenence_LN323() throws Exception {
		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.LN323_page();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.waitForElement("AccountNO");

			if (WebDr.AccountNo.isEmpty()) {
				WebDr.AccountNo = WebDr.getValue("LoanAccount");
			} else {
				WebDr.setText("AccountNO", WebDr.AccountNo, "Enter Loan Account Number");
			}
			WebDr.rTab();
			WebDr.alertAccept();
			WebDr.alertAccept();
			WebElement wbDocs = Driver.driver.findElement(By.xpath(".//table[@id='grdDocDetails']/tbody"));
			List obCellDatatr = wbDocs.findElements(By.tagName("tr"));
			int introws = obCellDatatr.size();
			// List intCellData =
			// Driver.driver.findElements(By.xpath(".//table[@id='grdDocDetails']//tr//td[@class='TGridURL']"));
			System.out.println("-------------------row count" + introws);
			for (int i = 1; i <= introws; i++) {
				WebDr.waitForPageLoaded();
				Driver.driver
						.findElement(By.xpath(".//table[@id='grdDocDetails']//tr[" + i + "]//td[@class='TGridURL']"))
						.click();
				WebDr.r.keyPress(KeyEvent.VK_R);
				WebDr.r.keyRelease(KeyEvent.VK_R);
				WebDr.rTab();
			}
			WebDr.clickwithmouse("LN323Screen_OK", "Click on the OK button");
			WebDr.authOnlyCreds();
			WebDr.waitForPageLoaded();
			// WebDr.alertAccept();
			WebDr.SwitchToLatestWindow();
			WebDr.alertHandlingForErrors("Record modified", "Check for alert message");
			HtmlReporter.WriteStep("Check the Document maintainance in LN323.",
					"User should be able to maintain all the documents in LN323.",
					"User is able to maintain all the documents in LN323 for loan account  - " + WebDr.AccountNo, true);
		} catch (Exception exc) {
			HtmlReporter.WriteStep("Check the Document maintainance in LN323.",
					"User should be able to maintain all the documents in LN323.",
					"User is not able to maintain all the documents in LN323 for loan account  - " + WebDr.AccountNo,
					false);
		}
	}

	public static void loanPayInst_LNM31_Add() throws Exception {
		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.LNM31_page();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			// WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("LNM31MntTool", "Click on the Add radio button");

			if (!(WebDr.AccountNo.isEmpty())) {
				WebDr.setText("LoanAccountNO", WebDr.AccountNo, "Enter Loan Account Number");
				
			} else {
				
				WebDr.AccountNo = WebDr.getValue("LoanAccount");
				WebDr.setText("LoanAccountNO", WebDr.AccountNo, "Enter Loan Account Number");
			}
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("ArrearType", WebDr.getValue("ArrearType"), "Enter Arrear Type");
			WebDr.setText("CASAAccountNO", WebDr.getValue("CASANumber"), "Enter CASA account number");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.click("FastPath", "Click in the field");
			WebDr.click("LNM31Screen_OK", "Click on the OK button");
			// WebDr.alertAccept();
			if (WebDr.isAlertPresent())
				WebDr.alertHandlingForErrors("Authorisation Pending", "Check for alert message");
			WebDr.click("FastPath", "Click in the field");
			WebDr.click("LNM31_Close", "Click on the CLOSE button");

			if (WebDr.strFCRCountry.equals("UG")) {
				LOAN.logout();
				WebDr.waitForPageLoaded();
				LOAN.superLogin();
				WebDr.waitForPageLoaded();
				pkgFCRPageObjects.FCR_LoanPageObjects.LNM31_page();
				WebDr.fastPath(WebDr.getValue("FastPath"));
				WebDr.waitForPageLoaded();
				WebDr.click("LNM31AuthMntTool", "");
				WebDr.setText("AuthLoanAccountNO", WebDr.AccountNo, "Click on the Authorize radio button");
				WebDr.rTab();
				WebDr.click("PickList", "Click on the account number picklist");
				WebDr.SelectTopAcct();
				// WebDr.SwitchToWindow(strFCRAppWindow);
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				WebDr.click("AuthLoanAccountNO", "Click in the field Loan Account Number");
				WebDr.waitForPageLoaded();
				WebDr.click("AuthLoanAccountNO", "Click in the field Loan Account Number");
				WebDr.click("LNM31Screen_Authorize_OK", "Click on the OK button");
				HtmlReporter.WriteStep("Check whether the user is able to Link Loan and CASA account in LNM31 or not.",
						"User should be able to Link Loan and CASA account in LNM31.", "User linked Link Loan account "
								+ WebDr.AccountNo + " and CASA account -" + WebDr.getValue("CASANumber"),
						true);
				WebDr.alertAccept();
				LOAN.logout();
				LOAN.login();
			} else if (WebDr.strFCRCountry.equals("NBC") || WebDr.strFCRCountry.equals("BBM")
					|| WebDr.strFCRCountry.equals("BBK")) {
				LOAN.logout();
				WebDr.waitForPageLoaded();
				LOAN.launch();
				WebDr.waitForPageLoaded();
				LOAN.superLogin();
				WebDr.waitForPageLoaded();
				pkgFCRPageObjects.FCR_LoanPageObjects.LNM31_page();
				WebDr.fastPath(WebDr.getValue("FastPath"));
				WebDr.waitForPageLoaded();
				WebDr.click("LNM31AuthMntTool", "Click on Authorise radio button");
				WebDr.setText("AuthLoanAccountNO", WebDr.AccountNo, "Click on the Authorize radio button");
				WebDr.rTab();
				WebDr.click("PickList", "Click on the account number picklist");
				WebDr.SelectTopAcct();
				// WebDr.SwitchToWindow(strFCRAppWindow);
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				// WebDr.clickactivatewithmouse("CustName", "Click on field");
				// WebDr.click("AuthLoanAccountNO", "Click in the field Loan
				// Account Number");
				// WebDr.waitForPageLoaded();
				// WebDr.click("FastPath", "Click in the FastPath field");
				// WebDr.click("LNM31Screen_Authorize_OK","Click on the OK
				// button");
				WebDr.clickAlwaysImageSikuli("OKAuthLNM31.PNG", 10, "Click on the OK button");
				WebDr.SwitchToLatestAlertCheck("Record Authorized");
				WebDr.alertHandlingForErrors("Record Authorized", "Verify alert message");
				// WebDr.alertHandlingForErrors("Record Authorized", "Verify
				// alert message");
				// WebDr.click("FastPath", "Click in the field");
				// WebDr.click("LNM31_Close","Click on the CLOSE button");
				HtmlReporter.WriteStep("Check whether the user is able to Link Loan and CASA account in LNM31 or not.",
						"User should be able to Link Loan and CASA account in LNM31.", "User linked Link Loan account "
								+ WebDr.AccountNo + " and CASA account -" + WebDr.getValue("CASANumber"),
						true);

				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				LOAN.logoutwithJSCommand(false);
				WebDr.waitForPageLoaded();
				LOAN.launch();
				WebDr.waitForPageLoaded();
				LOAN.login();
			}
		} catch (Exception exc) {
			exc.printStackTrace();
			HtmlReporter.WriteStep("Check whether the user is able to Link Loan and CASA account in LNM31 or not.",
					"User should be able to Link Loan and CASA account in LNM31.",
					"User could not link Link Loan account " + WebDr.AccountNo + " and CASA account -"
							+ WebDr.getValue("CASANumber"),
					false);
		}
	}

	public static void loanAcctSchedule_LN521() throws Exception {
		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.LN521_page();
			WebDr.fastPath(WebDr.getValue("FastPath"));

			if (!(WebDr.AccountNo.isEmpty())) {
				WebDr.setText("LoanAccountNO", WebDr.AccountNo, "Enter Loan Account Number");
				
			} else {
				
				WebDr.AccountNo = WebDr.getValue("LoanAccount");
				WebDr.setText("LoanAccountNO", WebDr.AccountNo, "Enter Loan Account Number");
			}
			// WebDr.setText("LoanAccountNO", "6000105218", "");
			WebDr.rTab();
			WebDr.alertAccept();
			WebDr.click("Disbursement", "Click on the Disbursement");
			WebDr.selectDropValueByVisibleText("DisbursementMode", WebDr.getValue("DisbursMode"),
					"Select Disbursement Mode");
			WebDr.rClearUpdateTextField("DisbursementAmount", WebDr.getValue("DisbursAmount"),
					"Enter Disbursement Value");
			// WebDr.setText("DisbursementAmount",
			// WebDr.getValue("DisbursAmount"), "Enter Disbursement Amount");
			// WebDr.selectDropValueByVisibleText("DisbursementReason",
			// "OTHERS", "Select Disbursement Reason");
			WebDr.selectDropValueByVisibleText("DisbursementReason", WebDr.getValue("Reason"),
					"Select Disbursement Reason");
			WebDr.setText("DisbursementReasonDescription", WebDr.getValue("Reason"),
					"Enter Disbursement Reason Description");
			WebDr.click("DeductionDetails", "Click on the Deduction Details");
			WebDr.click("DeductionOK", "Click on the Deduction OK");
			WebDr.click("ComputeSchedule", "Click on the Compute Schedule");
			WebDr.click("ValidateSchedule", "Click on the Validate Schedule");
			WebDr.waitForPageLoaded();
			WebDr.click("GenerateSchedule", "Click on the Generate Schedule");
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("LN521Screen_OK", "Click on the OK button");
			//WebDr.alertAccept();

			if (WebDr.strFCRCountry.equals("BBK")) {
				LOAN.logoutwithJSCommand(false);
				WebDr.waitForPageLoaded();
				LOAN.launch();
				WebDr.waitForPageLoaded();
				LOAN.superLogin();
				WebDr.waitForPageLoaded();
				pkgFCRPageObjects.FCR_LoanPageObjects.LN521_page();
				WebDr.fastPath(WebDr.getValue("FastPath"));
				WebDr.waitForPageLoaded();
				WebDr.clickwithmouse("LoanAuth", "Click on the Add Radio Button");
				WebDr.setText("LoanAccountNO", WebDr.AccountNo, "Enter the Loan Account Number");
				WebDr.rTab();
				WebDr.clickwithmouse("LN521Screen_OK", "Click on the OK button");
				WebDr.alertAccept();
			}

			else {
				WebDr.authOnlyCreds();
				
			}
			if (WebDr.alertHandlingForErrors("Disbursement Successful", "Verify disbursement")) {
				HtmlReporter.WriteStep("Check the Loan Disbursment and schedule in LN521.",
						"User should be able to generate Disbursment and schedule in LN521.",
						"User is able to generate Disbursment and schedule in LN521 for loan account - "
								+ WebDr.AccountNo,
						true);
				System.out.println("LN521 successful");
				
			} else {
				HtmlReporter.WriteStep("Check the Loan Disbursment and schedule in LN521.",
						"User should be able to generate Disbursment and schedule in LN521.",
						"User is not able to generate Disbursment and schedule in LN521 for loan account - "
								+ WebDr.AccountNo,
						false);
				System.out.println("LN521 unsuccessful");
				
			}
			WebDr.waitForPageLoaded();
			WebDr.alertCancel();
		} catch (Exception exc) {
			HtmlReporter.WriteStep("Check the Loan Disbursment and schedule in LN521.",
					"User should be able to generate Disbursment and schedule in LN521.",
					"User could not generate Disbursment and schedule in LN521 for loan account - " + WebDr.AccountNo,
					false);
			exc.printStackTrace();
		}
	}

	public static void loanDisburse_1413() throws Exception {
		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.LN1413_page();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.SwitchToLatestWindow();
			WebDr.waitForPageLoaded();
			WebDr.setText("LoanAccountNO", WebDr.getValue("CASANumber"), "Enter Loan Account NO");
			// WebDr.setText("LoanAccountNO", WebDr.AccountNo, "Enter Loan
			// Account NO");
			// WebDr.setText("LoanAccountNO", "6000112923", "Enter Loan Account
			// NO");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("DisbursementMode", WebDr.getValue("DisbursMode"),
					"Select Disbursement Mode");
			WebDr.clickwithmouse("1413Screen_OK", "Click on the OK button");
			WebDr.alertAccept();
			WebDr.waitForPageLoaded();
			WebDr.setText("AccountNumber", WebDr.getValue("CASANumber"), "Enter Account Number");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.click("UserRefNumber", "Enter User Ref Number");
			WebDr.setText("UserRefNumber", WebDr.getValue("UserRef"), "Enter User Ref Number");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.getTextBoxValue("DisbursementAMT", "Get Disbursement Amount");
			WebDr.clickwithmouse("1413Screen_OK", "Click on the OK button");

			// WebDr.authWithComment();
			WebDr.authWithCommentOnlyOnce();

			// if (WebDr.SwitchToLatestAlertCheck("Transaction sequence number
			// is"))
			if (WebDr.clickAlwaysImageSikuli("SignImageSuccessOK.PNG", 20, "Click on alert message"))
				HtmlReporter.WriteStep(
						"Check if the Loan disbursement inquiry can be done using 1413 option by selecting Disbursement Mode",
						"User should be allowed to perform loan disbursement inquiry using 1413 option",
						"User is allowed to perform loan disbursement inquiry using 1413 option for loan account - "
								+ WebDr.AccountNo,
						true);
			else
				HtmlReporter.WriteStep(
						"Check if the Loan disbursement inquiry can be done using 1413 option by selecting Disbursement Mode",
						"User should be allowed to perform loan disbursement inquiry using 1413 option",
						"User is not allowed to perform loan disbursement inquiry using 1413 option for loan account - "
								+ WebDr.AccountNo,
						false);

			WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
			WebDr.SwitchToLatestWindow();
		} catch (Exception exc) {
			exc.printStackTrace();
			HtmlReporter.WriteStep(
					"Check if the Loan disbursement inquiry can be done using 1413 option by selecting Disbursement Mode",
					"User should be allowed to perform loan disbursement inquiry using 1413 option",
					"User could not allow to perform loan disbursement inquiry using 1413 option for loan account - "
							+ WebDr.AccountNo,
					false);
		}
	}

	public static void loanBalanceEnq_7026() throws Exception {
		String strloanacc;
		if (!WebDr.AccountNo.isEmpty()) {
			strloanacc = WebDr.AccountNo;
		} else {
			strloanacc = WebDr.getValue("LoanAccountNO");
		}
		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.LN7026_page();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			// WebDr.setText("LoanAccountNO", WebDr.getValue("LoanAccountNO"),
			// "Enter Loan Account NO");
			WebDr.setText("LoanAccountNO", strloanacc, "Enter Loan Account NO");
			// WebDr.setText("LoanAccountNO", "6000112613", "Enter Loan Account
			// NO");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.clickactivatewithmouse("LoanBalanceAmt", "Click on Loan Balance field");
			WebDr.waitForPageLoaded();
			WebDr.waitForElement("LoanBalanceAmt");
			WebDr.getTextBoxValue("OutstandingBalanceAmt", "Get Outstanding Loan balance");
			WebDr.getTextBoxValue("UnclearAmt", "Get Unclear balance");
			WebDr.getTextBoxValue("PrincipalAmt", "Get Principal balance");

			String strLoanBal = WebDr.getTextBoxValue("LoanBalanceAmt", "Get Loan balance");
			if (strLoanBal != "")
				HtmlReporter.WriteStep("Check if the Loan balance can be inquired using 7026 option",
						"Loan balance should be inquired successfully using 7026",
						"Loan balance inquiry is performed successfully using 7026. Loan balance - " + strLoanBal,
						true);
			else
				HtmlReporter.WriteStep("Check if the Loan balance can be inquired using 7026 option",
						"Loan balance should be inquired successfully using 7026",
						"Loan balance inquiry is performed successfully using 7026. Loan balance - " + strLoanBal,
						false);

		} catch (Exception exc) {
			exc.printStackTrace();
			HtmlReporter.WriteStep("Check if the Loan balance can be inquired using 7026 option",
					"Loan balance should be inquired successfully using 7026",
					"Loan balance inquiry could not be performed successfully using 7026", false);
		}
	}

	public static void loanAccountTransactions_LNM10() throws Exception {
		String strloanacc;
		if (!WebDr.AccountNo.isEmpty()) {
			strloanacc = WebDr.AccountNo;
		} else {
			strloanacc = WebDr.getValue("LoanNumber");
		}
		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.LNM10_page();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.setText("LoanAccountNO", strloanacc, "Enter Loan Account NO");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.click("LoanAccountInqRadio", "Click on Account Details");
			WebDr.waitForPageLoaded();
			String strLoanAppl = WebDr.getTextBoxValue("LoanApplNumber", "Get Loan application number");
			if (strLoanAppl != "")
				HtmlReporter.WriteStep("Check if the user can inquire for Loan account transactions using LNM10",
						"Loan account transactions should be inquired successfully using LNM10",
						"Loan account transactions inquiry is performed successfully", true);
			else
				HtmlReporter.WriteStep("Check if the user can inquire for Loan account transactions using LNM10",
						"Loan account transactions should be inquired successfully using LNM10",
						"Loan account transactions inquiry is performed successfully", false);
			WebDr.click("Close", "Click on Close");
		} catch (Exception exc) {
			exc.printStackTrace();
			HtmlReporter.WriteStep("Check if the user can inquire for Loan account transactions using LNM10",
					"Loan account transactions should be inquired successfully using LNM10",
					"Loan account transactions inquiry could not be performed successfully using LNM10", false);
		}
	}

	public static void loanFullAccountDetails_Inquiry_LNM10() throws Exception {
		String strloanacc;
		if (!WebDr.AccountNo.isEmpty()) {
			strloanacc = WebDr.AccountNo;
		} else {
			strloanacc = WebDr.getValue("LoanNumber");
		}
		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.LNM10_page();

			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.setText("LoanAccountNO", strloanacc, "Enter Loan Account NO");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.click("Transactions", "Click on Account Details");
			WebDr.waitForPageLoaded();
			HtmlReporter.WriteStep(
					"Check if the user can inquire for Loan account-" + strloanacc + " transactions using LNM10",
					"Loan account transactions should be inquired successfully using LNM10",
					"Loan account transactions inquiry is performed successfully", true);

			// WebDr.click("TxnDetails", "Click on Txn Details");
			// WebDr.waitForPageLoaded();
			// HtmlReporter.WriteStep("Check if the user can inquire for Txn
			// Details Loan account transactions using LNM10","Loan account Txn
			// Details should be inquired successfully using LNM10","Loan
			// account Txn Details inquiry is performed successfully",true);

			WebDr.click("InterestDetails", "Click on Interest Details");
			WebDr.waitForPageLoaded();
			HtmlReporter.WriteStep("Check if the user can inquire for Loan account Interest Details using LNM10",
					"Loan account Interest Details should be inquired successfully using LNM10",
					"Loan account Interest Details inquiry is performed successfully", true);

			WebDr.click("AccountDetails", "Click on Account Details");
			WebDr.waitForPageLoaded();
			HtmlReporter.WriteStep("Check if the user can inquire for Loan account Account Details using LNM10",
					"Loan account Account Details should be inquired successfully using LNM10",
					"Loan account Account Details inquiry is performed successfully", true);

			WebDr.click("ArrearTotals", "Click on Arrear Totals Details");
			WebDr.waitForPageLoaded();
			HtmlReporter.WriteStep("Check if the user can inquire for Loan account Arrear Totals using LNM10",
					"Loan account Arrear Totals should be inquired successfully using LNM10",
					"Loan account Arrear Totals inquiry is performed successfully", true);

			WebDr.click("ArrearTxns", "Click on Arrear Txns Details");
			WebDr.waitForPageLoaded();
			HtmlReporter.WriteStep("Check if the user can inquire for Loan account Arrear Txns using LNM10",
					"Loan account Arrear Txns should be inquired successfully using LNM10",
					"Loan account Arrear Txns inquiry is performed successfully", true);

			WebDr.click("Close", "Click on Close");
		} catch (Exception exc) {
			exc.printStackTrace();
			HtmlReporter.WriteStep(
					"Check if the user can inquire for Loan account-" + strloanacc + " transactions using LNM10",
					"Loan account transactions should be inquired successfully using LNM10",
					"Loan account transactions inquiry could not be performed successfully using LNM10", false);
		}
	}

	public static void LoanInstallmentInquiry_1065() throws Exception {
		try {
			// TODO Auto-generated method stub
			pkgFCRPageObjects.FCR_LoanPageObjects.LoanInstallmentInquiry_1065();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.setText("LoanAccountNO", WebDr.getValue("LoanNumber"), "Enter Loan Account NO");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("InstallMode", WebDr.getValue("InstallMode"), "Select Install Mode");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("OK", "Click on OK button");
			WebDr.waitForPageLoaded();
			if (WebDr.strFCRCountry.equals("NBC")) {
				WebDr.authWithComment();
			}
			WebDr.alertHandlingForErrors("Want to continue", "Verify alert message");
			WebDr.getTextBoxValue("AmtDue", "Due Amount ");
			WebDr.getTextBoxValue("AmtBal", "Prinicipal Amount Balance ");
			WebDr.getTextBoxValue("InstArrears", "Installment Arrears ");
			HtmlReporter.WriteStep(
					"Check if the Loan Installment Payment inquiry can be done for the valid loan account using 1065",
					"User should be able to perform Loan Installment Payment inquiry using 1065",
					"Loan Installment Payment inquiry performed successfully", true);
			WebDr.clickwithmouse("Cancel", "Click on cancel button");
		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep(
					"Check if the Loan Installment Payment inquiry can be done for the valid loan account using 1065",
					"User should be able to perform Loan Installment Payment inquiry using 1065",
					"Loan Installment Payment inquiry could not be performed successfully", false);
		}
	}

	public static void LoanFullPaymentInquiry_1067() throws Exception {
		// TODO Auto-generated method stub
		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.LoanFullPaymentInquiry_1067();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.setText("LoanAccountNO", WebDr.getValue("LoanNumber"), "Enter Loan Account NO");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("PenaltyMethod", WebDr.getValue("PenaltyMethod"),
					"Select Penalty Method");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("SettleMode", WebDr.getValue("SettleMode"), "Select Settle Mode");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.click("LoanAccountNO", "Click in field");
			WebDr.clickwithmouse("OK", "Click on OK button");
			if (WebDr.strFCRCountry.equals("NBC")) {
				WebDr.authWithComment();
			}
			WebDr.alertHandlingForErrors("Want to continue", "Verify alert message");
			WebDr.waitForPageLoaded();
			String balance = WebDr.getTextBoxValue("ACY_Amount", "EFS Amount ");
			HtmlReporter.WriteStep(
					"Check if the Loan full Payment inquiry can be done for the valid loan account using 1067",
					"User should be able to perform full Loan Payment inquiry for the valid loan account using 1067",
					"Loan Payment inquiry performed successfully. <br>Current EFS amount is " + balance, true);
			WebDr.clickwithmouse("Cancel", "Click on cancel button");
		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep(
					"Check if the Loan full Payment inquiry can be done for the valid loan account using 1067",
					"User should be able to perform full Loan Payment inquiry for the valid loan account using 1067",
					"Loan Payment inquiry could not be performed successfully", false);
		}
	}

	public static void LoanAccountRates_LNM83() throws Exception {
		// TODO Auto-generated method stub
		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.LoanAccountRates_LNM83();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.click("LNM83Inquiry", "Click on Inquiry");
			WebDr.waitForPageLoaded();
			WebDr.setText("LoanAccountNO", WebDr.getValue("LoanNumber"), "Enter Loan Account NO");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.click("RatePlan", "Click on Rate Plan");
			WebDr.SwitchToLatestWindow();
			WebDr.rTab();
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.SwitchToLatestWindow();
			WebDr.click("Details", "Click on Details");
			WebDr.waitForPageLoaded();
			WebDr.click("RateRevision", "Click on Rate Revision");
			WebDr.waitForPageLoaded();
			HtmlReporter.WriteStep("Check account rates in LNM83 option",
					"User should be able to inquire for the account rates in LNM83 option",
					"User inquired for the account rates in LNM83 option", true);
			WebDr.clickwithmouse("Close", "Click on close button");
		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Check account rates in LNM83 option",
					"User should be able to inquire for the account rates in LNM83 option",
					"User could not inquire for the account rates in LNM83 option", false);
			WebDr.SwitchToLatestWindow();
		}
	}

	public static void LoanAccountAttributes_Inquiry_LNM35() throws Exception {
		// TODO Auto-generated method stub
		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.LoanAccountAttributes_LNM35();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.click("LoanInquiry", "Click on Inquiry");
			WebDr.waitForPageLoaded();
			WebDr.setText("LoanAccountNO", WebDr.getValue("LoanNumber"), "Enter Loan Account NO");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			if (WebDr.isElementExist("DateMgr", "Verify field")) {
				String name = WebDr.getTextBoxValue("DateMgr", "Date of Migration- ");
				if (name.isEmpty()) {
					throw new Exception();
				}
			}
			WebDr.click("LoanAttributes", "Click on Loan Attributes");
			WebDr.waitForPageLoaded();

			if (WebDr.isElementExist("DateMgr", "Verify field")) {
				WebDr.getTextBoxValue("DateMgr", "Date of Migration- ");
			}

			HtmlReporter.WriteStep("Check for Loan Account Attributes",
					"User should be able to check loan account attributes using LNM35 screen",
					"User inquired for the loan account attributes in LNM35 option", true);
			WebDr.clickwithmouse("Close", "Click on close button");
		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Check for Loan Account Attributes",
					"User should be able to check loan account attributes using LNM35 screen",
					"User could not inquire for the loan account attributes in LNM35 option", false);
			WebDr.SwitchToLatestWindow();
		}
	}

	public static void LOAN_Product_Master_Inquiry_LNM11() throws Exception {
		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.LoanProductMaster_LNM11();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();

			WebDr.clickwithmouse("LoanInquiry", "Click on the Inquiry Radio Button");
			WebDr.alertAccept();

			WebDr.waitForElement("LoanProd");
			WebDr.setText("LoanProd", WebDr.getValue("LoanProd"), "Enter Loan Prod");
			WebDr.rTab();
			WebDr.waitForPageLoaded();

			String name = WebDr.getTextBoxValue("LoanProdName", "Loan Prod Name");

			if (!name.isEmpty()) {
				HtmlReporter.WriteStep(
						"Check whether the user is able to inquire about the valid product or not in LNM11.",
						"User should be able to inquire about the existing products in the screen LNM11.",
						"User is able to inquire about the existing products in the screen LNM11.", true);
			} else {
				HtmlReporter.WriteStep(
						"Check whether the user is able to inquire about the valid product or not in LNM11.",
						"User should be able to inquire about the existing products in the screen LNM11.",
						"User is not able to inquire about the existing products in the screen LNM11.", false);
			}

		} catch (Exception e) {
			HtmlReporter.WriteStep("Check whether the user is able to inquire about the valid product or not in LNM11.",
					"User should be able to inquire about the existing products in the screen LNM11.",
					"Error occured during  inquiry of  product code in LNM11." + e.getMessage(), false);
		}

	}

	public static void LOAN_Product_RatePlan_Inquiry_LN060() throws Exception {
		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.LOANProductRatePlanInquiry_LN060();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();

			WebDr.clickwithmouse("LoanInquiry", "Click on the Inquiry Radio Button");
			WebDr.clickwithmouse("Clear", "Clear fields");

			WebDr.waitForElement("LoanRateID");
			WebDr.setText("LoanRateID", WebDr.getValue("LoanRatePlan"), "Enter LoanRateID");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.SwitchToLatestWindow();
			WebDr.waitForPageLoaded();
			WebDr.SelectTopAcct();
			WebDr.SwitchToLatestWindow();
			WebDr.waitForPageLoaded();

			String name = WebDr.getTextBoxValue("LoanPlanName", "Loan Plan Name");

			if (!name.isEmpty()) {
				HtmlReporter.WriteStep(
						"Check whether the user is able to inquire about the valid rate plan or not in LN060.",
						"User should be able to inquire about the existing rate plans in the screen LN060.",
						"User is able to inquire about the existing rate plans in the screen LN060.", true);
			} else {
				HtmlReporter.WriteStep(
						"Check whether the user is able to inquire about the valid rate plan or not in LN060.",
						"User should be able to inquire about the existing rate plans in the screen LN060.",
						"User is not able to inquire about the existing rate plans in the screen LN060.", false);
			}

		} catch (Exception e) {
			HtmlReporter.WriteStep(
					"Check whether the user is able to inquire about the valid rate plan or not in LN060.",
					"User should be able to inquire about the existing rate plans in the screen LN060.",
					"Error occured during  inquiry of  rate plan code in LN060." + e.getMessage(), false);
		}
	}

	public static void LOAN_Product_RatePlan_Add_LN060() throws Exception {
		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.LOANProductRatePlanInquiry_LN060();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("LoanAdd", "Click on the Add Radio Button");
			WebDr.waitForPageLoaded();
			WebDr.setText("LoanRateID", WebDr.getValue("LoanRateID"), "Enter Loan Rate ID");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.setText("LoanPlanName", WebDr.getValue("LoanPlanName"), "Enter Loan Plan Name");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			if (WebDr.strFCRCountry.equals("BBK")) {
				WebDr.setText("EffectiveDate", WebDr.getValue("EffectiveDate"), "Enter Effective Date");
				WebDr.waitForPageLoaded();
			}
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("LoanRateType", "Regular", "Select Rate Type");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("SlabDefinition", "Non Tiered", "Select Slab Definition");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("RateDefinition", "Fixed Rate", "Select Rate Definition");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("DetailsTab", "Click on the Details Tab");
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("OK", "Click on OK");
			WebDr.waitForPageLoaded();
			if (WebDr.isAlertPresent())
				WebDr.alertHandlingForErrors("Record Added", "Verify alert message");
			LOAN.logout();
			LOAN.superLogin();
			HtmlReporter.WriteStep(
					"Check whether the user is able to add new rate for an existing product code or not.",
					"User should be able to add new rate for an existing product code.",
					"New Rate Addition successful.", true);

		} catch (Exception e) {
			HtmlReporter.WriteStep(
					"Check whether the user is able to add new rate for an existing product code or not.",
					"User should be able to add new rate for an existing product code.",
					"New Rate Addition successful." + e.getMessage(), false);
			LOAN.logout();
			LOAN.superLogin();
		}

		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.LOANProductRatePlanInquiry_LN060();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("LoanAuth", "Click on authorize button");
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("Clear", "Clear fields");
			WebDr.waitForPageLoaded();
			WebDr.setText("LoanRateID", WebDr.getValue("LoanRateID"), "Enter Loan Rate ID");
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.SwitchToLatestWindow();
			WebDr.rTab();
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.SwitchToLatestWindow();
			WebDr.clickwithmouse("OK", "Click on OK");
			WebDr.waitForPageLoaded();
			if (WebDr.isAlertPresent())
				WebDr.alertHandlingForErrors("Record Authorized", "Verify alert message");
			LOAN.logout();
			LOAN.login();
			HtmlReporter.WriteStep(
					"Check whether the user is able to add new rate for an existing product code or not.",
					"User should be able to add new rate for an existing product code.",
					"New Rate Addition successful.", true);

		} catch (Exception e) {
			HtmlReporter.WriteStep(
					"Check whether the user is able to add new rate for an existing product code or not.",
					"User should be able to add new rate for an existing product code.",
					"New Rate Addition successful." + e.getMessage(), false);
			LOAN.logout();
			LOAN.login();
		}
	}

	public static void LOAN_Product_RatePlan_Modify_LN060() throws Exception {
		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.LOANProductRatePlanInquiry_LN060();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("LoanModify", "Click on the Modify Radio Button");
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("Clear", "Clear fields");
			WebDr.waitForPageLoaded();
			WebDr.setText("LoanRateID", WebDr.getValue("LoanRateID"), "Enter Loan Rate ID");
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.SwitchToLatestWindow();
			WebDr.rTab();
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.SwitchToLatestWindow();
			WebDr.clearMethod("NewEffectiveDate");
			WebDr.waitForPageLoaded();
			WebDr.setText("NewEffectiveDate", WebDr.getValue("NewEffectiveDate"), "Enter Effective Date");
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("OK", "Click on OK");
			if (WebDr.isAlertPresent())
				WebDr.alertHandlingForErrors("Record Modified", "Verify alert message");
			LOAN.logout();
			LOAN.superLogin();
			HtmlReporter.WriteStep(
					"Check whether the user is able to add new rate for an existing product code or not.",
					"User should be able to add new rate for an existing product code.",
					"New Rate Addition successful.", true);
		} catch (Exception e) {
			HtmlReporter.WriteStep(
					"Check whether the user is able to add new rate for an existing product code or not.",
					"User should be able to add new rate for an existing product code.",
					"New Rate Addition successful." + e.getMessage(), false);
			LOAN.logout();
			LOAN.superLogin();
		}

		try {
			pkgFCRPageObjects.FCR_LoanPageObjects.LOANProductRatePlanInquiry_LN060();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("LoanAuth", "Click on authorize button");
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("Clear", "Clear fields");
			WebDr.waitForPageLoaded();
			WebDr.setText("LoanRateID", WebDr.getValue("LoanRateID"), "Enter Loan Rate ID");
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.SwitchToLatestWindow();
			WebDr.rTab();
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.SwitchToLatestWindow();
			WebDr.clickwithmouse("OK", "Click on OK");
			WebDr.waitForPageLoaded();
			if (WebDr.isAlertPresent())
				WebDr.alertHandlingForErrors("Record Authorized", "Verify alert message");
			LOAN.logout();
			LOAN.login();
			HtmlReporter.WriteStep(
					"Check whether the user is able to add new rate for an existing product code or not.",
					"User should be able to add new rate for an existing product code.",
					"New Rate Addition successful.", true);

		} catch (Exception e) {
			HtmlReporter.WriteStep(
					"Check whether the user is able to add new rate for an existing product code or not.",
					"User should be able to add new rate for an existing product code.",
					"New Rate Addition successful." + e.getMessage(), false);
			LOAN.logout();
			LOAN.login();
		}
	}
}
