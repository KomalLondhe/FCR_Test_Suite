package pkgFCRResuableModule;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.By;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;

import testCases.Driver;
import utility.Constant;
import utility.HtmlReporter;
import utility.WebDr;


public class Clearing extends Driver{
	
	public static String AccountNo = "";
	public static String PassedChequeNo = "";
	public static String FailedChequeNo = "";
	public static String ChequeNo = "";
	public static boolean CH031Entry = false;
	public static boolean GLM04Entry = false;
	

	public static void InwardClearing_5521() throws Exception {
		try {
			// Enter_Details
			pkgFCRPageObjects.FCR_ClearingPageObjects.InwardClearing_5521();				
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("Action",
					WebDr.getValue("Action"), "Select Action");
			String BatchNo = WebDr.getTextBoxValue("Batch_number", "Get Batch NUmber");
			String BatchStatus = WebDr.getTextBoxValue("Batch_Status", "Get batch status");
			System.out.println(BatchNo + "," + BatchStatus);
			WebDr.selectDropValueByVisibleText("EndPoint",
					WebDr.getValue("EndPoint"), "Select EndPoint");
			WebDr.selectDropValueByVisibleText("Currency",
					WebDr.getValue("Currency"), "Select Currency");
			WebDr.setText("Cheque_Count", WebDr.getValue("Cheque_Count"), "Enter Number of Cheque");
			
			WebDr.selectDropValueByVisibleText("Clearing_Type",
					WebDr.getValue("Clearing_Type"), "Select Clearing Type");
			WebDr.click("OK_5521", "Click on OK");
			WebDr.waitForPageLoaded();
			//WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.keyboard(WebDr.getValue("AccountNo"));
			WebDr.rTab();
			WebDr.rTab();
			WebDr.keyboard(WebDr.getValue("Cheque_No"));
			WebDr.rTab();
			WebDr.keyboard(WebDr.getValue("Amount"));
			WebDr.rTab();
			WebDr.keyboard(WebDr.getValue("PayeeName"));
			WebDr.rTab();
			WebDr.keyboard(WebDr.getValue("Payee_RoutingNo"));
			Clearing.AccountNo =  WebDr.getValue("AccountNo");
			Clearing.ChequeNo =  WebDr.getValue("Cheque_No");
			/*WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
			WebDr.rTab();
			//WebDr.rClearUpdateTextField("Cheque_Routing_No", WebDr.getValue("Cheque_Routing_No"), "Enter Cheque Routing Number");
			WebDr.setText("Cheque_No", WebDr.getValue("Cheque_No"), "Enter Cheque Number");
			WebDr.setText("Amount", WebDr.getValue("Amount"), "Enter Amount");
			WebDr.setText("PayeeName", WebDr.getValue("PayeeName"), "Enter Payee Name");
			WebDr.setText("Payee_RoutingNo", WebDr.getValue("Payee_RoutingNo"), "Enter Payee Routing Number");*/
			WebDr.click("Save_5521", "Click on save button");
			WebDr.alertAccept();
			WebDr.clickwithmouse("Validate_btn_5521", "Click on validate button");
			WebDr.waitForPageLoaded();
			WebDr.SwitchToLatestAlertCheck("Batch Validated");
			WebDr.waitForPageLoaded();
			LOAN.logout();
			WebDr.waitForPageLoaded();
			LOAN.superLogin();
			WebDr.waitForPageLoaded();
			pkgFCRPageObjects.FCR_ClearingPageObjects.InwardClearing_5521();		
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("Action",WebDr.getValue("Action1"), "Select Action");
			WebDr.setText("Batch_number", BatchNo, "Enter Batch Number");
			WebDr.rTab();
			WebDr.click("OK_5521", "Click on OK");
			WebDr.waitForPageLoaded();
			WebDr.click("Authorize_btn", "Click on Authorize");
			WebDr.alertAccept();
			WebDr.alertClickWithText("Batch Processing");
			WebDr.BatchNo = WebDr.getBatchNo();
			//if(WebDr.SwitchToLatestAlertCheck("Batch Number")){
			if(! WebDr.BatchNo.isEmpty()){	
				HtmlReporter.WriteStep("Check if the Inward Clearing clearing batch is created from 5521 screen",
						"User should be able to create a clearing batch",
						"User is able to create a clearing batch "+ WebDr.BatchNo +" successfully", true);
				}
				else {
					HtmlReporter.WriteStep("Check if the Inward Clearing clearing batch is created from 5521 screen",
						"User should be able to create a clearing batch",
						"User is unable to create a clearing batch successfully", false);
			}
			WebDr.waitForPageLoaded();
			/*LOAN.logout();
			LOAN.login();*/
			
		}
		
		catch(Exception errAuth1){
			errAuth1.printStackTrace();
			HtmlReporter.WriteStep("Check if the Inward Clearing clearing batch is created from 5521 screen",
					"User should be able to create a clearing batch",
					"User is unable to create a clearing batch successfully", false);
		}
	}
	
	
	
	public static void Auth_InwardClearing_ST032() throws Exception {
		try {
			/*LOAN.logout();
			WebDr.waitForPageLoaded();
			LOAN.superLogin();*/
			pkgFCRPageObjects.FCR_ClearingPageObjects.Auth_InwardClearing_ST032();				
			WebDr.fastPath(WebDr.getValue("FastPath_Auth"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("Batch_Click", "Click on batch number");
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("Authorize_btn_ST032", "Click on Authorize button");
			if(WebDr.alertClickWithText("Record Authorized")){
				
				HtmlReporter.WriteStep("Check if the Inward Clearing cheque batch is authorized from ST032 screen",
						"User should be able to authroize a cheque batch",
						"User is able to authroize a cheque batch successfully", true);
			}
			else {
			
				HtmlReporter.WriteStep("Check if the Inward Clearing cheque batch is authorized from ST032 screen",
						"User should be able to authroize a cheque batch",
						"User is able to authroize a cheque batch successfully", false);
			}
			WebDr.waitForPageLoaded();
			LOAN.logout();
			LOAN.login();
			WebDr.fastPath(WebDr.getValue("FastPath_InwClearing"));
			WebDr.waitForPageLoaded();
			pkgFCRPageObjects.FCR_ClearingPageObjects.Auth_InwardClearing_ST032();
			WebDr.selectDropValueByVisibleText("EndPoint",
					WebDr.getValue("EndPoint"), "Select EndPoint");
			WebDr.selectDropValueByVisibleText("Clearing_Type",
					WebDr.getValue("Clearing_Type"), "Select Clearing Type");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("OK_ST033", "Click on OK");
			if(WebDr.alertClickWithText("Inward Clearing Run Successful")){
				
				HtmlReporter.WriteStep("Check if the Inward Clearing process can be run in ST033 option",
						"User should be able to process a Inward clearing batch",
						"User is able to process a Inward clearing batch successfully", true);
			}
			else {
			
				HtmlReporter.WriteStep("Check if the Inward Clearing process can be run in ST033 option",
						"User should be able to process a Inward clearing batch",
						"User is unable to process a Inward clearing batch successfully", false);
			}

			
			
			
		}
		catch(Exception errAuth1){
			errAuth1.printStackTrace();
			HtmlReporter.WriteStep("Check if the Inward Clearing process can be run in ST033 option",
					"User should be able to process a Inward clearing batch",
					"User is unable to process a Inward clearing batch successfully", false);
		}
		}
	
	public static void ClearingViewDebitEntry_CH031() throws  Exception{
		try{
			pkgFCRPageObjects.FCR_ClearingPageObjects.ClearingViewDebitEntry_CH031();
			
			WebDr.fastPath(WebDr.getValue("FastPath_CH031"));
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();	
			
			WebDr.setText("AccountNo", Clearing.AccountNo, "Enter Account Number for statement enquiry");
			
			WebDr.rTab();
			WebDr.waitForPageLoaded();	
			
			WebDr.click("RadioTransaction", "Click on Transactions radio button");
			String sysdate = WebDr.getTextBoxValue("SystemDate", "System date is fetched and displayed");
			WebDr.rClearUpdateTextField("StartDate", WebDr.ChangeDatebyStaticDays(-1), "Enter start date");
			WebDr.rTab();
			WebDr.rClearUpdateTextField("EndDate", sysdate, "Enter start date");
			WebDr.rTab();
			/*if (! WebDr.getValue("EndDate").isEmpty()){
				WebDr.rDelete();
				WebDr.setText("EndDate", sysdate, "Enter end date");
				WebDr.rTab();
			}*/
			
			WebDr.waitForPageLoaded();
//			WebDr.click("AccountNo", "Click on acc no");
			WebDr.clickwithmouse("Inquire", "Click on Inquire button");	
			WebDr.waitForPageLoaded();
			
			if ( WebDr.isElementExist("ChequeNo", "Check if element is present")){
				Clearing.CH031Entry = true;
				WebDr.doubleClick("ChequeNo");
				//WebDr.waitForPageLoaded();
				
				HtmlReporter.WriteStep("Check the debit to account once the inward clearing batches process is run in ST033",
					"The user should be able to view the transaction in CH031",
					"Transactions are displayed successfully", true);
				}
			else 
			{
				HtmlReporter.WriteStep("Check the debit to account once the inward clearing batches process is run in ST033",
						"The user should be able to view the transaction in CH031",
						"Transactions are not displayed successfully", false);	
			}
		} 
			catch (Exception e) {
				HtmlReporter.WriteStep("Check the debit to account once the inward clearing batches process is run in ST033",
						"The user should be able to view the transaction in CH031",
						"Transactions are not displayed successfully" + e.getMessage(), false);
		}
	}
	
	public static void InwardClearing_PassFail_5521() throws Exception {
		try {
			// Enter_Details
			pkgFCRPageObjects.FCR_ClearingPageObjects.InwardClearing_5521();				
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("Action",
					WebDr.getValue("Action"), "Select Action");
			String BatchNo = WebDr.getTextBoxValue("Batch_number", "Get Batch NUmber");
			String BatchStatus = WebDr.getTextBoxValue("Batch_Status", "Get batch status");
			System.out.println(BatchNo + "," + BatchStatus);
			WebDr.selectDropValueByVisibleText("EndPoint",
					WebDr.getValue("EndPoint"), "Select EndPoint");
			WebDr.selectDropValueByVisibleText("Currency",
					WebDr.getValue("Currency"), "Select Currency");
			WebDr.setText("Cheque_Count", WebDr.getValue("Cheque_Count"), "Enter Number of Cheque");
			
			WebDr.selectDropValueByVisibleText("Clearing_Type",
					WebDr.getValue("Clearing_Type"), "Select Clearing Type");
			WebDr.click("OK_5521", "Click on OK");
			WebDr.waitForPageLoaded();
			//WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.keyboard(WebDr.getValue("AccountNo"));
			WebDr.rTab();
			WebDr.rTab();
			WebDr.keyboard(WebDr.getValue("Cheque_No1"));
			WebDr.rTab();
			WebDr.keyboard(WebDr.getValue("Amount1"));
			WebDr.rTab();
			WebDr.keyboard(WebDr.getValue("PayeeName"));
			WebDr.rTab();
			WebDr.keyboard(WebDr.getValue("Payee_RoutingNo1"));
			WebDr.rTab();
			WebDr.rTab();
			WebDr.rTab();
			WebDr.keyboard(WebDr.getValue("AccountNo"));
			WebDr.rTab();
			WebDr.rTab();
			WebDr.keyboard(WebDr.getValue("Cheque_No2"));
			WebDr.rTab();
			WebDr.keyboard(WebDr.getValue("Amount2"));
			WebDr.rTab();
			WebDr.keyboard(WebDr.getValue("PayeeName"));
			WebDr.rTab();
			WebDr.keyboard(WebDr.getValue("Payee_RoutingNo2"));
			Clearing.AccountNo =  WebDr.getValue("AccountNo");
			Clearing.PassedChequeNo =  WebDr.getValue("Cheque_No1");
			Clearing.FailedChequeNo =  WebDr.getValue("Cheque_No2");
			WebDr.click("Save_5521", "Click on save button");
			WebDr.alertAccept();
			WebDr.clickwithmouse("Validate_btn_5521", "Click on validate button");
			WebDr.waitForPageLoaded();
			WebDr.SwitchToLatestAlertCheck("Batch Validated");
			WebDr.waitForPageLoaded();
			LOAN.logout();
			WebDr.waitForPageLoaded();
			LOAN.superLogin();
			WebDr.waitForPageLoaded();
			pkgFCRPageObjects.FCR_ClearingPageObjects.InwardClearing_5521();		
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("Action",
					WebDr.getValue("Action1"), "Select Action");
			WebDr.setText("Batch_number", BatchNo, "Enter Batch Number");
			WebDr.rTab();
			WebDr.click("OK_5521", "Click on OK");
			WebDr.waitForPageLoaded();
			WebDr.click("Authorize_btn", "Click on Authorize");
			WebDr.alertAccept();
			WebDr.alertClickWithText("Batch Processing");
			WebDr.BatchNo = WebDr.getBatchNo();
			WebDr.waitForPageLoaded();
			
			Clearing.Auth_InwardClearing_ST032();
			
			boolean PassCheque= false;
			boolean FailCheque= false;
		
			pkgFCRPageObjects.FCR_ClearingPageObjects.Clearing_PassedCheque_ST035();			
			WebDr.fastPath(WebDr.getValue("FastPath_Pass"));
			WebDr.waitForPageLoaded();
			WebDr.setText("BatchNo", WebDr.BatchNo, "Enter Batch Number");
			//WebDr.setText("BatchNo", "35302", "Enter Batch Number");
			WebDr.clickwithmouse("OK_ST034", "Click on OK");
			WebDr.waitForPageLoaded();
			if ( WebDr.isElementExist("PassChequeNo", "Check if element is present")){
				WebDr.doubleClick("PassChequeNo");
				 PassCheque= true;
			}
			
			else
			{
				HtmlReporter.WriteStep("Check if the instrumenrs are divided in to Passed items post the ST033 process is run",
						"The user should be able to view passed items in ST035 screen",
						"Items are not divided into passed items", false);
			}
			
			pkgFCRPageObjects.FCR_ClearingPageObjects.Clearing_RejectedCheque_ST034();			
			WebDr.fastPath(WebDr.getValue("FastPath_Fail"));
			WebDr.waitForPageLoaded();
			WebDr.setText("BatchNo", WebDr.BatchNo, "Enter Batch Number");
			//WebDr.setText("BatchNo", "35302", "Enter Batch Number");
			WebDr.clickwithmouse("OK_ST034", "Click on OK");
			WebDr.waitForPageLoaded();
			if ( WebDr.isElementExist("FailChequeNo", "Check if element is present")){
				WebDr.doubleClick("FailChequeNo");
				FailCheque= true;
			}
			
			else
			{
				HtmlReporter.WriteStep("Check if the instrumenrs are divided in to Failed items post the ST033 process is run",
						"The user should be able to view Failed items in ST034 screen",
						"Items are not divided into Failed items", false);
			}
			
			if ((PassCheque == true) && (FailCheque= true)){
				HtmlReporter.WriteStep("Check if the instrumenrs are divided in to Passed items and Rejected items post the ST033 process is run",
						"The user should be able to view Passed and Failed items  post the ST033 process is run",
						"Items are divided into Passed and Failed items", true);
			}
			else
			{
				HtmlReporter.WriteStep("Check if the instrumenrs are divided in to Passed items and Rejected items post the ST033 process is run",
						"The user should be able to view Passed and Failed items  post the ST033 process is run",
						"Items are not divided into Passed and Failed items", false);
			}
			
			
			
		}
		
		catch(Exception errAuth1){
			errAuth1.printStackTrace();
			HtmlReporter.WriteStep("Check if the instrumenrs are divided in to Passed items and Rejected items post the ST033 process is run",
					"The user should be able to view Passed and Failed items  post the ST033 process is run",
					"Items are not divided into Passed and  Failed items", false);
		}
	}
	
	public static void Inquire_Failed_Instrument_ST034() throws Exception {	
	try{
		
		String RejectReason="";
		Clearing.InwardClearing_5521();
		Clearing.Auth_InwardClearing_ST032();
		//Clearing.ChequeNo = Clearing.FailedChequeNo;
		pkgFCRPageObjects.FCR_ClearingPageObjects.Inquire_Failed_Instrument_ST034();			
		WebDr.fastPath(WebDr.getValue("FastPath_Fail"));
		WebDr.waitForPageLoaded();
		WebDr.setText("BatchNo", WebDr.BatchNo, "Enter Batch Number");
		//WebDr.setText("BatchNo", "35302", "Enter Batch Number");
		WebDr.clickwithmouse("OK_ST034", "Click on OK");
		WebDr.waitForPageLoaded();
		if ( WebDr.isElementExist("FailChequeNo", "Check if element is present")){
			WebDr.doubleClick("FailChequeNo");
			WebDr.waitForPageLoaded();
			 RejectReason =  WebDr.getTextBoxValue("RejectReason", "Get Reject Reason");
			}
		if (! RejectReason.isEmpty())
		{
			HtmlReporter.WriteStep("Check if there are any instruments in Inward Rejections pending in ST034 option",
					"The user should be able to view Rejected instruments in ST034 screen",
					"Instrument no "+Clearing.ChequeNo+" is rejected and pending in ST034 screen ", true);	
		}
		
		else
		{
			HtmlReporter.WriteStep("Check if there are any instruments in Inward Rejections pending in ST034 option",
					"The user should be able to view Rejected instruments in ST034 screen",
					"No cheque is rejected and pending in ST034 screen ", false);	
		}
		
	} 
		catch (Exception e) {
			HtmlReporter.WriteStep("Check if there are any instruments in Inward Rejections pending in ST034 option",
					"The user should be able to view Rejected instruments in ST034 screen",
					"No instrument is rejected and pending in ST034 screen ", false);	
			}

	}
	
	
	public static void OutwardClearing_5506() throws Exception{
	try {
		// Enter_Details
		pkgFCRPageObjects.FCR_ClearingPageObjects.OutwardClearing_5506();				
		WebDr.fastPath(WebDr.getValue("FastPath"));
		WebDr.waitForPageLoaded();
		WebDr.selectDropValueByVisibleText("Action",
				WebDr.getValue("Action"), "Select Action");
	
		WebDr.selectDropValueByVisibleText("DepositBranch",
				WebDr.getValue("DepositBranch"), "Select Deposit Branch");
		WebDr.selectDropValueByVisibleText("Currency",
				WebDr.getValue("Currency"), "Select Currency");
		WebDr.setText("Cheque_Count", WebDr.getValue("Cheque_Count"), "Enter Number of Cheque");
		String BatchNo = WebDr.getTextBoxValue("Batch_number", "Get Batch NUmber");
		String BatchStatus = WebDr.getTextBoxValue("Batch_Status", "Get batch status");
		System.out.println(BatchNo + "," + BatchStatus);
		WebDr.click("OK_5506", "Click on OK");
		WebDr.waitForPageLoaded();
		//WebDr.waitForPageLoaded();
		for(int i = 1;i<3;i++){
		WebDr.keyboard(WebDr.getValue("AccountNo"));
		WebDr.rTab();
		WebDr.keyboard(WebDr.getValue("Cheque_No"+i+""));
		WebDr.rTab();
		WebDr.keyboard(WebDr.getValue("Amount"));
		WebDr.rTab();
		WebDr.rDown();
		WebDr.rDown();
		WebDr.rTab();
		WebDr.keyboard(WebDr.getValue("Cheque_Routing_No"));
		WebDr.rTab();
		WebDr.SwitchToLatestWindow();
		WebDr.rTab();
		WebDr.rEnter();
		WebDr.waitForPageLoaded();
		WebDr.rTab();
		WebDr.rTab();
		WebDr.rTab();
		//WebDr.keyboard(WebDr.getValue("DrawerAccountNo"));
		WebDr.setText("DrawerAccountNo"+i+"", WebDr.getValue("DrawerAccountNo"), "Enter drawee account number");
		WebDr.rTab();
		WebDr.rTab();
		WebDr.rTab();		
		WebDr.rTab();
		WebDr.rTab();
		}
		//WebDr.setText("DrawerAccountNo2", WebDr.getValue("DrawerAccountNo"), "Enter drawee account number");
		Clearing.AccountNo =  WebDr.getValue("AccountNo");	
		WebDr.click("Save_5506", "Click on save button");
		WebDr.alertAccept();
		WebDr.clickwithmouse("Validate_btn_5506", "Click on validate button");
		WebDr.waitForPageLoaded();
		WebDr.alertClickWithText("Batch Validated Successfully.Authorization pending");
		WebDr.waitForPageLoaded();
		LOAN.logout();
		WebDr.waitForPageLoaded();
		LOAN.superLogin();
		WebDr.waitForPageLoaded();
		pkgFCRPageObjects.FCR_ClearingPageObjects.OutwardClearing_5506();		
		WebDr.fastPath(WebDr.getValue("FastPath"));
		WebDr.waitForPageLoaded();
		WebDr.selectDropValueByVisibleText("Action",
				WebDr.getValue("Action1"), "Select Action");
		WebDr.setText("Batch_number", BatchNo, "Enter Batch Number");
		WebDr.rTab();
		WebDr.click("OK_5506", "Click on OK");
		WebDr.waitForPageLoaded();
		WebDr.click("Authorize_btn", "Click on Authorize");
		WebDr.alertClickWithText("batchtype");
		if(WebDr.SwitchToLatestAlertCheck("Batch Processing Successful at Host"))
		{	
			HtmlReporter.WriteStep("Check if the Outward Clearing cheque batch is created from 5506 screen",
					"User should be able to create a clearing batch",
					"User is able to create a cheque batch "+ WebDr.BatchNo +" successfully", true);
			}
			else {
				HtmlReporter.WriteStep("Check if the Outward Clearing clearing batch is created from 5506 screen",
					"User should be able to create a clearing batch",
					"User is unable to create a clearing batch successfully", false);
		}
		WebDr.waitForPageLoaded();
		LOAN.logout();
		LOAN.login();
		
	}
	
	catch(Exception errAuth1){
		errAuth1.printStackTrace();
		HtmlReporter.WriteStep("Check if the Outward Clearing clearing batch is created from 5506 screen",
				"User should be able to create a clearing batch",
				"User is unable to create a clearing batch successfully", false);
	}
	
	}
	
	public static void OutwardClearing_ST023() throws Exception{
		try {
			Clearing.OutwardClearing_5506();
			pkgFCRPageObjects.FCR_ClearingPageObjects.OutwardClearing_ST023();
			WebDr.fastPath(WebDr.getValue("FastPath_OutClearing"));
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("Clearinghouse",
					WebDr.getValue("Clearinghouse"), "Select Clearing house");
			WebDr.selectDropValueByVisibleText("Clearing_Type",
					WebDr.getValue("Clearing_Type"), "Select Clearing Type");
			WebDr.rTab();
			WebDr.clickwithmouse("OK_ST023", "Click on OK");
			if(WebDr.alertHandlingForErrors("Outward Clearing Successful","Check for alert message"))
			{	
				HtmlReporter.WriteStep("Check if the Outward Clearing Process can be run from ST023 option",
						"User should be able to run Outward Clearing Process from ST023 option",
						"User is able to run a cheque batch successfully", true);
				}
				else {
					HtmlReporter.WriteStep("Check if the Outward Clearing Process can be run from ST023 option",
							"User should be able to run Outward Clearing Process from ST023 option",
							"User is unable to run a cheque batch successfully", false);
			}
		}
		catch(Exception errAuth1){
			errAuth1.printStackTrace();
			HtmlReporter.WriteStep("Check if the Outward Clearing Process can be run from ST023 option",
					"User should be able to run Outward Clearing Process from ST023 option",
					"User is unable to run a cheque batch successfully", false);
		}
		}
	
	public static void Inward_Clearing_AccountingEntries() throws Exception{
		try {
			Clearing.InwardClearing_5521();
			Clearing.Auth_InwardClearing_ST032();
			Clearing.ClearingViewDebitEntry_CH031();
			pkgFCRPageObjects.FCR_ClearingPageObjects.Inward_Clearing_AccountingEntries();
			WebDr.fastPath(WebDr.getValue("Fasthpath_GLentries"));
			String sysdate = WebDr.getTextBoxValue("SystemDate", "System date is fetched and displayed");
			WebDr.setText("GL_Acct", WebDr.getValue("GL_Acct"), "Enter GL Account Number for GL statement enquiry");
			WebDr.rTab();
			WebDr.selectDropValueByVisibleText("GL_Branch",
					WebDr.getValue("GL_Branch"), "Select GL Branch");
			WebDr.selectDropValueByVisibleText("GL_Currency",
					WebDr.getValue("GL_Currency"), "Select GL Currency");
			WebDr.selectDropValueByVisibleText("Inquiry_type",
					WebDr.getValue("Inquiry_type"), "Select Inquiry type ");
			WebDr.rClearUpdateTextField("From_Date", WebDr.ChangeDatebyStaticDays(-7), "Enter start date");
			WebDr.rTab();
			WebDr.rClearUpdateTextField("To_Date", sysdate, "Enter End date");
			WebDr.rTab();
			WebDr.clickwithmouse("Inquire_GLM04", "Click on inquiry button");
			WebDr.waitForPageLoaded();
			if ( WebDr.isElementExist("GL_Entry", "Check if element is present")){
				Clearing.GLM04Entry = true;
				WebDr.doubleClick("GL_Entry");
			}
			if((Clearing.CH031Entry==true) && (Clearing.GLM04Entry==true)){
				HtmlReporter.WriteStep("Check the accounting entries for Inward clearing i.e. Debit customer and credit inward clearing GL once the inward clearing batches process is run in ST033",
					"The user should be able to view the transaction in CH031 & GLM04",
					"Transactions are displayed successfully", true);
				}
			else 
			{
				HtmlReporter.WriteStep("Check the accounting entries for Inward clearing i.e. Debit customer and credit inward clearing GL once the inward clearing batches process is run in ST033",
						"The user should be able to view the transaction in CH031  & GLM04",
						"Transactions are not displayed successfully", false);	
			}
			
			
			
		}
		catch(Exception errAuth1){
			errAuth1.printStackTrace();
			HtmlReporter.WriteStep("Check the accounting entries for Inward clearing i.e. Debit customer and credit inward clearing GL once the inward clearing batches process is run in ST033",
					"The user should be able to view the transaction in CH031  & GLM04",
					"Transactions are not displayed successfully", false);	
			
		}
		}
	
	public static void ValueDate_Clearing_ST001() throws Exception{
		try {
			//47 KAMPALA//INWARD CLEARING
			pkgFCRPageObjects.FCR_ClearingPageObjects.ValueDate_Clearing_ST001();
			WebDr.fastPath(WebDr.getValue("Fasthpath_ValueDate"));
			WebDr.selectDropValueByVisibleText("EndPoint",
					WebDr.getValue("EndPoint"), "Select EndPoint ");
			WebDr.selectDropValueByVisibleText("Clearing_Type",
					WebDr.getValue("Clearing_Type"), "Select Clearing type ");
			WebDr.clickwithmouse("OK_ST001", "Click on OK");
			if(WebDr.SwitchToLatestAlertCheck("SUCCESS...Click Ok to continue"))
			{	
				HtmlReporter.WriteStep("Check if the teller can run Value date clearing using option ST001",
						"User should be able to run the Value date clearing process using ST001 option post completion of all clearing process for all clearing types of the endpoint",
						"User is able to run value dated clearing successfully", true);
				}
				else {
					HtmlReporter.WriteStep("Check if the teller can run Value date clearing using option ST001",
							"User should be able to run the Value date clearing process using ST001 option post completion of all clearing process for all clearing types of the endpoint",
							"User is unable to run value dated clearing successfully", false);
			}
		}
	
		
		catch(Exception errAuth1){
			errAuth1.printStackTrace();
			HtmlReporter.WriteStep("Check if the teller can run Value date clearing using option ST001",
					"User should be able to run the Value date clearing process using ST001 option post completion of all clearing process for all clearing types of the endpoint",
					"User is unable to run value dated clearing successfully", false);

		
	}
	}
}
//180251000