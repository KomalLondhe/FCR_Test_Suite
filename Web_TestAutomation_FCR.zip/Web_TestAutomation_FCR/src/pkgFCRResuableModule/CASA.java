package pkgFCRResuableModule;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

import testCases.Driver;
import utility.Constant;
import utility.FCRDBConnection;
import utility.HtmlReporter;
import utility.WebDr;

public class CASA extends Driver {

	public static void CASAAcctOpening_8051() throws Exception,
			Exception {
			
		try {
			pkgFCRPageObjects.FCR_CASAPageObjects.CASAAcctOpening_8051();

			WebDr.fastPath(WebDr.getValue("FastPath"));
			String strUDFDate = WebDr.getTextBoxValue("SystemDate", "System date is fetched and displayed");
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("BranchName",
					WebDr.getValue("BranchName"), "Select Branch Name");
			WebDr.selectDropValueByVisibleText("ProductName",
					WebDr.getValue("ProductName"), "Select Product Name");
			WebDr.setText("AccountTitle", WebDr.getValue("AcctTitle"), "Enter Account Title");
			if (WebDr.strFCRCountry.equals("NBC") || WebDr.strFCRCountry.equals("BBK")){
				WebDr.click("CustPick", "Click on Validate");	
				WebDr.selectDropValueByVisibleText("SelectSearchCriteria", "Customer ID", "Select search criteria");
				WebDr.rTab();
			
				//WebDr.setText("SearchValue",WebDr.CustID, "Enter search value");
				WebDr.setText("SearchValue", WebDr.getValue("CustomerID"), "Enter search value");
				
				WebDr.rTab();
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.rDown();
				WebDr.rEnter();
				WebDr.SwitchToLatestWindow();
				//WebDr.click("SelectRow", "Click on record");	
				WebDr.waitForPageLoaded();
				//Thread.sleep(8000);
			}
			else
				WebDr.setText("CustomerIC1", WebDr.getValue("CustomerIC1"), "Enter Customer IC");
			
			WebDr.SwitchToLatestWindow();
			if (!( (WebDr.strFCRCountry.equals("NBC") || (WebDr.strFCRCountry.equals("BBK"))) ) ){
				WebDr.selectDropValueByVisibleText("Category1",WebDr.getValue("Category1"), "Selct Category");
			}
			WebDr.setText("Relation1", WebDr.getValue("Relations"), "Enter Relation");
			WebDr.selectDropValueByVisibleText("OfficerID",	WebDr.getValue("OfficerID"), "Select Officer ID");
			if (!( (WebDr.strFCRCountry.equals("NBC") || (WebDr.strFCRCountry.equals("UG"))) ) ){
			WebDr.setText("NoOfLeaves", WebDr.getValue("NoOfLeaves"), "Enter No Of Leaves");
			}
			if(WebDr.strFCRCountry.equals("BBK"))
			{
				WebDr.rTab();
				WebDr.rTab();
				WebDr.rTab();
				WebDr.rTab();
				WebDr.rTab();
			}
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("Validate", "Click on Validate");
			// WebDr.rEnter();
//			WebDr.alertAccept();
			WebDr.alertHandlingForErrors("Existing", "Check for alert message");
			WebDr.waitForPageLoaded();
			// WebDr.rEnter();
			WebDr.clickwithmouse("AccountTitle", "Click Account Title");
//			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("Ok", "Click on OK");
			
			if(WebDr.strFCRCountry.equals("BBK")){
				WebDr.alertClickWithText("UDF");
				WebDr.waitForPageLoaded();
				WebDr.rClearUpdateTextField("UDFDate", strUDFDate, "Account open date");
				//WebDr.setText("UDFDate", strUDFDate, "Account open date");
				WebDr.clickwithmouse("UDFValidate", "Click on validate");
				WebDr.waitForPageLoaded();
				WebDr.clickwithmouse("UDFBack", "Click on Back");
				WebDr.clickwithmouse("Ok", "Click on OK");
			}
			if((WebDr.strFCRCountry.equals("NBC")))
			{
				
				if(WebDr.isAlertPresent())
				{
					WebDr.alertClickWithText("Invalid date");
				}
			}
			if((WebDr.strFCRCountry.equals("NBC")) || (WebDr.strFCRCountry.equals("BBM"))){
				WebDr.authWithComment();
			}
			WebDr.waitForPageLoaded();
			//WebDr.getAccountNo();
			WebDr.AccountNo= WebDr.getAccountNo();
			
			WebDr.alertAccept();
			WebDr.waitForPageLoaded();
			if (! (WebDr.AccountNo.toString().length() == 0)) {
				HtmlReporter.WriteStep("Verify opening of CASA account",
						"User should be able to create a "+WebDr.getValue("ProductName")+ "  CASA Account.",
						"CASA Account Creation Successful. CASA Account No - " + WebDr.AccountNo,
						true);
			}
			else
			{
				HtmlReporter.WriteStep("Verify opening of CASA account",
						"User should be able to create CASA Account.",
						"CASA Account Creation Unsuccessful. CASA Account No - ",
						false);
				
			}

		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Verify opening of CASA account",
					"User should be able to create CASA Account. ",
					"CASA Account creation unsuccessful: " + e.toString(),
					false);
		}
	}

	public static void CashDeposit_1401() throws Exception {
		try {
			pkgFCRPageObjects.FCR_CASAPageObjects.CashDeposit_1401();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			if (WebDr.AlertHandleForUnknownErrors())
				throw new Exception();
			WebDr.waitForPageLoaded();
			WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
			WebDr.rTab();	
			WebDr.waitForPageLoaded();
			if(WebDr.strFCRCountry.equals("NBC")){
				WebDr.selectDropValueByVisibleText("TxnCurrency",WebDr.getValue("TxnCurrency"), "Select Txn Currency");
			}
			WebDr.setText("TxnAmount", WebDr.getValue("TxnAmount"), "Enter Tax Amount");
			WebDr.click("TxnAmount", "Click in TxnAmount field");
			WebDr.rTab();
			WebDr.AlertHandleOfflineChargeErrors();
			if(WebDr.strFCRCountry.equals("NBC")){
				WebDr.setText("DepositorID", WebDr.getValue("DepositorID"), "Enter Depositor ID");
				WebDr.rTab();
				WebDr.setText("DepositorName", WebDr.getValue("DepositorName"), "Enter Depositor Name");
				WebDr.rTab();
			}
			WebDr.setText("UserRefNo", WebDr.getValue("UserRef"), "Enter User Ref");
			WebDr.rTab();
			WebDr.rTab();
			WebDr.clickwithmouse("Ok", "Clik on OK");	
			WebDr.waitForPageLoaded();
			if(WebDr.strFCRCountry.equals("UG") || WebDr.strFCRCountry.equals("NBC"))
			{
				WebDr.alertAccept();
			}
			if(WebDr.strFCRCountry.equals("UGChanged")){
				// SignatureVerfication
				WebDr.waitForPageLoaded();
				WebDr.click("Sign", "Click on Sign");
				WebDr.click("SignOk", "Click on OK");
				WebDr.waitForPageLoaded();
				WebDr.waitForNumberOfWindowsToEqual(3);
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				WebDr.clickactivatewithmouse("SignZoom", "Click on signature window");
				WebDr.CloseWindowWithTitle("Signature");
				WebDr.SwitchToLatestWindow();
				WebDr.click("FastPath", "Click in the textfield");		
				WebDr.click("SignVerified", "Click on Signature Verified");
				WebDr.click("SignCancel", "Click on Cancel");
	
				// 1401ScreenReturn
				WebDr.waitForPageLoaded();
				WebDr.click("AccountNo", "Click on Account No");
				WebDr.click("Ok", "Click on OK");
				WebDr.alertAccept();
			}
			
			if(WebDr.strFCRCountry.equals("BBM"))
			{
				WebDr.alertAccept();
				WebDr.waitForPageLoaded();
				WebDr.click("MandatoryUDF1", "Click on OK");
				WebDr.setText("MandatoryUDF1", WebDr.getValue("MandatoryUDF1"), "Enter Mandatory UDF 1");
				WebDr.rTab();
				WebDr.setText("MandatoryUDF2", WebDr.getValue("MandatoryUDF2"), "Enter Mandatory UDF 2");
				WebDr.rTab();
				WebDr.setText("MandatoryUDF3", WebDr.getValue("MandatoryUDF3"), "Enter Mandatory UDF 3");
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				WebDr.click("Validate","Click on Validate");
				WebDr.click("Back","Click on Back");
				WebDr.waitForPageLoaded();
				WebDr.click("Ok", "Click on OK");
				WebDr.alertAccept();
			}
			if(!WebDr.strFCRCountry.equals("BBK")){
			// Denomination
			WebDr.waitForPageLoaded();
			WebDr.DenominationEntry("Enter Denomination");
			WebDr.click("D_Ok", "Click on OK button");
			}
			//WebDr.setText				("Count", "2", "");
			//WebDr.setText("Denomination", WebDr.getValue("Denomination"), "Enter Denomination");
			// 1401ScreenReturn
			//WebDr.waitForPageLoaded();
			/*try{
				WebDr.click("AccountNo", "Click on Account No");					
				WebDr.clickwithmouse("Ok", "Click on OK");
				WebDr.waitForPageLoaded();
				//WebDr.AlertHandleOfflineChargeErrors();
				//WebDr.alertAccept();
			}catch(Exception e){
				System.out.println("Inside");
				Thread.sleep(5000);	
				e.printStackTrace();
				WebDr.alertAccept();
			}*/
			WebDr.click("AccountNo", "Click on Account No");
			WebDr.clickwithmouse("Ok", "Click on OK");
			WebDr.waitForPageLoaded();
			if(WebDr.strFCRCountry.equals("UG") ) {
				
				WebDr.authWithComment();
				
				
			}
			else if(WebDr.strFCRCountry.equals("BBK") || (WebDr.strFCRCountry.equals("BBM")))
			{
				WebDr.waitForPageLoaded();
				WebDr.alertClickWithText("Authorisation required.Do you want to continue?");
				WebDr.clickElementImageSikuli("SuperAuthOK.PNG", 10, "Accept");
				WebDr.waitForPageLoaded();
				WebDr.click("Ok", "Click on OK");
				WebDr.waitForPageLoaded();
				WebDr.authWithComment();
			}
			
			if(WebDr.strFCRCountry.equals("UG") || WebDr.strFCRCountry.equals("NBC"))
			{
				if (WebDr.alertClickWithText("Transaction sequence number is"))
					HtmlReporter.WriteStep("Check whether teller is able to fund a CASA account using physical cash  from 1401 screen.",
						"User should be able to deposit funds successfully. ",
						"Funds Transfer Successful. ", true);
				else {
				HtmlReporter.WriteStep("Check whether teller is able to fund a CASA account using physical cash  from 1401 screen.",
						"User should be able to deposit funds successfully. ",
						"Funds Transfer Unsuccessful. ", false);
					}
				
			}else if(WebDr.strFCRCountry.equals("BBK"))
			{
				if (WebDr.VerifyStatusBarText("StatusBar",10,"Transaction sequence number is","Verify transaction status"))
					HtmlReporter.WriteStep("Check whether teller is able to fund a CASA account using physical cash  from 1401 screen.",
						"User should be able to deposit funds successfully. ",
						"Funds Transfer Successful. ", true);
			else {
				HtmlReporter.WriteStep("Check whether teller is able to fund a CASA account using physical cash  from 1401 screen.",
						"User should be able to deposit funds successfully. ",
						"Funds Transfer Unsuccessful. ", false);
				}		
				
				WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
			}else if(WebDr.strFCRCountry.equals("BBM"))
			{
				if (WebDr.alertClickWithText("Transaction sequence number is"))
					HtmlReporter.WriteStep("Check whether teller is able to fund a CASA account using physical cash  from 1401 screen.",
						"User should be able to deposit funds successfully. ",
						"Funds Transfer Successful. ", true);
				else {
				HtmlReporter.WriteStep("Check whether teller is able to fund a CASA account using physical cash  from 1401 screen.",
						"User should be able to deposit funds successfully. ",
						"Funds Transfer Unsuccessful. ", false);
					}
				WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
			}
			
			
		}
		catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Check whether teller is able to fund a CASA using physical cash  from 1401 screen.",
					"User should be able to deposit funds successfully. ",
					"Funds Transfer Unsuccessful. " + e.getMessage(), false);

		}	
	}

	
	
	
	
	public static void FundsTransferRequest_1006() throws Exception {
		try{
			pkgFCRPageObjects.FCR_CASAPageObjects.FundsTransferRequest_1006();
			WebDr.fastPath(WebDr.getValue("FastPath"));

			WebDr.waitForPageLoaded();
			WebDr.setText("FromAcctNo", WebDr.getValue("FromAcctNo"), "Enter From Account Number");
			WebDr.rTab();
			WebDr.setText("ToAcctNo", WebDr.getValue("ToAcctNo"), "Enter To Account Number");
			WebDr.rTab();
			WebDr.setText("FromAmount", WebDr.getValue("FromAmount"), "Enter Amount to be transferred");
			WebDr.rTab();
			WebDr.AlertHandleOfflineChargeErrors();
			if(WebDr.strFCRCountry.equals("NBC"))
			{
				WebDr.setText("DepositorID", WebDr.getValue("DepositorID"), "Enter Depositor ID ");
				WebDr.rTab();
				WebDr.setText("DepositorName", WebDr.getValue("DepositorName"), "Enter Depositor Name");
				WebDr.rTab();
			}
			WebDr.setText("UserRefNo", WebDr.getValue("UserRefNo"), "Enter User Reference");
			WebDr.clickwithmouse("Ok", "Click on 1006 screen Ok");

			if((WebDr.strFCRCountry.equals("NBC")) || (WebDr.strFCRCountry.equals("BBM"))){
				// SignatureVerfication
				WebDr.alertClickWithText(WebDr.getValue("FromAcctNo"));
				WebDr.waitForPageLoaded();
				WebDr.click("Sign", "Click on Sign");
				WebDr.click("SignOk", "Click on OK");
				WebDr.waitForPageLoaded();
				WebDr.waitForNumberOfWindowsToEqual(3);
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				WebDr.clickactivatewithmouse("SignZoom", "Click on signature window");
				WebDr.CloseWindowWithTitle("Signature");
				WebDr.SwitchToLatestWindow();
				WebDr.click("FastPath", "Click in the textfield");
				WebDr.click("SignVerified", "Click on Signature Verified");
				//WebDr.click("SignCancel", "Click on Cancel");
				// 1401ScreenReturn
				WebDr.waitForPageLoaded();
				WebDr.click("FromAcctNo", "Click on Account No");
				WebDr.clickwithmouse("Ok", "Click on OK");
				//WebDr.alertAccept();
			}
			if(!(WebDr.strFCRCountry.equals("BBM")))
			{
			WebDr.authWithComment();
			}
			

			Thread.sleep(5000);
			try{
				if((WebDr.strFCRCountry.equals("BBK"))){
					if (WebDr.VerifyStatusBarText("StatusBar",10,"Transaction sequence number is","Verify transaction status"))
						HtmlReporter.WriteStep("Check whether the user is able to perform a cash transaction successfully or not using 1006 screen.",
								"User should be able to perform a cash transaction successfully. ",
								"Cash transaction successful. ", true);
					else
						HtmlReporter.WriteStep("Check whether the user is able to perform a cash transaction successfully or not using 1006 screen.",
								"User should be able to perform a cash transaction successfully. ",
								"Cash transaction unsuccessful. ", false);
					
					WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
				}
				else if (WebDr.strFCRCountry.equals("BBM"))
					{
						if(WebDr.isAlertPresent())
						{
							WebDr.waitForPageLoaded();
							WebDr.alertAccept();
						}
						HtmlReporter.WriteStep("Check whether the user is able to perform a cash transaction successfully or not using 1006 screen.",
								"User should be able to perform a cash transaction successfully. ",
								"Cash transaction successful. ", true);
						WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
					}
				else {		
					

					if (WebDr.alertClickWithText("Transaction sequence number is"))
						HtmlReporter.WriteStep("Check whether the user is able to perform a cash transaction successfully or not using 1006 screen.",
								"User should be able to perform a cash transaction successfully. ",
								"Cash transaction successful. ", true);
					else
						HtmlReporter.WriteStep("Check whether the user is able to perform a cash transaction successfully or not using 1006 screen.",
								"User should be able to perform a cash transaction successfully. ",
								"Cash transaction unsuccessful. ", false);
					if (WebDr.isAlertPresent())
						Driver.driver.switchTo().alert().dismiss();
						
					WebDr.SwitchToLatestWindow();
					WebDr.rTab();
					WebDr.rEnter();
				}
			
			}catch(Exception e){
				e.printStackTrace();	
			}
		}catch(Exception error){
			HtmlReporter.WriteStep("Check whether the user is able to perform a cash transaction successfully or not using 1006 screen.",
					"User should be able to perform a cash transaction successfully. ",
					"Cash transaction unsuccessful. ", false);
			error.printStackTrace();
		}
	}

	public static void CashWithdrawal_1001() throws UnhandledAlertException,
			Exception {
		try {
			pkgFCRPageObjects.FCR_CASAPageObjects.CashWithdrawal_1001();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account No");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			if(WebDr.strFCRCountry.equals("NBC")){
				WebDr.selectDropValueByVisibleText("TxnCurrency",WebDr.getValue("TxnCurrency"), "Select Txn Currency");
			}
			WebDr.setText("Amount", WebDr.getValue("Amount"), "Enter amount");
			WebDr.rTab();
			WebDr.AlertHandleOfflineChargeErrors();
			WebDr.setText("UserRefNo", WebDr.getValue("UserRefNo"), "Enter User Ref No");
			WebDr.clickwithmouse("Ok", "Click on OK");
			
			if(WebDr.strFCRCountry.equals("BBK")){
				WebDr.alertClickWithText(WebDr.getValue("AccountNo"));
			}
			
			
			// SignatureVerfication
			WebDr.waitForPageLoaded();
			WebDr.click("Sign", "Click on Sign");
			
			if(! WebDr.strFCRCountry.equals("BBK")){
				WebDr.click("SignOk", "Click on OK");
				WebDr.waitForPageLoaded();
			}

			WebDr.waitForNumberOfWindowsToEqual(3);
			WebDr.SwitchToLatestWindow();
			WebDr.waitForPageLoaded();
			WebDr.clickactivatewithmouse("SignZoom", "Click on signature window");
			WebDr.CloseWindowWithTitle("Signature");
			WebDr.SwitchToLatestWindow();
			WebDr.click("FastPath", "Click in the textfield");
			
			WebDr.click("SignVerified", "Click on Signature Verified");
			
			if(WebDr.strFCRCountry.equals("UG")){
				WebDr.click("SignCancel", "Click on Cancel");
			}
			
			// ScreenReturn
			if(WebDr.strFCRCountry.equals("UG") || WebDr.strFCRCountry.equals("NBC") ||  WebDr.strFCRCountry.equals("BBK")){
				WebDr.waitForPageLoaded();
				WebDr.click("Ok", "Click on OK");
				WebDr.alertClickWithText("cash to vault");
			}
			
			if(WebDr.strFCRCountry.equals("UG")) {
				WebDr.alertClickWithText("Suntec");
				WebDr.alertClickWithText("Denomination");
				
				// Denomination
				WebDr.waitForPageLoaded();
				WebDr.DenominationEntry("Enter denomination");
				//WebDr.setText("Denomination", WebDr.getValue("Denomination"), "Enter Denomination");
				WebDr.click("D_Ok", "Click on OK");
	
				// ScreenReturn
				WebDr.waitForPageLoaded();
				WebDr.click("Ok", "Click on OK");
				
				WebDr.alertClickWithText("Suntec");
				WebDr.alertClickWithText("kool");
				// AuthWithComments
				WebDr.authWithComment();
			}
		else if(WebDr.strFCRCountry.equals("BBK")){
				// Denomination
				WebDr.waitForPageLoaded();
				WebDr.DenominationEntry("Enter denomination");
				//WebDr.setText("Denomination", WebDr.getValue("Denomination"), "Enter Denomination");
				//WebDr.click("D_Ok", "Click on OK");
	
				// ScreenReturn
				WebDr.waitForPageLoaded();
				WebDr.clickwithmouse("Ok", "Click on OK");
				// AuthWithComments
				WebDr.authWithComment();
			}
			
			else if(WebDr.strFCRCountry.equals("BBM"))
			{
				WebDr.waitForPageLoaded();
				WebDr.click("Ok", "Click on OK");
				WebDr.rEnter();
				WebDr.waitForPageLoaded();
				WebDr.DenominationEntry("Enter denomination");
				WebDr.click("D_Ok", "Click on OK");
				WebDr.waitForPageLoaded();
				WebDr.clickwithmouse("Ok", "Click on OK");
				
			}
			
			//WebDr.alertAccept();
			if (! WebDr.strFCRCountry.equals("BBK")) {
				if (WebDr.alertClickWithText("Transaction sequence number is"))
					HtmlReporter.WriteStep("Check whether the user is able to withdraw cash from CASA account using 1001 screen.",
						"User should be able to withdraw cash successfully. ",
						"Cash Withdrawal Successful. ", true);
				else
					HtmlReporter.WriteStep("Check whether the user is able to withdraw cash from CASA account using 1001 screen.",
							"User should be able to withdraw cash successfully. ",
							"Cash Withdrawal Unuccessful. ", false);
				WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
			}
			else if(WebDr.strFCRCountry.equals("BBK"))
			{
				WebDr.waitForPageLoaded();
				WebDr.rEnter();
				if (WebDr.VerifyStatusBarText("StatusBar",10,"Transaction sequence number is","Verify transaction status"))
					HtmlReporter.WriteStep("Check whether the user is able to withdraw cash from CASA account using 1001 screen.",
						"User should be able to withdraw cash successfully. ",
						"Cash Withdrawal Successful. ", true);
				else
					HtmlReporter.WriteStep("Check whether the user is able to withdraw cash from CASA account using 1001 screen.",
							"User should be able to withdraw cash successfully. ",
							"Cash Withdrawal Unuccessful. ", false);
				WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
			}
			else if(WebDr.strFCRCountry.equals("UG"))
			{
				if (WebDr.VerifyStatusBarText("StatusBar",10,"Transaction sequence number is","Verify transaction status"))
					HtmlReporter.WriteStep("Check whether the user is able to withdraw cash from CASA account using 1001 screen.",
						"User should be able to withdraw cash successfully. ",
						"Cash Withdrawal Successful. ", true);
				else
					HtmlReporter.WriteStep("Check whether the user is able to withdraw cash from CASA account using 1001 screen.",
							"User should be able to withdraw cash successfully. ",
							"Cash Withdrawal Unuccessful. ", false);
			}
			else if(WebDr.strFCRCountry.equals("BBM"))
			{
				if (WebDr.VerifyStatusBarText("StatusBar",10,"Transaction sequence number is","Verify transaction status"))
					HtmlReporter.WriteStep("Check whether the user is able to withdraw cash from CASA account using 1001 screen.",
						"User should be able to withdraw cash successfully. ",
						"Cash Withdrawal Successful. ", true);
				else
					HtmlReporter.WriteStep("Check whether the user is able to withdraw cash from CASA account using 1001 screen.",
							"User should be able to withdraw cash successfully. ",
							"Cash Withdrawal Unuccessful. ", false);
				
				WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
				
			}
			else {
				if (WebDr.VerifyStatusBarText("StatusBar",10,"Transaction sequence number is","Verify transaction status"))
					HtmlReporter.WriteStep("Check whether the user is able to withdraw cash from CASA account using 1001 screen.",
						"User should be able to withdraw cash successfully. ",
						"Cash Withdrawal Successful. ", true);
				else
					HtmlReporter.WriteStep("Check whether the user is able to withdraw cash from CASA account using 1001 screen.",
							"User should be able to withdraw cash successfully. ",
							"Cash Withdrawal Unuccessful. ", false);
				
				WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
			}

		} catch (Exception e) {
			HtmlReporter.WriteStep("Check whether the user is able to withdraw cash from CASA account using 1001 screen.",
					"User should be able to withdraw cash successfully. ",
					"Cash Withdrawal Unsuccessful. " + e.getMessage(), false);
			e.printStackTrace();

		}

	}

	public static void CustomerSearch_1000() throws Exception {
		try{
			pkgFCRPageObjects.FCR_CASAPageObjects.CustomerSearch_1000();
			
			driver.switchTo().window(strFCRTellerWindow);
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.setText("SearchBy", WebDr.getValue("SearchBy"), "Enter search criteria");
			WebDr.setText("SearchString", WebDr.getValue("SearchString"), "Enter search string");
			WebDr.click("OK_1000", "Click on OK");
			WebDr.waitForPageLoaded();
			WebDr.click("CustIDRow", "Click on customer ID");
			WebDr.waitForPageLoaded();
			/*WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.rEnter();*/
			
			String strCustID = WebDr.getTextBoxValue("CustomerID", "Get Value");
			if (! strCustID.isEmpty()){
				HtmlReporter.WriteStep("Check whether customer information can be obtained by inquring from 1000 screen.",
						"User should be able to get customer information",
						"Get customer information successful. ", true);
			}
			else{
				HtmlReporter.WriteStep("Check whether customer information can be obtained by inquring from 1000 screen.",
						"User should be able to get customer information",
						"Get customer information unsuccessful. ", false);
			}
			
			System.out.println("***********************************");
			/*//Database Validation
			FCRDBConnection.DBValidation_FetchValue(WebDr.getValue("Query"));
			FCRDBConnection.DBValidation_VerifyValue();
			*/
		} catch (Exception e) {
			HtmlReporter.WriteStep("Check whether customer information can be obtained by inquring from 1000 screen.",
					"User should be able to get customer information",
					"Get customer information unsuccessful. " + e.getMessage(), false);
		}
	}
	
	public static void Account_Closing_CH001() throws Exception {
		try{
			pkgFCRPageObjects.FCR_CASAPageObjects.Account_Closing_CH001();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			/*if(WebDr.strFCRCountry.equals("BBK"))
			{
				WebDr.clickwithmouse("AddBtn", "Selct Mode ADD");	
			}*/
			
			WebDr.setText("AccountNo", WebDr.getValue("CASACloseAccount"), "Enter Account Number to be closed");
			WebDr.rTab();
			WebDr.selectDropValueByVisibleText("ClosingReason", WebDr.getValue("ReasonForClosure"), "Select Reason For Closure");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.click("OK_CH001", "Click OK button");
			if(WebDr.strFCRCountry.equals("BBM")){
				WebDr.authWithComment();
			}
			if(WebDr.strFCRCountry.equals("BBK"))
			{  
                if(WebDr.multiplealertHandlingForErrors("Authorisation Pending", "Verify alert message"))
				{	
					WebDr.alertAccept();
					LOAN.logout();
					WebDr.waitForPageLoaded();
					LOAN.superLogin();
					WebDr.waitForPageLoaded();
					pkgFCRPageObjects.FCR_CASAPageObjects.Account_Closing_CH001();	
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.click("CLEAR_CH001", "Click OK button");
					WebDr.waitForPageLoaded();
					WebDr.click("AuthorizeBtn","Click on Authorize radio button");
					WebDr.waitForPageLoaded();
					WebDr.setText("AccountNo", WebDr.getValue("CASACloseAccount"), "Enter Account Number to be closed");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.selectDropValueByVisibleText("ClosingReason", WebDr.getValue("ReasonForClosure"), "Select Reason For Closure");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("OK_CH001", "Click on OK");
					WebDr.alertAccept();	
					HtmlReporter.WriteStep("Check whether open regular CASA account will close from CH001 screen.",
								"User should be able to close account successfully.",
								"Close account successful. ", true);
				}
			}
			else{
			HtmlReporter.WriteStep("Check whether open regular CASA account will close from CH001 screen.",
					"User should be able to close account successfully.",
					"Close account successful. ", true);
			}
		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Check whether open regular CASA account will close from CH001 screen.",
					"User should be able to close account successfully. ",
					"Close account unsuccessful. " + e.getMessage(), false);
		}
	
	}
	
	public static void Account_Open_Today_CH021() throws  Exception{
		try{
			pkgFCRPageObjects.FCR_CASAPageObjects.Account_Open_Today_CH021();
			String AccStatus;
			int intcnt = 0;
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			//WebDr.setText("AccountNo", WebDr.getValue("CASA_Account"), "Enter account number");	
			WebDr.setText("AccountNo", WebDr.AccountNo, "Enter Account Number that is opened today");
			WebDr.rTab();
			WebDr.waitForPageLoaded();	
			do{
				AccStatus = WebDr.getSelectedDropdownValue("AccountStatus", "Verify Account Status as Opened Today");
				intcnt = intcnt + 1;
			}while ((!AccStatus.isEmpty()) && intcnt < 5);
			
			if (AccStatus.equals("Account Opened Today"))
				HtmlReporter.WriteStep("Check whether the user is able to view the account openned in 8051 in CH021 or not.",
					"User should be able to view the account openned in 8051 in CH021",
					"User is able to view the account openned in 8051 in CH021", true);
			else
				HtmlReporter.WriteStep("Check whether the user is able to view the account openned in 8051 in CH021 or not.",
						"User should be able to view the account openned in 8051 in CH021",
						"User is not able to view the account openned in 8051 in CH021", false);
		} catch (Exception e) {
			HtmlReporter.WriteStep("Check whether the user is able to view the account openned in 8051 in CH021 or not.",
					"User should be able to view the account openned in 8051 in CH021",
					"User is not able to view the account openned in 8051 in CH021" + e.getMessage(), false);
		}
	}
	
	public static void CashWithdrawalInvalid_1001() throws UnhandledAlertException, Exception {
		try {
			pkgFCRPageObjects.FCR_CASAPageObjects.CashWithdrawalInvalid_1001();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account No");
			WebDr.rTab();
			if(WebDr.strFCRCountry.equals("BBM")){
				
				if(WebDr.alertHandlingForErrors("Invalid account number", "Verify invalid account message"))	{
					
					HtmlReporter.WriteStep("Check whether the user is able to perform a transaction in an invalid account status or not",
					"User should not be to perform a transactions account having invalid status and system should give an error message.",
					"Cash Withdrawal unsuccessful for account having invalid status", true);
				}
				else{
					HtmlReporter.WriteStep("Check whether the user is able to perform a transaction in an invalid account status or not",
							"User should not be to perform a transactions account having invalid status and system should give an error message.",
							"Unable to verify transaction status", false);
				}	
			}
			/*if(WebDr.strFCRCountry.equals("BBK")){
				if(WebDr.alertHandlingForErrors("Closed", "Verify invalid account message"))	{
					
					HtmlReporter.WriteStep("Check whether the user is able to perform a transaction in an invalid account status or not",
					"User should not be to perform a transactions account having invalid status and system should give an error message.",
					"Cash Withdrawal unsuccessful for account having invalid status", true);
				}
				else{
					HtmlReporter.WriteStep("Check whether the user is able to perform a transaction in an invalid account status or not",
							"User should not be to perform a transactions account having invalid status and system should give an error message.",
							"Unable to verify transaction status", false);
				}	
				return;
			}
				
			WebDr.waitForPageLoaded();
			if(WebDr.strFCRCountry.equals("NBC")){
				WebDr.selectDropValueByVisibleText("TxnCurrency",WebDr.getValue("TxnCurrency"), "Select Txn Currency");
			}
			WebDr.setText("Amount", WebDr.getValue("Amount"), "Enter amount");
			WebDr.rTab();
			WebDr.AlertHandleOfflineChargeErrors();
			WebDr.setText("UserRefNo", WebDr.getValue("UserRefNo"), "Enter User Ref No");
			WebDr.click("Ok", "Click on OK");
			
			// SignatureVerfication
			WebDr.waitForPageLoaded();
			WebDr.click("Sign", "Click on Sign");
			WebDr.click("SignOk", "Click on OK");
			WebDr.waitForPageLoaded();
			WebDr.waitForNumberOfWindowsToEqual(3);
			WebDr.SwitchToLatestWindow();
			WebDr.waitForPageLoaded();
			WebDr.clickactivatewithmouse("SignZoom", "Click on signature window");
			WebDr.CloseWindowWithTitle("Signature");
			WebDr.SwitchToLatestWindow();
			WebDr.click("FastPath", "Click in the textfield");
			
			WebDr.click("SignVerified", "Click on Signature Verified");
			
			if(WebDr.strFCRCountry.equals("UG")){
				WebDr.click("SignCancel", "Click on Cancel");
			}

			// ScreenReturn
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("Ok", "Click on OK");
			WebDr.alertClickWithText("cash to vault");
			
			if(WebDr.strFCRCountry.equals("UG")){
				WebDr.alertClickWithText("Suntec");
				WebDr.alertClickWithText("Denomination");
				
				// Denomination
				WebDr.waitForPageLoaded();
				WebDr.DenominationEntry("Enter denomination");
				//WebDr.setText("Denomination", WebDr.getValue("Denomination"), "Enter Denomination");
				WebDr.click("D_Ok", "Click on OK");
	
				// ScreenReturn
				WebDr.waitForPageLoaded();
				WebDr.click("Ok", "Click on OK");
				
				WebDr.alertClickWithText("Suntec");
				WebDr.alertClickWithText("kool");
				// AuthWithComments
				WebDr.authWithComment();
			}
			
			if (WebDr.alertHandlingForErrors("Server Rejected Request", "Verify alert message")){	
				if (WebDr.isAlertPresent()){
					WebDr.alertHandlingForErrors("Account Closed", "Verify alert message");}
				HtmlReporter.WriteStep("Check whether the user is able to perform a transaction in an invalid account status or not",
					"User should not be to perform a transactions account having invalid status and system should give an error message.",
					"Cash Withdrawal unsuccessful for account having invalid status", true);
			}
			else
				HtmlReporter.WriteStep("Check whether the user is able to perform a transaction in an invalid account status or not",
						"User should not be to perform a transactions account having invalid status and system should give an error message.",
						"Unable to verify transaction status", false);
		*/
		} catch (Exception e) {
			e.printStackTrace();
			HtmlReporter.WriteStep("Check whether the user is able to perform a transaction in an invalid account status or not",
					"User should not be to perform a transactions account having invalid status and system should give an error message.",
					e.getMessage(), false);
		
		}
		
		}
	
	
	public static void ProductMasterMaintenance_CHM01() throws  Exception{
		try{
			pkgFCRPageObjects.FCR_CASAPageObjects.ProductMasterMaintenance_CHM01();
			
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.setText("ProductCode", WebDr.getValue("ProductCode"), "Enter Product Code");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			//Database Validation
			//FCRDBConnection.DBValidation_FetchValue("SELECT NAM_PRODUCT FROM CH_PROD_MAST WHERE COD_PROD='670'");
			//FCRDBConnection.DBValidation_VerifyValue();
			String strProdCode = WebDr.getTextBoxValue("ProductCode", "Get Value");			
			if ((! strProdCode.isEmpty()))
				HtmlReporter.WriteStep("Check whether the user is able to open and inquire about the valid product or not.",
					"User should be able to open and inquire about the existing products in the screen CHM01.",
					"User is be able to open and inquire about the existing products in the screen CHM01.", true);
			else
				HtmlReporter.WriteStep("Check whether the user is able to open and inquire about the valid product or not.",
						"User should be able to open and inquire about the existing products in the screen CHM01.",
						"User is not able to open and inquire about the existing products in the screen CHM01.", false);
		} catch (Exception e) {
			HtmlReporter.WriteStep("Check whether the user is able to open and inquire about the valid product or not.",
					"User should be able to open and inquire about the existing products in the screen CHM01.",
					"User is not able to open and inquire about the existing products in the screen CHM01." + e.getMessage(), false);
		}
	}
	
	public static void CASA_Account_Status_CHM21() throws Exception {
		try{
			pkgFCRPageObjects.FCR_CASAPageObjects.CASA_Account_Status_CHM21();
			String setStatus;
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			//WebDr.setText("AcctNo", WebDr.AccountNo, "Enter Account Number to be closed");
			WebDr.setText("AcctNo", WebDr.getValue("AccountNo"), "Enter Account Number");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			
			String strAppChoice = WebDr.getSelectedDropdownValue("CurrentAccStatus", "Get current account status");
			if (strAppChoice.contains("No")){
				 setStatus = WebDr.getValue("StatusChoice1");
			}
			else{
				 setStatus = WebDr.getValue("StatusChoice2");
			}

			WebDr.selectDropValueByVisibleText("StatusChoice", setStatus, "Select Status to Change");
			WebDr.selectDropValueByVisibleText("StatusReason", WebDr.getValue("StatusReason"), "Select Reason to Change");
			WebDr.clickwithmouse("OK_CHM21", "Click OK button");
			//WebDr.waitForPageLoaded();
			if (WebDr.isAlertPresent())
				WebDr.alertHandlingForErrors("Record Modified", "Verify alert message");
			LOAN.logoutwithJSCommand(false);
			LOAN.superLogin();
			
			HtmlReporter.WriteStep("Check whether the user is able to change the status of a Saving/Current account or not.",
					"User should be able to change the status in the screen for a saving and current account successfully.",
					"Account status change successful.", true);
		} catch (Exception e) {
			HtmlReporter.WriteStep("Check whether the user is able to change the status of a Saving/Current account or not.",
					"User should  be able to change the status in the screen for a saving and current account successfully.",
					"Account status change unsuccessful." + e.getMessage(), false);
			LOAN.logoutwithJSCommand(false);
			LOAN.superLogin();
		}
		try{
			pkgFCRPageObjects.FCR_CASAPageObjects.CASA_CH021_Authorize();
			WebDr.fastPath(WebDr.getValue("FastPathAuth"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("AuthorizeBtn", "Click on authorize button");
//			WebDr.setText("AcctNo", WebDr.AccountNo, "Enter Account Number to be Authorized");
			WebDr.setText("AcctNo", WebDr.getValue("AccountNo"), "Enter Account Number to be Authorized");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("OK_CH021", "Click OK button");
			WebDr.alertHandlingForErrors("Record Authorized", "Verify alert message");
			HtmlReporter.WriteStep("Check whether the user is able to authorise the changed status of an account in CH021 or not.",
					"User should be able to authorise the changed status in CH021 successfully.",
					"Account status authorized successful. ", true);
			LOAN.logout();	
			LOAN.login();
		} catch (Exception e) {
			HtmlReporter.WriteStep("Check whether the user is able to authorise the changed status of an account in CH021 or not.",
					"User should be able to authorise the changed status in CH021 successfully.",
					"Account status authorized unsuccessful . " + e.getMessage(), false);
			LOAN.logout();	
			LOAN.login();
		}
	}
	
	public static void CASAInterestRateTiersMaintenance_CHM02() throws  Exception{
		try{
			pkgFCRPageObjects.FCR_CASAPageObjects.CASAInterestRateTiersMaintenance_CHM02();
			
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();	
			
			WebDr.click("PlanCodePickList", "Click on the Plan Code Pick List");
			
			WebDr.rTab();
			WebDr.rTab();
			WebDr.rEnter();
			
			String strPlanCode = WebDr.getTextBoxValue("PlanCode", "Get Value");
			
			
			if (! (strPlanCode.isEmpty()))
				HtmlReporter.WriteStep("Check whether the user is able to navigate fast path CHM02 or not.",
					"Valid teller should be able to navigate the FP CHM02.",
					"Valid teller is able to navigate the FP CHM02.", true);
			else
				HtmlReporter.WriteStep("Check whether the user is able to navigate fast path CHM02 or not.",
						"Valid teller should be able to navigate the FP CHM02.",
						"Valid teller is not able to navigate the FP CHM02.", false);
		} 
			
			catch (Exception e) {
			HtmlReporter.WriteStep("Check whether the user is able to navigate fast path CHM02 or not.",
					"Valid teller should be able to navigate the FP CHM02.",
					"Valid teller is not able to navigate the FP CHM02." + e.getMessage(), false);
		}
	}
	
	public static void CASSViewAccountStatement_CH031() throws  Exception{
		try{
			pkgFCRPageObjects.FCR_CASAPageObjects.CASSViewAccountStatement_CH031();
			
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();	
			String sysdate = WebDr.getTextBoxValue("SystemDate", "System date is fetched and displayed");	
			WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number for statement enquiry");
			
			WebDr.rTab();
			WebDr.waitForPageLoaded();	
			
			WebDr.click("RadioTransaction", "Click on Transactions radio button");
			
			//WebDr.rClearUpdateTextField("StartDate", WebDr.ChangeDatebyStaticDays(-3) , "Enter start date"); 
			WebDr.rClearUpdateTextField("StartDate", WebDr.getValue("StartDate") , "Enter start date");
			WebDr.rTab();

			if (! WebDr.getValue("EndDate").isEmpty()){
				WebDr.rDelete();
				//WebDr.setText("EndDate",sysdate , "Enter end date");
				WebDr.setText("EndDate",WebDr.getValue("EndDate") , "Enter end date");
				WebDr.rTab();
			}

			WebDr.waitForPageLoaded();
//			WebDr.click("AccountNo", "Click on acc no");
			WebDr.clickwithmouse("Inquire", "Click on Inquire button");	
			WebDr.waitForPageLoaded();
			
			//if (! (strPlanCode.isEmpty()))
				HtmlReporter.WriteStep("Check whether the user is able to view the transaction in CH031 or not.",
					"The user should be able to view the transaction in CH031",
					"Transactions are displayed successfully", true);
		} 
			catch (Exception e) {
				HtmlReporter.WriteStep("Check whether the user is able to view the transaction in CH031 or not.",
						"The user should be able to view the transaction in CH031",
						"Transactions are not displayed successfully" + e.getMessage(), false);
		}
	}
	
	public static void CASAModifyCustomerShortName_7101() throws  Exception{
		try{
			pkgFCRPageObjects.FCR_CASAPageObjects.CASAModifyCustomerShortName_7101();
			
			Random randno = new Random();
			int randint1 = randno.nextInt(1000);
			
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();	
			
			WebDr.selectDropValueByVisibleText("ChangeType", WebDr.getValue("ChangeType"), "Select change type");
			WebDr.rTab();
			WebDr.waitForPageLoaded();	
			WebDr.setText("CustomerIC", WebDr.getValue("CustomerIC"), "Enter Customer IC");
			WebDr.rTab();
			WebDr.selectDropValueByVisibleText("CustomerType", WebDr.getValue("CustomerType"), "Select Customer Type");
			WebDr.rTab();
			WebDr.waitForPageLoaded();	
			WebDr.setText("NewShortName", WebDr.getValue("NewShortName") + randint1, "Enter New Customer Short Name");
			WebDr.rTab();
			WebDr.clickwithmouse("OK", "Click on OK");
			WebDr.authWithComment();
			
			if (WebDr.isAlertPresent())
				WebDr.alertAccept();
			
			HtmlReporter.WriteStep("Check whether customer short name can be modified from 7101 screen.",
					"User should be able to modify customer short name from 7101 screen.",
					"Customer short name is modified successfully from 7101 screen as - " + WebDr.getValue("NewShortName") + randint1, true);
			
		} 
			catch (Exception e) {
				HtmlReporter.WriteStep("Check whether customer short name can be modified from 7101 screen.",
						"User should be able to modify customer short name from 7101 screen.",
						"Customer short name is not modified successfully from 7101 screen." + e.getMessage(), false);
		}
	}
	
	public static void Cust_SignPhoto_Delink_7103() throws Exception {
		String strEnterCustID;
		if (! WebDr.CustID.isEmpty()){
			strEnterCustID = WebDr.CustID;
		}else{
			strEnterCustID = WebDr.getValue("CustomerID");
		}
		try {
			// Enter_Details
			pkgFCRPageObjects.FCR_CASAPageObjects.Cust_SignPhoto_Delink_7103();				
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("ImageType",WebDr.getValue("ImageType"), "Select Image Type");
			WebDr.selectDropValueByVisibleText("SelectionCriteria",WebDr.getValue("SelectionCriteria"), "Select Selection Criteria");
			WebDr.setText("CustomerID", strEnterCustID, "Enter CustomerID");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.waitForNumberOfWindowsToEqual(3);
			WebDr.SwitchToLatestWindow();
			WebDr.CloseWindowWithTitle("Signature");
			WebDr.SwitchToLatestWindow();
			
//			WebDr.click("FastPath", "Click in fastpath field");
//			WebDr.clickwithmouse("OK_7102", "Click OK");
//			WebDr.SwitchToLatestWindow();
//			WebDr.waitForPageLoaded();
			
			WebDr.click("FastPath", "Click in fastpath field");
			WebDr.clickwithmouse("OK_7102", "Click OK");
			WebDr.clickElementImageSikuli("NoSuperOKButton.PNG", 5, "Click on OK");

				HtmlReporter.WriteStep("Check whether customer Image can be delinked from 7103 screen.",
					"The user should be able to delink customer Image",
					"Image delinked Successfully. ", true);

		}catch(Exception errAuth){
			errAuth.printStackTrace();
			HtmlReporter.WriteStep("Check whether customer Image can be delinked from 7103 screen.",
					"The user should be able to delink customer Image",
					"Image is not delinked Successfully. ", false);
		}
	}
	
	public static void CASA_Invalid_Standing_Instruction() throws Exception {
		
		try {
			// Enter_Details
			pkgFCRPageObjects.FCR_CASAPageObjects.CASA_Invalid_Standing_Instruction();				
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("AddBtn", "Selct Mode ADD");
			WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			if(WebDr.alertHandlingForErrors("This facility is not supported", "Verify Alert Message")){

				HtmlReporter.WriteStep("Check whether the user is not able to perform SI on account of a product having SI flag modified to disabled or not.",
					"The user should not be able to perform SI",
					"Adding standing Instruction unsuccessful. ", true);
			}
			else {
			
				HtmlReporter.WriteStep("Check whether the user is not able to perform SI on account of a product having SI flag modified to disabled or not.",
					"The user should is able to perform SI",
					"Adding standing Instruction successful.", false);
			}
		}catch(Exception errAuth){
			errAuth.printStackTrace();
			HtmlReporter.WriteStep("Check whether the user is not able to perform SI on account of a product having SI flag modified to disabled or not.",
					"The user should is able to perform SI",
					"Adding standing Instruction successful. ", false);
		}
	}
	
		public static void CASA_SweepIN_CHM39() throws Exception {
				
				try {
					// Enter_Details
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_SweepIN_CHM39();				
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("AddBtn", "Select Mode ADD");	
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
					WebDr.rTab();
					String InstructionNumber = WebDr.getTextBoxValue("Instr_No", "Get the Instruction Number");		
					WebDr.setText("SweepInAccountNo", WebDr.getValue("SweepInAccountNo"), "Enter SweepIn Account Number");
					WebDr.click("CHM39_OK","Click on the OK button");
					if(WebDr.isAlertPresent())
						WebDr.alertHandlingForErrors("Authorisation Pending", "Check for alert message");
					WebDr.click("FastPath", "Click in the field");
					WebDr.click("CHM39_Close","Click on the CLOSE button");
					LOAN.logout();
					WebDr.waitForPageLoaded();
					LOAN.superLogin();
					WebDr.waitForPageLoaded();
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_SweepIN_CHM39();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("AuthorizeBtn","Select Mode Authorize");
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("AccountNo","Click on AccountNo");
					WebDr.waitForPageLoaded();
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
					WebDr.rTab();
					WebDr.setText("Instr_No", InstructionNumber , "Enter Instruction Number");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("CHM39_OK","Click on the OK button");
					if(WebDr.SwitchToLatestAlertCheck("Record Authorized")){
		
						HtmlReporter.WriteStep("Check whether the user is able to add a 'Sweep in' record or not.",
							"The user should  be able to add sweep in record",
							"Sweep In addition successful. ", true);
					}
					else {
					
						HtmlReporter.WriteStep("Check whether the user is able to add a 'Sweep in' record or not.",
							"The user should  be able to add sweep in record",
							"Sweep In addition unsuccessful. ", false);
					}
					WebDr.waitForPageLoaded();
					LOAN.logout();
					LOAN.login();
				}catch(Exception errAuth){
					errAuth.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to add a 'Sweep in' record or not.",
							"The user should  be able to add sweep in record",
							"Sweep In addition unsuccessful. ", false);
				}
			}
			
			public static void CASA_Modify_Sign_Link_7111() throws Exception {
				String strEnterCustID;
				if (! WebDr.CustID.isEmpty()){
					strEnterCustID = WebDr.CustID;
				}else{
					strEnterCustID = WebDr.getValue("CustomerID");
				}
				try {
					// Enter_Details
					pkgFCRPageObjects.FCR_CIFPageObjects.Cust_Sign_Link_7102();				
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.selectDropValueByVisibleText("ImageType",WebDr.getValue("ImageType"), "Select Image Type");
					WebDr.selectDropValueByVisibleText("SelectionCriteria",WebDr.getValue("SelectionCriteria"), "Select Selection Criteria");
					WebDr.setText("CustomerID", strEnterCustID, "Enter CustomerID");
					WebDr.rTab();
					WebDr.click("FastPath", "Click in fastpath field");
					WebDr.clickwithmouse("OK_7102", "Click OK");
					WebDr.SwitchToLatestWindow();
					WebDr.waitForPageLoaded();
					WebDr.waitForPageLoaded();
					WebDr.waitForPageLoaded();
					WebDr.waitForPageLoaded();
					try{
			//			if (! WebDr.waitElementImageSikuli("SignImageBrowse.png", 120, "Verify Browse button")){
			//				WebDr.CloseWindowWithTitle("Signature");
			//				WebDr.SwitchToLatestWindow();
			//			}
							WebDr.clickElementImageSikuli("SignImageBrowse.png", 120, "Verify Browse button");
					}catch(Exception e){
						e.printStackTrace();
					}
					Thread.sleep(2000);
					System.out.println(Constant.SikuliScreenPath + "SignLink7102.png");
					WebDr.keyboard(Constant.SikuliScreenPath + "SignLink7102.png");
					WebDr.rTab();
					WebDr.rTab();
					WebDr.rEnter();
					WebDr.SwitchToLatestWindow();
					WebDr.clickwithmouse("Image_OK", "Click OK on upload page");
					if(WebDr.SwitchToLatestAlertCheck("Linked Successfully")){
						HtmlReporter.WriteStep("Check whether the user is able to modify an image/signature  in the screen 7111.",
							"User should be able to modify an image/signature to a customer successfully.",
							"Image modified Successful. ", true);
					}
					else {
						HtmlReporter.WriteStep("Check whether the user is able to modify an image/signature  in the screen 7111.",
							"User should be able to modify an image/signature to a customer successfully. ",
							"Image modification Unsuccessful. ", false);
					}
					
				}
				catch (Exception e) {
					e.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to modify an image/signature  in the screen 7111.",
							"User should be able to modify an image/signature to a customer successfully. ",
							"Image modification Unsuccessful. ", false);
				
				}
				
				try{
					LOAN.logout();
					WebDr.waitForPageLoaded();
					LOAN.superLogin();
					WebDr.waitForPageLoaded();
					pkgFCRPageObjects.FCR_CIFPageObjects.Cust_Sign_Link_7102();
					WebDr.fastPath(WebDr.getValue("FastPathAuth"));
					WebDr.waitForPageLoaded();
					
					
					WebDr.selectDropValueByVisibleText("ImageType",WebDr.getValue("ImageType"), "Select Image Type");
					WebDr.selectDropValueByVisibleText("SelectionCriteria",WebDr.getValue("SelectionCriteria"), "Select Selection Criteria");
					WebDr.setText("CustomerID", strEnterCustID, "Enter CustomerID");
					WebDr.rTab();
					WebDr.SwitchToLatestWindow();
					WebDr.waitForPageLoaded();
					WebDr.waitForPageLoaded();
					WebDr.waitForPageLoaded();
					WebDr.waitForPageLoaded();
					WebDr.clickactivatewithmouse("SignZoom", "Click on signature window");
					WebDr.CloseWindowWithTitle("Signature");
					WebDr.SwitchToLatestWindow();
					WebDr.click("FastPath", "Click in fastpath field");
					WebDr.clickwithmouse("OK_7102", "Click OK on authorise image page");
					if(WebDr.SwitchToLatestAlertCheck("Image Authorization Successful")){
						HtmlReporter.WriteStep("Check whether the user is able to authorise an image/signature  in the screen 7104.",
							"User should be able to authorise an image/signature to a customer successfully. ",
							"Image Linked and Authorised Successfully. ", true);
					}
					else {
						HtmlReporter.WriteStep("Check whether the user is able to authorise an image/signature  in the screen 7104.",
							"User should be able to authorise an image/signature to a customer successfully. ",
							"Image authorise Unsuccessful. ", false);
					}
					LOAN.logout();	
					LOAN.login();
					WebDr.waitForPageLoaded();
				}catch(Exception errAuth){
					errAuth.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to authorise an image/signature  in the screen 7104.",
							"User should be able to authorise an image/signature to a customer successfully. ",
							"Image Authorised Unsuccessful.", false);
				}
			}
	
			public static void Reversal_6006() throws Exception {
				String txnStatus= null;
				try
				{
				pkgFCRPageObjects.FCR_CASAPageObjects.Reversal_6006();
				do{
				WebDr.fastPath(WebDr.getValue("FastPath1"));
				WebDr.waitForPageLoaded();
				
				WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
				WebDr.setText("Mnemonic", WebDr.getValue("Mnemonic"), "Enter Transaction Mnemonic");
				WebDr.clickwithmouse("GET_Btn", "Click GET button");
				txnStatus = WebDr.getCellTextBoxValue("State", "Get transaction status");
				System.out.println(txnStatus);
				if (txnStatus.equals("Sent")){
					WebDr.click("Mnemonic", "Click on mnemonic field");
					WebDr.rTab();
					WebDr.rTab();
					WebDr.rTab();
					WebDr.rEnter();
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("Reversal_Btn", "Click Reversal button");
					if (WebDr.strFCRCountry.equals("BBM")){
					WebDr.authWithComment();
					WebDr.alertHandlingForErrors("Serial", "Verify serial number");
					}
				}
				
				}while(! txnStatus.equals("Reversed"));
				if (txnStatus.equals("Reversed")){
				HtmlReporter.WriteStep("Check whether the user is able to perform a reversal for a transaction performed.",
						"User should be able to reverse a transaction successfully. ",
						"Transaction reversed successful.", true);
				}
				else{
					HtmlReporter.WriteStep("Check whether the user is able to perform a reversal for a transaction performed.",
							"User should be able to reverse a transaction successfully. ",
							"Transaction reversed unsuccessful.", false);
				}
				}
				catch (Exception e) {
					e.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to perform a reversal for a transaction performed.",
							"User should be able to reverse a transaction successfully. ",
							"Transaction reversed unsuccessful.", false);
				
				}
			}
			
		
			
			public static void CASA_ModifyCustomerID_CIM39() throws  Exception{
				try{
					pkgFCRPageObjects.FCR_CASAPageObjects.CASAModifyCustomerID_CIM39();
					String strAppAccount = null;
					String celltext;
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();			
					if(WebDr.strFCRCountry.equals("BBK"))
					{
						WebDr.clickwithmouse("ModifyBtn", "Select Mode MODIFY");
					}
					WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"), "Select Search Criteria");
					WebDr.rTab();
					WebDr.waitForPageLoaded();	
					WebDr.setText("CustInfo", WebDr.getValue("CustInfo"), "Enter Cust Info");
					WebDr.rTab();
					WebDr.SwitchToLatestWindow();
					WebDr.waitForPageLoaded();
					WebDr.rTab();
					WebDr.rTab();
					WebDr.rTab();
					WebDr.rEnter();
					WebDr.SwitchToLatestWindow();
		
					WebDr.getTextBoxValue("CustInfo", "Get value");
					WebElement wbDocs = Driver.driver.findElement(By.xpath("//table[@id='grdAccountDetails']/tbody"));
					List obCellDatatr = wbDocs.findElements(By.tagName("tr"));
					String accstatus = WebDr.getValue("AccountStatus");
					int introws = obCellDatatr.size();
					boolean valfound = false;
					//List intCellData = Driver.driver.findElements(By.xpath(".//table[@id='grdDocDetails']//tr//td[@class='TGridURL']"));
					System.out.println("-------------------row count" + introws);
					for(int i=2;i<=introws;i++){
						WebDr.waitForPageLoaded();
						strAppAccount = Driver.driver.findElement(By.xpath("//table[@id='grdAccountDetails']//tr["+i+"]/td[1]")).getText();
						celltext = Driver.driver.findElement(By.xpath("//table[@id='grdAccountDetails']//tr["+i+"]/td[3]")).getText();
						if (celltext.equals(accstatus)){
							Driver.driver.findElement(By.xpath("//table[@id='grdAccountDetails']//tr["+i+"]/td[3]")).click();
							WebDr.rEnter();
							valfound = true;
							break;
						}
						WebDr.waitForPageLoaded();
					}
					
					if (valfound == false)
						throw new Exception();
					
					WebDr.selectDropValueByVisibleText("NewSearchCriteria1", WebDr.getValue("NewSearchCriteria"), "Select Search Criteria");
					WebDr.rTab();
					WebDr.waitForPageLoaded();	
					WebDr.setText("NewCustInfo1", WebDr.getValue("NewCustInfo"), "Enter New Cust Info");
					WebDr.rTab();
					WebDr.SwitchToLatestWindow();
					WebDr.waitForPageLoaded();
					WebDr.rTab();
					WebDr.rTab();
					WebDr.rTab();
					WebDr.rEnter();
					WebDr.SwitchToLatestWindow();
					WebDr.waitForPageLoaded();
					
					WebDr.clickwithmouse("OK", "Click on OK");
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("OK_CIM39", "Click on OK in CIM39 screen");
					if(WebDr.strFCRCountry.equals("NBC") || WebDr.strFCRCountry.equals("UG"))
					{
						WebDr.authOnlyCreds();
						WebDr.SwitchToLatestAlertCheck("Customer Id changed successfully");
					}
					if(WebDr.strFCRCountry.equals("BBM"))
					{
						WebDr.authOnlyCreds();
						WebDr.SwitchToLatestAlertCheck("Customer Id changed succesfully");
					}
					if(WebDr.multiplealertHandlingForErrors("Authorisation Pending", "Verify alert message"))
					{	
						WebDr.alertAccept();
						LOAN.logout();
						WebDr.waitForPageLoaded();
						LOAN.superLogin();
						WebDr.waitForPageLoaded();
						pkgFCRPageObjects.FCR_CASAPageObjects.CASAModifyCustomerID_CIM39();		
						WebDr.fastPath(WebDr.getValue("FastPath"));
						WebDr.waitForPageLoaded();
						WebDr.click("AuthorizeBtn","Click on Authorize radio button");
						WebDr.waitForPageLoaded();
						WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"), "Select Search Criteria");
						WebDr.rTab();
						WebDr.waitForPageLoaded();	
						WebDr.setText("CustInfo", WebDr.getValue("CustInfo"), "Enter Cust Info");
						WebDr.rTab();
						WebDr.SwitchToLatestWindow();
						WebDr.waitForPageLoaded();
						WebDr.rTab();
						WebDr.rTab();
						WebDr.rTab();
						WebDr.rEnter();
						WebDr.SwitchToLatestWindow();
						WebDr.clickwithmouse("OK", "Click on OK");
						if(WebDr.SwitchToLatestAlertCheck("Record Authorized")){
							
							HtmlReporter.WriteStep("Check whether customer ID can be modified� from CIM39 screen.",
									"User should be able to modify customer ID from CIM39 screen.",
									"Customer ID is modified from successfully to " +  WebDr.getValue("NewCustInfo") + "for account number " + strAppAccount, true);
						}
					}
//					if (WebDr.isAlertPresent())
					
					
					HtmlReporter.WriteStep("Check whether customer ID can be modified� from CIM39 screen.",
							"User should be able to modify customer ID from CIM39 screen.",
							"Customer ID is modified from successfully to " +  WebDr.getValue("NewCustInfo") + "for account number " + strAppAccount, true);
					
				} 
					catch (Exception e) {
						HtmlReporter.WriteStep("Check whether customer ID can be modified� from CIM39 screen.",
								"User should be able to modify customer ID from CIM39 screen.",
								"Customer ID is not modified from successfully to " +  WebDr.getValue("NewCustInfo"), false);
						e.printStackTrace();
				}
			}
			
			public static void Balance_Inquiry_7002() throws Exception {
				try{
				pkgFCRPageObjects.FCR_CASAPageObjects.BalanceInquiry_7002();				
				WebDr.fastPath(WebDr.getValue("FastPath"));
				WebDr.waitForPageLoaded();
				WebDr.setText("AccountNumber", WebDr.getValue("AccountNumber"), "Enter Account Number");
				WebDr.rTab();
				WebDr.waitForPageLoaded();
				
				//Code for getting balance. 
				HtmlReporter.WriteStep("Check whether the user is able to inquire the Balance in the 7002 screen", "User should be able to inquire the Balance in the 7002 screen", "User is able to inquire the Balance in the 7002 screen - " +WebDr.TDAccountNo,true);
			}
			catch(Exception exc){
				exc.printStackTrace();
				HtmlReporter.WriteStep("Check whether the user is able to inquire the Balance in the 7002 screen", "User should be able to inquire the Balance in the 7002 screen", exc.getMessage(),false);
			}
				
			}
			
			
			public static void CASA_Modify_AccountAddress_CHM36() throws Exception {
				try {
					// Enter_Details
					String addr=null;
					String setaddr=null;
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_Modify_AccountAddress_CHM36();				
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.click("ModifyBtn","Click on Modify");
					WebDr.waitForPageLoaded();
					WebDr.setText("AccountNumber", WebDr.getValue("AccountNumber"), "Enter Account Number");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.setText("SerialNumber", WebDr.getValue("SerialNumber"), "Enter Serial Number");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					
					addr = WebDr.getTextBoxValue("Address1","Get address 1");
					setaddr = addr;
					if (addr.contains(WebDr.getValue("ModifyAddress")))
						setaddr = addr.replace(WebDr.getValue("ModifyAddress"),"");
					else
						setaddr = setaddr + WebDr.getValue("ModifyAddress");
					
					WebDr.setText("Address1", setaddr,"Enter address");
					WebDr.clickwithmouse("OK", "Click on OK");
					if(WebDr.SwitchToLatestAlertCheck("Record Modified")){
						HtmlReporter.WriteStep("Check whether the account address can be modified from CHM36 screen.",
							"User should be able to modify account address successfully",
							"User is able to modify account address successfully", true);
					}
					else {
						HtmlReporter.WriteStep("Check whether the account address can be modified from CHM36 screen.",
							"User should be able to modify account address successfully",
							"User is not able to modify account address successfully", false);
					}
				}
				catch (Exception e) {
					e.printStackTrace();
					HtmlReporter.WriteStep("Check whether the account address can be modified from CHM36 screen.",
							"User should be able to modify account address successfully",
							"User is not able to modify account address successfully", false);
				}
				try{
					LOAN.logout();
					WebDr.waitForPageLoaded();
					LOAN.superLogin();
					WebDr.waitForPageLoaded();
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_Modify_AccountAddress_CHM36();		
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.click("AuthorizeBtn","Click on Authorize");
					WebDr.waitForPageLoaded();
					WebDr.setText("AccountNumber", WebDr.getValue("AccountNumber"), "Enter Account Number");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.setText("SerialNumber", WebDr.getValue("SerialNumber"), "Enter Serial Number");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("OK", "Click on OK");
//					WebDr.clickwithmouseandacceptalert("OK", "Click on OK");
					if(WebDr.SwitchToLatestAlertCheck("Record Authorized")){
						HtmlReporter.WriteStep("Check whether the account address can be modified from CHM36 screen.",
							"User should be able to modify account address successfully",
							"User is able to modify and authorize account address successfully", true);
					}
					else {
						HtmlReporter.WriteStep("Check whether the account address can be modified from CHM36 screen.",
							"User should be able to modify account address successfully",
							"User is not able to authorize account address successfully", false);
					}
					LOAN.logout();	
					LOAN.login();
					WebDr.waitForPageLoaded();
				}catch(Exception errAuth){
					errAuth.printStackTrace();
					HtmlReporter.WriteStep("Check whether the account address can be modified from CHM36 screen.",
							"User should be able to modify account address successfully",
							"User is not able to authorize account address successfully", false);
				}
			}
			
			
			public static void CASA_StandingInstruction_CHM31() throws Exception {
				try {
					// Enter_Details
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_StandingInstruction_CHM31();				
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("AddBtn", "Selct Mode ADD");//6000091365      
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
					WebDr.rTab();
					String InstructionNumber = WebDr.getTextBoxValue("Instr_No", "Get the Instruction Number");		
					WebDr.selectDropValueByVisibleText("InstructionType", WebDr.getValue("InstructionType"), "Select Instruction Type");
					WebDr.setText("PriorityNo", InstructionNumber, "Enter Priority Number");
					WebDr.selectDropValueByVisibleText("Freqeuncy", WebDr.getValue("Freqeuncy"), "Select Freqeuncy");
					WebDr.rClearUpdateTextField("Amount",WebDr.getValue("Amount"),"Enter Amount");
					WebDr.setText("BenefAccountNo", WebDr.getValue("BenefAccountNo"), "Enter Beneficiary Account Number");
					WebDr.rClearUpdateTextField("EndDate", WebDr.ChangeDatebyStaticDays(180), "Enter End Date");
					WebDr.rClearUpdateTextField("NextDate", WebDr.ChangeDatebyStaticDays(30), "Enter Next Date");
					WebDr.rClearUpdateTextField("Retries", WebDr.getValue("Retries") , "Enter No. of Retry");
					WebDr.setText("Narrative", WebDr.getValue("Narrative"), "Enter Narrative");
					WebDr.click("CHM31_OK","Click on the OK button");
					if(WebDr.isAlertPresent())
						WebDr.alertHandlingForErrors("Authorisation Pending", "Check for alert message");
					WebDr.click("FastPath", "Click in the field");
					WebDr.click("CHM31_Close","Click on the CLOSE button");
					LOAN.logout();
					WebDr.waitForPageLoaded();
					LOAN.superLogin();
					WebDr.waitForPageLoaded();
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_StandingInstruction_CHM31();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("AuthorizeBtn","Select Mode Authorize");
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
					WebDr.rTab();
					WebDr.setText("Instr_No", InstructionNumber , "Enter Instruction Number");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("CHM31_OK","Click on the OK button");
					if(WebDr.SwitchToLatestAlertCheck("Record Authorized")){
		
						HtmlReporter.WriteStep("Check whether the user is able to add a 'Standing Instruction' record or not.",
							"The user should  be able to add Standing Instruction record",
							"Standing Instruction addition successful. ", true);
					}
					else {
					
						HtmlReporter.WriteStep("Check whether the user is able to add a 'Standing Instruction' record or not.",
							"The user should  be able to add Standing Instruction record",
							"Standing Instruction addition unsuccessful. ", false);
					}
					WebDr.waitForPageLoaded();
					LOAN.logout();
					LOAN.login();
				}catch(Exception errAuth){
					errAuth.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to add a 'Standing Instruction' record or not.",
							"The user should  be able to add Standing Instruction record",
							"Standing Instruction addition unsuccessful. ", false);
				}
			}
			
			public static void CASA_GL_Credit_CASA_Debit_1460() throws Exception {
				try{
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_GLCreditCASADebit_1460();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.setText("GLCurrency", WebDr.getValue("GLCurrency"), "Select GL Currency");
					WebDr.waitForPageLoaded();
					WebDr.setText("GLAccountNo", WebDr.getValue("GLAccountNo"), "Select GL AccountNo");
					WebDr.waitForPageLoaded();
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.setText("TxnAmount", WebDr.getValue("TxnAmount"), "Select Transaction Amount");
					WebDr.setText("RefNumber", WebDr.getValue("RefNumber"), "Select Reference Number");
					WebDr.setText("UserRefNumber", WebDr.getValue("UserRefNumber"), "Select User Reference Number");
					WebDr.clickwithmouse("OKButton", "Click on the OK Button");
					//WebDr.waitForPageLoaded();
					WebDr.rEnter();
					WebDr.waitForPageLoaded();
					//WebDr.authWithComment();
					WebDr.authWithAlertComment();
					//WebDr.alertClickWithText("kool");
					//WebDr.authWithComment();

					/*// Denomination
					WebDr.waitForPageLoaded();
					WebDr.alertClickWithText("Denomination");
					WebDr.DenominationEntry("Enter Denomination");
					WebDr.clickwithmouse("OKDenomButton", "Click on the Denomination OK Button");
					WebDr.clickwithmouse("OKButton", "Click on the OK Button");
					WebDr.authWithComment();
					
					//WebDr.SwitchToLatestAlertCheck("Serial Number is");
*/					
					try{
						
						if (WebDr.multiplealertHandlingForErrors("Transaction sequence number is", "Click on the Transaction Sequence number generated"))
							HtmlReporter.WriteStep("Check whether the user is able to Debit CASA credit GL from 1460 screen",
									"User should be able to Debit CASA credit GL from 1460 screen",
									"Transaction successful. ", true);
						else
							HtmlReporter.WriteStep("Check whether the user is able to Debit CASA credit GL from 1460 screen",
									"User should be able to Debit CASA credit GL from 1460 screen",
									"Transaction unsuccessful. ", false);
						

					}catch(Exception e){
						e.printStackTrace();
					}
				}catch(Exception error){
					error.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to Debit CASA credit GL from 1460 screen",
							"User should be able to Debit CASA credit GL from 1460 screen",
							"Transaction unsuccessful. ", false);
				}
			}
			
			
			public static void CASA_GL_Debit_CASA_Credit_1060() throws Exception {
				try{
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_GLDebitCASACredit_1060();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.selectDropValueByVisibleText("GLCurrency", WebDr.getValue("GLCurrency"), "Select GL Currency");
					WebDr.waitForPageLoaded();
					WebDr.rTab();
					WebDr.rTab();
					WebDr.setText("GLAccountNo", WebDr.getValue("GLAccountNo"), "Select GL AccountNo");
					WebDr.rTab();
					WebDr.rTab();
					WebDr.setText("TxnAmount", WebDr.getValue("TxnAmount"), "Select Transaction Amount");
					WebDr.rTab();
					WebDr.rTab();
					WebDr.setText("RefNumber", WebDr.getValue("RefNumber"), "Select Reference Number");
					WebDr.rTab();
					WebDr.setText("UserRefNumber", WebDr.getValue("UserRefNumber"), "Select User Reference Number");
					WebDr.rTab();
					WebDr.clickwithmouse("OKButton", "Click on the OK Button");
					
					if((WebDr.strFCRCountry.equals("BBM")) || (WebDr.strFCRCountry.equals("NBC")) )
					{
					  WebDr.authWithComment();
					}
					else
					{
					// Denomination
					WebDr.waitForPageLoaded();
					WebDr.alertClickWithText("Denomination");
					WebDr.DenominationEntry("Enter Denomination");
					WebDr.clickwithmouse("OKDenomButton", "Click on the Denomination OK Button");
					}
					if((WebDr.strFCRCountry.equals("BBK")))
					{
						WebDr.clickwithmouse("OKButton", "Click on the OK Button");
						WebDr.waitForPageLoaded();
						WebDr.authWithComment();
						WebDr.alertHandlingForErrors("Serial Number is", "Accept alert");
					}
					else
					{
					//WebDr.clickwithmouse("OKButton", "Click on the OK Button");
					WebDr.waitForPageLoaded();
					WebDr.alertHandlingForErrors("TZS : Cash more than maximum limit. Please sell cash to vault", "Accept alert");
					WebDr.waitForPageLoaded();
					WebDr.alertHandlingForErrors("Transaction sequence number is", "Accept alert");
					WebDr.waitForPageLoaded();
					WebDr.alertHandlingForErrors("Serial Number is", "Accept alert");
					}
					/*if(WebDr.alertClickWithText("TZS : Cash more than maximum limit. Please sell cash to vault"))
					{
						 HtmlReporter.WriteStep("Check whether the user is able to click on alert generated",
									"User should be able to to click on alert generated",
									"Alert accepted", true);
					}
					if(WebDr.alertClickWithText("Transaction sequence number is"))
					{
						 HtmlReporter.WriteStep("Check whether the user is able to click on alert generated",
									"User should be able to to click on alert generated",
									"Alert accepted", true);
					}
					if(WebDr.alertClickWithText("Serial Number is"))
					{
						 HtmlReporter.WriteStep("Check whether the user is able to click on alert generated",
									"User should be able to to click on alert generated",
									"Alert accepted", true);
					}				*/
					HtmlReporter.WriteStep("Check whether the user is able to Debit GL and credit CASA from 1060 screen",
							"User should be able to Debit GL and credit CASA from 1060 screen",
							"Transaction successful. ", true);	
				}catch(Exception error){
					error.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to Debit GL and credit CASA from 1060 screen",
							"User should be able to Debit GL and credit CASA from 1060 screen",
							"Transaction unsuccessful. ", false);
				}
			}
			
			public static void CASA_BranchStatus_Inquiry_BAM95() throws Exception {
				try{
					pkgFCRPageObjects.FCR_CASAPageObjects.BranchStatus_Inquiry_BAM95();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					
					WebDr.selectDropValueByVisibleText("BranchCode", WebDr.getValue("BranchCode"), "Select Branch Code");
					WebDr.waitForPageLoaded();
					WebDr.selectDropValueByVisibleText("BranchStatus", WebDr.getValue("BranchStatus"), "Select Branch Status");
					WebDr.waitForPageLoaded();
					if(WebDr.strFCRCountry.equals("BBK") || WebDr.strFCRCountry.equals("BBM"))
					{
					WebDr.click("Close", "Click on Close button");
					WebDr.waitForPageLoaded();
					}
					else
					{
						WebDr.click("OK", "Click on OK button");
						WebDr.waitForPageLoaded();
						WebDr.click("Close", "Click on Close button");
						WebDr.waitForPageLoaded();
					}
					HtmlReporter.WriteStep("Check whether Branch Batch Status Inquiry can de done from BAM95 screen.",
							"Branch Batch Status Inquiry should be done from BAM95 screen.",
							"Branch Batch Status Inquiry performed successfully from BAM95 screen.", true);
				} catch (Exception e) {
					HtmlReporter.WriteStep("Check whether Branch Batch Status Inquiry can de done from BAM95 screen.",
							"Branch Batch Status Inquiry should be done from BAM95 screen.",
							"Branch Batch Status Inquiry unsuccessful. " + e.getMessage(), false);
				}
			}
			
			public static void CASA_Chequebook_Issue_CHM37() throws Exception {
				try{
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_Chequebook_Issue_CHM37();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					
					WebDr.click("CHKBKAdd", "Click on Add button");
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account No");
					WebDr.rTab();				
					WebDr.waitForPageLoaded();
					
					if (WebDr.isAlertPresent())
						throw new Exception();
					String strSerial = WebDr.getTextBoxValue("CHKBKSerial", "Serial number");	
					WebDr.selectDropValueByVisibleText("CHKBKType", WebDr.getValue("CHKBKType"), "Select Type");
					WebDr.rTab();				
					WebDr.waitForPageLoaded();
					WebDr.rClearSelSendkeys("CHKBKleaves", WebDr.getValue("ChequeBookleaves"));
					WebDr.rTab();
					WebDr.selectDropValueByVisibleText("ChequeType", WebDr.getValue("ChequeType"), "Select Cheque Type");
					WebDr.rTab();				
					WebDr.waitForPageLoaded();
					WebDr.waitForPageLoaded();
					if(WebDr.strFCRCountry.equals("BBK"))
					{
						WebDr.selectDropValueByVisibleText("CHKBKDeliveryBranch", WebDr.getValue("CHKBKDeliveryBranch"), "Select Delivery Branch");
						WebDr.waitForPageLoaded();
						//001 - VPC
					}
					WebDr.click("Requested", "Click on Requested");
					
					if (WebDr.getValue("WaiveSC").equals("Yes"))
						WebDr.click("WaiveSCYes", "Click on WaiveSCYes");
					else
						WebDr.click("WaiveSCNo", "Click on WaiveSCNo");
					
					WebDr.clickwithmouse("OK", "Click on OK button");
					WebDr.multiplealertHandlingForErrors("Authorisation Pending", "Verify alert message");				
					WebDr.clickwithmouse("Close", "Click on Close button");
					WebDr.waitForPageLoaded();
					
					LOAN.logout();
					WebDr.waitForPageLoaded();
					
					LOAN.superLogin();
					WebDr.waitForPageLoaded();
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_Chequebook_Issue_CHM37();		
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.click("CHKBKAuthorize","Click on Authorize radio button");
					WebDr.waitForPageLoaded();
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account No");
					WebDr.rTab();				
					WebDr.waitForPageLoaded();
					WebDr.setText("CHKBKSerial", strSerial, "Enter Account No");
					WebDr.rTab();				
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("OK", "Click on OK button");
					WebDr.SwitchToLatestAlertCheck("Record Authorized");
					LOAN.logoutwithJSCommand(false);
					LOAN.login();
					
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_Chequebook_Issue_CHM37();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					
					WebDr.click("CHKBKModify", "Click on Add button");
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account No");
					WebDr.rTab();				
					WebDr.waitForPageLoaded();
					WebDr.setText("CHKBKSerial", strSerial, "Enter Account No");
					WebDr.rTab();				
					WebDr.waitForPageLoaded();
					WebDr.click("Issued", "Click on Issued");
					WebDr.clickwithmouse("OK", "Click on OK button");
					WebDr.multiplealertHandlingForErrors("Authorisation Pending", "Verify alert message");		
					WebDr.clickwithmouse("Close", "Click on Close button");
					WebDr.waitForPageLoaded();
					LOAN.logoutwithJSCommand(false);
					
					LOAN.superLogin();
					WebDr.waitForPageLoaded();
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_Chequebook_Issue_CHM37();		
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.click("CHKBKAuthorize","Click on Authorize radio button");
					WebDr.waitForPageLoaded();
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account No");
					WebDr.rTab();				
					WebDr.waitForPageLoaded();
					WebDr.setText("CHKBKSerial", strSerial, "Enter Account No");
					WebDr.rTab();		
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("OK", "Click on OK button");
					WebDr.SwitchToLatestAlertCheck("Record Authorized");
					LOAN.logoutwithJSCommand(false);
					LOAN.login();
					
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_Chequebook_Issue_CHM37();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					
					WebDr.click("CHKBKModify", "Click on Add button");
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account No");
					WebDr.rTab();				
					WebDr.waitForPageLoaded();
					WebDr.setText("CHKBKSerial", strSerial, "Enter Account No");
					WebDr.rTab();				
					WebDr.waitForPageLoaded();
					WebDr.click("Delivered", "Click on Requested");
					WebDr.clickwithmouse("OK", "Click on OK button");
					WebDr.multiplealertHandlingForErrors("Authorisation Pending", "Verify alert message");				
					WebDr.clickwithmouse("Close", "Click on Close button");
					WebDr.waitForPageLoaded();
					LOAN.logoutwithJSCommand(false);
					
					LOAN.superLogin();
					WebDr.waitForPageLoaded();
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_Chequebook_Issue_CHM37();		
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.click("CHKBKAuthorize","Click on Authorize radio button");
					WebDr.waitForPageLoaded();
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account No");
					WebDr.rTab();				
					WebDr.waitForPageLoaded();
					WebDr.setText("CHKBKSerial", strSerial, "Enter Account No");
					WebDr.rTab();		
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("OK", "Click on OK button");
					WebDr.SwitchToLatestAlertCheck("Record Authorized");
					LOAN.logoutwithJSCommand(false);
					LOAN.login();
					
					HtmlReporter.WriteStep("Check whether the user is able to issue a cheque book for a product where the flag is enabled or not.",
							"System should allow to issue a cheque book or a product where the flag is enabled.",
							"User is able to issue a chequebook successfully using CHM37 screen.", true);
				} catch (Exception e) {
					HtmlReporter.WriteStep("Check whether the user is able to issue a cheque book for a product where the flag is enabled or not.",
							"System should allow to issue a cheque book or a product where the flag is enabled.",
							"User is not able to issue a chequebook " + e.getMessage(), false);
					e.printStackTrace();
					LOAN.logoutwithJSCommand(false);
					LOAN.login();
				}
			}
			
			public static void CASA_SingleAccountTransfer_BA995() throws Exception {
				try{
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_SingleAccountTransfer_BA995();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.click("RecordAdd", "Click on Add");
					WebDr.waitForPageLoaded();
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
					WebDr.rTab();
					WebDr.click("FastPath", "Click in fastpath");
					if(WebDr.isAlertPresent()){
						WebDr.alertAccept();
						throw new Exception();
					}
					String strbranch = WebDr.getSelectedDropdownValue("Branch", "Existing Branch");
					if (! strbranch.equals(WebDr.getValue("TransferBranch")))
						WebDr.selectDropValueByVisibleText("TransferBranch", WebDr.getValue("TransferBranch"), "Select transfer branch");
					else
						WebDr.selectDropValueByVisibleText("TransferBranch", WebDr.getValue("TransferBranchTwo"), "Select transfer branch");
					WebDr.rTab();
					WebDr.clickwithmouse("OK","Click on OK button");
					WebDr.multiplealertHandlingForErrors("Authorisation Pending", "Verify alert message");								
					LOAN.logout();
					WebDr.waitForPageLoaded();
					LOAN.superLogin();
					WebDr.waitForPageLoaded();
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_SingleAccountTransfer_BA995();		
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.click("RecordAuth","Click on Authorize radio button");
					WebDr.waitForPageLoaded();
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account No");
					WebDr.rTab();				
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("OK", "Click on OK button");
					WebDr.SwitchToLatestAlertCheck("Record Authorized");
					HtmlReporter.WriteStep("Check whether Single Account Transfer can be done from BA995 screen.",
							"Single Account Transfer should be done from BA995 screen.",
							"Single Account Transfer is done from BA995 screen.", true);
					LOAN.logoutwithJSCommand(false);
					LOAN.login();
				}catch(Exception error){
					error.printStackTrace();
					HtmlReporter.WriteStep("Check whether Single Account Transfer can be done from BA995 screen.",
							"Single Account Transfer should be done from BA995 screen.","Single Account Transfer is done from BA995 screen.", false);
					LOAN.logoutwithJSCommand(false);
					LOAN.login();
				}
			}
			
			public static void CASA_HoldAccountFund_Add_1055() throws Exception {
				try{
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_HoldAccountFund_Add_1055();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account No");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.setText("Amount", WebDr.getValue("Amount"), "Select Amount");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.selectDropValueByVisibleText("EarmarkType", WebDr.getValue("EarmarkType"), "Select Earmark Type");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.selectDropValueByVisibleText("EarmarkReason", WebDr.getValue("EarmarkReason"), "Select Earmark Reason");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.setText("ExpiryDate", WebDr.getValue("ExpiryDate"), "Enter Expiry Date");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.click("Amount", "Click in the field");
					WebDr.clickwithmouse("OK", "Click on the OK Button");
					WebDr.authWithComment();
					//WebDr.SwitchToLatestWindow();
					if(WebDr.strFCRCountry.equals("BBK")){
						if (WebDr.VerifyStatusBarText("StatusBar",20,"Transaction sequence number is","Verify transaction status"))
						{
							HtmlReporter.WriteStep("Check whether user is able to place� holds on CASA accounts from 1055 screen.",
									"User should able to place�holds on CASA accounts from 1055 screen.",
									"User is able to place�hold on CASA accounts from 1055 screen.", true);
						}
						else{
							HtmlReporter.WriteStep("Check whether user is able to place� holds on CASA accounts from 1055 screen.",
									"User should able to place�holds on CASA accounts from 1055 screen.",
									"User is not able to place�hold on CASA accounts from 1055 screen.", false);
						}
						}
					else{
					try{
						if (WebDr.SwitchToLatestAlertCheck("Transaction sequence number is"))
							HtmlReporter.WriteStep("Check whether user is able to place� holds on CASA accounts from 1055 screen.",
									"User should able to place�holds on CASA accounts from 1055 screen.",
									"User is able to place�hold on CASA accounts from 1055 screen.", true);
						else
							HtmlReporter.WriteStep("Check whether user is able to place� holds on CASA accounts from 1055 screen.",
									"User should able to place�holds on CASA accounts from 1055 screen.",
									"User is not able to place�hold on CASA accounts from 1055 screen.", false);
					}catch(Exception e){
						e.printStackTrace();
					}
					}
					//WebDr.SwitchToLatestAlertCheck("Serial Number is");
					
				}catch(Exception error){
					error.printStackTrace();
					HtmlReporter.WriteStep("Check whether user is able to place� hold on CASA accounts from 1055 screen.",
							"User should able to place�hold on CASA accounts from 1055 screen.",
							"User is not able to place�hold on CASA accounts from 1055 screen.", false);
				}
			}
			
			public static void CASA_HoldAccountFund_Delete_CHM33() throws Exception {
				try{
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_HoldAccountFund_Delete_CHM33();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.click("RecordDelete", "Click on Record Delete");
					WebDr.waitForPageLoaded();
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account No");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.click("PickList", "Click on Picklist");
					WebDr.waitForPageLoaded();
					WebDr.SwitchToLatestWindow();
					WebDr.rTab();
					WebDr.rTab();
					WebDr.rEnter();
					WebDr.waitForPageLoaded();
					WebDr.SwitchToLatestWindow();
					WebDr.clickwithmouse("OK", "Click on the OK Button");
					WebDr.alertHandlingForErrors("Authorisation Pending", "Check for alert message");
					LOAN.logout();
					WebDr.waitForPageLoaded();
					LOAN.superLogin();
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_HoldAccountFund_Delete_CHM33();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					
					WebDr.click("RecordAuth", "Click on Record Authorize");
					WebDr.waitForPageLoaded();
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account No");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.click("PickList", "Click on Picklist");
					WebDr.waitForPageLoaded();
					WebDr.SwitchToLatestWindow();
					WebDr.rTab();
					WebDr.rTab();
					WebDr.rEnter();
					WebDr.waitForPageLoaded();
					WebDr.SwitchToLatestWindow();
					WebDr.clickwithmouse("OK", "Click on the OK Button");					
					try{
						if (WebDr.multiplealertHandlingForErrors("Record Authorized", "Click on the popup message"))
							HtmlReporter.WriteStep("Check whether user is able to remove holds on CASA accounts from CHM33 screen.",
									"User should able to remove holds on CASA accounts from CHM33 screen.",
									"User is able to remove holds on CASA accounts from CHM33 screen.", true);
						else
							HtmlReporter.WriteStep("Check whether user is able to remove holds on CASA accounts from CHM33 screen.",
									"User should able to remove holds on CASA accounts from CHM33 screen.",
									"User is not able to remove holds on CASA accounts from CHM33 screen.", false);
					}catch(Exception e){
						e.printStackTrace();
					}
					
					LOAN.logoutwithJSCommand(false);
					LOAN.login();
				}catch(Exception error){
					error.printStackTrace();
					HtmlReporter.WriteStep("Check whether user is able to remove holds on CASA accounts from CHM33 screen.",
							"User should able to remove holds on CASA accounts from CHM33 screen.",
							"User is not able to remove holds on CASA accounts from CHM33 screen.", false);
					LOAN.logoutwithJSCommand(false);
					LOAN.login();
				}
			}
			
			public static void CASA_SweepOutMaintenance_Add_CHM32() throws Exception {
				try {
					// Enter_Details
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_SweepOutMaintenance_Add_CHM32();				
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("RecordAdd", "Select Mode ADD");
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					if (WebDr.getValue("SweepOutTo").equals("CASA"))
						WebDr.click("SweepOutToCASA", "Sweep out to CASA Account");
					else if(WebDr.getValue("SweepOutTo").equals("TD"))
						WebDr.click("SweepOutToTD", "Sweep out to TD Account");
					WebDr.rTab();
					WebDr.click("MinBal","Click Min Bal");
					if (WebDr.getValue("SweepOutTo").equals("CASA"))
						WebDr.setText("CASASweepOutAccount", WebDr.getValue("CASASweepOutAccount"), "Enter CASASweepOut Account");
					else if(WebDr.getValue("SweepOutTo").equals("TD"))
						WebDr.selectDropValueByVisibleText("ProdTD", WebDr.getValue("ProductTD"), "Select TD");
					WebDr.rTab();
					
					if (WebDr.getValue("ExecutionType").equals("EOD"))
						WebDr.click("ExecutionTypeEOD", "Click Execution Type");
					else if(WebDr.getValue("ExecutionType").equals("BOD"))
						WebDr.click("ExecutionTypeBOD", "Click Execution Type");
					WebDr.rTab();
					
					WebDr.selectDropValueByVisibleText("Frequency", WebDr.getValue("Frequency"), "Select Frequency");
					WebDr.rTab();
					WebDr.rClearUpdateTextField("EndDate", WebDr.ChangeDatebyStaticDays(360), "Enter End Date");
					WebDr.rClearUpdateTextField("NextDate", WebDr.ChangeDatebyStaticDays(30), "Enter Next Date");
										
					WebDr.rClearUpdateTextField("MinBal", WebDr.getValue("MinBal"), "Enter Min Bal");
					WebDr.rClearUpdateTextField("MaxAmtSweepOut", WebDr.getValue("MaxAmtSweepOut"), "Enter Max Amt SweepOut");
					WebDr.rClearUpdateTextField("MinAmtSweepOut", WebDr.getValue("MinAmtSweepOut"), "Enter Min Amt SweepOut");
					
					if (WebDr.getValue("SweepOutTo").equals("CASA"))
						WebDr.rClearUpdateTextField("Narrative", WebDr.getValue("Narrative"), "Enter Narrative");
					
					WebDr.rTab();
					if(WebDr.getValue("SweepOutTo").equals("TD")){
						WebDr.click("TDDetails", "Click TD Details");
						WebDr.rClearUpdateTextField("AcctVar", WebDr.getValue("AcctVar"), "Enter Account Variance");
						WebDr.rTab();
						WebDr.selectDropValueByVisibleText("CompFreq", WebDr.getValue("CompFreq"), "Select Comp Freq");
						WebDr.rTab();
						WebDr.selectDropValueByVisibleText("PayOutFreq", WebDr.getValue("PayOutFreq"), "Select PayOut Freq");
						WebDr.rTab();
						WebDr.selectDropValueByVisibleText("BaseAmtTierRate", WebDr.getValue("BaseAmtTierRate"), "Select BaseAmtTierRate");
						WebDr.rTab();
						WebDr.rClearUpdateTextField("Months", WebDr.getValue("Months"), "Enter Months");
						WebDr.rTab();
						WebDr.rClearUpdateTextField("Days", WebDr.getValue("Days"), "Enter Days");
						WebDr.rTab();
						
						if(WebDr.getValue("TdSweepinStatus").equals("Yes"))
							WebDr.click("TdSweepinStatus", "Click TdSweepinStatus");
							
						WebDr.click("BeneficiaryDetails", "Click Beneficiary Details");
					}
					
//					WebDr.clickwithmouseandacceptalert("OK","Click on the OK button");
					WebDr.clickwithmouse("OK","Click on the OK button");
					WebDr.SwitchToLatestAlertCheck("Authorisation Pending");
					WebDr.click("FastPath", "Click in the field");
					WebDr.click("Close","Click on the CLOSE button");
					LOAN.logout();
					WebDr.waitForPageLoaded();
					LOAN.superLogin();
					WebDr.waitForPageLoaded();
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_SweepOutMaintenance_Add_CHM32();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("RecordAuth","Select Mode Authorize");
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
					WebDr.rTab();
					WebDr.click("Picklist","Click on the Picklist button");
					WebDr.SwitchToLatestWindow(); 
					WebDr.rTab();
					WebDr.rTab();
					WebDr.rEnter();
					WebDr.waitForPageLoaded();
					WebDr.SwitchToLatestWindow();
					WebDr.clickwithmouse("OK","Click on the OK button");
					
					if(WebDr.SwitchToLatestAlertCheck("Record Authorized")){
		
						HtmlReporter.WriteStep("Check whether the user is able to perform Sweep out on account of a product having Sweep out  flag enabled or not.",
							"System should allow to perform Sweep out on account of a product having Sweep out flag enabled.",
							"Sweep out addition successful. ", true);
					}
					else {
							
						HtmlReporter.WriteStep("Check whether the user is able to perform Sweep out on account of a product having Sweep out  flag enabled or not.",
								"System should allow to perform Sweep out on account of a product having Sweep out flag enabled.",
								"Sweep out addition unsuccessful. ", false);
					}
					WebDr.waitForPageLoaded();
					LOAN.logout();
					LOAN.login();
				}catch(Exception errAuth){
					errAuth.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to perform Sweep out on account of a product having Sweep out  flag enabled or not.",
							"System should allow to perform Sweep out on account of a product having Sweep out flag enabled.",
							"Sweep out addition unsuccessful. ", false);
				}
			}
			
			public static void FundTransfer_Reversal_6006() throws Exception {
				String txnStatus= null;
				try
				{
					
				do{
					pkgFCRPageObjects.FCR_CASAPageObjects.Reversal_6006();
					WebDr.fastPath(WebDr.getValue("FastPath1"));
					WebDr.waitForPageLoaded();
					
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
					WebDr.setText("Mnemonic", WebDr.getValue("Mnemonic"), "Enter Transaction Mnemonic");
					WebDr.clickwithmouse("GET_Btn", "Click GET button");
					txnStatus = WebDr.getCellTextBoxValue("State", "Get transaction status");
					System.out.println(txnStatus);
					if (txnStatus.equals("Sent")){
						WebDr.click("Mnemonic", "Click on mnemonic field");
						WebDr.rTab();
						WebDr.rTab();
						WebDr.rTab();
						WebDr.rEnter();
						WebDr.waitForPageLoaded();
						WebDr.clickwithmouse("Reversal_Btn", "Click Reversal button");
						WebDr.authWithComment();
						WebDr.SwitchToLatestWindow();
						WebDr.rTab();
						WebDr.rEnter();
					}
				}while(! txnStatus.equals("Reversed"));
				if (txnStatus.equals("Reversed")){
				HtmlReporter.WriteStep("Check whether the user is able to perform a reversal for a fund transfer transaction performed.",
						"User should be able to reverse a transaction successfully. ",
						"Transaction reversed successful.", true);
				}
				else{
					HtmlReporter.WriteStep("Check whether the user is able to perform a reversal for a fund transfer transaction performed.",
							"User should be able to reverse a transaction successfully. ",
							"Transaction reversed unsuccessful.", false);
				}
				}
				catch (Exception e) {
					e.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to perform a reversal for a  fund transfer transaction performed.",
							"User should be able to reverse a transaction successfully. ",
							"Transaction reversed unsuccessful.", false);
				
				}
			}
			
			public static void CASA_Misc_Customer_Debit_1008() throws Exception {
			try{
				pkgFCRPageObjects.FCR_CASAPageObjects.CASA_Misc_Customer_Debit();
				
				WebDr.fastPath(WebDr.getValue("FastPath"));
				String sysdate = WebDr.getTextBoxValue("SystemDate", "System date is fetched and displayed");
				WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
				WebDr.selectDropValueByVisibleText("Txn_Ccy", WebDr.getValue("Txn_Ccy"), "Select Transaction currency");
				WebDr.setText("GlAccountNo", WebDr.getValue("GlAccountNo"), "Enter GL Account Number");
				WebDr.setText("Amount", WebDr.getValue("Amount"), "Enter Amount");
				WebDr.setText("ReferenceNo", WebDr.getValue("ReferenceNo"), "Enter Reference Number");
				WebDr.setText("UserReferenceNo", WebDr.getValue("UserReferenceNo"), "Enter User Reference Number");
				WebDr.clickwithmouse("btn_OK_1008", "Click on the OK Button");
				if(WebDr.strFCRCountry.equals("BBM")){
					// SignatureVerfication
					WebDr.waitForPageLoaded();
					WebDr.click("Sign", "Click on Sign");
					WebDr.click("SignOk", "Click on OK");
					WebDr.waitForPageLoaded();
					WebDr.waitForNumberOfWindowsToEqual(3);
					WebDr.SwitchToLatestWindow();
					WebDr.waitForPageLoaded();
					WebDr.clickactivatewithmouse("SignZoom", "Click on signature window");
					WebDr.CloseWindowWithTitle("Signature");
					WebDr.SwitchToLatestWindow();
					WebDr.click("FastPath", "Click in the textfield");		
					WebDr.click("SignVerified", "Click on Signature Verified");
					
					WebDr.click("SignCancel", "Click on Cancel");
					WebDr.clickwithmouse("btn_OK_1008", "Click on the OK Button");
				}
				
				WebDr.authWithComment();
				WebDr.alertClickWithText("Transaction sequence number is");
				WebDr.alertClickWithText("Serial Number is");
				WebDr.fastPath(WebDr.getValue("FastPath1"));
				WebDr.setText("GlAccountNo1", WebDr.getValue("GlAccountNo"), "Enter GL Account Number");
				WebDr.rTab();
				WebDr.selectDropValueByVisibleText("Branch", WebDr.getValue("Branch"), "Select Branch");
				WebDr.selectDropValueByVisibleText("Currency", WebDr.getValue("Currency"), "Select Currency");
				WebDr.selectDropValueByVisibleText("Transactions_type", WebDr.getValue("Transactions_type"), "Select Transaction Type");
				WebDr.rClearUpdateTextField("FromDate", sysdate, "Enter From Date");
				WebDr.rClearUpdateTextField("ToDate", sysdate, "Enter To Date");
				WebDr.clickwithmouse("Inquire_GLM04", "Click on the Inquire Button");
				if(WebDr.isElementExist("Transaction", "Check for transaction entry")){
					HtmlReporter.WriteStep("Check whether the liability  GL gets credited for a Misc customer Debit. or not.",
						"User should be able to view a transaction successfully. ",
						"GL credit successful.", true);
				}
				else{
					HtmlReporter.WriteStep("Check whether the liability  GL gets credited for a Misc customer Debit. or not.",
							"User should be able to view a transaction successfully. ",
							"GL credit unsuccessful.", false);
				}
					
				
			}
			catch (Exception e) {
				e.printStackTrace();
				HtmlReporter.WriteStep("Check whether the liability  GL gets credited for a Misc customer Debit. or not.",
						"User should be able to view a transaction successfully. ",
						"GL credit unsuccessful.", false);
			}
			}
			
			public static void CASA_Interest_Rate_CHM02() throws Exception {
				try{
					
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_Interest_Rate_Add_CHM02();
					
					WebDr.fastPath(WebDr.getValue("FastPath"));
					String sysdate = WebDr.getTextBoxValue("SystemDate", "System date is fetched and displayed");
					
					WebDr.clickwithmouse("RecordAdd", "Click on Add");
					if (WebDr.isAlertPresent())
						WebDr.alertAccept();
					
					WebDr.setText("Plan_code", WebDr.getValue("Plan_code"), "Enter Plan_code");
					WebDr.rTab();
					if (WebDr.getValue("Effective_date").isEmpty())
						WebDr.rClearUpdateTextField("Effective_date", sysdate, "Enter Effective date");
					else
						WebDr.rClearUpdateTextField("Effective_date", WebDr.getValue("Effective_date"), "Enter Effective date");
					WebDr.rTab();
					
					if (WebDr.getValue("Plan_Description").isEmpty())
						WebDr.rClearUpdateTextField("Plan_Description", sysdate, "Enter Plan Description");
					else
						WebDr.rClearUpdateTextField("Plan_Description", WebDr.getValue("Plan_Description"), "Enter Plan Description");
					WebDr.rTab();
					
					WebDr.click("Credit_Type", "Click on Credit_Type");
					WebDr.click("AddRate", "Click on AddRate");
					WebDr.clickwithmouse("Max_Balance", "Click on Max_Balance and enter as " +WebDr.getValue("Max_Balance"));
					WebDr.keyboard(WebDr.getValue("Max_Balance"));
					WebDr.doubleClick("Index_code");
					WebDr.waitForPageLoaded();
					WebDr.SwitchToLatestWindow();
					WebDr.rTab();
					WebDr.rTab();
					WebDr.rEnter();
					WebDr.SwitchToLatestWindow();
					//WebDr.click("SelectRow", "Click on record");	
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("Int_Variance", "Click Int_Variance and enter as " +WebDr.getValue("Int_Variance"));
					WebDr.keyboard(WebDr.getValue("Int_Variance"));
					WebDr.rTab();
					WebDr.clickwithmouse("OK_CHM02", "Click on OK_CHM02");
					WebDr.alertHandlingForErrors("Authorisation Pending", "Check for alert message");
					
					///////////////////loop
					String arrType[] = {"Debit_Type","Overline_Type","TOD_Type"};
					for(int i=0;i<3;i++){
						WebDr.setText("Plan_code", WebDr.getValue("Plan_code"), "Enter Plan_code for " + arrType[i]);
						WebDr.rTab();
						if (WebDr.getValue("Effective_date").isEmpty())
							WebDr.rClearUpdateTextField("Effective_date", sysdate, "Enter Effective date");
						else
							WebDr.rClearUpdateTextField("Effective_date", WebDr.getValue("Effective_date"), "Enter Effective date");
						WebDr.rTab();
						WebDr.clickwithmouse("Plan_Description","Click Plan_Description for " + arrType[i]);
						WebDr.alertClickWithText("Unauthorized Added Record");
						WebDr.waitForPageLoaded();
						WebDr.clickwithmouse(arrType[i], "Click on " + arrType[i]);
						if (WebDr.isAlertPresent())
							WebDr.alertAccept();
						WebDr.click("AddRate", "Click on AddRate");
						WebDr.clickwithmouse("Max_Balance", "Click on Max_Balance and enter as " +WebDr.getValue("Max_Balance"));
						WebDr.keyboard(WebDr.getValue("Max_Balance"));
						WebDr.doubleClick("Index_code");
						WebDr.waitForPageLoaded();
						WebDr.SwitchToLatestWindow();
						WebDr.rTab();
						WebDr.rTab();
						WebDr.rEnter();
						WebDr.SwitchToLatestWindow();
						//WebDr.click("SelectRow", "Click on record");	
						WebDr.waitForPageLoaded();
						WebDr.clickwithmouse("Int_Variance", "Click Int_Variance and enter as " +WebDr.getValue("Int_Variance"));
						WebDr.keyboard(WebDr.getValue("Int_Variance"));
						WebDr.rTab();
						WebDr.clickwithmouse("OK_CHM02", "Click on OK_CHM02 to add new plan for " + arrType[i]);
						WebDr.alertHandlingForErrors("Authorisation Pending", "Check for alert message");
					}				
					HtmlReporter.WriteStep("Check whether the user is able to add inquiry rate in an existing plan code or not.",
							"User should be able to add new rates for 'Credit','Debit', 'Overline' and 'TOD' for an existing Plan code successfully.",
							"User added new rates for 'Credit','Debit', 'Overline' and 'TOD' for an existing Plan code successfully.", true);
					
				}catch (Exception e) {
						e.printStackTrace();
						HtmlReporter.WriteStep("Check whether the user is able to add inquiry rate in an existing plan code or not.",
								"User should be able to add new rates for 'Credit','Debit', 'Overline' and 'TOD' for an existing Plan code successfully.",
								"User did not add new rates for 'Credit','Debit', 'Overline' and 'TOD' for an existing Plan code successfully.", false);
					}
					
					try{
						LOAN.logout();
						WebDr.waitForPageLoaded();
						LOAN.superLogin();
						WebDr.waitForPageLoaded();
						pkgFCRPageObjects.FCR_CASAPageObjects.CASA_Interest_Rate_Add_CHM02();
						WebDr.fastPath(WebDr.getValue("FastPath"));
						WebDr.waitForPageLoaded();
												
						WebDr.clickwithmouse("RecordAuth", "Click on Auth");
						if (WebDr.isAlertPresent())
							WebDr.alertAccept();
						
						for(int i=0;i<4;i++){
							WebDr.setText("Plan_code", WebDr.getValue("Plan_code"), "Enter Plan_code");
							WebDr.rTab();
							WebDr.clickwithmouse("PlanSelect", "Click on Plan Select");
							WebDr.waitForPageLoaded();
							WebDr.SwitchToLatestWindow();
							WebDr.rTab();
							WebDr.rTab();
							WebDr.rEnter();
							WebDr.SwitchToLatestWindow();
							WebDr.clickwithmouse("FastPath", "Click in fastpath field");
							WebDr.clickwithmouse("OK_CHM02", "Click on OK_CHM02 to authorize");
							WebDr.alertHandlingForErrors("Record Authorised", "Verify alert message");
						}
						
						HtmlReporter.WriteStep("Check whether the user is able to authorize add inquiry rate in an existing plan code or not.",
								"User should be able to authorize added new rates for 'Credit','Debit', 'Overline' and 'TOD' for an existing Plan code successfully.",
								"User authorized added new rates for 'Credit','Debit', 'Overline' and 'TOD' for an existing Plan code successfully.", true);
					}
					catch(Exception autherror){
						autherror.printStackTrace();
						HtmlReporter.WriteStep("Check whether the user is able to authorize added inquiry rate in an existing plan code or not.",
								"User should be able to authorize added new rates for 'Credit','Debit', 'Overline' and 'TOD' for an existing Plan code successfully.",
								"User did not authorize added new rates for 'Credit','Debit', 'Overline' and 'TOD' for an existing Plan code successfully.", false);

					}
			}
			
			public static void TD_Account_StatusChange_Fail_CHM21() throws Exception {
				try{
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_Account_Status_CHM21();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.setText("AcctNo", WebDr.getValue("AcctNo"), "Enter Account Number");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					if(WebDr.alertClickWithText("FCR1688 : Record does not Exist"))
					{
						WebDr.alertAccept();
						HtmlReporter.WriteStep("Check whether the user is able to change a status of a TD account in CHM21 or not.",
								"User should not be able to change a status of a TD account in CHM21",
								"User did not changed the status of a TD account in CHM21", true);
					}
					else if(WebDr.alertHandlingForErrors("Invalid account number", "Verifying alert"))
					{
						HtmlReporter.WriteStep("Check whether the user is able to change a status of a TD account in CHM21 or not.",
								"User should not be able to change a status of a TD account in CHM21",
								"User did not changed the status of a TD account in CHM21", true);
					}
					else
					{
						HtmlReporter.WriteStep("Check whether the user is able to change a status of a TD account in CHM21 or not.",
								"User should be able to change a status of a TD account in CHM21",
								"User changed the status of a TD account in CHM21", false);
					}
					
				}
					catch(UnhandledAlertException err)
					{
						Alert alert=driver.switchTo().alert();
						alert.accept();
						HtmlReporter.WriteStep("Check whether the user is able to change a status of a LN account in CHM21 or not.",
								"User should not be able to change a status of a TD account in CHM21",
								"User changed the status of a LN account in CHM21", false);
					}	
					catch (Exception e) {
						e.printStackTrace();
						HtmlReporter.WriteStep("Check whether the user is able to change a status of a TD account in CHM21 or not.",
								"User should be able to change a status of a TD account in CHM21",
								"User changed the status of a TD account in CHM21", false);
					}
          }
          
			public static void LN_Account_StatusChange_Fail_CHM21() throws Exception {
				try{
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_Account_Status_CHM21();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.setText("AcctNo", WebDr.getValue("AcctNo"), "Enter Account Number");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					if(WebDr.alertClickWithText("FCR1688 : Record does not Exist"))
					{
						WebDr.alertAccept();
						HtmlReporter.WriteStep("Check whether the user is able to change a status of a LN account in CHM21 or not.",
								"User should not be able to change a status of a LN account in CHM21",
								"User did not changed the status of a LN account in CHM21", true);
					}
					else if(WebDr.alertClickWithText("FCR2976 : Invalid account number"))
					{
						WebDr.alertAccept();
						HtmlReporter.WriteStep("Check whether the user is able to change a status of a TD account in CHM21 or not.",
								"User should not be able to change a status of a TD account in CHM21",
								"User did not changed the status of a TD account in CHM21", true);
					}
					else
					{
						HtmlReporter.WriteStep("Check whether the user is able to change a status of a LN account in CHM21 or not.",
								"User should not be able to change a status of a LN account in CHM21",
								"User changed the status of a LN account in CHM21", false);
					}
					
				}
				catch(UnhandledAlertException err)
				{
					Alert alert=driver.switchTo().alert();
					alert.accept();
					HtmlReporter.WriteStep("Check whether the user is able to change a status of a LN account in CHM21 or not.",
							"User should not be able to change a status of a TD account in CHM21",
							"User changed the status of a LN account in CHM21", false);
				}
				catch (Exception e) {
					HtmlReporter.WriteStep("Check whether the user is able to change a status of a LN account in CHM21 or not.",
							"User should not be able to change a status of a TD account in CHM21",
							"User changed the status of a LN account in CHM21", false);
				}
          }
			
			public static void SweepIn_SweepOut_Priority_Maintenance_CHM40() throws NullPointerException,Exception {
                try{
                		
                       pkgFCRPageObjects.FCR_CASAPageObjects.SweepIn_SweepOut_Priority_Maintenance_CHM40();
                       WebDr.fastPath(WebDr.getValue("FastPath"));
                       WebDr.waitForPageLoaded();
                       WebDr.clickwithmouse("Modify", "Click on Modify ");
                       WebDr.setText("Account_No", WebDr.getValue("Account_No"), "Enter Account No ");
                       WebDr.rTab();
                       WebDr.waitForPageLoaded();
                       WebDr.clickactivatewithmouse("Priority_Number", "Click on Priority Number");
                       WebDr.keyboard(WebDr.getValue("Priority_Number")); 
                       WebDr.clickwithmouse("OK_CHM40", "Click on OK");
                       WebDr.authOnlyCreds();
                       WebDr.waitForPageLoaded();
                       if(WebDr.isAlertPresent())
           				WebDr.alertHandlingForErrors("Record Modified", "Verify alert message");                
                       WebDr.clickwithmouse("CLOSE_CHM40", "Click on Close");
                       HtmlReporter.WriteStep("Check whether the user is able to set the priorities in CHM40 for sweep in or not.",
                               "System should allow to set pririty in CHM40 for sweep in.",
                               "System is able to set priority in CHM40", true);
                       
                }
                catch(Exception e)
                {
                	e.printStackTrace();
                	 HtmlReporter.WriteStep("Check whether the user is able to set the priorities in CHM40 for sweep in or not.",
                			 "System should allow to set pririty in CHM40 for sweep in.",
                             "System is not able to set priority in CHM40", false);
                	 WebDr.clickwithmouse("CLOSE_CHM40", "Click on Close");
                }
          }
			
			public static void Account_Master_Maintenance_CH021() throws UnhandledAlertException, Exception{
				try{
				 pkgFCRPageObjects.FCR_CASAPageObjects.Account_Master_Maintenance_CH021();
                 WebDr.fastPath(WebDr.getValue("FastPath"));
                 WebDr.waitForPageLoaded();
                 WebDr.setText("Account_No", WebDr.getValue("Account_No"), "Enter Account No ");
                 WebDr.rTab();
                 WebDr.waitForPageLoaded();
                 switch(WebDr.getValue("TABOperation")){
                 case "BalanceInfo":
                	 try{
                		 WebDr.click("BalanceInfo", "Click on Balnce Info tab");
                		 String bal_available = WebDr.getTextBoxValue("Available_Balance", "Get available balance");
                		 System.out.println(bal_available);
                		 if (bal_available != "")
             				HtmlReporter.WriteStep("Check whether the user is able to view the balances in balance info tab correctly in FP CH021", "User should be able to view the balances in balance info tab correctly in FP CH021", "Able to view balance successfully",true);
             			else
             				HtmlReporter.WriteStep("Check whether the user is able to view the balances in balance info tab correctly in FP CH021", "User should be able to view the balances in balance info tab correctly in FP CH021", "Not able to view balance successfully",false);
                	 }
                	 
                	 catch(Exception er1){
                	 er1.printStackTrace();
                	 HtmlReporter.WriteStep("Check whether the user is able to view the balances in balance info tab correctly in FP CH021", "User should be able to view the balances in balance info tab correctly in FP CH021", "Not able to view balance successfully" +er1.toString(),false);
                	 }
                	 break ;
                 case "Overdraft/Overline":
                	 try{
                		 WebDr.click("Overdraft", "Click on Overdraft Info tab");
                		 String debit_balance = WebDr.getTextBoxValue("Last_Debit_Amt", "Get debit balance");
                		 String credit_balance = WebDr.getTextBoxValue("Last_Credit_Amt", "Get credit balance");
                		 if ((debit_balance != "") && (credit_balance != ""))
              				HtmlReporter.WriteStep("Check whether the system displays the balances correctly in overdraft/overline for an account correctly in FP CH021", "User should be able to view the balances in overdraft/overline info tab correctly in FP CH021", "Able to view balance successfully",true);
              			else
              				HtmlReporter.WriteStep("Check whether the system displays the balances correctly in overdraft/overline for an account correctly in FP CH021", "User should be able to view the balances in overdraft/overline info tab correctly in FP CH021", "Not able to view balance successfully",false);
                 	 
                	 }
                	 
                	 catch(Exception er2){
                	 er2.printStackTrace();
                	 HtmlReporter.WriteStep("Check whether the system displays the balances correctly in overdraft/overline for an account correctly in FP CH021", "User should be able to view the balances in overdraft/overline info tab correctly in FP CH021", "Not able to view balance successfully",false);
                	 }
                	 break;
                 case "InterestTier":
                	 try{
                		 boolean rateFlag = false;
                		 WebDr.click("InterestTiers", "Click on Interest Tiers Info tab");
                		 WebDr.waitForPageLoaded();
                		 WebElement RateTable = Driver.driver.findElement(By.xpath("//table[@id='grdIntRates']/tbody"));
                			List  RateTableRows = RateTable.findElements(By.tagName("tr"));
                			int introws = RateTableRows.size();
                			System.out.println("-------------------row count" + introws);
                			for(int i=1;i<=introws;i++){
                				WebDr.waitForPageLoaded();
                				String IntRate = Driver.driver.findElement(By.xpath("//table[@id='grdIntRates']//tr["+i+"]//td[@class='TGridURL'][3]")).getText();
                				System.out.println(IntRate);
                				if (IntRate.isEmpty()){
                					rateFlag = true;
                					break ;
                					
                				}
                				else{
                					System.out.println(IntRate);
                				}
                			}
                			if (rateFlag == true){
                				HtmlReporter.WriteStep("Check whether the interest information is updated in the 'Interest info tiers' or not. in FP CH021", "User should be able to view the rates in interest info correctly in FP CH021", "Not able to view interest info successfully",false);	
                			}
                			else {
                				HtmlReporter.WriteStep("Check whether the interest information is updated in the 'Interest info tiers' or not. in FP CH021", "User should be able to view the rates in interest info correctly in FP CH021", "Able to view balance successfully",true);
                			}
                			
                	 }
                	 
                	 catch(Exception er3){
                	 er3.printStackTrace();
                	 HtmlReporter.WriteStep("Check whether the interest information is updated in the 'Interest info tiers' or not. in FP CH021", "User should be able to view the rates in interest info correctly in FP CH021", "Not able to view interest info successfully " +er3.toString(),false);
                	 }
                	 break;
                	 }
				}
				
				catch(Exception ex){
					ex.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to view the balances in balance info tab correctly in FP CH021", "User should be able to view the balances in balance info tab correctly in FP CH021", "Not able to view balance successfully" +ex.toString(),false);
				}
				
			}
			
			public static void Invalid_CHQBK_CHM37() throws Exception{
			try{
				pkgFCRPageObjects.FCR_CASAPageObjects.Invalid_CHQBK_CHM37();
				WebDr.fastPath(WebDr.getValue("FastPath"));
				WebDr.waitForPageLoaded();
				WebDr.clickwithmouse("RecordAdd", "Select Mode ADD");
				WebDr.setText("Account_No", WebDr.getValue("Account_No"), "Enter Account Number");
				WebDr.rTab();
				if(WebDr.alertClickWithText("Cheque Book Facility Not Available")){
					HtmlReporter.WriteStep("Check whether the user is able to issue a cheque book for a product where the flag is modified to disabled or not in FP CHM37.",
                            "User should not be able to issue a cheque book for a product where the flag is modified to disabled or not in FP CHM37",
                            "Checque book Issue unsuccessful", true);
				}
				else{
					HtmlReporter.WriteStep("Check whether the user is able to issue a cheque book for a product where the flag is modified to disabled or not in FP CHM37.",
                            "User should not be able to issue a cheque book for a product where the flag is modified to disabled or not in FP CHM37",
                            "Checque book Issue successful", false);
				}
				
			}
			catch(Exception e){
				e.printStackTrace();
				HtmlReporter.WriteStep("Check whether the user is able to issue a cheque book for a product where the flag is modified to disabled or not in FP CHM37.",
                        "User should not be able to issue a cheque book for a product where the flag is modified to disabled or not in FP CHM37",
                        "Checque book Issue successful", false);
			}
			}
			
			public static void Verify_SweepIn_Execution() throws NumberFormatException,Exception
			{
				 try{	 
					 //Step-1		Check Balance " BEFORE TRANSACTION"
					 //Code for getting balance. 
					 String Balance_Available = null;
					 float Balance_Available_float;
					 String Txn_Amount;
					 float Txn_Amount_float;
					 String Minimum_Balance;
					 float Minimum_Balance_float;
					 float Before_txn_sweepIn_acct_bal = 0;
					 float Before_txn_Instruction1_bal = 0;
					 float Before_txn_Instruction2_bal = 0;
					 float Before_txn_Instruction3_bal = 0;
					 
					 float Txn_Amount_SweepIn_Account;
					 float Txn_Amount_Instruction1_Account;
					 float Txn_Amount_Instruction2_Account;
					 float Txn_Amount_Instruction3_Account;
					 
					 pkgFCRPageObjects.FCR_CASAPageObjects.BalanceInquiry_7002();				
					 for(int i=1;i<=4;i++)
					 {
						 WebDr.fastPath(WebDr.getValue("FastPath_BalanceInquiry"));
						 WebDr.waitForPageLoaded();
						 WebDr.setText("AccountNumber", WebDr.getValue("AccountNumber"+i), "Enter Account Number");
						 WebDr.rTab();
						 WebDr.waitForPageLoaded();
						 Balance_Available=WebDr.getTextBoxValue("Available_Balance", "Available Balance");
						 Balance_Available=Balance_Available.replaceAll("[,;]", "");
						 Balance_Available_float=Float.parseFloat(Balance_Available);
						 if(i==1)
						 {
							 Before_txn_sweepIn_acct_bal=Balance_Available_float;
						 }
						 else if(i==2)
						 {
							 Before_txn_Instruction1_bal=Balance_Available_float;
						 }
						 else if(i==3)
						 {
							 Before_txn_Instruction2_bal=Balance_Available_float;
						 }
						 else
						 {
							 Before_txn_Instruction3_bal=Balance_Available_float;
						 }
						 System.out.println("\n\n\n Balance  = "+Balance_Available);
						 WebDr.clickwithmouse("CANCEL_7002", "Click on CLOSE");
					 }
					 
					 Txn_Amount=WebDr.getValue("Amount");
					 Txn_Amount=Txn_Amount.replaceAll("[,;]", "");
					 Txn_Amount_float=Float.parseFloat(Txn_Amount);
					 
					 Minimum_Balance=WebDr.getValue("Min_Balance");
					 Minimum_Balance=Minimum_Balance.replaceAll("[,;]", "");
					 Minimum_Balance_float=Float.parseFloat(Minimum_Balance);
					 
					 
					 Txn_Amount_SweepIn_Account = Before_txn_sweepIn_acct_bal - Minimum_Balance_float;
					 Txn_Amount_Instruction1_Account = Txn_Amount_float - Txn_Amount_SweepIn_Account;
					 Txn_Amount_Instruction2_Account = Txn_Amount_Instruction1_Account - Before_txn_Instruction1_bal;
					 Txn_Amount_Instruction3_Account = Txn_Amount_Instruction2_Account - Before_txn_Instruction2_bal;

					 //Step-2 Transaction - Cash Withdrawal
					if(WebDr.getValue("Classification").equals("CashWithdrawalTxn"))
					 {
					 CashWithdrawal_1001();
					 }
					
					 //Step-3 Statement Inquiry
					 pkgFCRPageObjects.FCR_CASAPageObjects.CASSViewAccountStatement_CH031();
						WebDr.fastPath(WebDr.getValue("FastPath_StatementInquiry"));
						WebDr.waitForPageLoaded();
						WebDr.rTab();
						WebDr.waitForPageLoaded();	
						
						WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number for statement enquiry");
						
						WebDr.rTab();
						WebDr.waitForPageLoaded();	
						
						WebDr.click("RadioTransaction", "Click on Transactions radio button");
						
						WebDr.rClearUpdateTextField("StartDate", WebDr.getValue("StartDate"), "Enter start date");
						WebDr.rTab();

						if (! WebDr.getValue("EndDate").isEmpty()){
							WebDr.rDelete();
							WebDr.setText("EndDate", WebDr.getValue("EndDate"), "Enter end date");
							WebDr.rTab();
						}

						WebDr.waitForPageLoaded();
//						WebDr.click("AccountNo", "Click on acc no");
						WebDr.clickwithmouse("Inquire", "Click on Inquire button");	
						WebDr.waitForPageLoaded();
	
					 //Step-4 Verification
					if(Txn_Amount_float>Txn_Amount_SweepIn_Account)
					 {
						 if(Txn_Amount_Instruction1_Account>Before_txn_Instruction1_bal)
						 {
							 if(Txn_Amount_Instruction2_Account>Before_txn_Instruction2_bal)
							 {
								 if(Txn_Amount_Instruction3_Account>Before_txn_Instruction3_bal)
								 {
									 HtmlReporter.WriteStep("Check whether user is able to execute the SweepIn according to the instruction set or not.",
					              			 "System should validate the 'instruction no.' and execute the sweepin accordingly.",
					                           "System did not validate the 'instruction no.' and execute the sweepin accordingly.", false);
								 }
								 else
								 {
									 if((WebDr.isElementExist("Txn_Table_Date", "Check for Transaction Date")) && (WebDr.isElementExist("Txn_Table_Instruction1", "Check for Instruction1 Sweep In Entry")) && (WebDr.isElementExist("Txn_Table_Instruction2", "Check for Instruction2 Sweep In Entry")) && (WebDr.isElementExist("Txn_Table_Instruction3", "Check for Instruction3 Sweep In Entry")))
									 {
									 HtmlReporter.WriteStep("Check whether SweepIn According to Instruction No", "SweepIn should be from Accounts with Instruction 1 , 2 and 3", "SweepIn from Accounts with Instruction 1 , 2 and 3", true);
									 }
								 }
							 }
							 else
							 {
								 if((WebDr.isElementExist("Txn_Table_Date", "Check for Transaction Date")) && (WebDr.isElementExist("Txn_Table_Instruction1", "Check for Instruction1 Sweep In Entry")) && (WebDr.isElementExist("Txn_Table_Instruction2", "Check for Instruction2 Sweep In Entry")))
								 {
								 HtmlReporter.WriteStep("Check whether SweepIn According to Instruction No", "SweepIn should be from Accounts with Instruction 1 and 2", "SweepIn from Accounts with Instruction 1 and 2", true);
								 }
							 }
						 }
						 else
						 {
							 if((WebDr.isElementExist("Txn_Table_Date", "Check for Transaction Date")) && (WebDr.isElementExist("Txn_Table_Instruction1", "Check for Instruction1 Sweep In Entry")))
							 {
							 HtmlReporter.WriteStep("Check whether SweepIn According to Instruction No", "SweepIn should be from Accounts with Instruction 1 ", "SweepIn from Accounts with Instruction 1 ", true);
							 }
						 }
					 }
					 else
					 {
						 HtmlReporter.WriteStep("Check whether SweepIn According to Instruction No", "SweepIn not required", "SweepIn not triggered as the account has sufficient balance", false);
					 }
					WebDr.clickwithmouse("CANCEL_CH031", "Click on CANCEL");
					 HtmlReporter.WriteStep("Check whether user is able to execute the SweepIn according to the instruction set or not.",
	              			 "System should validate the 'instruction no.' and execute the sweepin accordingly.",
	                           "System validated the 'instruction no.' and execute the sweepin accordingly.", true);
              }
              catch(Exception e)
              {
              	e.printStackTrace();
              	 HtmlReporter.WriteStep("Check whether user is able to execute the SweepIn according to the instruction set or not.",
              			 "System should validate the 'instruction no.' and execute the sweepin accordingly.",
                           "System did not validate the 'instruction no.' and execute the sweepin accordingly.", false);	 
              }
			}
			public static void SweepOut_Maintainance_Modify_CHM32() throws Exception {
                try {
                       pkgFCRPageObjects.FCR_CASAPageObjects.CASA_SweepOutMaintenance_Add_CHM32();                     
                       WebDr.fastPath(WebDr.getValue("FastPath"));
                       WebDr.waitForPageLoaded();
                       WebDr.clickwithmouse("Modify", "Click on Modify ");
                       WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
                       WebDr.rTab();        
                       WebDr.setText("Instruction_No", WebDr.getValue("Instruction_No"), "Enter Instruction Number");
                       WebDr.rTab();
                       WebDr.rClearUpdateTextField("MinBal", WebDr.getValue("MinBal"), "Enter Minimum Balance");
                       WebDr.rClearUpdateTextField("MaxAmtSweepOut", WebDr.getValue("MaxAmtSweepOut"), "Enter Max Amt SweepOut");
                       WebDr.rClearUpdateTextField("MinAmtSweepOut", WebDr.getValue("MinAmtSweepOut"), "Enter Min Amt SweepOut");
                       WebDr.clickwithmouse("OK","Click on the OK button");
                       WebDr.alertAccept();
                       WebDr.click("Close","Click on the CLOSE button");
                       LOAN.logout();
                       WebDr.waitForPageLoaded();
                       LOAN.superLogin();
                       pkgFCRPageObjects.FCR_CASAPageObjects.CASA_SweepOutMaintenance_Add_CHM32(); 
                       WebDr.waitForPageLoaded();
                       WebDr.fastPath(WebDr.getValue("FastPath"));
                       WebDr.waitForPageLoaded();
                       WebDr.clickwithmouse("RecordAuth","Select Mode Authorize");
                       WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
                       WebDr.rTab();
                       WebDr.setText("Instruction_No", WebDr.getValue("Instruction_No"), "Enter Instruction Number");
                       WebDr.rTab();
                       WebDr.clickwithmouse("OK","Click on the OK button");
                       if(WebDr.SwitchToLatestAlertCheck("Record Authorized")){
                              
                              HtmlReporter.WriteStep("Check whether the user is able to modify and Authorize the Records in CHM32.",
                                     "System should allow the user to Modify and Authorize the Record",
                                     "Sweep out Record Modified and authorize successfully", true);
                       }
                       else {
                                     
                              HtmlReporter.WriteStep("Check whether the user is able to modify and Authorize the Records in CHM32",
                                            "System should allow to modify and authorize Records in CHM32",
                                            "Sweep out Record modification and authorization unsuccessful", false);
                       }
                       WebDr.alertAccept();
                       WebDr.waitForPageLoaded();
                       LOAN.logout();
                       LOAN.login();
                       
                }catch(Exception errAuth){
                       errAuth.printStackTrace();
                       HtmlReporter.WriteStep("Check whether the user is able to modify and authorize the records in CHM32",
                                     "System should allow the user to the modified and authorize record in the screen CHM32",
                                     " Sweep out Record modification and authorization unsuccessful", false);
                }
                
          }

			public static void SweepOut_Maintainance_Delete_CHM32() throws Exception {
                
                try {
                       
                       pkgFCRPageObjects.FCR_CASAPageObjects.CASA_SweepOutMaintenance_Add_CHM32();                     
                       WebDr.fastPath(WebDr.getValue("FastPath"));
                       WebDr.waitForPageLoaded();
                       WebDr.clickwithmouse("Delete", "Click on Modify ");
                       WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
                       WebDr.rTab();
                       WebDr.setText("Instruction_No", WebDr.getValue("Instruction_No"), "Enter Instruction Number");
                       WebDr.rTab();
                       WebDr.clickwithmouse("OK","Click on the OK button");
                       WebDr.alertAccept();
                       WebDr.click("Close","Click on the CLOSE button");
                       LOAN.logout();
                       WebDr.waitForPageLoaded();
                       LOAN.superLogin();
                       pkgFCRPageObjects.FCR_CASAPageObjects.CASA_SweepOutMaintenance_Add_CHM32(); 
                       WebDr.waitForPageLoaded();
                       WebDr.fastPath(WebDr.getValue("FastPath"));
                       WebDr.waitForPageLoaded();
                       WebDr.clickwithmouse("RecordAuth","Select Mode Authorize");
                       WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
                       WebDr.rTab();
                       WebDr.setText("Instruction_No", WebDr.getValue("Instruction_No"), "Enter Instruction Number");
                       WebDr.rTab();
                       WebDr.clickwithmouse("OK","Click on the OK button");
                       if(WebDr.SwitchToLatestAlertCheck("Record Authorized")){
                              
                              HtmlReporter.WriteStep("Check whether the user is able to delete the records in transaction or not on CHM32.",
                                     "System should allow to delete the records.",
                                     "Record deleted successfully ", true);
                       }
                       else {
                                     
                              HtmlReporter.WriteStep("Check whether the user is able to Delete the records in transaction or not in CHM32.",
                                            "System should allow the user to delete the record",
                                            "User is unable to delete the records", false);
                       }
                       WebDr.waitForPageLoaded();
                       LOAN.logout();
                       LOAN.login();
                       
                }catch(Exception errAuth){
                       errAuth.printStackTrace();
                       HtmlReporter.WriteStep("Check whether the user is able to delete the records in transaction or not.",
                                     "System should allow the user to delete the  record in the screen CHM32",
                                     "User is unable to delete the records. ", false);
                }
         }

			public static void SweepIn_SweepOut_Priority_Set_CHM40() throws NullPointerException,Exception {
                try{
                		
                       pkgFCRPageObjects.FCR_CASAPageObjects.SweepIn_SweepOut_Priority_Maintenance_CHM40();
                       WebDr.fastPath(WebDr.getValue("FastPath"));
                       WebDr.waitForPageLoaded();
                       WebDr.clickwithmouse("Add", "Click on Add ");
                       WebDr.setText("Account_No", WebDr.getValue("Account_No"), "Enter Account No ");
                       WebDr.rTab();
                       WebDr.waitForPageLoaded();
                       WebDr.clickactivatewithmouse("Priority_Number", "Click on Priority Number");
                       WebDr.keyboard(WebDr.getValue("Priority_Number")); 
                       WebDr.clickwithmouse("OK_CHM40", "Click on OK");
                       WebDr.authOnlyCreds();
                       WebDr.waitForPageLoaded();
                       if(WebDr.isAlertPresent())
           				WebDr.alertHandlingForErrors("Record Added", "Verify alert message");                
                       WebDr.clickwithmouse("CLOSE_CHM40", "Click on Close");
                       HtmlReporter.WriteStep("Check whether the user is able to set the priorities in CHM40 for sweep in or not.",
                               "System should allow to set pririty in CHM40 for sweep in.",
                               "System is able to set priority in CHM40", true);
                }
                catch(Exception e)
                {
                	e.printStackTrace();
                	 HtmlReporter.WriteStep("Check whether the user is able to set the priorities in CHM40 for sweep in or not.",
                			 "System should allow to set pririty in CHM40 for sweep in.",
                             "System is not able to set priority in CHM40", false);
                	 WebDr.clickwithmouse("CLOSE_CHM40", "Click on Close");
                }
          }
			
			
			public static void StartDate_EndDate_Validation_CHM31() throws Exception {
				try {
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_StandingInstruction_CHM31();				
					WebDr.fastPath(WebDr.getValue("FastPath"));
					
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("ModifyBtn", "Selct Mode MODIFY");     
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.setText("InstructionNumber", WebDr.getValue("InstructionNumber") , "Enter Instruction Number");
					WebDr.rTab();
					WebDr.waitForPageLoaded();	
		
					WebDr.rClearUpdateTextField("StartDate", WebDr.getValue("StartDateInvalid"), "Enter Start Date");
					WebDr.click("CHM31_OK","Click on the OK button");
					WebDr.alertClickWithText("FCR2962 : Start Date should not be less than account opening date");
					WebDr.rClearUpdateTextField("StartDate", WebDr.getValue("StartDateValid"), "Enter Correct Start Date");
					WebDr.rClearUpdateTextField("EndDate", WebDr.getValue("EndDateInvalid"), "Enter End Date");
					WebDr.click("CHM31_OK","Click on the OK button");
					WebDr.alertClickWithText("FCR6358 : Date should be greater than process date");
					WebDr.rClearUpdateTextField("EndDate", WebDr.getValue("EndDateValid"), "Enter Correct End Date");
					
					WebDr.click("CHM31_OK","Click on the OK button");
					if(WebDr.isAlertPresent())
						WebDr.alertHandlingForErrors("Authorisation Pending", "Check for alert message");
					WebDr.click("FastPath", "Click in the field");
					WebDr.click("CHM31_Close","Click on the CLOSE button");
					LOAN.logout();
					WebDr.waitForPageLoaded();
					LOAN.superLogin();
					WebDr.waitForPageLoaded();
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_StandingInstruction_CHM31();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("AuthorizeBtn","Select Mode Authorize");
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
					WebDr.rTab();
					WebDr.setText("InstructionNumber", WebDr.getValue("InstructionNumber") , "Enter Instruction Number");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("CHM31_OK","Click on the OK button");
					if(WebDr.SwitchToLatestAlertCheck("Record Authorized")){
		
						HtmlReporter.WriteStep("Check whether the user is able to add a 'Standing Instruction' record or not.",
							"The user should  be able to add Standing Instruction record",
							"Standing Instruction addition successful. ", true);
					}
					else {
					
						HtmlReporter.WriteStep("Check whether the user is able to add a 'Standing Instruction' record or not.",
							"The user should  be able to add Standing Instruction record",
							"Standing Instruction addition unsuccessful. ", false);
					}
					WebDr.waitForPageLoaded();
					LOAN.logout();
					LOAN.login();
				}catch(Exception errAuth){
					errAuth.printStackTrace();
					HtmlReporter.WriteStep("Check whether the system validates for a 'Start Date' and 'End Date' for a system or not.",
							"The user should  be able to validate 'Start Date' and 'End Date' ",
							"'Start Date' and 'End Date' validation unsuccessful ", false);
				}
			}
			public static void CASA_StandingInstruction_Modify_CHM31() throws Exception {
                try {
                       pkgFCRPageObjects.FCR_CASAPageObjects.CASA_StandingInstruction_CHM31();                         
                       WebDr.fastPath(WebDr.getValue("FastPath"));
                       WebDr.waitForPageLoaded();
                       WebDr.clickwithmouse("ModifyBtn", "Click on Modify button");
                       WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
                       WebDr.rTab();
                       WebDr.setText("Instr_No", WebDr.getValue("Instr_No"), "Enter Instruction No.");
                       WebDr.rTab();
                       WebDr.selectDropValueByVisibleText("Freqeuncy", WebDr.getValue("Freqeuncy"), "Select Freqeuncy");
                       WebDr.rClearUpdateTextField("Amount",WebDr.getValue("Amount"),"Enter Amount");
                       WebDr.rClearUpdateTextField("Narrative", WebDr.getValue("Narrative") , "Enter Narrative");
                       WebDr.click("CHM31_OK","Click on the OK button");
                       WebDr.alertAccept();
                       WebDr.click("CHM31_Close","Click on the CLOSE button");
                       LOAN.logout();
                       WebDr.waitForPageLoaded();
                       /*if(WebDr.isAlertPresent())
                       {
                       WebDr.alertHandlingForErrors("SessInvalid", "Handling alert with error Session Invalid");
                       }      
                       else
                       {
                              System.out.println("**************************No Session Invalid error***********************");
                       }*/
                       LOAN.superLogin();
                       WebDr.waitForPageLoaded();
                       pkgFCRPageObjects.FCR_CASAPageObjects.CASA_StandingInstruction_CHM31();
                       WebDr.fastPath(WebDr.getValue("FastPath"));
                       WebDr.waitForPageLoaded();
                       WebDr.clickwithmouse("AuthorizeBtn","Select Mode Authorize");
                       WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
                       WebDr.rTab();
                       WebDr.waitForPageLoaded();
                       WebDr.setText("Instr_No", WebDr.getValue("Instr_No"), "Enter Instruction No.");
                       WebDr.rTab(); 
                       WebDr.waitForPageLoaded();
                       WebDr.clickwithmouse("CHM31_OK","Click on the OK button");
                       if(WebDr.SwitchToLatestAlertCheck("Record Authorized")){
                              
                              HtmlReporter.WriteStep("Check whether the user is able to modify 'Standing Instruction' record or not.",
                                     "The user should  be able to modify the standing order instruction Records",
                                     "Standing Instruction Modified successfully. ", true);
                       }
                       else {
                       
                              HtmlReporter.WriteStep("Check whether the user is able to modify 'Standing Instruction' record or not.",
                                     "The user should  be able to modify the standing order instruction Records",
                                     "Unable to mofiey Standing order Instruction", false);
                       }
                       WebDr.waitForPageLoaded();
                       LOAN.logout();
                       /*if(WebDr.isAlertPresent())
                       {
                       WebDr.alertHandlingForErrors("SessInvalid", "Handling alert with error Session Invalid");
                       }      
                       else
                       {
                              System.out.println("**************************No Session Invalid error***********************");
                       }*/
                       LOAN.login();                            
                }catch(Exception errAuth){
                       errAuth.printStackTrace();
                       HtmlReporter.WriteStep("Check whether the user is able to modify 'Standing Instruction' record or not.",
                                     "The user should  be able to modify the standing order instruction Records",
                                     "Standing Instruction Modified successfully.", false);
                }
         }

			public static void CASA_StandingInstruction_inquiry_CHM31() throws Exception {
                try {
                       // Enter_Details
                       pkgFCRPageObjects.FCR_CASAPageObjects.CASA_StandingInstruction_CHM31();                         
                       WebDr.fastPath(WebDr.getValue("FastPath"));
                       WebDr.waitForPageLoaded();
                       WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
                       WebDr.rTab();
                       WebDr.setText("Instr_No", WebDr.getValue("Instr_No"), "Enter Instruction No.");
                       WebDr.rTab();
                       String Amount= WebDr.getTextBoxValue("Amount", "Print the value of Amount filed");
                       System.out.println("Value in the the field Amount= "+Amount);               
                       WebDr.click("CHM31_Close","Click on the CLOSE button");       
                       HtmlReporter.WriteStep("check whether the user is able to inquire for an existing record or not in CHM31.",
                                     "User should be able to inquire for an existing record.",
                                     "Inquiry for an existing record successful", true);
                       }catch(Exception errAuth){
                       errAuth.printStackTrace();
                       HtmlReporter.WriteStep("check whether the user is able to inquire for an existing record or not in CHM31",
                                     "User should be able to inquire for an existing record.",
                                     "Unable to make inquiry for existing record", false);
                }
         }
			
			public static void Transaction_Definition_TC001() throws Exception {
                try {
                     
                       pkgFCRPageObjects.FCR_CASAPageObjects.Transaction_Definition_TC001();                         
                       WebDr.fastPath(WebDr.getValue("FastPath"));
                       WebDr.waitForPageLoaded();
                      /* if (WebDr.strFCRCountry.equals("NBC"))
                       {
                    	   WebDr.rTab();
                    	   WebDr.rTab();
                    	   WebDr.rEnter();
                       }*/
                       for(int i=0;i<=1;i++)
                       {
	                       WebDr.clickwithmouse("ModifyBtn","Select Mode Modify");
	                       WebDr.setText("BranchCode", WebDr.getValue("BranchCode"), "Enter Branch Code");
	                       WebDr.rTab();
	                       if(i==0)
	                    	   WebDr.setText("TransactionMnem", WebDr.getValue("TransactionMnem_CashDeposit"), "Enter Transaction Mnemonic");
	                       else
	                    	   WebDr.setText("TransactionMnem", WebDr.getValue("TransactionMnem_CashWithdrawal"), "Enter Transaction Mnemonic");
	                       WebDr.rTab();
	                       if(WebDr.IsCheckboxSelected("DualControl", "Check if Check Box is selected"))
	                    	   WebDr.clickwithmouse("OK_TC001","Click OK");
	                       else
	                       {
	                       WebDr.clickwithmouse("DualControl","Select Dual Control Checkbox");
	                       WebDr.clickwithmouse("OK_TC001","Click OK");
	                       }
	                       if(WebDr.SwitchToLatestAlertCheck("Record Authorized"))
	                       {                       
	                           HtmlReporter.WriteStep("Check whether the system ask for an authorisation or not",
	                                  "System should ask authorisation for dual auth in TC0z01 in cash deposit and cash withdrawal",
	                                  "System asks for Dual auth in TC001", true);
	                       }
	                       else {
	                           HtmlReporter.WriteStep("Check whether the system ask for an authorisation or not",
	                                  "System should ask authorisation for dual auth in TC001 in cash deposit and cash withdrawal",
	                                  "System does not ask for Dual auth in TC001", false);      
	                       } 
                       }
                       WebDr.clickwithmouse("CLOSE_TC001","Click OK");    
                }
                catch(Exception err)
                {
                	err.printStackTrace();
                	 HtmlReporter.WriteStep("Check whether the system ask for an authorisation or not",
                             "System should ask authorisation for dual auth in TC001 in cash deposit and cash withdrawal",
                             "System does not ask for Dual auth in TC001", false);
                      WebDr.clickwithmouse("CLOSE_TC001","Click OK");
                }
			}

			public static void CASAInterestRateTiersMaintenance_Modify_CHM02() throws Exception {
                try{
                       
                       pkgFCRPageObjects.FCR_CASAPageObjects.CASA_Interest_Rate_Add_CHM02();
                       WebDr.fastPath(WebDr.getValue("FastPath"));
                       WebDr.clickwithmouse("RecordModify", "Click on Modify");
                       WebDr.alertAccept();
                       WebDr.setText("Plan_code", WebDr.getValue("Plan_code"), "Enter Plan_code");
                       WebDr.rTab();
                       WebDr.rEnter();
                       WebDr.waitForPageLoad();
                       WebDr.SwitchToLatestWindow();
                       WebDr.clickElementImageSikuli("InterestType_CHM02.PNG", 5, "Select Interest type Dropdown which want to modify");
                       String TransType = WebDr.getValue("TransType");
                    WebDr.keyboard(TransType);
                    WebDr.rTab();
                       WebDr.rTab();
                       WebDr.rEnter();
                       WebDr.waitForPageLoad();
                       WebDr.SwitchToLatestWindow();
                       WebDr.clickwithmouse("Int_Variance", "Click Int_Variance");
                       WebDr.rClearSendkeys("4");
                       WebDr.rTab();
                       WebDr.clickwithmouse("OK_CHM02", "Click on OK_CHM02");
                       WebDr.alertAccept();
                       WebDr.clickwithmouse("CLOSE_CHM02", "Click on CLOSE_CHM02");
                       LOAN.logout();
                       WebDr.waitForPageLoaded();
                       LOAN.superLogin();
                       WebDr.waitForPageLoaded();
                       pkgFCRPageObjects.FCR_CASAPageObjects.CASA_Interest_Rate_Add_CHM02();
                       WebDr.fastPath(WebDr.getValue("FastPath"));
                       WebDr.waitForPageLoaded();                                    
                       WebDr.clickwithmouse("RecordAuth", "Click on Auth");
                       WebDr.alertAccept();
                       WebDr.setText("Plan_code", WebDr.getValue("Plan_code"), "Enter Plan_code");
                       WebDr.rTab();
                       WebDr.rEnter();
                       WebDr.waitForPageLoad();
                       WebDr.SwitchToLatestWindow();
                       WebDr.rTab();
                       WebDr.rTab();
                       WebDr.rEnter();
                       WebDr.waitForPageLoad();
                       WebDr.SwitchToLatestWindow();
                       WebDr.clickwithmouse("OK_CHM02", "Click on OK_CHM02");
                       WebDr.alertAccept();
                       LOAN.logout();
                       WebDr.waitForPageLoaded();
                       LOAN.login();
                       HtmlReporter.WriteStep("Check whether the user is able to  modify new rate in an existing plan code or not.",
                                     "User should be able to add new rates for 'Credit','Debit', 'Overline' and 'TOD' for an existing Plan code successfully.",
                                     "User able to modify  new rates for 'Credit','Debit', 'Overline' and 'TOD' for an existing Plan code successfully.", true);
                       
                }catch (Exception e) {
                              e.printStackTrace();
                              HtmlReporter.WriteStep("Check whether the user is able to  modify new rate in an existing plan code or not.",
                                            "User should be able to add new rates for 'Credit','Debit', 'Overline' and 'TOD' for an existing Plan code successfully.",
                                            "User is unable to modify rates for 'Credit','Debit', 'Overline' and 'TOD' for an existing Plan code successfully.", false);
                       }
                       
         }
			public static void SweepIn_Invalid_Beneficiery_Provider_Add_CHM39() throws Exception {
                try{
                       
                       pkgFCRPageObjects.FCR_CASAPageObjects.CASA_SweepIN_CHM39();
                       WebDr.fastPath(WebDr.getValue("FastPath"));
                       WebDr.waitForPageLoaded();
                       WebDr.clickwithmouse("AddBtn", "Click on ADD");
                       WebDr.setText("AccountNo", WebDr.getValue("Beneficiery_Acct_Invalid"), "Enter Beneficiery Account");
                       WebDr.rTab();
                       if(WebDr.strFCRCountry.equals("NBC"))
                       {
                    	   if(WebDr.alertClickWithText("FCR1001 : Account is Dormant."))
       						{
       							WebDr.alertAccept();
       							HtmlReporter.WriteStep("Check whether the user is able to add a sweepin for a provider having valid status and benefiary account having invalid status or not.",
	                                   "User should not be able to add a sweepin� for a provider having valid status and benefiary account having invalid status",
	                                   "User unable to add a sweepin� for a provider having valid status and benefiary account having invalid status.", true);
	                       }
                       }
                       if(WebDr.strFCRCountry.equals("BBK"))
                       {
	                       if((WebDr.alertHandlingForErrors("Invalid Account Status", "Verifying alert")))
	                       {
	                    	   HtmlReporter.WriteStep("Check whether the user is able to add a sweepin for a provider having valid status and benefiary account having invalid status or not.",
	                                   "User should not be able to add a sweepin� for a provider having valid status and benefiary account having invalid status",
	                                   "User unable to add a sweepin� for a provider having valid status and benefiary account having invalid status.", true);
	                       }
                       }
                       if(WebDr.strFCRCountry.equals("BBM"))
                       {
	                       if((WebDr.alertHandlingForErrors("Invalid account number", "Verifying alert")))
	                       {
	                    	   HtmlReporter.WriteStep("Check whether the user is able to add a sweepin for a provider having valid status and benefiary account having invalid status or not.",
	                                   "User should not be able to add a sweepin� for a provider having valid status and benefiary account having invalid status",
	                                   "User unable to add a sweepin� for a provider having valid status and benefiary account having invalid status.", true);
	                       }
                       }
                	   WebDr.rClearUpdateTextField("AccountNo", WebDr.getValue("Beneficiery_Acct_Valid"), "Enter Beneficiery Account");
                       WebDr.rTab();
                       WebDr.setText("SweepInAccountNo", WebDr.getValue("Provider_Acct_Invalid"), "Enter Provider Account");
                       WebDr.rTab();
                       if(WebDr.strFCRCountry.equals("NBC"))
                       {
                    	   WebDr.clickwithmouse("CHM39_OK", "Click on OK");
                    	   if((WebDr.alertHandlingForErrors("Sweep in account has invalid status", "Verifying alert")))
                           {
                        	   HtmlReporter.WriteStep("Check whether the user is able to add a sweepin for a provider having invalid status and benefiary account having valid status or not.",
                                   "User should not be able to add a sweepin� for a provider having invalid status and benefiary account having valid status",
                                   "User unable to add a sweepin� for a provider having invalid status and benefiary account having regular status.", true);
                        	   WebDr.clickwithmouse("CHM39_Close", "Click on CLOSE");
                           }
                       }
                       if(WebDr.strFCRCountry.equals("UG") || WebDr.strFCRCountry.equals("BBK"))
                       {
                    	   HtmlReporter.WriteStep("Check whether the user is able to add a sweepin for a provider having invalid status and benefiary account having valid status or not.",
                               "User should not be able to add a sweepin� for a provider having invalid status and benefiary account having valid status",
                               "User unable to add a sweepin� for a provider having invalid status and benefiary account having regular status.", true);
                    	   WebDr.clickwithmouse("CHM39_Close", "Click on CLOSE");
                       }
                       if(WebDr.strFCRCountry.equals("BBM"))
                       {
	                       if((WebDr.alertHandlingForErrors("Invalid account number", "Verifying alert")))
	                       {
	                    	   HtmlReporter.WriteStep("Check whether the user is able to add a sweepin for a provider having valid status and benefiary account having invalid status or not.",
	                                   "User should not be able to add a sweepin� for a provider having valid status and benefiary account having invalid status",
	                                   "User unable to add a sweepin� for a provider having valid status and benefiary account having invalid status.", true);
	                       }
                       }
                }catch (Exception e) {
                              e.printStackTrace();
                              HtmlReporter.WriteStep("Check whether the user is able to add a sweepin for a provider having invalid status and benefiary account having regular status and vice -versa or not.",
                                      "User should not be able to add a sweepin� for a provider having invalid status and benefiary account having regular status and vice-versa.",
                                      "User able to add a sweepin� for a provider having invalid status and benefiary account having regular status and vice -versa.", false);
                              WebDr.clickwithmouse("CHM39_Close", "Click on CLOSE");
                       }
                       
         }
			
			public static void SweepIn_Modified_Added_Excution_CHM39() throws Exception {
                try{
              	//Step1 - Modification
                	pkgFCRPageObjects.FCR_CASAPageObjects.CASA_SweepIN_CHM39();				
					WebDr.fastPath(WebDr.getValue("FastPath_SweepIn"));
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("ModifyBtn", "Selct Mode MODIFY");
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("AccountNo", "Click on the Account Number tab");
                    WebDr.waitForPageLoaded();
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Beneficiery Account Number");
					WebDr.rTab();
					WebDr.setText("InstructionNumber", WebDr.getValue("InstructionNumber"), "Enter Instruction Number");
					WebDr.rTab();
					WebDr.rClearUpdateTextField("SweepInAccountNo", WebDr.getValue("SweepInAccountNo"), "Enter SweepIn Account Number");
					WebDr.click("CHM39_OK","Click on the OK button");
					if(WebDr.isAlertPresent())
						WebDr.alertHandlingForErrors("Authorisation Pending", "Check for alert message");
					WebDr.click("FastPath", "Click in the field");
					WebDr.click("CHM39_Close","Click on the CLOSE button");
					LOAN.logout();
					WebDr.waitForPageLoaded();
					LOAN.superLogin();
					WebDr.waitForPageLoaded();
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_SweepIN_CHM39();
					WebDr.fastPath(WebDr.getValue("FastPath_SweepIn"));
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("AuthorizeBtn","Select Mode Authorize");
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
					WebDr.rTab();
					WebDr.setText("InstructionNumber", WebDr.getValue("InstructionNumber"), "Enter Instruction Number");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("CHM39_OK","Click on the OK button");
					if(WebDr.SwitchToLatestAlertCheck("Record Authorized")){
						HtmlReporter.WriteStep("Check whether the user is able to modify a 'Sweep in' record or not.",
							"The user should  be able to modify swee"
							+ "p in record",
							"Sweep In modification successful. ", true);
					}
					else {
						HtmlReporter.WriteStep("Check whether the user is able to modify a 'Sweep in' record or not.",
							"The user should  be able to modify sweep in record",
							"Sweep In modification unsuccessful. ", false);
					}
					WebDr.waitForPageLoaded();
					LOAN.logout();
					LOAN.login();
                
					 //Step-2 Transaction - Cash Withdrawal
					if(WebDr.getValue("Classification").equals("CashWithdrawalTxn"))
					 {
					 CashWithdrawal_1001();
					 }
				
					 //Step-3 Statement Inquiry 
					 pkgFCRPageObjects.FCR_CASAPageObjects.CASSViewAccountStatement_CH031();
						WebDr.fastPath(WebDr.getValue("FastPath_StatementInquiry"));
						WebDr.waitForPageLoaded();
						WebDr.rTab();
						WebDr.waitForPageLoaded();	
						
						WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number for statement enquiry");
						
						WebDr.rTab();
						WebDr.waitForPageLoaded();	
						
						WebDr.click("RadioTransaction", "Click on Transactions radio button");
						
						WebDr.rClearUpdateTextField("StartDate", WebDr.getValue("StartDate"), "Enter start date");
						WebDr.rTab();

						if (! WebDr.getValue("EndDate").isEmpty()){
							WebDr.rDelete();
							WebDr.setText("EndDate", WebDr.getValue("EndDate"), "Enter end date");
							WebDr.rTab();
						}

						WebDr.waitForPageLoaded();
//						WebDr.click("AccountNo", "Click on acc no");
						WebDr.clickwithmouse("Inquire", "Click on Inquire button");	
						WebDr.waitForPageLoaded();
	
					//Verification
						if(WebDr.isElementExist("ModifiedAccount", "Check if modified account is displayed"))
						{
							HtmlReporter.WriteStep("Check whether the user is able to execute the modifed and added sweepin sucessfully or not.",
									"The user should  be able to to execute the modifed and added sweepin",
									"Modifed and added sweepin execution successful", true);
							WebDr.clickwithmouse("CANCEL_CH031", "Click on CANCEL");
							
						}
						
				}catch(Exception errAuth){
					errAuth.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to execute the modifed and added sweepin sucessfully or not.",
							"The user should  be able to to execute the modifed and added sweepin",
							"Modifed and added sweepin execution unsuccessful", false);
				}
                       
         }
			
			public static void SweepIn_Inquiry_CHM39() throws Exception {
                try{
                       
                       pkgFCRPageObjects.FCR_CASAPageObjects.CASA_SweepIN_CHM39();
                       WebDr.fastPath(WebDr.getValue("FastPath"));
                       WebDr.waitForPageLoaded();
                       WebDr.clickwithmouse("AccountNo", "Click on the Account Number tab");
                       WebDr.waitForPageLoaded();
                       WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number for Inquiry");
                       WebDr.rTab();
                       if( ! (WebDr.strFCRCountry.equals("BBM"))){
                    	   
                      
                       WebDr.setText("InstructionNumber", WebDr.getValue("InstructionNumber") , "Enter Instruction Number");
                       WebDr.rTab();
                       }
                       if(WebDr.alertClickWithText("FCR1688 : Record does not Exist"))
   						{
   						WebDr.alertAccept();
   						HtmlReporter.WriteStep("check whether the user is able to inquire for an existing record or not.",
                             "User should be able to inquire for an existing record.",
                             "User not able to inquire for an existing record.", false);
   						WebDr.clickwithmouse("CHM39_Close", "Click on CLOSE");
   						}
                       else
                       {
                       HtmlReporter.WriteStep("check whether the user is able to inquire for an existing record or not.",
                               "User should be able to inquire for an existing record.",
                               "User able to inquire for an existing record.", true);
                       WebDr.clickwithmouse("CHM39_Close", "Click on CLOSE"); 
                       }
                }catch (Exception e) {
                              e.printStackTrace();
                              HtmlReporter.WriteStep("check whether the user is able to inquire for an existing record or not.",
                                      "User should be able to inquire for an existing record.",
                                      "User not able to inquire for an existing record.", false);
                              WebDr.clickwithmouse("CHM39_Close", "Click on CLOSE");
                       }
                       
         }

			public static void SweepOutMMaintainance__Date_Verify_CHM32() throws Exception {
				try {
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_SweepOutMaintenance_Modify_CHM32();		
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("Modify", "Selct Mode MODIFY");     
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.setText("Instruction_No", WebDr.getValue("Instruction_No") , "Enter Instruction Number");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
		
					WebDr.rClearUpdateTextField("StartDate", WebDr.getValue("StartDateInvalid"), "Enter Start Date");
					WebDr.click("OK","Click on the OK button");
					if(WebDr.strFCRCountry.equals("BBM"))		
						WebDr.alertClickWithText("FCR2962 : Start Date should not be less than account opening date");
					WebDr.alertClickWithText("FCR2699 : Date should be Greater than or equal to Process Date");
					WebDr.rClearUpdateTextField("StartDate", WebDr.getValue("StartDateValid"), "Enter Correct Start Date");
					WebDr.rClearUpdateTextField("EndDate", WebDr.getValue("EndDateInvalid"), "Enter End Date");
					WebDr.click("OK","Click on the OK button");
					WebDr.alertClickWithText("FCR2966 : Next Date should not be greater than Expiry Date..");
					WebDr.rClearUpdateTextField("EndDate", WebDr.getValue("EndDateValid"), "Enter Correct End Date");
					
					WebDr.rClearUpdateTextField("NextDate", WebDr.getValue("NextDateInavlid"), "Enter Inavlid Next Date");
					WebDr.click("OK","Click on the OK button");
					if(WebDr.strFCRCountry.equals("BBM"))
						WebDr.alertClickWithText("FCR2965 : Start Date should not be greater than next date");
					else
					{
						WebDr.alertClickWithText("FCR2965 : Start date should not be greater than next date");
					}
					WebDr.alertClickWithText("FCR2699 : Date should be Greater than or equal to Process Date");
					WebDr.rClearUpdateTextField("NextDate", WebDr.getValue("NextDateValid"), "Enter Correct Next Date");
					
					WebDr.click("OK","Click on the OK button");
					if(WebDr.isAlertPresent())
						WebDr.alertHandlingForErrors("Authorisation Pending", "Check for alert message");
					WebDr.click("FastPath", "Click in the field");
					WebDr.click("Close","Click on the CLOSE button");
					LOAN.logout();
					WebDr.waitForPageLoaded();
					LOAN.superLogin();
					WebDr.waitForPageLoaded();
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_SweepOutMaintenance_Add_CHM32();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("RecordAuth","Select Mode Authorize");
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
					WebDr.rTab();
					WebDr.setText("Instruction_No", WebDr.getValue("Instruction_No") , "Enter Instruction Number");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("Close","Click on the OK button");
					if(WebDr.SwitchToLatestAlertCheck("Record Authorized")){
		
						HtmlReporter.WriteStep("Check whether the user is able to add a 'Standing Instruction' record or not.",
							"The user should  be able to add Standing Instruction record",
							"Standing Instruction addition successful. ", true);
					}
					else {
					
						HtmlReporter.WriteStep("Check whether the user is able to add a 'Standing Instruction' record or not.",
							"The user should  be able to add Standing Instruction record",
							"Standing Instruction addition unsuccessful. ", false);
					}
					WebDr.waitForPageLoaded();
					LOAN.logout();
					LOAN.login();
				}catch(Exception errAuth){
					errAuth.printStackTrace();
					HtmlReporter.WriteStep("Check whether the system validates for a 'Start Date' and 'End Date' for a system or not.",
							"The user should  be able to validate 'Start Date' and 'End Date' ",
							"'Start Date' and 'End Date' validation unsuccessful ", false);
				}
				
				
			}

			public static void CASA_SweepOutMaintenance_ValidCASAAcct_CHM32() throws Exception {
				try {
					// Enter_Details
					pkgFCRPageObjects.FCR_CASAPageObjects.CASA_SweepOutMaintenance_Add_CHM32();				
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("RecordAdd", "Select Mode ADD");
					WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
					WebDr.rTab();
					if (WebDr.getValue("ExecutionType").equals("EOD"))
						WebDr.click("ExecutionTypeEOD", "Click Execution Type");
					else if(WebDr.getValue("ExecutionType").equals("BOD"))
						WebDr.click("ExecutionTypeBOD", "Click Execution Type");
					WebDr.rTab();
					//WebDr.rClearUpdateTextField("StartDate", WebDr.getValue("StartDate"), "Enter Correct Start Date");
					WebDr.rClearUpdateTextField("NextDate", WebDr.getValue("NextDate"), "Enter Correct Next Date");
					WebDr.rTab();
					WebDr.rClearUpdateTextField("MaxAmtSweepOut", WebDr.getValue("MaxAmtSweepOut"), "Enter Max Amt SweepOut");
					WebDr.rClearUpdateTextField("MinAmtSweepOut", WebDr.getValue("MinAmtSweepOut"), "Enter Min Amt SweepOut");
					
					if (WebDr.getValue("SweepOutTo").equals("CASA"))
					{
						WebDr.click("SweepOutToCASA", "Sweep out to CASA Account");
					    WebDr.setText("CASASweepOutAccount", WebDr.getValue("TDSweepOutAccount"), "Enter TD SweepOut Account");
					    WebDr.rTab();
					    if(WebDr.isAlertPresent())
					    {
					    WebDr.getTextOnAlertPopup("Alert for Invalid acccount no");
					    WebDr.alertAccept();
					    HtmlReporter.WriteStep("Check whether the system validates 'Sweepout to' for CASA account or not.",
								"System should validate 'Sweepout to'  for CASA account successfully.",
								"System validate 'Sweepout to'  for CASA account successfully. ", true);
						}
						else {
								
							HtmlReporter.WriteStep("Check whether the system validates 'Sweepout to' for CASA account or not.",
									"System should validate 'Sweepout to'  for CASA account successfully.",
									"System doesn't validate 'Sweepout to'  for CASA account. ", false);
					    
					    }
					    
					    WebDr.clearMethod("CASASweepOutAccount");
					    WebDr.rTab();
					}
					
					}
					catch(Exception errAuth){
					errAuth.printStackTrace();
					HtmlReporter.WriteStep("Check whether the system validates 'Sweepout to' for CASA account or not.",
							"System should validate 'Sweepout to'  for CASA account successfully.",
							"System doesn't validate 'Sweepout to'  for CASA account. ", false);
				}
			}
			
			public static void TD_LN_Products_NotViewed_8051() throws Exception {
				try {
					pkgFCRPageObjects.FCR_CASAPageObjects.CASAAcctOpening_8051();
					WebDr.fastPath(WebDr.getValue("FastPath"));
					WebDr.waitForPageLoaded();
					WebDr.selectDropValueByVisibleText("BranchName",WebDr.getValue("BranchName"), "Select Branch Name");
					Select  selProducts=new Select(driver.findElement(By.id("ProductCode")));
					List<WebElement> list =selProducts.getOptions();
					list.remove(selProducts.getFirstSelectedOption());
					System.out.println("	CHECKING FOR TD OR Loan PRODUCTS	 ");
					ArrayList arrlist = new ArrayList();
					String startNum = WebDr.getValue("StartProductNumber");
					int startNumber = Integer.parseInt(startNum);
					String endNum = WebDr.getValue("EndProductNumber");
					int endNumber = Integer.parseInt(endNum);
					for(int i=startNumber; i<=endNumber; i++)
					{
						arrlist.add(i);
					}
					for(WebElement elements : list)
					{		
						for(int intcnt = 0;intcnt<arrlist.size();intcnt++)
						{
							if(elements.equals(arrlist.get(intcnt)))
							{
								System.out.println(list.get(intcnt).getText());
								HtmlReporter.WriteStep("Check while account opening user is able to view the TD or Loan products or not.",
									"User should not be able to view the TD or Loan products in 8051 screen at the time of account openning",
									"User able to view the TD or Loan products in 8051 screen at the time of account openning", false);
							}
							
						}
					}
					//DBValidation
					for(int intcnt = 0;intcnt<arrlist.size();intcnt++)
					{
					String DBvalue = FCRDBConnection.QueryValueExecutor(WebDr.getValue("Query_one"), arrlist.get(intcnt).toString(), WebDr.getValue("Query_two"));
					if(DBvalue==null)
					{
						HtmlReporter.WriteStep("Check while account openning user is able to view the TD or Loan products or not through DB VALIDATION",
								"User should not be able to view the TD or Loan products in 8051 screen at the time of account openning through DB VALIDATION",
								"User not able to view the TD or Loan products in 8051 screen at the time of account openning through DB VALIDATION", true);
					}
					}
					System.out.println(" TD Product code from range : \t"+startNumber+ " to " +endNumber+" not found in 8051");
					HtmlReporter.WriteStep("Check while account openning user is able to view the TD or Loan products or not.",
							"User should not be able to view the TD or Loan products in 8051 screen at the time of account openning",
							"User not able to view the TD or Loan products in 8051 screen at the time of account openning", true);					
					}
					catch(Exception errAuth){
					errAuth.printStackTrace();
					HtmlReporter.WriteStep("Check while account openning user is able to view the TD products or not.",
							"User should not be able to view the TD or Loan products in 8051 screen at the time of account openning",
							"User able to view the TD or Loan products in 8051 screen at the time of account openning", false);
				}
			}
			
			
			
}



	
