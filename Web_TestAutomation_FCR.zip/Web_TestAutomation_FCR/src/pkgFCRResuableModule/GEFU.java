package pkgFCRResuableModule;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import testCases.Driver;
import utility.HtmlReporter;
import utility.WebDr;

public class GEFU extends Driver {
	
	
	public static void GEFU_File_Upload_BA452() throws Exception {
		try{
			pkgFCRPageObjects.FCR_GEFUPageObjects.GEFU_FileUpload_BA452();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("ExtSysCodePickList", "Click on External System Code Pick List");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("FileTypePickList", "Click on File Type Pick List");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.setText("InputFileName", WebDr.getValue("InputFileName"), "Enter Input File Name");
			WebDr.setText("Narration", WebDr.getValue("Narration"), "Enter Narration");
			WebDr.clickwithmouse("OKButton", "Click on OK Button");
			
			try{
				
				if (WebDr.alertClickWithText("File Successfully"))
					HtmlReporter.WriteStep("Check if the GEFU File can be successfully uploaded using BA452 option",
							"User should be able to upload the GEFU File successfully using BA452 option",
							"File Upload Successful. ", true);
				else
					HtmlReporter.WriteStep("Check if the GEFU File can be successfully uploaded using BA452 option",
							"User should be able to upload the GEFU File successfully using BA452 option",
							"File Upload not Successful. ", false);
			}
			catch(Exception e){
				e.printStackTrace();
			}
			
			
			}
			catch(Exception error){
			error.printStackTrace();
			HtmlReporter.WriteStep("Check if the GEFU File can be successfully uploaded using BA452 option",
					"User should be able to upload the GEFU File successfully using BA452 option",
					"File Upload not Successful. ", false);
			}
	}
	
	
	public static void GEFU_File_Upload_Inquiry_BAM96() throws Exception {
		try{
			pkgFCRPageObjects.FCR_GEFUPageObjects.GEFU_FileUploadInquiry_BAM96();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("ExtSysCodePickList", "Click on External System Code Pick List");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rDown();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			
			WebDr.clickwithmouse("FileTypePickList", "Click on File Type Pick List");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			
			WebDr.clickwithmouse("OKButton", "Click on OK Button");
			WebDr.doubleClick("GEFUUploadedFile");
			WebDr.clickwithmouse("GetResponseButton", "Click on Get Response Button");
			
			
			try{
				
				if (WebDr.alertClickWithText("File"))
					HtmlReporter.WriteStep("Check the uplaod status inquiry for both gefu and maint using BAM96 option by providing XF system code",
							"User should be able to Check the uplaod status inquiry for both gefu and maint using BAM96 option",
							"File Generated Successfully. ", true);
				else
					HtmlReporter.WriteStep("Check the uplaod status inquiry for both gefu and maint using BAM96 option by providing XF system code",
							"User should be able to Check the uplaod status inquiry for both gefu and maint using BAM96 option",
							"File not generated ", false);
			}
			catch(Exception e){
				e.printStackTrace();
			}
			
			
			}
			catch(Exception error){
			error.printStackTrace();
			HtmlReporter.WriteStep("Check the uplaod status inquiry for both gefu and maint using BAM96 option by providing XF system code",
					"User should be able to Check the uplaod status inquiry for both gefu and maint using BAM96 option",
					"File not generated ", false);
			}
	}
	
	public static void GEFU_Statement_Inquiry_CH031() throws Exception {
		try{
			pkgFCRPageObjects.FCR_GEFUPageObjects.GEFU_StatementInquiry_CH031();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.setText("AccountNumber", WebDr.getValue("AccountNumber"), "Enter Account Number");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			
			
			
			try{
				
				if (WebDr.alertClickWithText(""))
					HtmlReporter.WriteStep("Check if the transactions are passed for GEFU Upload, inquire in CH031 option",
							"User should be able to Check if the transactions are passed for GEFU Upload, inquire in CH031 option",
							"Transaction Successful", true);
				else
					HtmlReporter.WriteStep("Check if the transactions are passed for GEFU Upload, inquire in CH031 option",
							"User should be able to Check if the transactions are passed for GEFU Upload, inquire in CH031 option",
							"Transaction not successful", false);
			}
			catch(Exception e){
				e.printStackTrace();
			}
			
			
			}
			catch(Exception error){
			error.printStackTrace();
			HtmlReporter.WriteStep("Check if the transactions are passed for GEFU Upload, inquire in CH031 option",
					"User should be able to Check if the transactions are passed for GEFU Upload, inquire in CH031 option",
					"Transaction not successful", false);
			}
	}


	public static void GEFU_StartDate_EndDate_BAM96() throws Exception 
	{
		try{
			pkgFCRPageObjects.FCR_GEFUPageObjects.GEFU_FileUploadInquiry_BAM96();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("ExtSysCodePickList", "Click on External System Code Pick List");
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();                                            
			WebDr.waitForPageLoaded();                                                                                                                                                                                                   
			for(int i=0;i<=8;i++)
			{
				WebDr.rDown();
				WebDr.waitForPageLoaded();
			}
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("FileTypePickList", "Click on File Type Pick List");
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			
			WebDr.clearMethod("UserID");
			WebDr.setText("UserID", WebDr.getValue("UserID") , "Enter User ID");
			WebDr.clearMethod("UploadDate");
			WebDr.setText("UploadDate", WebDr.getValue("UploadDate") , "Enter Upload Date");
			WebDr.clearMethod("ProcessDate");
			WebDr.setText("ProcessDate", WebDr.getValue("ProcessDate") , "Enter Upload Date");
			WebDr.rTab();
			WebDr.rTab();
			WebDr.selectDropValueByVisibleText("BranchCode", WebDr.getValue("BranchCode"), "Select Branch Code");
			WebDr.clickwithmouse("OKButton", "Click on OK Button");
			WebDr.waitForPageLoaded();
			if(WebDr.isElementExist("StartDate", "Start Date") && WebDr.isElementExist("EndDate", "End Date"))
			{
				HtmlReporter.WriteStep("Check the Start time and end time are stamped for the File uploaded",
					"User should be able to check the start and end time",
					"Start and End Date Stamped for the File upload", true);	
			}
			else
			{
				HtmlReporter.WriteStep("Check the Start time and end time are stamped for the File uploaded",
						"User should be able to check the start and end time",
						"Start and End Date not Stamped for the File upload", false);
			}
			}
			catch(Exception error){
			error.printStackTrace();
			HtmlReporter.WriteStep("Check the Start time and end time are stamped for the File uploaded",
					"User should be able to check the start and end time",
					"Start and End Date not Stamped for the File upload", false);
			}
	}
	
	public static void GEFU_File_Status_Inquiry_BAM96() throws Exception
	{
		try
		{
			
			pkgFCRPageObjects.FCR_GEFUPageObjects.GEFU_FileUploadInquiry_BAM96();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("ExtSysCodePickList", "Click on External System Code Pick List");
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();                                            
			WebDr.waitForPageLoaded();                                                                                                                                                                                                   
			WebDr.rDown();
			WebDr.waitForPageLoaded(); 
			if(WebDr.strFCRCountry.equals("UG") || WebDr.strFCRCountry.equals("BBK") || WebDr.strFCRCountry.equals("BBM"))
			{
			WebDr.rDown();
			WebDr.waitForPageLoaded();
			}
			if(WebDr.strFCRCountry.equals("BBK") || WebDr.strFCRCountry.equals("BBM"))
			{
				WebDr.rDown();
				WebDr.waitForPageLoaded();
			}
			if(WebDr.strFCRCountry.equals("BBM"))
			{
				WebDr.rDown();
				WebDr.waitForPageLoaded();
			}
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("FileTypePickList", "Click on File Type Pick List");
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.clearMethod("UserID");
			WebDr.setText("UserID", WebDr.getValue("UserID") , "Enter User ID");
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("BranchCode", WebDr.getValue("BranchCode"), "Select Branch Code");
			WebDr.clickwithmouse("OKButton", "Click on OK Button");
			WebDr.waitForPageLoaded();
			if (!(WebDr.alertClickWithText("No data found")))
			{
			switch(WebDr.getValue("Choice"))
			{
			case "StatusInquiry": 
				WebElement StatusProcessed=WebDr.getElement("Status");
				String Status = StatusProcessed.getText();
				//System.out.println("***************   "+ Status);
				//Status.contentEquals("Processed");
				//System.out.println( "*********** " + Status.contentEquals("Processed"));
				if(Status.contentEquals(WebDr.getValue("ExpectedValue")))
				{
					HtmlReporter.WriteStep("Check if the Files status can be checked by providing XF system code and file name, process date",
							"User should be able to Check if the Files status can be checked by providing XF system code and file name, process date",
							"Transaction Successful", true);
				}
				else
				{
					HtmlReporter.WriteStep("Check if the Files status can be checked by providing XF system code and file name, process date",
							"User should not be able to Check if the Files status can be checked by providing XF system code and file name, process date",
							"Transaction Not Successful", false);
				}
				break;
				
			case "FileLevelInquiry":
				WebDr.doubleclickwithmouse("Record", "Click on the record");
				WebDr.waitForPageLoaded();
				WebElement FileProcessed=WebDr.getElement("RecordStatus");
				String FileStatus = FileProcessed.getText();
				if(FileStatus.contentEquals(WebDr.getValue("ExpectedValue")))
				{
					HtmlReporter.WriteStep("Check if the Files status can be checked by providing XF system code and file name, process date",
							"User should be able to Check if the Files status can be checked by providing XF system code and file name, process date",
							"Transaction Successful", true);
				}
				else
				{
					HtmlReporter.WriteStep("Check if the Files status can be checked by providing XF system code and file name, process date",
							"User should not be able to Check if the Files status can be checked by providing XF system code and file name, process date",
							"Transaction Not Successful", false);
				}
				break;
				
			case "RecordLevelInquiry":
				WebDr.doubleclickwithmouse("Record", "Click on the record");
				WebDr.waitForPageLoaded();
				WebDr.doubleclickwithmouse("RecordStatus", "Click on the record");
				WebDr.waitForPageLoaded();
				WebElement RecordProcessed=WebDr.getElement("RecordDetails");
				String RecordStatus = RecordProcessed.getText();
				if(RecordStatus.contentEquals(WebDr.getValue("ExpectedValue")))
				{
					HtmlReporter.WriteStep("Check if the Files status can be checked by providing XF system code and file name, process date",
							"User should be able to Check if the Files status can be checked by providing XF system code and file name, process date",
							"Transaction Successful", true);
				}
				else
				{
					HtmlReporter.WriteStep("Check if the Files status can be checked by providing XF system code and file name, process date",
							"User should not be able to Check if the Files status can be checked by providing XF system code and file name, process date",
							"Transaction Not Successful", false);
				}
				
				break;
			}//switch ends
			}//if ends
			else
			{
					HtmlReporter.WriteStep("Check if the Files status can be checked by providing XF system code and file name, process date",
							"User should not be able to Check if the Files status can be checked by providing XF system code and file name, process date",
							"Transaction Not Successful", false);
			}
		}
			
		catch(Exception e){
				e.printStackTrace();
			
			}
		
	}
}
			
		

	
	
	

