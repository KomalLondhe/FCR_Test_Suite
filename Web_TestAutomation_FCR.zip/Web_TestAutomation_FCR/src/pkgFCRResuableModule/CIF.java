		
package pkgFCRResuableModule;

import org.apache.poi.hssf.record.formula.functions.If;
import org.openqa.selenium.UnhandledAlertException;
import org.openqa.selenium.interactions.Keyboard;

//import com.thoughtworks.selenium.webdriven.commands.WaitForPageToLoad;

import testCases.Driver;
import utility.Constant;
import utility.FCRDBConnection;
import utility.HtmlReporter;
import utility.WebDr;

public class CIF extends Driver {
	public static void Customer_Addition_8053() throws UnhandledAlertException, Exception {
		try{
			pkgFCRPageObjects.FCR_CIFPageObjects.Customer_Addition_8053();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.setText("CustomerIC", WebDr.getValue("CustomerIC") + WebDr.getTimeStamp(), "Enter CustomerIC");	
			WebDr.selectDropValueByVisibleText("Category", WebDr.getValue("Category"), "Select Category	");
			if (WebDr.strFCRCountry.equals("BBK")){
			WebDr.rTab();			
			WebDr.alertHandlingForErrors("new customer", "Click on alert");
			WebDr.rClearUpdateTextField("DateOfBirth", WebDr.getValue("DateOfBirth"),"Enter Date Of Birth");
			WebDr.selectDropValueByVisibleText("Gender", WebDr.getValue("Gender"), "Select Gender");
			WebDr.selectDropValueByVisibleText("Salutation", WebDr.getValue("Salutation"), "Selecy Salutation");
			WebDr.setText("FirstName", WebDr.getValue("FirstName")  + WebDr.getTimeStamp(), "Enter FirstName");
			WebDr.rTab();
			
			if(WebDr.alertClickWithText("No data found")){
				WebDr.waitForPageLoaded();
				WebDr.setText("MiddleName", WebDr.getValue("MiddleName"), "Enter MiddleName");
				WebDr.setText("LastName", WebDr.getValue("LastName"), "Enter LastName");
			}
			else{
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.rTab();
				WebDr.rDown();
				WebDr.rEnter();
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				WebDr.setText("MiddleName", WebDr.getValue("MiddleName"), "Enter MiddleName");
				WebDr.setText("LastName", WebDr.getValue("LastName"), "Enter LastName");
			}
			WebDr.setText("ShortName", WebDr.getValue("ShortName"), "Enter Shortname");
			WebDr.selectDropValueByVisibleText("Language", WebDr.getValue("Language"), "Select Language");
			WebDr.selectDropValueByVisibleText("Nationality", WebDr.getValue("Nationality"), "Select Nationality");
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("ResidentCountry", WebDr.getValue("ResidentCountry"), "Select Country of Residence");
			WebDr.selectDropValueByVisibleText("MaritalStatus", WebDr.getValue("MaritalStatus"), "Select Marital status");
			WebDr.selectDropValueByVisibleText("Profession", WebDr.getValue("Profession"), "Select Profession");
			WebDr.setText("Designation", WebDr.getValue("Designation"), "Enter Designation");
			WebDr.selectDropValueByVisibleText("IncomeCategory", WebDr.getValue("IncomeCategory"), "Select Income Category");
			WebDr.selectDropValueByVisibleText("Business_kenya", WebDr.getValue("Business"), "Select Business Category");
			WebDr.setText("AddressLine1", WebDr.getValue("AddressLine1"), "Enter Address");
			WebDr.setText("AddressLine2", WebDr.getValue("AddressLine2"), "Enter Address");
			WebDr.setText("AddressLine3", WebDr.getValue("AddressLine3"), "Enter Address");
			WebDr.selectDropValueByVisibleText("City", WebDr.getValue("City"), "Select City");
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("State", WebDr.getValue("State"), "Select State");
			WebDr.waitForPageLoaded();
			WebDr.setText("Zipcode", WebDr.getValue("Zipcode"), "Enter Zipcode");
			WebDr.setText("Phone1", WebDr.getValue("Phone1"), "Enter Phone number");
			WebDr.setText("Phone2", WebDr.getValue("Phone2"), "Enter Phone number");
			WebDr.setText("Phone3", WebDr.getValue("Phone3"), "Enter Phone number");
			WebDr.setText("Fax", WebDr.getValue("Fax"), "Enter Fax number");
			WebDr.setText("OfficePhone1", WebDr.getValue("OfficePhone1"), "Enter Phone number");
			WebDr.setText("OfficePhone2", WebDr.getValue("OfficePhone2"), "Enter Phone number");
			WebDr.setText("OfficePhone3", WebDr.getValue("OfficePhone3"), "Enter Phone number");
			WebDr.setText("OfficePhone4", WebDr.getValue("OfficePhone4"), "Enter Phone number");
			WebDr.setText("Mail", WebDr.getValue("Mail"), "Enter Mail");
			WebDr.setText("Email", WebDr.getValue("Email"), "Enter EmailId");
			WebDr.clickwithmouse("Kenya_OK", "Click on Validate customer");
			}
			else
			{
				WebDr.selectDropValueByVisibleText("Language", WebDr.getValue("Language"), "Select Language");
				WebDr.setText("ShortName", WebDr.getValue("ShortName"), "Enter Shortname");
				WebDr.selectDropValueByVisibleText("Salutation", WebDr.getValue("Salutation"), "Selecy Salutation");
				WebDr.setText("FirstName", WebDr.getValue("FirstName"), "Enter FirstName");
				WebDr.setText("MiddleName", WebDr.getValue("MiddleName"), "Enter MiddleName");
				WebDr.setText("LastName", WebDr.getValue("LastName"), "Enter LastName");
				WebDr.setText("AddressLine1", WebDr.getValue("AddressLine1"), "Enter Address");
				WebDr.setText("AddressLine2", WebDr.getValue("AddressLine2"), "Enter Address");
				WebDr.setText("AddressLine3", WebDr.getValue("AddressLine3"), "Enter Address");
				WebDr.selectDropValueByVisibleText("City", WebDr.getValue("City"), "Select City");
				WebDr.waitForPageLoaded();
				WebDr.selectDropValueByVisibleText("State", WebDr.getValue("State"), "Select State");
				WebDr.waitForPageLoaded();
				WebDr.selectDropValueByVisibleText("Country", WebDr.getValue("Country"), "Select Country");
				WebDr.waitForPageLoaded();
				/*WebDr.selectDropValueByVisibleText("ResidentCountry", WebDr.getValue("ResidentCountry"), "Select Country of Residence");
				WebDr.waitForPageLoaded();*/
				WebDr.selectDropValueByVisibleText("Nationality", WebDr.getValue("Nationality"), "Select Nationality");
				WebDr.waitForPageLoaded();
				WebDr.setText("Zipcode", WebDr.getValue("Zipcode"), "Enter Zipcode");
				WebDr.rClearUpdateTextField("DateOfBirth", WebDr.getValue("DateOfBirth"),"Enter Date Of Birth");
				WebDr.waitForPageLoaded();
				//WebDr.setText("DateOfBirth", WebDr.getValue("DateOfBirth"), "Enter DateofBirth");
				
				WebDr.setText("Phone1", WebDr.getValue("Phone1"), "Enter Phone number");
				WebDr.setText("Phone2", WebDr.getValue("Phone2"), "Enter Phone number");
				WebDr.setText("Phone3", WebDr.getValue("Phone3"), "Enter Phone number");
				WebDr.selectDropValueByVisibleText("CustEducation", WebDr.getValue("CustEducation"), "Select Customer Education");
				WebDr.setText("MobileNo", WebDr.getValue("MobileNo"), "Enter Mobile Number");
				WebDr.setText("Email", WebDr.getValue("Email"), "Enter EmailId");
				WebDr.selectDropValueByVisibleText("Gender", WebDr.getValue("Gender"), "Select Gender");
				WebDr.selectDropValueByVisibleText("MaritalStatus", WebDr.getValue("MaritalStatus"), "Select Marital status");
				
				//check this condition
				//WebDr.selectDropValueByVisibleText("Business", WebDr.getValue("Business"), "Select Business");
				
				// uncomment below 3 lines for creating a staff customer //
				/*WebDr.click("Staff_flag", "");
				WebDr.rTab();
				WebDr.setText("Employee_ID", WebDr.getTimeStamp(), "Enter CustomerIC");*/
				WebDr.click("Business", "Click Business");
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.rTab();
				WebDr.rDown();
				WebDr.rDown();
				WebDr.rEnter();
				//WebDr.rClearSelSendkeys(elementName, Value);
				WebDr.SwitchToLatestWindow();
			//WebDr.waitForPageLoaded();
				WebDr.selectDropValueByVisibleText("Profession", WebDr.getValue("Profession"), "Select Profession");
				if ((WebDr.strFCRCountry.equals("NBC")) || (WebDr.strFCRCountry.equals("BBM")))
				{
					WebDr.selectDropValueByVisibleText("AMLRating", WebDr.getValue("AMLRating"), "Select AMLRating");
					WebDr.selectDropValueByVisibleText("PEP", WebDr.getValue("PEP"), "Select PEP");
					WebDr.selectDropValueByVisibleText("InternationalTxn", WebDr.getValue("InternationalTxn"), "Select International Transactionn");
					WebDr.setText("IssuingAuth", WebDr.getValue("IssuingAuth"), "Enter Issuing Authority");
					WebDr.setText("Issuingbranch", WebDr.getValue("Issuingbranch"), "Enter Issuing Branch");
					//WebDr.clearMethod("IssuingDate");
					WebDr.rClearUpdateTextField("IssuingDate", WebDr.getValue("IssuingDate"),"Enter Issuing Date");
					//WebDr.setText("IssuingDate", WebDr.getValue("IssuingDate"), "Enter Issuing Date");
					//WebDr.clearMethod("CIVDate");
					WebDr.rClearUpdateTextField("CIVDate", WebDr.getValue("CIVDate"),"Enter CIV Date");
					//WebDr.setText("CIVDate", WebDr.getValue("CIVDate"), "Enter CIV Date");
					WebDr.setText("BirthPlace", WebDr.getValue("BirthPlace"), "Enter Birth Place");
				}
				WebDr.clickwithmouse("ValidateCustomer", "Click on Validate customer");
				WebDr.SwitchToLatestWindow();
				WebDr.alertClickWithText("new customer");
				//WebDr.alertAccept();
				WebDr.SwitchToLatestWindow();
				WebDr.clickwithmouse("8053_OK", "Click OK");
				}
//			WebDr.getAccountNo();
			
			WebDr.CustID = WebDr.getAccountNo(); 
			System.out.println(WebDr.CustID);
			WebDr.alertAccept();
			if (! WebDr.CustID.isEmpty()) {
				HtmlReporter.WriteStep("Create Customer", "User is able to add customer through 8053 option. ",  "Customer addition successful: " + WebDr.CustID,true);
			}
			else
			{
				HtmlReporter.WriteStep("Create Customer", "User is able to add customer through 8053 option. ",  "Customer addition unsuccessful: ",false);
				
			}
			

		}
		/*HtmlReporter.WriteStep("Create Customer", "User is able to add customer through 8053 option. ",  "Customer addition successful: " + WebDr.CustID,true);
		//200005110
		
		}*/
		catch(Exception e){
			e.printStackTrace();
			HtmlReporter.WriteStep("Create Customer", "User is able to  add customer through 8053 option. ",  "Customer addition unsuccessful: "+e.toString(),false);
		}

	}
	
	public static void Customer_InquiryByCriteria_CIM09() throws UnhandledAlertException, Exception {
		String strCriteriaValue = WebDr.getValue("SearchCriteria");
		try{
			pkgFCRPageObjects.FCR_CIFPageObjects.Customer_Inquiry_CIM09();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("InquiryBtn", "Selct Mode INQUIRY");
			WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"), "Select Search Criteria");
			WebDr.setText("SearchString", WebDr.getValue("SearchString"), "Enter Search String");	
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.SwitchToLatestWindow();
			WebDr.rTab();
			WebDr.rTab();
			WebDr.rEnter();
			if (WebDr.isAlertPresent()){
				try{
					
					WebDr.alertAccept();
					WebDr.alertAccept();
					if(WebDr.isAlertPresent()){
					WebDr.alertAccept();
					WebDr.alertAccept();
					}
				}catch(Exception eAlert){
					System.out.println("Error window did not exist");
				}
			}
			//validation step
			//WebDr.SwitchToWindow(strFCRAppWindow);
			WebDr.SwitchToLatestWindow();
			String strAppCust = WebDr.getTextBoxValue("CustomerID", "Get Customer ID value");
			System.out.println("ID=================>" + strAppCust);
			if (strAppCust != "")
				HtmlReporter.WriteStep("Check whether the user is able to navigate the FP CIM09 or not using "+ strCriteriaValue, "User should be able to view all the details in CIM09",  "Customer inquiry successful: "+ strAppCust,true);
			else
				HtmlReporter.WriteStep("Check whether the user is able to navigate the FP CIM09 or not using "+ strCriteriaValue, "User should be able to view all the details in CIM09",  "Customer inquiry unsuccessful: "+ strAppCust,false);
			WebDr.clickwithmouse("Close_CIM09", "Click Clear");
		}
		catch(Exception e){
			try {
				WebDr.alertAccept();
				WebDr.alertAccept();
				WebDr.alertAccept();
				WebDr.alertAccept();
			} catch (Exception errorpopup) {
				errorpopup.printStackTrace();
			}
			e.printStackTrace();
			HtmlReporter.WriteStep("Check whether the user is able to navigate the FP CIM09 or not using "+ strCriteriaValue , "User should be able to view all the details in CIM09 with the help of the customer id.",  "Customer inquiry unsuccessful: "+e.toString(),false);
		}
	}
	
//	public static void Customer_InquiryByCriteria_CIM09() throws UnhandledAlertException, Exception {
//		try{
//			String strEnterValue = "";
//			birPageObjects.FCR_CIFPageObjects.Customer_Inquiry_CIM09();
//			WebDr.fastPath(WebDr.getValue("FastPath"));
//			WebDr.waitForPageLoaded();
//			WebDr.clickwithmouse("InquiryBtn", "Selct Mode INQUIRY");
//			WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"), "Select Search Criteria");
//			WebDr.setText("SearchString", WebDr.getValue("SearchString"), "Enter Search String");
////			if(WebDr.getValue("SearchCriteria").equals("Customer Ic"))
////				strEnterValue =  WebDr.getValue("Customer Ic");
////			else if(WebDr.getValue("SearchCriteria").equals("Customer Id"))
////				strEnterValue =  WebDr.getValue("Customer Id");
////			else if(WebDr.getValue("SearchCriteria").equals("Short Name"))
////				strEnterValue =  WebDr.getValue("Short Name");
////				
//			
//			//WebDr.SelectTopAcct();
//		
//			WebDr.rTab();
//			WebDr.SwitchToLatestWindow();
//			WebDr.rTab();
//			WebDr.rTab();
//			WebDr.rEnter();
//			
//			WebDr.getTextBoxValue("CustomerID", "Get CustomerID value");
//			//validation step
//			WebDr.waitForPageLoaded();
//			WebDr.clickwithmouse("Clear_CIM09", "Click Clear");
//		
//		
//		}
//		catch(Exception e){
//			e.printStackTrace();
//			HtmlReporter.WriteStep("Inquire Customer", "User should be able to view all the details in CIM09 with the help of the customer id.",  "Customer inquiry unsuccessful: "+e.toString(),false);
//		}
//
//	}
//	
	
	public static void Customer_Inquiry_CIM09() throws UnhandledAlertException, Exception {
		try{
			pkgFCRPageObjects.FCR_CIFPageObjects.Customer_Activation();
			WebDr.fastPath(WebDr.getValue("Fastpath_Post"));
			WebDr.selectDropValueByVisibleText("SearchCriteria_CIM33", WebDr.getValue("SearchCriteria_CIM33"), "Select Search Criteria");
			WebDr.setText("CustomerID_CIM33", WebDr.CustID, "Enter Customer ID");
			WebDr.click("Post_CIM33"," Click on Post button");
			WebDr.alertClickWithText("Record Posted Successfully");
			WebDr.waitForPageLoaded();
			WebDr.fastPath(WebDr.getValue("Fastpath_Activate"));
			WebDr.selectDropValueByVisibleText("Action", WebDr.getValue("Action"), "Select Action");
			WebDr.selectDropValueByVisibleText("SearchCriteria_CIM34", WebDr.getValue("SearchCriteria_CIM34"), "Select Search Criteria");
			WebDr.setText("CustomerID_CIM34", WebDr.CustID, "Enter Customer ID");
			WebDr.clickwithmouse("CIM34_OK"," Click on OK button");
			if(WebDr.alertClickWithText("Customer Activated"))
			{	
			pkgFCRPageObjects.FCR_CIFPageObjects.Customer_Inquiry_CIM09();
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("InquiryBtn", "Selct Mode INQUIRY");
			WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"), "Select Search Criteria");
			WebDr.setText("SearchString", WebDr.CustID, "Enter Search String");
			//WebDr.SelectTopAcct();
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.SwitchToLatestWindow();
			WebDr.rTab();
			WebDr.rTab();
			WebDr.rEnter();
			if (WebDr.isAlertPresent()){
				try{
					
					WebDr.alertAccept();
					WebDr.alertAccept();
					if(WebDr.isAlertPresent()){
					WebDr.alertAccept();
					WebDr.alertAccept();
					}
				}catch(Exception eAlert){
					System.out.println("Error window did not exist");
				}
			}
			//change below method in webdr
			WebDr.SwitchToLatestWindow();
			String strAppCust = WebDr.getTextBoxValue("CustomerID", "Get value");
			System.out.println("ID=================>" + strAppCust);
			if ((strAppCust != "") || (strAppCust ==  WebDr.CustID)){
			HtmlReporter.WriteStep("Check whether all the details for a customer created in 8053 or not.", "User should be able to view all the details in CIM09 with the help of the customer id.",  "Customer inquiry successful: " + WebDr.CustID,true);
			}
			else
			{
				HtmlReporter.WriteStep("Check whether all the details for a customer created in 8053 or not.", "User should be able to view all the details in CIM09 with the help of the customer id.",  "Customer inquiry unsuccessful: ",false);
			}
			}
			else{
				HtmlReporter.WriteStep("Check whether all the details for a customer created in 8053 or not.", "User should be able to view all the details in CIM09 with the help of the customer id.",  "Customer inquiry unsuccessful: ",false);
			}
		}
		catch(Exception e){
			e.printStackTrace();
			HtmlReporter.WriteStep("Check whether all the details for a customer created in 8053 or not.", "User should be able to view all the details in CIM09 with the help of the customer id.",  "Customer inquiry unsuccessful: "+e.toString(),false);
		}

	}
	
	

	public static void Customer_Search_1000() throws UnhandledAlertException, Exception {
		try{
			
			pkgFCRPageObjects.FCR_CIFPageObjects.Customer_Search_1000();;
			
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByVisibleText("SearchBy", WebDr.getValue("SearchBy"), "Select Search Criteria");
			WebDr.setText("SearchString1", WebDr.getValue("SearchString1"), "Select Search String");
			WebDr.click("OK_1000", "Click on OK");
			WebDr.waitForPageLoaded();
			WebDr.click("CustIDRow", "Click on customer ID");
			WebDr.waitForPageLoaded();
			/*WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.rEnter();*/
			String strCustID = WebDr.getTextBoxValue("CustomerID", "Get Value");
			String strFullName = WebDr.getTextBoxValue("FullName", "Get Value");
			String strCustIC = WebDr.getTextTable("CustomerIC", "Check for Value");
			String strCategory = WebDr.getTextTable("Customer_Type", "Check for Value");
			String strHomeBranch = WebDr.getTextTable("HomeBranch", "Check for Value");
			System.out.println(strCustIC);
			System.out.println(strFullName);
			System.out.println(strCategory);
			System.out.println(strHomeBranch);
			String custDetails= strCustIC.concat("").concat(strCategory).concat("").concat(strHomeBranch);
			System.out.println("***********************************");
			//Database Validation
			/*FCRDBConnection.DBValidation_FetchValue(WebDr.getValue("Query"));
			FCRDBConnection.DBValidation_VerifyValue();*/
			
			
			if (! strCustID.isEmpty()){
				HtmlReporter.WriteStep("Search Customer", "User should be able to search customer details in 1000 with the help of the " +WebDr.getValue("SearchBy"),  "Customer Search successful and details are displayed as:- Customer ID:" +strCustID+  "Full name: " +strFullName +custDetails ,true);
				}
			else{
				HtmlReporter.WriteStep("Search Customer", "User should be able to search customer details in 1000 with the help of the " +WebDr.getValue("SearchBy"),  "Customer Search unsuccessful: " ,false);
			}
		}
		catch(Exception e){
			e.printStackTrace();
			HtmlReporter.WriteStep("Search Customer", "User should be able to search customer details in 1000 with the help of the " +WebDr.getValue("SearchBy"),  "Customer Search unsuccessful: "+e.toString(),false);
		}
	}
	
	
	public static void Customer_Modify_CIM09() throws UnhandledAlertException, Exception {
		try{
			if ((WebDr.strFCRCountry.equals("BBK")) || (WebDr.strFCRCountry.equals("NBC")) || (WebDr.strFCRCountry.equals("BBM"))){
				pkgFCRPageObjects.FCR_CIFPageObjects.Customer_Modify_CIM09_BBK();
			}
			else{
			pkgFCRPageObjects.FCR_CIFPageObjects.Customer_Modify_CIM09();
			}
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("ModifyBtn", "Click Modify Button");
			WebDr.waitForPageLoaded();
			if ((WebDr.strFCRCountry.equals("BBK")) || (WebDr.strFCRCountry.equals("NBC")) || (WebDr.strFCRCountry.equals("BBM"))){
				WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"), "Select Search Criteria");
				WebDr.setText("SearchString", WebDr.getValue("SearchString"), "Enter Search string");
			}
			else{
			WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"), "Select Search Criteria");
			//WebDr.setText("SearchString", WebDr.getValue("SearchString"), "Enter Search string");
			WebDr.setText("SearchString", WebDr.CustID, "Enter Search string");
			}
			WebDr.rTab();
			if ((WebDr.strFCRCountry.equals("UG"))){
			try{
				WebDr.alertAccept();
				WebDr.alertAccept();
				WebDr.alertAccept();
				WebDr.alertAccept();
				}catch(Exception eAlert){
					System.out.println("Error window did not exist");
				}
			}
			
			WebDr.SwitchToLatestWindow();
			WebDr.rTab();
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.SwitchToLatestWindow();
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("CustomerMIS", "Click CustomerMIS");
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByIndex("BIC", 1, "Select BIC code");
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByIndex("MarketSegment", 1, "Select Mark Segment code");
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByIndex("Residence", 1, "Select Country of residence");
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByIndex("CompanyCode", 1, "Company Code Identifier");
			WebDr.waitForPageLoaded();
			if ((WebDr.strFCRCountry.equals("BBK")) || (WebDr.strFCRCountry.equals("NBC"))){
				WebDr.selectDropValueByIndex("WorkplaceRanking", 1, "Select Workplace Ranking code");
				WebDr.waitForPageLoaded();
				WebDr.selectDropValueByIndex("CountryResidence", 1, "Select Country Residence");
				WebDr.waitForPageLoaded();
				WebDr.selectDropValueByIndex("CustomerExp", 1, "Select Customer Experience");
				WebDr.waitForPageLoaded();
				WebDr.selectDropValueByIndex("BawEmployerCode", 1, "Company  Baw Employer Code");
				WebDr.waitForPageLoaded();	
				WebDr.selectDropValueByIndex("ESDCode", 1, "Select ESD Code");
				WebDr.waitForPageLoaded();
				WebDr.selectDropValueByIndex("BorrowingHistory1", 1, "Company Borrowing History");
				WebDr.waitForPageLoaded();
			}
			
			WebDr.clickwithmouse("CompositeMIS", "Click Composite MIS");
			WebDr.selectDropValueByIndex("ReferStream", 1, "Select Refer Stream code");
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByIndex("ProfitCost", 1, "Select Profit and Cost Centres");
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByIndex("TradingPartner", 1, "Select Trading Partner");
			WebDr.waitForPageLoaded();
			WebDr.selectDropValueByIndex("SalesCode", 1, "Select 45899-CORPORATE");
			WebDr.waitForPageLoaded();
			if ((WebDr.strFCRCountry.equals("BBK")) || (WebDr.strFCRCountry.equals("NBC"))){
				WebDr.selectDropValueByIndex("CPF", 1, "Select CPF code");
				WebDr.waitForPageLoaded();
				WebDr.selectDropValueByIndex("AgricValue", 1, "Select Agric Value");
				WebDr.waitForPageLoaded();
			}
			if (WebDr.strFCRCountry.equals("BBK")){
				WebDr.selectDropValueByIndex("BorrowingHistory2", 1, "Company Borrowing History");
				WebDr.waitForPageLoaded();
			}
					
			if (WebDr.strFCRCountry.equals("NBC")){
				WebDr.clickwithmouse("IndividualCustomerInfo", "Click Individual Customer Info Tab");
				WebDr.setTextIfFieldEmpty("SourceofFunds", WebDr.getValue("SourceofFunds"), "Enter Source of Funds if field is empty");
				WebDr.selectDropValueByVisibleText("IncomeCategory", WebDr.getValue("IncomeCategory"), "Select Income Category");
				WebDr.setTextIfFieldEmpty("PlaceofBirth", WebDr.getValue("PlaceofBirth"), "Enter Place of Birth if field is empty");
				WebDr.clickwithmouse("BasicInformation", "Click Basic Information Tab");
				WebDr.setTextIfFieldEmpty("IncomeTaxNum", WebDr.getValue("IncomeTaxNum"), "Enter Income Tax Number if Field is empty");
			}
			else{
			WebDr.clickwithmouse("CIM09_OK", "Click OK");
			WebDr.alertAccept();
			WebDr.waitForPageLoaded();
			if (WebDr.strFCRCountry.equals("BBK")){
				WebDr.selectDropValueByVisibleText("KYCIndicator", WebDr.getValue("KYCIndicator"), "Select KYC indicator");
				WebDr.setText("KYCDate", WebDr.getValue("KYCDate"), "Select KYC date");
				//WebDr.selectDropValueByIndex("AddressVerification", 2, "Select AddressVerification");
				//WebDr.setText("AddressVerifier", WebDr.getValue("AddressVerifier"), "Select Address Verifier");
				WebDr.rClearUpdateTextField("NetMonthSalary", WebDr.getValue("NetMonthSalary"), "Enter Net Month Salary");
				WebDr.rClearUpdateTextField("OtherIncome", WebDr.getValue("OtherIncome"), "Enter Other Income");
				WebDr.selectDropValueByVisibleText("PEP", WebDr.getValue("PEP"), "Select PEP");
				WebDr.selectDropValueByVisibleText("RiskAssessment", WebDr.getValue("RiskAssessment"), "Select Risk Assessment");
				WebDr.selectDropValueByVisibleText("ParentCompany", WebDr.getValue("ParentCompany"), "Select Parent Company");
				WebDr.selectDropValueByVisibleText("CountryofRegistration", WebDr.getValue("CountryofRegistration"), "Select Country of Registration");
				WebDr.selectDropValueByVisibleText("ComplexStructure", WebDr.getValue("ComplexStructure"), "Select Complex Structure");
			}
			else{
			WebDr.selectDropValueByVisibleText("PEP", WebDr.getValue("PEP"), "Select PEP");
			WebDr.setText("KYCDate", WebDr.getValue("KYCDate"), "Select KYC date");
			WebDr.selectDropValueByIndex("KYCIndicator", 3, "Select KYC indicator");
			WebDr.selectDropValueByIndex("AddressVerification", 2, "Select AddressVerification");
			WebDr.setText("AddressVerifier", WebDr.getValue("AddressVerifier"), "Select Address Verifier");
			}
			WebDr.clickwithmouse("Validate", "Click Validate");
			WebDr.clickwithmouse("BackButton", "Click Back");
			WebDr.click("IndividualCustomerInfo", "Click on Individual Customer Info");
			WebDr.waitForPageLoaded();
			if (!(WebDr.strFCRCountry.equals("BBK"))){
				WebDr.setText("Designation", WebDr.getValue("Designation"), "Enter Designation");
				WebDr.click("BasicInformation", "Click on Basic Information");
				WebDr.waitForPageLoaded();
				WebDr.setText("EmployeeID", WebDr.getTimeStamp(), "Enter EmployeeID");	
			}
			}
			WebDr.clickwithmouse("CIM09_OK", "Click OK");
			WebDr.alertAccept();
			LOAN.logout();
			LOAN.superLogin();
			WebDr.waitForPageLoaded();
			WebDr.waitForPageLoaded();
			if ((WebDr.strFCRCountry.equals("BBK")) || (WebDr.strFCRCountry.equals("NBC"))){
				pkgFCRPageObjects.FCR_CIFPageObjects.Customer_Modify_CIM09_BBK();
			}
			else{
			pkgFCRPageObjects.FCR_CIFPageObjects.Customer_Modify_CIM09();
			}
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("AuthorizeBtn", "Click Authorize Button");
			WebDr.waitForPageLoaded();
			if ((WebDr.strFCRCountry.equals("BBK")) || (WebDr.strFCRCountry.equals("NBC"))){
				WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"), "Select Search Criteria");
				WebDr.setText("SearchString", WebDr.getValue("SearchString"), "Enter Search string");
			}
			else{
			WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"), "Select Search Criteria");
			//WebDr.setText("SearchString", WebDr.getValue("SearchString"), "Enter Search string");
			WebDr.setText("SearchString", WebDr.CustID, "Enter Search string");
			}
			WebDr.rTab();
			if ((WebDr.strFCRCountry.equals("UG"))){
			try{
				WebDr.alertAccept();
				WebDr.alertAccept();
				WebDr.alertAccept();
				WebDr.alertAccept();
				}catch(Exception eAlert){
					System.out.println("Error window did not exist");
				}
			}
			WebDr.SwitchToLatestWindow();
			WebDr.rTab();
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.SwitchToLatestWindow();
			WebDr.waitForPageLoaded();
			WebDr.clickwithmouse("CIM09Authorize_OK", "Click OK");
			if(WebDr.alertClickWithText("Record Authorized")){
			HtmlReporter.WriteStep("Check whether the user is able to modify and Authorize the records in CIM09 or not.", "User should be able to modify customer details in CIM09 with the help of the customer id.",  "Customer Details Modification successful: ",true);
			}
			else{
				HtmlReporter.WriteStep("Check whether the user is able to modify and Authorize the records in CIM09 or not.", "User should be able to modify customer details in CIM09 with the help of the customer id.",  "Customer Details Modification unsuccessful: " ,false);	
			}
		}
		catch(Exception e){
			e.printStackTrace();
			HtmlReporter.WriteStep("Check whether the user is able to modify and Authorize the records in CIM09 or not.", "User should be able to modify customer details in CIM09 with the help of the customer id.",  "Customer Details Modification unsuccessful: "+e.toString(),false);
		}
	}
	
		public static void Bill_Payment_by_Cash_1025() throws Exception,UnhandledAlertException{
			try{
				pkgFCRPageObjects.FCR_CIFPageObjects.Bill_Payment_by_Cash_1025();
				WebDr.fastPath(WebDr.getValue("FastPath"));
				WebDr.waitForPageLoaded();
				WebDr.selectDropValueByVisibleText("CompanyID",  WebDr.getValue("CompanyID"),  "Select Company ID");
				WebDr.rTab();
				WebDr.setText("BillNumber",  WebDr.getValue("BillNumber"),  "Enter Bill Number");
				//WebDr.alertAccept();
				WebDr.rTab();
				WebDr.setText("ConsumerNo", WebDr.getValue("ConsumerNo"),  "Enter Consumer number");
				WebDr.selectDropValueByVisibleText("BillCcy", WebDr.getValue("BillCcy"), "Select Bill Currency");
				WebDr.selectDropValueByVisibleText("TxnCcy",  WebDr.getValue("TxnCcy"), "Select Transaction currency");
				if (WebDr.strFCRCountry.equals("BBK")){
					WebDr.rTab();
					WebDr.AlertHandleOfflineChargeErrors();
				}
				WebDr.setText("BillAmount", WebDr.getValue("BillAmount"), "Enter Bill Amount");
				WebDr.rTab();
				try{
					if (WebDr.isAlertPresent()){
						WebDr.alertAccept();
						WebDr.alertAccept();
						WebDr.alertAccept();
						WebDr.alertAccept();
					}
					}catch(Exception eAlert){
						System.out.println("Error window did not exist");
					}
				WebDr.setText("ReferenceNo1", WebDr.getValue("ReferenceNo1"), "Enter Reference Number");
				WebDr.setText("ReferenceNo2",  WebDr.getValue("ReferenceNo2"),  "Enter Reference Number");
				WebDr.setText("UserReference", WebDr.getValue("UserReference"),  "Enter User Reference");
				if (WebDr.strFCRCountry.equals("BBK")){
					WebDr.setText("RemitterName", WebDr.getValue("RemitterName"), "Enter Remitter Name");
					WebDr.setText("RemitterID",  WebDr.getValue("RemitterID"),  "Enter Remitter ID");
					WebDr.setText("UserNarrative", WebDr.getValue("UserNarrative"),  "Enter User Narrative");
				}
				WebDr.clickwithmouse("OK_1025", "");
				
				if(WebDr.strFCRCountry.equals("BBK"))
				{
					WebDr.alertAccept();
					WebDr.waitForPageLoaded();
					WebDr.setText("MandatoryUDF1", WebDr.getValue("MandatoryUDF1"), "Enter Mandatory UDF 1");
					WebDr.setText("MandatoryUDF2", WebDr.getValue("MandatoryUDF2"), "Enter Mandatory UDF 2");
					WebDr.waitForPageLoaded();
					WebDr.click("Validate","Click on Validate");
					WebDr.waitForPageLoaded();
					WebDr.click("Back","Click on Back");
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("OK_1025", "");
					WebDr.waitForPageLoaded();
				}
				if ((WebDr.strFCRCountry.equals("NBC")) || (WebDr.strFCRCountry.equals("BBM"))){
					WebDr.alertAccept();
					WebDr.SwitchToLatestWindow();
					WebDr.waitForPageLoaded();
					WebDr.DenominationEntry("Enter Denomination");
					/*WebDr.getTextBoxValue("Denomination", "");
					WebDr.exists("Count", true, "");*/
//					WebDr.setText("Count","2", "");
					WebDr.rTab();
					WebDr.click("D_OK", "Click OK");
					WebDr.clickwithmouse("OK_1025", "");
				}
				WebDr.authWithComment();
				//WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
				if(WebDr.strFCRCountry.equals("BBK"))
				{
					WebDr.VerifyStatusBarText("StatusBar",10,"Transaction sequence number is","Verify transaction status");
				}
				else{
				if( (WebDr.strFCRCountry.equals("UG"))){
				WebDr.alertClickWithText("Please sell cash to vault");
				}
				WebDr.alertHandlingForErrors("Transaction sequence number is","Verify transaction status");
				}
				//WebDr.clickAlwaysImageIndexSikuli("CancelButton.png", 5, 0,  "Click on the CancelButton" );
				WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
				if(WebDr.alertHandlingForErrors("Serial", "Verify serial number")){
					//WebDr.alertAccept();
					HtmlReporter.WriteStep("Bill Payment by Cash", "User should be able to pay bill in 1025.",  "Bill Payment by Cash for amount: " +  WebDr.getValue("BillAmount"),true);
				}
				else{
					WebDr.alertAccept();
					WebDr.alertAccept();
					HtmlReporter.WriteStep("Bill Payment by Cash", "User should be able to pay bill in 1025.",  "Bill Payment by Cash: ",false);
				}
			}
			catch(Exception e){
				e.printStackTrace();
				HtmlReporter.WriteStep("Bill Payment by Cash", "User should be able to pay bill in 1025.",  "Bill Payment by Cash: "+e.toString(),false);
			}
		}
		
		public static void Bill_Payment_Against_Account_1075() throws Exception,UnhandledAlertException{
			try{
				pkgFCRPageObjects.FCR_CIFPageObjects.Bill_Payment_by_Cash_1025();
				WebDr.fastPath(WebDr.getValue("FastPath"));
				WebDr.waitForPageLoaded();
				
				WebDr.selectDropValueByVisibleText("CompanyID",  WebDr.getValue("CompanyID"),  "Select Company ID");
				WebDr.setText("BillNumber",  WebDr.getValue("BillNumber"),  "Enter Bill Number");
				WebDr.alertAccept();
				WebDr.waitForPageLoaded();
				WebDr.setText("ConsumerNo", WebDr.getValue("ConsumerNo"),  "Enter Consumer number");
				WebDr.rTab();
				WebDr.waitForPageLoaded();
						
				WebDr.setText("AccountNo", WebDr.getValue("AccountNo"),  "Enter Account number");
				WebDr.rTab();
				WebDr.selectDropValueByVisibleText("BillCcy", WebDr.getValue("BillCcy"), "Select Bill Currency");
				WebDr.rTab();
				
				if (! WebDr.strFCRCountry.equals("BBK")){
					WebDr.selectDropValueByVisibleText("TxnCcy",  WebDr.getValue("TxnCcy"), "Select Transaction currency");
					WebDr.rTab();
				}
				
				WebDr.setText("BillAmountAccount", WebDr.getValue("BillAmount"), "Enter Bill Amount");
				WebDr.rTab();
				
				WebDr.AlertHandleOfflineChargeErrors();
				
				if (WebDr.strFCRCountry.equals("BBK")){
					WebDr.setText("BillRemitName", WebDr.getValue("BillRemitName"), "Enter Bill Remit Name");
					WebDr.rTab();
					WebDr.setText("BillRemitID", WebDr.getValue("BillRemitID"), "Enter Bill RemitID");
					WebDr.rTab();
				}
				
				WebDr.setText("ReferenceNo1", WebDr.getValue("ReferenceNo1"), "Enter Reference Number");
				WebDr.setText("ReferenceNo2",  WebDr.getValue("ReferenceNo2"),  "Enter Reference Number");
				WebDr.setText("UserReference", WebDr.getValue("UserReference"),  "Enter User Reference");
				
				if (WebDr.strFCRCountry.equals("BBK")){
					WebDr.setText("UsrNarrative", WebDr.getValue("UsrNarrative"),  "Enter UsrNarrative");
				}
				
				WebDr.clickwithmouse("OK_1025", "");
				
				if (WebDr.strFCRCountry.equals("BBK")){
					WebDr.alertClickWithText(WebDr.getValue("AccountNo"));
					WebDr.waitForPageLoaded();
					WebDr.click("Sign", "Click on Sign");
					WebDr.click("SignOk", "Click on OK");
					WebDr.waitForNumberOfWindowsToEqual(3);
					WebDr.SwitchToLatestWindow();
					WebDr.waitForPageLoaded();
					WebDr.clickactivatewithmouse("SignZoom", "Click on signature window");
					WebDr.CloseWindowWithTitle("Signature");
					WebDr.SwitchToLatestWindow();
					WebDr.click("FastPath", "Click in the textfield");
					WebDr.click("SignVerified", "Click on Signature Verified");
					//ScreenReturn
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("OK_1025", "");
					WebDr.authWithComment();
					WebDr.alertClickWithText("Account:");
					WebDr.authWithComment();
					WebDr.VerifyStatusBarText("StatusBar", 20, "Transaction sequence number is","Verify transaction status");
//					if(WebDr.SwitchToLatestAlertCheck("Passbook"))
//						WebDr.alertCancel();
					WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
				}
				else if (WebDr.strFCRCountry.equals("BBM")){
					WebDr.alertAccept();
					WebDr.waitForPageLoaded();
					WebDr.click("Sign", "Click on Sign");
					WebDr.click("SignOk", "Click on OK");
					WebDr.waitForNumberOfWindowsToEqual(3);
					WebDr.SwitchToLatestWindow();
					WebDr.waitForPageLoaded();
					WebDr.clickactivatewithmouse("SignZoom", "Click on signature window");
					WebDr.CloseWindowWithTitle("Signature");
					WebDr.SwitchToLatestWindow();
					WebDr.click("FastPath", "Click in the textfield");
					WebDr.click("SignVerified", "Click on Signature Verified");
					//ScreenReturn
					WebDr.waitForPageLoaded();
					WebDr.clickwithmouse("OK_1025", "");
					WebDr.authWithComment();
					WebDr.alertHandlingForErrors("Transaction sequence number is","Verify transaction status");
					WebDr.clickElementImageSikuli("CloseWindow.PNG", 10, "Close receipt window");
				}
				else{
					WebDr.authWithComment();
					WebDr.alertClickWithText("Account:");
					WebDr.alertClickWithText("Please sell cash to vault");
					WebDr.alertHandlingForErrors("Transaction sequence number is","Verify transaction status");
					if(WebDr.SwitchToLatestAlertCheck("Passbook"))
						WebDr.alertCancel();
	//				WebDr.rTab();
	//				WebDr.rEnter();
					
				}
				WebDr.alertClickWithText("Serial");
				WebDr.SwitchToLatestWindow();
				HtmlReporter.WriteStep("Bill Payment Against Account by select the utility biller from the drop down", "User should be able to pay bill in 1075 by selecting the utility biller from the drop down",  "Bill Payment Against Account " + WebDr.getValue("AccountNo") + " is paid by amount: " +  WebDr.getValue("BillAmount"),true);
				
			}
			catch(Exception e){
				e.printStackTrace();
				HtmlReporter.WriteStep("Bill Payment Against Account by select the utility biller from the drop down", "User should be able to pay bill in 1075 by selecting the utility biller from the drop down",  "Bill Payment by Cash failed: "+e.toString(),false);
				WebDr.SwitchToLatestWindow();
			}
		}
		
		
		public static void Customer_Relation_CI141() throws Exception,UnhandledAlertException{
			try{
				pkgFCRPageObjects.FCR_CIFPageObjects.Customer_Relation_CI141();
				WebDr.fastPath(WebDr.getValue("FastPath"));
				WebDr.waitForPageLoaded();
				WebDr.click("AddBtn", "Click on Add");
				WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"), "Select search criteria");
				WebDr.setText("SearchString", WebDr.getValue("SearchString"), "Enter search string");
				WebDr.clickactivatewithmouse("InputBy", "Click on field");
				WebDr.waitForPageLoaded();
				WebDr.SwitchToLatestWindow();
				WebDr.rTab();
				WebDr.rTab();
				WebDr.rEnter();
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				WebDr.selectDropValueByVisibleText("SearchCriteria1", WebDr.getValue("SearchCriteria1"), "Select search criteria");
				 
				//WebDr.setText("SearchString1", WebDr.getValue("SearchString1"), "");
				//dyanamic cust id
				WebDr.setText("SearchString1", WebDr.CustID, "Enter search string");
				WebDr.rTab();
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.rTab();
				WebDr.rEnter();
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				WebDr.click("Picklist1", "Select picklist");
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.rTab();
				WebDr.rEnter();
				/*WebDr.keyboard(WebDr.getValue("RelationCode"));
				//WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				WebDr.rTab();
				WebDr.rTab();
				WebDr.rEnter();*/
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				
				WebDr.clickwithmouse("OK_CI141", "Click on OK button");
				//WebDr.alertAccept();
				if(WebDr.alertClickWithText("Record Authorized")){
					HtmlReporter.WriteStep("Chech whether the user is able to navigate and add Customer Relation in FP141", "User should be able to add realtion in CI141.",  "Add customer relation as  " +WebDr.getTextBoxValue("Relation", "") ,true);	
				}
				else{
				WebDr.alertAccept();
				HtmlReporter.WriteStep("Chech whether the user is able to navigate and add Customer Relation in FP141", "User should  be able to add realtion in CI141.",  "Add customer relation as unsuccessful" ,false);
				}
			}
				catch(Exception e){
					e.printStackTrace();
					HtmlReporter.WriteStep("Chech whether the user is able to navigate and add Customer Relation in FP141", "User should  be able to add realtion in CI141.",  "Add customer relation as "+e.toString(),false);
				}
			}	
		
		public static void CashDeposit_HighMemoCust_1401() throws Exception {
			try {
				// Enter_Details
				pkgFCRPageObjects.FCR_CASAPageObjects.CashDeposit_1401();
				WebDr.fastPath(WebDr.getValue("FastPath"));
				WebDr.waitForPageLoaded();
				WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
				WebDr.rTab();	
				WebDr.waitForPageLoaded();
				
				if(WebDr.strFCRCountry.equals("NBC")){
					WebDr.selectDropValueByVisibleText("TxnCurrency",WebDr.getValue("TxnCurrency"), "Select Txn Currency");
				}
				
				WebDr.setText("TxnAmount", WebDr.getValue("TxnAmount"), "Enter Tax Amount");
				WebDr.rTab();
				
				try {
					if(WebDr.isAlertPresent()){
					WebDr.alertAccept();
					WebDr.alertAccept();
					}
					if(WebDr.isAlertPresent()){
					WebDr.alertAccept();
					WebDr.alertAccept();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				if(WebDr.strFCRCountry.equals("NBC")){
					WebDr.setText("DepositorID", WebDr.getValue("DepositorID"), "Enter Depositor ID");
					WebDr.rTab();
					WebDr.setText("DepositorName", WebDr.getValue("DepositorName"), "Enter Depositor Name");
					WebDr.rTab();
				}
				
				WebDr.setText("UserRefNo", WebDr.getValue("UserRef"), "Enter User Ref");
				WebDr.rTab();
				WebDr.rTab();
				WebDr.clickwithmouse("Ok", "Clik on OK");
				WebDr.alertAccept();
				
				if(WebDr.strFCRCountry.equals("UGChanged")){
					// SignatureVerfication
					WebDr.waitForPageLoaded();
					WebDr.click("Sign", "Click on Sign");
					WebDr.click("SignOk", "Click on OK");
					WebDr.waitForPageLoaded();
					WebDr.waitForNumberOfWindowsToEqual(2);
					WebDr.SwitchToLatestWindow();
					WebDr.waitForPageLoaded();
					WebDr.clickactivatewithmouse("SignZoom", "Click on signature window");
					WebDr.CloseWindowWithTitle("Signature");
					WebDr.SwitchToLatestWindow();
					WebDr.click("FastPath", "Click in the textfield");
					
					WebDr.click("SignVerified", "Click on Signature Verified");
					WebDr.click("SignCancel", "Click on Cancel");
		
					// 1401ScreenReturn
					WebDr.waitForPageLoaded();
					WebDr.click("AccountNo", "Click on Account No");
					WebDr.click("Ok", "Click on OK");
					WebDr.alertAccept();
				}
				if(WebDr.strFCRCountry.equals("BBM"))
				{
					WebDr.alertAccept();
					WebDr.waitForPageLoaded();
					WebDr.setText("MandatoryUDF1", WebDr.getValue("MandatoryUDF1"), "Enter Mandatory UDF 1");
					WebDr.rTab();
					WebDr.setText("MandatoryUDF2", WebDr.getValue("MandatoryUDF2"), "Enter Mandatory UDF 2");
					WebDr.rTab();
					WebDr.setText("MandatoryUDF3", WebDr.getValue("MandatoryUDF3"), "Enter Mandatory UDF 3");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.click("Validate","Click on Validate");
					WebDr.click("Back","Click on Back");
					WebDr.waitForPageLoaded();
					WebDr.click("Ok", "Click on OK");
					WebDr.alertAccept();
				}
				// Denomination
				WebDr.waitForPageLoaded();
				WebDr.DenominationEntry("Enter Denomination");
				
				//WebDr.setText				("Count", "2", "");
				//WebDr.setText("Denomination", WebDr.getValue("Denomination"), "Enter Denomination");
				WebDr.click("D_Ok", "Click on OK button");
				// 1401ScreenReturn
				WebDr.waitForPageLoaded();
				try{
					WebDr.click("AccountNo", "Click on Account No");					
					WebDr.clickwithmouse("Ok", "Click on OK");
				//WebDr.alertAccept();
				}catch(Exception e){
					System.out.println("Inside");
					Thread.sleep(5000);	
					e.printStackTrace();
					WebDr.alertAccept();
				}
				
				if( (WebDr.strFCRCountry.equals("UG")) ){
					WebDr.alertClickWithText("Suntec");
					WebDr.alertClickWithText("kool");
					// AuthWithComments
					WebDr.alertHandlingForErrors(("high"),"Verify alert window");
					WebDr.authWithComment();
					WebDr.alertHandlingForErrors("Transaction sequence number is","Verify transaction status");
				}
				else if( (WebDr.strFCRCountry.equals("NBC")) && (WebDr.alertHandlingForErrors(("High severity"),"Verify alert window")))
				{ 
					WebDr.authWithComment();
					if (WebDr.alertHandlingForErrors("Transaction sequence number is","Verify transaction status"))
						HtmlReporter.WriteStep("Check whether the user is able to perform transaction through the account on whose customer is having high memo.",
							"User should be able to perform transaction through the account whose customer is having high memo ",
							"Funds Transfer Successful. ", true);
					else {
						HtmlReporter.WriteStep("Check whether the user is able to perform transaction through the account on whose customer is having high memo.",
								"User should be able to perform transaction through the account whose customer is having high memo ",
								"Funds Transfer Unsuccessful. ", false);
					}
					
				}
				else if(WebDr.strFCRCountry.equals("BBM"))
				{
					WebDr.authWithComment();
				}
			} catch (Exception e) {
				e.printStackTrace();
				HtmlReporter.WriteStep("Check whether the user is able to perform transaction through the account on whose customer is having high memo.",
						"User should be able to perform transaction through the account whose customer is having high memo ",
						"Funds Transfer Unsuccessful. " + e.getMessage(), false);

			}
		}
		
		public static void CashDeposit_LowMemoCust_1401() throws Exception {
			try {
				// Enter_Details
				pkgFCRPageObjects.FCR_CASAPageObjects.CashDeposit_1401();
				WebDr.fastPath(WebDr.getValue("FastPath"));
				WebDr.waitForPageLoaded();
				WebDr.setText("AccountNo", WebDr.getValue("AccountNo"), "Enter Account Number");
				WebDr.rTab();	
				WebDr.waitForPageLoaded();
				
				if(WebDr.strFCRCountry.equals("NBC")){
					WebDr.selectDropValueByVisibleText("TxnCurrency",WebDr.getValue("TxnCurrency"), "Select Txn Currency");
				}
				
				WebDr.setText("TxnAmount", WebDr.getValue("TxnAmount"), "Enter Tax Amount");
				WebDr.rTab();
				
				try {
					if(WebDr.isAlertPresent()){
					WebDr.alertAccept();
					WebDr.alertAccept();
					}
					if(WebDr.isAlertPresent()){
					WebDr.alertAccept();
					WebDr.alertAccept();
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
				
				if(WebDr.strFCRCountry.equals("NBC")){
					WebDr.setText("DepositorID", WebDr.getValue("DepositorID"), "Enter Depositor ID");
					WebDr.rTab();
					WebDr.setText("DepositorName", WebDr.getValue("DepositorName"), "Enter Depositor Name");
					WebDr.rTab();
				}
				
				WebDr.setText("UserRefNo", WebDr.getValue("UserRef"), "Enter User Ref");
				WebDr.rTab();
				WebDr.rTab();
				WebDr.clickwithmouse("Ok", "Clik on OK");
				WebDr.alertAccept();
				
				if(WebDr.strFCRCountry.equals("UGChanged")){
					// SignatureVerfication
					WebDr.waitForPageLoaded();
					WebDr.click("Sign", "Click on Sign");
					WebDr.click("SignOk", "Click on OK");
					WebDr.waitForPageLoaded();
					WebDr.waitForNumberOfWindowsToEqual(2);
					WebDr.SwitchToLatestWindow();
					WebDr.waitForPageLoaded();
					WebDr.clickactivatewithmouse("SignZoom", "Click on signature window");
					WebDr.CloseWindowWithTitle("Signature");
					WebDr.SwitchToLatestWindow();
					WebDr.click("FastPath", "Click in the textfield");
					
					WebDr.click("SignVerified", "Click on Signature Verified");
					WebDr.click("SignCancel", "Click on Cancel");
		
					// 1401ScreenReturn
					WebDr.waitForPageLoaded();
					WebDr.click("AccountNo", "Click on Account No");
					WebDr.click("Ok", "Click on OK");
					WebDr.alertAccept();
				}
				if(WebDr.strFCRCountry.equals("BBM"))
				{
					WebDr.alertAccept();
					WebDr.waitForPageLoaded();
					WebDr.setText("MandatoryUDF1", WebDr.getValue("MandatoryUDF1"), "Enter Mandatory UDF 1");
					WebDr.rTab();
					WebDr.setText("MandatoryUDF2", WebDr.getValue("MandatoryUDF2"), "Enter Mandatory UDF 2");
					WebDr.rTab();
					WebDr.setText("MandatoryUDF3", WebDr.getValue("MandatoryUDF3"), "Enter Mandatory UDF 3");
					WebDr.rTab();
					WebDr.waitForPageLoaded();
					WebDr.click("Validate","Click on Validate");
					WebDr.click("Back","Click on Back");
					WebDr.waitForPageLoaded();
					WebDr.click("Ok", "Click on OK");
					WebDr.alertAccept();
				}
				
				// Denomination
				WebDr.waitForPageLoaded();
				WebDr.DenominationEntry("Enter Denomination");
				
				//WebDr.setText				("Count", "2", "");
				//WebDr.setText("Denomination", WebDr.getValue("Denomination"), "Enter Denomination");
				WebDr.click("D_Ok", "Click on OK button");
				// 1401ScreenReturn
				WebDr.waitForPageLoaded();
				try{
					WebDr.click("AccountNo", "Click on Account No");					
					WebDr.clickwithmouse("Ok", "Click on OK");
				//WebDr.alertAccept();
				}catch(Exception e){
					System.out.println("Inside");
					Thread.sleep(5000);	
					e.printStackTrace();
					WebDr.alertAccept();
				}
				
				//WebDr.waitForPageLoaded();
				
				if(WebDr.isAlertPresent())
					WebDr.alertClickWithText(WebDr.getValue("AccountNo"));
				
				//WebDr.alertClickWithText(WebDr.getValue("AccountNo"));
				
				if(( WebDr.strFCRCountry.equals("UG")) ){
					WebDr.alertClickWithText("Suntec");
					WebDr.alertClickWithText("kool");
					// AuthWithComments
					WebDr.alertHandlingForErrors(("LOW"),"Verify alert window");
					WebDr.authWithComment();
					WebDr.alertHandlingForErrors("Transaction sequence number is","Verify transaction status");
				}
				else if(WebDr.strFCRCountry.equals("NBC")){
					if (WebDr.alertHandlingForErrors("memo","Verify alert message")){
						HtmlReporter.WriteStep("Check whether the user is able to perform transaction through the account on whose customer is having low memo.",
							"User should be able to perform transaction through the account whose customer is having low memo ",
							"Funds Transfer Successful. ", true);
					}
					else {
						HtmlReporter.WriteStep("Check whether the user is able to perform transaction through the account on whose customer is having low memo.",
								"User should be able to perform transaction through the account whose customer is having low memo ",
								"Funds Transfer Unsuccessful. ", false);
					}
					if(WebDr.isAlertPresent())
						WebDr.alertAccept();
				}
				else if(WebDr.strFCRCountry.equals("BBM"))
				{
					WebDr.authWithComment();
				}
			} catch (Exception e) {
				e.printStackTrace();
				HtmlReporter.WriteStep("Check whether the user is able to perform transaction through the account on whose customer is having low memo.",
						"User should be able to perform transaction through the account whose customer is having low memo ",
						"Funds Transfer Unsuccessful. " + e.getMessage(), false);

			}
		}
		
		public static void Cust_Sign_Link_7102() throws Exception {
			String strEnterCustID;
			if (! WebDr.CustID.isEmpty()){
				strEnterCustID = WebDr.CustID;
			}else{
				strEnterCustID = WebDr.getValue("CustomerID");
			}
			try {
				// Enter_Details
				pkgFCRPageObjects.FCR_CIFPageObjects.Cust_Sign_Link_7102();				
				WebDr.fastPath(WebDr.getValue("FastPath"));
				WebDr.waitForPageLoaded();
				WebDr.selectDropValueByVisibleText("ImageType",WebDr.getValue("ImageType"), "Select Image Type");
				WebDr.selectDropValueByVisibleText("SelectionCriteria",WebDr.getValue("SelectionCriteria"), "Select Selection Criteria");
				WebDr.setText("CustomerID", strEnterCustID, "Enter CustomerID");
				WebDr.rTab();
				WebDr.click("FastPath", "Click in fastpath field");
				WebDr.clickwithmouse("OK_7102", "Click OK");
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				WebDr.waitForPageLoaded();
				WebDr.waitForPageLoaded();
				WebDr.waitForPageLoaded();
				try{
//					if (! WebDr.waitElementImageSikuli("SignImageBrowse.png", 120, "Verify Browse button")){
//						WebDr.CloseWindowWithTitle("Signature");
//						WebDr.SwitchToLatestWindow();
//					}
						WebDr.clickElementImageSikuli("SignImageBrowse.png", 120, "Verify Browse button");
				}catch(Exception e){
					e.printStackTrace();
				}
				Thread.sleep(2000);
				System.out.println(Constant.SikuliScreenPath + "SignLink7102.png");
				WebDr.keyboard(Constant.SikuliScreenPath + "SignLink7102.png");
				WebDr.rTab();
				WebDr.rTab();
				WebDr.rEnter();
				WebDr.SwitchToLatestWindow();
				WebDr.clickwithmouse("Image_OK", "Click OK on upload page");
				if(WebDr.SwitchToLatestAlertCheck("Linked Successfully")){
					HtmlReporter.WriteStep("Check whether the user is able to attach an image/signature  in the screen 7102.",
						"User should be able to attach an image/signature to a customer successfully. ",
						"Image Link Successful. ", true);
				}
				else {
					HtmlReporter.WriteStep("Check whether the user is able to attach an image/signature  in the screen 7102.",
						"User should be able to attach an image/signature to a customer successfully. ",
						"Image Link Unsuccessful. ", false);
				}
				
			}
			catch (Exception e) {
				e.printStackTrace();
				HtmlReporter.WriteStep("Check whether the user is able to attach an image/signature  in the screen 7102.",
						"User should be able to attach an image/signature to a customer successfully. ",
						"Image Link Unsuccessful. ", false);
			
			}
			
			try{
				LOAN.logout();
				WebDr.waitForPageLoaded();
				LOAN.superLogin();
				WebDr.waitForPageLoaded();
				pkgFCRPageObjects.FCR_CIFPageObjects.Cust_Sign_Link_7102();
				WebDr.fastPath(WebDr.getValue("FastPathAuth"));
				WebDr.waitForPageLoaded();
				
				
				WebDr.selectDropValueByVisibleText("ImageType",WebDr.getValue("ImageType"), "Select Image Type");
				WebDr.selectDropValueByVisibleText("SelectionCriteria",WebDr.getValue("SelectionCriteria"), "Select Selection Criteria");
				WebDr.setText("CustomerID", strEnterCustID, "Enter CustomerID");
				WebDr.rTab();
				WebDr.SwitchToLatestWindow();
				WebDr.waitForPageLoaded();
				WebDr.waitForPageLoaded();
				WebDr.waitForPageLoaded();
				WebDr.waitForPageLoaded();
				WebDr.clickactivatewithmouse("SignZoom", "Click on signature window");
				WebDr.CloseWindowWithTitle("Signature");
				WebDr.SwitchToLatestWindow();
				WebDr.click("FastPath", "Click in fastpath field");
				WebDr.clickwithmouse("OK_7102", "Click OK on authorise image page");
				if(WebDr.SwitchToLatestAlertCheck("Image Authorization Successful")){
					HtmlReporter.WriteStep("Check whether the user is able to authorise an image/signature  in the screen 7104.",
						"User should be able to authorise an image/signature to a customer successfully. ",
						"Image Linked and Authorised Successfully. ", true);
				}
				else {
					HtmlReporter.WriteStep("Check whether the user is able to authorise an image/signature  in the screen 7104.",
						"User should be able to authorise an image/signature to a customer successfully. ",
						"Image authorise Unsuccessful. ", false);
				}
				LOAN.logout();	
				LOAN.login();
				WebDr.waitForPageLoaded();
			}catch(Exception errAuth){
				errAuth.printStackTrace();
				HtmlReporter.WriteStep("Check whether the user is able to authorise an image/signature  in the screen 7104.",
						"User should be able to authorise an image/signature to a customer successfully. ",
						"Image Authorised Unsuccessful.", false);
			}
		}
		
		
				
		public static void Customer_MemoMaintenance_CIM13() throws UnhandledAlertException, Exception {
			try{
				pkgFCRPageObjects.FCR_CIFPageObjects.Customer_MemoMaintenance_CIM13();
				WebDr.fastPath(WebDr.getValue("FastPath"));
				WebDr.waitForPageLoaded();
				
				 switch(WebDr.getValue("Action")){
                 case "Add":
	               	  try{
		               		WebDr.click("MemoAdd", "Click on ADD radio button");
		    				WebDr.waitForPageLoaded();
		    				WebDr.click("Clear_CIM13", "Click on Clear button");
		    				WebDr.waitForPageLoaded();
		    				WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"), "Select Search Criteria");
		    				WebDr.waitForPageLoaded();
		    				WebDr.setText("CustomerSearchString", WebDr.getValue("SearchString"), "Enter Search String");
		    				WebDr.rTab();
		    				WebDr.SwitchToLatestWindow();
		    				WebDr.waitForPageLoaded();
		    				WebDr.rTab();
		    				WebDr.rTab();
		    				WebDr.rEnter();
		    				//WebDr.waitForPageLoaded();
		    				WebDr.SwitchToLatestWindow();
		    				//WebDr.clickwithmouse("MemoReason", "Click on customer search field");
		    				WebDr.clickAlwaysPartialImageSikuli("CustMemoReason.PNG", 5, 0.9, "Click on memo");
		    				WebDr.clickAlwaysPartialImageSikuli("MemoCIM13.PNG", 5, 0.9, "Click on memo");
		//    				WebDr.rDown();
		//    				WebDr.rEnter();
		    				WebDr.click("FastPath", "Click on FastPath");
		    				//WebDr.clickAlwaysImageSikuli("MemoCIM13.PNG", 5, "Click on memo");
		    				//WebDr.waitForPageLoaded();
		    				//WebDr.selectDropValueByVisibleText("MemoReason", WebDr.getValue("MemoReason"), "Select Memo Reason");
		    				WebDr.waitForPageLoaded();
		//    				String strCustID = WebDr.getTextBoxValue("LabelCustID", "Get Value");
		//    				if (strCustID.isEmpty()){
		//    					HtmlReporter.WriteStep("Search Customer", "User should be able to search customer details in 1000 with the help of the customer id.",  "Customer Search unsuccessful: " ,false);
		//    					return;
		//    				}
		    				WebDr.selectDropValueByVisibleText("MemoSeverity", WebDr.getValue("MemoSeverity"), "Select Memo Severity");
		    				WebDr.waitForPageLoaded();
		    				WebDr.click("MemoText", "Click on Memo text box");
		    				WebDr.setText("MemoText", WebDr.getValue("MemoText"), "Enter Memo Text");
		    				WebDr.click("OK_CIM33", "Click on OK button");
		    				WebDr.waitForPageLoaded();
		    				WebDr.authOnlyCreds();
		    				if (WebDr.SwitchToLatestAlertCheck("Record Authorized")){
		    					HtmlReporter.WriteStep("Check whether the user is able to add a new memo for a customer or not in FP CIM13.", "User should be able to add memo for a customer in CIM13.",  "Customer memo added successfully" ,true);	
		    				}
		    				else{
		    				WebDr.alertAccept();
		    				HtmlReporter.WriteStep("Check whether the user is able to add a new memo for a customer or not in FP CIM13.", "User should be able to add memo for a customer in CIM13.",  "Customer memo added unsuccessful" ,false);
		    				}
		               	}catch(Exception e1){
		               		  e1.printStackTrace();
		               		  HtmlReporter.WriteStep("Check whether the user is able to add a new memo for a customer or not in FP CIM13.", "User should be able to add memo for a customer in CIM13.",  "Customer memo added unsuccessful" ,false);
	               		 }
               	  break;
               	  
                 case "Delete":
                	try{
                	 	WebDr.click("MemoDelete", "Click on Delete radio button");
	    				WebDr.waitForPageLoaded();
	    				WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"), "Select Search Criteria");
	    				WebDr.waitForPageLoaded();
	    				WebDr.setText("CustomerSearchString", WebDr.getValue("SearchString"), "Enter Search String");
	    				WebDr.rTab();
	    				WebDr.SwitchToLatestWindow();
	    				WebDr.waitForPageLoaded();
	    				WebDr.rTab();
	    				WebDr.rTab();
	    				WebDr.rEnter();
	    				
	    				if (WebDr.alertClickWithText("not exist"))
	    					throw new Exception();
	    				
	    				WebDr.SwitchToLatestWindow();
	    				WebDr.click("FastPath", "Click on FastPath");
	    				
	    				if (WebDr.strFCRCountry.equals("BBK")){
	    					WebDr.clickwithmouse("OK_CIM13", "Click on OK button");
	    					WebDr.SwitchToLatestAlertCheck("Record Deleted");
	    					LOAN.logout();
	    					LOAN.launch();
	    					WebDr.waitForPageLoaded();
	    					LOAN.superLogin();
	    					WebDr.waitForPageLoaded();
	    					pkgFCRPageObjects.FCR_CIFPageObjects.Customer_MemoMaintenance_CIM13();
	    					WebDr.fastPath(WebDr.getValue("FastPath"));
	    					WebDr.waitForPageLoaded();
	    					WebDr.click("MemoAuth","Select Authorise radio button");
	    					WebDr.waitForPageLoaded();
	    					WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"), "Select Search Criteria");
		    				WebDr.waitForPageLoaded();
		    				WebDr.setText("CustomerSearchString", WebDr.getValue("SearchString"), "Enter Search String");
		    				WebDr.rTab();
		    				WebDr.SwitchToLatestWindow();
		    				WebDr.waitForPageLoaded();
		    				WebDr.rTab();
		    				WebDr.rTab();
		    				WebDr.rEnter();
		    				
		    				if (WebDr.alertClickWithText("not exist"))
		    					throw new Exception();
		    				
		    				WebDr.SwitchToLatestWindow();
		    				WebDr.clickwithmouse("OK_CIM13", "Click on OK button");
	    						    					
	    					if (WebDr.SwitchToLatestAlertCheck("Record Authorized")){
		    					HtmlReporter.WriteStep("Check whether the user is able to delete memo for a customer or not in FP CIM13.", "User should be able to delete memo for a customer in CIM13.",  "Customer memo deleted successfully" ,true);	
		    				}
		    				else{
			    				WebDr.alertAccept();
			    				HtmlReporter.WriteStep("Check whether the user is able to delete memo a new memo for a customer or not in FP CIM13.", "User should be able to delete memo for a customer in CIM13.",  "Customer memo deletion unsuccessful" ,false);
		    				}
	    					
	    					LOAN.logout();	
	    					LOAN.launch();
	    					LOAN.login();
	    				}
	    				else{
		    				WebDr.clickwithmouse("OK_CIM13", "Click on OK button");
		    				WebDr.authOnlyCreds();
	    				
		    				if (WebDr.SwitchToLatestAlertCheck("Record Authorized")){
		    					HtmlReporter.WriteStep("Check whether the user is able to delete memo for a customer or not in FP CIM13.", "User should be able to delete memo for a customer in CIM13.",  "Customer memo deleted successfully" ,true);	
		    				}
		    				else{
			    				WebDr.alertAccept();
			    				HtmlReporter.WriteStep("Check whether the user is able to delete memo a new memo for a customer or not in FP CIM13.", "User should be able to delete memo for a customer in CIM13.",  "Customer memo deletion unsuccessful" ,false);
		    				}
	    				}
	                }catch(Exception e1){
	            		  HtmlReporter.WriteStep("Check whether the user is able to delete memo a new memo for a customer or not in FP CIM13.", "User should be able to delete memo for a customer in CIM13.",  "Customer memo deletion unsuccessful" ,false);
	            		  if (WebDr.strFCRCountry.equals("BBK")){
		            		  LOAN.logout();
		            		  LOAN.launch();
		      				  LOAN.login();
	      				  }
	      				 e1.printStackTrace();
            		}
                	 
                	 break;
                	 
                 case "Modify":
                 	try{
                 	 	WebDr.click("MemoModify", "Click on Modify radio button");
 	    				WebDr.waitForPageLoaded();
 	    				WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"), "Select Search Criteria");
 	    				WebDr.waitForPageLoaded();
 	    				WebDr.setText("CustomerSearchString", WebDr.getValue("SearchString"), "Enter Search String");
 	    				WebDr.rTab();
 	    				WebDr.SwitchToLatestWindow();
 	    				WebDr.waitForPageLoaded();
 	    				WebDr.rTab();
 	    				WebDr.rTab();
 	    				WebDr.rEnter();
 	    				
 	    				if (WebDr.alertClickWithText("not exist"))
 	    					throw new Exception();
 	    				
 	    				WebDr.SwitchToLatestWindow();
 	    				String timestmp =  WebDr.getTimeStamp();
 	    				System.out.println("timestamp " + timestmp);
 	    				WebDr.rClearUpdateTextField("MemoTextArea", "Memo updated on " + timestmp, "Modify Memo description");
 	    				WebDr.click("FastPath", "Click on FastPath");
 	    				
 	    				if (WebDr.strFCRCountry.equals("BBK")){
 	    					WebDr.clickwithmouse("OK_CIM13", "Click on OK button");
 	    					WebDr.SwitchToLatestAlertCheck("Record Modified");
 	    					LOAN.logout();
 	    					LOAN.launch();
 	    					WebDr.waitForPageLoaded();
 	    					LOAN.superLogin();
 	    					WebDr.waitForPageLoaded();
 	    					pkgFCRPageObjects.FCR_CIFPageObjects.Customer_MemoMaintenance_CIM13();
 	    					WebDr.fastPath(WebDr.getValue("FastPath"));
 	    					WebDr.waitForPageLoaded();
 	    					WebDr.click("MemoAuth","Select Authorise radio button");
 	    					WebDr.waitForPageLoaded();
 	    					WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"), "Select Search Criteria");
 		    				WebDr.waitForPageLoaded();
 		    				WebDr.setText("CustomerSearchString", WebDr.getValue("SearchString"), "Enter Search String");
 		    				WebDr.rTab();
 		    				WebDr.SwitchToLatestWindow();
 		    				WebDr.waitForPageLoaded();
 		    				WebDr.rTab();
 		    				WebDr.rTab();
 		    				WebDr.rEnter();
 		    				
 		    				if (WebDr.alertClickWithText("not exist"))
 		    					throw new Exception();
 		    				
 		    				WebDr.SwitchToLatestWindow();
 		    				WebDr.clickwithmouse("OK_CIM13", "Click on OK button");
 	    						    					
 	    					if (WebDr.SwitchToLatestAlertCheck("Record Authorized")){
 		    					HtmlReporter.WriteStep("Check whether the user is able to modify memo for a customer or not in FP CIM13.", "User should be able to modify memo for a customer in CIM13.",  "Customer memo modified successfully" ,true);	
 		    				}
 		    				else{
 			    				WebDr.alertAccept();
 			    				HtmlReporter.WriteStep("Check whether the user is able to modify memo a new memo for a customer or not in FP CIM13.", "User should be able to modify memo for a customer in CIM13.",  "Customer memo deletion unsuccessful" ,false);
 		    				}
 	    					
 	    					LOAN.logout();	
 	    					LOAN.launch();
 	    					LOAN.login();
 	    				}
 	    				else{
 		    				WebDr.clickwithmouse("OK_CIM13", "Click on OK button");
 		    				WebDr.authOnlyCreds();
 	    				
 		    				if (WebDr.SwitchToLatestAlertCheck("Record Authorized")){
 		    					HtmlReporter.WriteStep("Check whether the user is able to modify memo for a customer or not in FP CIM13.", "User should be able to modify memo for a customer in CIM13.",  "Customer memo modified successfully" ,true);	
 		    				}
 		    				else{
 			    				WebDr.alertAccept();
 			    				HtmlReporter.WriteStep("Check whether the user is able to modify memo for a customer or not in FP CIM13.", "User should be able to modify memo for a customer in CIM13.",  "Customer memo modified unsuccessful" ,false);
 		    				}
 	    				}
 	                }catch(Exception e1){
 	            		  HtmlReporter.WriteStep("Check whether the user is able to modify memo for a customer or not in FP CIM13.", "User should be able to modify memo for a customer in CIM13.",  "Customer memo modified unsuccessful" ,false);
 	            		  if (WebDr.strFCRCountry.equals("BBK")){
 		            		  LOAN.logout();
 		            		  LOAN.launch();
 		      				  LOAN.login();
 	      				  }
 	      				 e1.printStackTrace();
             		}
                 	 
                 	 break;
               	  }
				
			}
			catch(Exception e){
				e.printStackTrace();
				HtmlReporter.WriteStep("Search Customer", "User should be able to search customer details in 1000 with the help of the customer id.",  "Customer Search unsuccessful: "+e.toString(),false);
			}
		}

		public static void Bill_Payment_by_Cheque_6575() throws Exception{
			try{
				pkgFCRPageObjects.FCR_CIFPageObjects.Bill_Payment_by_Cheque_6575();
				WebDr.fastPath(WebDr.getValue("FastPath"));
				WebDr.waitForPageLoaded();
				
				WebDr.selectDropValueByVisibleText("CompanyID",  WebDr.getValue("CompanyID"),  "Select Company ID");
				WebDr.setText("BillNumber",  WebDr.getValue("BillNumber"),  "Enter Bill Number");
				WebDr.alertAccept();
				WebDr.setText("ConsumerNo", WebDr.getValue("ConsumerNo"),  "Enter Consumer number");
				WebDr.selectDropValueByVisibleText("BillCcy", WebDr.getValue("BillCcy"), "Select Bill Currency");
				WebDr.selectDropValueByVisibleText("TxnCcy",  WebDr.getValue("TxnCcy"), "Select Transaction currency");
				WebDr.setText("BillAmount", WebDr.getValue("BillAmount"), "Enter Bill Amount");
				WebDr.rTab();
				if(WebDr.strFCRCountry.equals("BBM"))
				{
				try{
					if (WebDr.isAlertPresent()){
					WebDr.alertAccept();
					WebDr.alertAccept();
					WebDr.alertAccept();
					WebDr.alertAccept();
					}
					}catch(Exception eAlert){
						System.out.println("Error window did not exist");
					}
				}
				else {
				WebDr.setText("ReferenceNo1", WebDr.getValue("ReferenceNo1"), "Enter Reference Number");
				WebDr.setText("ReferenceNo2",  WebDr.getValue("ReferenceNo2"),  "Enter Reference Number");
				WebDr.setText("UserReference", WebDr.getValue("UserReference"),  "Enter User Reference");
				WebDr.clickwithmouse("OK_6575", "Click on OK");
				
				WebDr.waitForPageLoaded();
				WebDr.selectDropValueByVisibleText("ClearingType", WebDr.getValue("ClearingType"), "Select Clearing Type");
				WebDr.rTab();
				WebDr.setText("ChqNo", WebDr.getValue("ChqNo"), "Enter Chq No");
				WebDr.selectDropValueByVisibleText("ChqLiteral", WebDr.getValue("ChqLiteral"), "Select Chq Literal");
				WebDr.rTab();
				
				if (! WebDr.getValue("ChqDate").isEmpty())
					WebDr.setText("ChqDate", WebDr.getValue("ChqDate"), "Enter Chq Date");
				
				WebDr.rTab();
				WebDr.setText("ChqRoutingNo", WebDr.getValue("ChqRoutingNo"), "Enter Chq RoutingNo");
				WebDr.rTab();
				WebDr.setText("DraweeAcct", WebDr.getValue("DraweeAcct"), "Enter DraweeAcct");
				WebDr.rTab();
				WebDr.selectDropValueByVisibleText("Commision", WebDr.getValue("Commision"), "Select Commision");
				WebDr.rTab();
				WebDr.clickwithmouse("D_OK", "Click on OK to submit instrument details");
				WebDr.waitForPageLoaded();
				WebDr.clickwithmouse("OK_6575", "Click on OK");
//				WebDr.waitForPageLoaded();
//				WebDr.authWithComment();
//				WebDr.alertClickWithText("Please sell cash to vault");
				if (WebDr.alertHandlingForErrors("Transaction sequence number is","Verify transaction status"))
					HtmlReporter.WriteStep("Bill Payment by Cheque", "User should be able to pay bill in 6575.",  "Bill Payment by Cheque for amount: " +  WebDr.getValue("BillAmount"),true);
				else
					HtmlReporter.WriteStep("Bill Payment by Cheque", "User should be able to pay bill in 6575.",  "Bill Payment unsuccessful by Cheque for amount: " +  WebDr.getValue("BillAmount"),false);
//				try{
//					WebDr.clickAlwaysImageSikuli("NoSuperOKButton.PNG", 5, "Click No Supervisor Logged In");
//				}catch(Exception e){
//					e.printStackTrace();
//				}
				WebDr.waitForPageLoaded();
				WebDr.rEnter();			
			}
			}
			catch(Exception e){
				e.printStackTrace();
				HtmlReporter.WriteStep("Bill Payment by Cheque", "User should be able to pay bill in 6575.",  "Bill Payment by Cheque: "+e.toString(),false);
			}
		}
		
		public static void Customer_Type_MNT_CIM08() throws UnhandledAlertException, Exception{
			pkgFCRPageObjects.FCR_CIFPageObjects.Customer_Type_MNT_CIM08();
			try{
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			WebDr.click("MemoAdd", "Click on Add button");
			WebDr.setText("CustTypeCode", WebDr.getValue("CustTypeCode"), "Enter Customer Type Code");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.setText("CustTypeName", WebDr.getValue("CustTypeName"), "Enter Customer Type Name");
			WebDr.clickwithmouse("CorporateFlag", "Check Corporate");
			WebDr.selectDropValueByVisibleText("IdentificationCriteria", WebDr.getValue("IdentificationCriteria"), "Select Identification Criteria");
			WebDr.clickwithmouse("ExternalValidationCheckBox", "Check External Validation CheckBox");
			WebDr.setText("ExternalValidationDescription", WebDr.getValue("ExternalValidationDescription"), "Enter External Validation Description");
			WebDr.setText("ExternalValidationURL", WebDr.getValue("ExternalValidationURL"), "Enter External Validation URL");
			WebDr.clickwithmouse("TaxCode1", "Click on Tax Code1 button");
			WebDr.SwitchToLatestWindow();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.SwitchToLatestWindow();
			WebDr.clickwithmouse("TaxCode2", "Click on Tax Code2 button");
			WebDr.SwitchToLatestWindow();
			WebDr.waitForPageLoaded();
			WebDr.rTab();
			WebDr.rTab();
			WebDr.rEnter();
			WebDr.waitForPageLoaded();
			WebDr.SwitchToLatestWindow();
			WebDr.clickwithmouse("OK_CIM08", "Click on OK");
			if (WebDr.SwitchToLatestAlertCheck("Record Authorized")){
				HtmlReporter.WriteStep("Check whether the user is able to navigate and add new customer type or not in FP CIM08.", "User should be able to add type in CIM08.",  "Customer type added successfully" ,true);	
			}
			else{
			WebDr.alertAccept();
			HtmlReporter.WriteStep("Check whether the user is able to navigate and add new customer type or not in FP CIM08.", "User should be able to add type in CIM08..",  "Customer type addedunsuccessful" ,false);
			}
			}
			catch(Exception e){
				e.printStackTrace();
				HtmlReporter.WriteStep("Check whether the user is able to navigate and add new customer type or not in FP CIM08.", "User should be able to add type in CIM08..",  "Customer type addedunsuccessful" ,false);
			
			}
		}
			
		public static void Customer_Type_Modify_CIM08() throws UnhandledAlertException, Exception{
			pkgFCRPageObjects.FCR_CIFPageObjects.Customer_Type_MNT_CIM08();
			try{
			WebDr.fastPath(WebDr.getValue("FastPath"));
			WebDr.waitForPageLoaded();
			
			WebDr.click("ModifyBtn", "Click on Modify button");
			WebDr.setText("CustTypeCode", WebDr.getValue("CustTypeCode"), "Enter Customer Type Code");
			WebDr.rTab();
			WebDr.waitForPageLoaded();
			WebDr.click("ExternalValidationDescription", "Click on Modify button");
			WebDr.rClearUpdateTextField("ExternalValidationDescription", WebDr.getValue("ExternalValidationDescriptionupdate"), "Enter External Validation Description");
			WebDr.click("ExternalValidationURL", "Click on Modify button");
			WebDr.rClearUpdateTextField("ExternalValidationURL", WebDr.getValue("ExternalValidationURLupdate"), "Enter External Validation URL");
			WebDr.clickwithmouse("OK_CIM08", "Click on OK");
			if (WebDr.SwitchToLatestAlertCheck("Record Authorized")){
				HtmlReporter.WriteStep("Modify Customer Type", "User should be able to modify customer type in CIM08.",  "Customer type modified successfully" ,true);	
			}
			else{
			WebDr.alertAccept();
			HtmlReporter.WriteStep("Modify Customer Type", "User should be able to Modify type in CIM08..",  "Customer type modified unsuccessful" ,false);
			}
			}
			catch(Exception e){
				e.printStackTrace();
				HtmlReporter.WriteStep("Modify Customer Type", "User should be able to Modify type in CIM08..",  "Customer type modified unsuccessful" ,false);
			
			}
		}
		
		public static void Customer_Type_Invalid_CIM08() throws Exception{
			pkgFCRPageObjects.FCR_CIFPageObjects.Customer_Type_MNT_CIM08();
			try{
				WebDr.fastPath(WebDr.getValue("FastPath"));
				WebDr.waitForPageLoaded();
				WebDr.click("MemoAdd", "Click on Add button");
				WebDr.setText("CustTypeCode", WebDr.getValue("CustTypeCode"), "Enter Customer Type Code");
				WebDr.rTab();
				if (WebDr.SwitchToLatestAlertCheck("Authorized Record Exists")){
					HtmlReporter.WriteStep("Check whether the user is able to input invalid values in the fields on the screen and save or not.", "User should be able to add type in CIM08.",  "Customer type added unsuccessfully" ,true);	
				}
				else{
				WebDr.alertAccept();
				HtmlReporter.WriteStep("Check whether the user is able to input invalid values in the fields on the screen and save or not.", "User should be able to add type in CIM08..",  "Customer type added successful" ,false);
				}
				}
				catch(Exception e){
					e.printStackTrace();
					HtmlReporter.WriteStep("Check whether the user is able to input invalid values in the fields on the screen and save or not.", "User should be able to add type in CIM08..",  "Customer type added successful" ,false);
				
				}
		}
		
		public static void View_Signature_Image_7102() throws Exception{
            
            	try{
    				pkgFCRPageObjects.FCR_CIFPageObjects.Cust_Sign_Link_7102();
    				WebDr.fastPath(WebDr.getValue("FastPath"));
    				WebDr.waitForPageLoaded();
    				WebDr.selectDropValueByVisibleText("ImageType",  WebDr.getValue("ImageType"),  "Select Image Type");
    				WebDr.selectDropValueByVisibleText("SelectionCriteria",  WebDr.getValue("SelectionCriteria"),  "Select Selection Criteria");
    				WebDr.setText("CustomerID", WebDr.getValue("CustomerID"), "Enter Customer ID");
    				WebDr.clickwithmouse("OK_7102", "Click on OK");
    				WebDr.SwitchToLatestWindow();
    				WebDr.waitForPageLoaded();
    				if(WebDr.isElementExist("SignZoom", "Signature Window element exists"))
    				{
    				HtmlReporter.WriteStep("Check whether user is able to navigate through 7102 and view signature image ", "User should be able to navigate through 7102 and view signature image",  "View Signature Image  ",true);
    				WebDr.CloseWindowWithTitle("Signature/Image");

    				}
    				WebDr.clickwithmouse("CLOSE_7102", "Click on CLOSE");
    			}
    			catch(Exception e){
    				e.printStackTrace();
    				HtmlReporter.WriteStep("Check whether user is able to navigate through 7102 and view signature image", "User should not be able to navigate through 7102 and view signature image",  "View Signature Image ",false);
    			}
     }
		
		public static void Customer_Relation_Modify_CI141() throws Exception,UnhandledAlertException{
            try{
                  pkgFCRPageObjects.FCR_CIFPageObjects.Customer_Relation_CI141();
                  WebDr.fastPath(WebDr.getValue("FastPath"));
                  WebDr.waitForPageLoaded();
                  WebDr.click("Modify_CI141", "Click on Modify");
                  WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"), "Select search criteria");
                  WebDr.setText("SearchString", WebDr.getValue("SearchString"), "Enter search string");
                  WebDr.rTab();
                  WebDr.waitForPageLoaded();
                  WebDr.SwitchToLatestWindow();
                  WebDr.rTab();
                  WebDr.rTab();
                  WebDr.rEnter();
                  WebDr.SwitchToLatestWindow();
                  WebDr.waitForPageLoaded();
                  WebDr.rEnter();
                  WebDr.clearMethod("Inversion_Relation_Code");
                  WebDr.setText("Inversion_Relation_Code", WebDr.getValue("Inversion_Relation_Code"), "Enter Inversion Relation code");
                  WebDr.clearMethod("Share_Holding_Percent");
                  WebDr.setText("Share_Holding_Percent", WebDr.getValue("Share_Holding_Percent"), "Enter Share Holding Percentage");
                  WebDr.clickwithmouse("OK_CI141", "Click on OK");
                  //WebDr.alertAccept();
                  if(WebDr.alertClickWithText("Record Authorized")){
                         HtmlReporter.WriteStep("Chech whether the user is able to modify the  Relation in FP141", "User should be able to Modify realtion in CI141.",  "Share Percentage of Record Modified Successfully" ,true);    
                  }
                  else{
                  WebDr.alertAccept();
                  HtmlReporter.WriteStep("Chech whether the user is able to modify the  Relation in FP141", "User should not able to Modify realtion in CI141.",  "Record Modification Unsuccessfull" ,false);
                  }
                  WebDr.clickwithmouse("CLOSE_CI141", "Click on OK");
            }
                  catch(Exception e){
                         e.printStackTrace();
                         HtmlReporter.WriteStep("Check whether the user is able to modify  the records in transaction or not", "User is able to modify  the records in transactioNS",  "Record modified Succesfully",false);
                  }
            }      

		
		public static void Customer_Relation_Delete_CI141() throws Exception,UnhandledAlertException{
            try{
                  pkgFCRPageObjects.FCR_CIFPageObjects.Customer_Relation_CI141();
                  WebDr.fastPath(WebDr.getValue("FastPath"));
                  WebDr.waitForPageLoaded();
                  WebDr.click("Delete_CI141", "Click on Delete");
                  WebDr.selectDropValueByVisibleText("SearchCriteria", WebDr.getValue("SearchCriteria"), "Select search criteria for deleteing the Record");
                  WebDr.setText("SearchString", WebDr.getValue("SearchString"), "Enter search string for deleting the record");
                  WebDr.rTab();
                  WebDr.waitForPageLoaded();
                  WebDr.SwitchToLatestWindow();
                  WebDr.rTab();
                  WebDr.rTab();
                  WebDr.rEnter();
                  WebDr.SwitchToLatestWindow();
                  WebDr.waitForPageLoaded();
                  //WebElement wbDocs = Driver.driver.findElement(By.xpath(".//table[@id='fgdetails']/tbody"));
                  //List obCellDatatr = wbDocs.findElements(By.tagName("tr"));
                  //int introws = obCellDatatr.size();
                  //System.out.println("********************Records in table - "+introws);
                  WebDr.rEnter();
                  WebDr.clickwithmouse("OK_CI141", "Click on OK");
                  //WebDr.alertAccept();
                  if(WebDr.alertClickWithText("Record Authorized")){
                         HtmlReporter.WriteStep("Chech whether the user is able to Delete the  Records in FP141", "User should be able to delete the records in CI141.",  "Record Deelted Successfully" ,true);       
                  }
                  else{
                  WebDr.alertAccept();
                  HtmlReporter.WriteStep("Chech whether the user is able to Delete the Records in FP141", "User should not able to Delete realtion in CI141.",  "Record not deleted" ,false);
                  }
            
            }
                  catch(Exception e){
                         e.printStackTrace();
                         HtmlReporter.WriteStep("Check whether the user is able to Delete the records in transaction or not", "User is able to  Delete the records in transactioNS",  "Record  Deleted Succesfully",false);
                  }
            }      

}



